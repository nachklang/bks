# Distributed Task Scheduler — System Design

> Interview prep document. Covers requirements, capacity, architecture, workflows, failure modes, and trade-offs.

---

## Table of Contents

1. [Problem Statement](#1-problem-statement)
2. [Functional Requirements](#2-functional-requirements)
3. [Non-Functional Requirements](#3-non-functional-requirements)
4. [Capacity Estimation](#4-capacity-estimation)
5. [API Design](#5-api-design)
6. [Data Models](#6-data-models)
7. [High-Level Architecture](#7-high-level-architecture)
8. [Component Deep Dive](#8-component-deep-dive)
9. [Workflows & Sequence Diagrams](#9-workflows--sequence-diagrams)
10. [Scheduling Algorithms](#10-scheduling-algorithms)
11. [Failure Modes & Mitigations](#11-failure-modes--mitigations)
12. [Scalability & Bottlenecks](#12-scalability--bottlenecks)
13. [Key Trade-offs](#13-key-trade-offs)

---

## 1. Problem Statement

Design a **distributed task scheduler** that allows clients to submit tasks (one-time or recurring) to be executed at a specified time or on a cron-like schedule. The system must reliably execute tasks exactly once, handle failures gracefully, and scale horizontally to millions of tasks per day.

**Real-world analogues:** AWS EventBridge Scheduler, Airflow, Celery Beat, Quartz Scheduler, GitHub Actions scheduled workflows.

---

## 2. Functional Requirements

### Core

| # | Requirement |
|---|-------------|
| FR-1 | Submit a **one-time task** to execute at a specific timestamp |
| FR-2 | Submit a **recurring task** using cron expression (e.g., `0 9 * * MON`) |
| FR-3 | Cancel a pending or recurring task by ID |
| FR-4 | Pause / resume a recurring task |
| FR-5 | Query task status: `PENDING`, `RUNNING`, `SUCCEEDED`, `FAILED`, `CANCELLED` |
| FR-6 | Retry failed tasks with configurable backoff and max attempts |
| FR-7 | Execute tasks with **at-least-once** delivery guarantee (idempotent tasks) |
| FR-8 | Support task **priorities** (HIGH, MEDIUM, LOW) |
| FR-9 | Support task **dependencies** — task B runs only after task A completes |
| FR-10 | Deliver execution result/output back to the caller (via callback URL or polling) |

### Nice-to-Have

| # | Requirement |
|---|-------------|
| FR-11 | Rate limiting per client / tenant |
| FR-12 | Task timeouts — kill a task that runs longer than `max_duration_seconds` |
| FR-13 | DAG-based workflows (chains of dependent tasks) |
| FR-14 | Dead-letter queue for tasks that exhaust all retries |

---

## 3. Non-Functional Requirements

| Category | Requirement |
|----------|-------------|
| **Reliability** | Tasks must fire within ±5 seconds of their scheduled time (P99) |
| **Durability** | Zero task loss — persist every task before acknowledging the client |
| **Availability** | 99.99% uptime for the scheduling plane; no single point of failure |
| **Scalability** | Support 10 M tasks/day (~115 tasks/sec average, 1 000 tasks/sec peak) |
| **Consistency** | A task must run **at most once** per trigger (prefer at-least-once + idempotency keys) |
| **Observability** | Full audit log of task lifecycle events; distributed tracing |
| **Security** | mTLS between internal services; tenant isolation; secrets never stored in task payload |
| **Latency** | Task submission API: P99 < 200 ms |
| **Fault tolerance** | Tolerate loss of any single node/zone without task loss or duplicate execution |

---

## 4. Capacity Estimation

```
Tasks submitted per day       : 10,000,000
Average task payload size     : 2 KB
Peak QPS (submission)         : 1,000 req/s
Peak QPS (execution triggers) : 1,000 tasks/s

Storage per task record       : ~2 KB (payload) + 0.5 KB (metadata) = 2.5 KB
Tasks retained for 90 days    : 10M × 90 × 2.5 KB ≈ 2.25 TB
Write throughput (DB)         : 1,000 writes/s × 2.5 KB ≈ 2.5 MB/s
Read throughput (polling)     : ~5,000 reads/s (assume 5× reads per write)

Message broker throughput     : 1,000 messages/s × 2 KB ≈ 2 MB/s
Worker pool size              : assuming 500 ms avg task duration →
                                1,000 tasks/s × 0.5 s = 500 concurrent workers needed
```

---

## 5. API Design

### Submit Task

```
POST /v1/tasks
Authorization: Bearer <token>

{
  "name": "send-weekly-report",
  "schedule": {
    "type": "cron",          // "once" | "cron"
    "cron_expr": "0 9 * * MON",
    "timezone": "America/New_York",
    "start_at": "2026-01-01T00:00:00Z",  // optional
    "end_at":   "2026-12-31T23:59:59Z"   // optional
  },
  "job": {
    "type": "http",          // "http" | "grpc" | "lambda" | "script"
    "endpoint": "https://internal.svc/reports/generate",
    "method": "POST",
    "headers": { "X-Tenant": "acme" },
    "body": "{\"format\":\"pdf\"}",
    "timeout_seconds": 30
  },
  "retry_policy": {
    "max_attempts": 3,
    "backoff": "exponential",   // "fixed" | "exponential"
    "initial_delay_seconds": 5,
    "max_delay_seconds": 300
  },
  "priority": "HIGH",
  "idempotency_key": "report-2026-W01",
  "callback_url": "https://client.example.com/hooks/task-done"
}

Response 201:
{
  "task_id": "tsk_9xKjv2mPqL",
  "status": "SCHEDULED",
  "next_run_at": "2026-01-05T14:00:00Z"
}
```

### Other Endpoints

```
GET    /v1/tasks/{task_id}              — get task + latest execution
GET    /v1/tasks/{task_id}/executions   — execution history (paginated)
DELETE /v1/tasks/{task_id}              — cancel (soft delete)
PATCH  /v1/tasks/{task_id}             — update schedule/policy
POST   /v1/tasks/{task_id}/pause        — pause recurring task
POST   /v1/tasks/{task_id}/resume       — resume recurring task
POST   /v1/tasks/{task_id}/trigger      — manually trigger now
GET    /v1/tasks?status=FAILED&page=2   — list/filter tasks
```

---

## 6. Data Models

### tasks table (PostgreSQL / CockroachDB)

```sql
CREATE TABLE tasks (
  task_id          TEXT        PRIMARY KEY,         -- "tsk_..."
  tenant_id        TEXT        NOT NULL,
  name             TEXT        NOT NULL,
  status           TEXT        NOT NULL,            -- ACTIVE | PAUSED | CANCELLED
  schedule_type    TEXT        NOT NULL,            -- once | cron
  cron_expr        TEXT,
  timezone         TEXT        NOT NULL DEFAULT 'UTC',
  next_run_at      TIMESTAMPTZ NOT NULL,            -- indexed — critical for polling
  start_at         TIMESTAMPTZ,
  end_at           TIMESTAMPTZ,
  job_config       JSONB       NOT NULL,
  retry_policy     JSONB       NOT NULL,
  priority         TEXT        NOT NULL DEFAULT 'MEDIUM',
  idempotency_key  TEXT,
  callback_url     TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_tasks_next_run ON tasks (next_run_at) WHERE status = 'ACTIVE';
CREATE UNIQUE INDEX idx_tasks_idempotency ON tasks (tenant_id, idempotency_key)
  WHERE idempotency_key IS NOT NULL;
```

### executions table

```sql
CREATE TABLE executions (
  execution_id   TEXT        PRIMARY KEY,
  task_id        TEXT        NOT NULL REFERENCES tasks(task_id),
  tenant_id      TEXT        NOT NULL,
  attempt        INT         NOT NULL DEFAULT 1,
  status         TEXT        NOT NULL,   -- PENDING | RUNNING | SUCCEEDED | FAILED | TIMED_OUT
  scheduled_at   TIMESTAMPTZ NOT NULL,
  started_at     TIMESTAMPTZ,
  finished_at    TIMESTAMPTZ,
  worker_id      TEXT,
  result_code    INT,
  result_body    TEXT,
  error_message  TEXT,
  lease_token    TEXT,                   -- for distributed locking
  lease_expires  TIMESTAMPTZ
);

CREATE INDEX idx_executions_task ON executions (task_id, scheduled_at DESC);
CREATE INDEX idx_executions_status ON executions (status, lease_expires)
  WHERE status = 'RUNNING';
```

---

## 7. High-Level Architecture

```mermaid
graph TB
    subgraph Clients
        C1[Web App]
        C2[Backend Service]
        C3[CI/CD System]
    end

    subgraph API Layer
        AG[API Gateway<br/>Rate Limiting · Auth · TLS]
        TS[Task Service<br/>REST API]
    end

    subgraph Scheduling Plane
        SC[Scheduler Service<br/>Leader + Followers]
        ZK[(ZooKeeper / etcd<br/>Leader Election)]
    end

    subgraph Message Broker
        MQ[(Kafka / SQS<br/>Priority Queues)]
    end

    subgraph Execution Plane
        WM[Worker Manager<br/>Auto-scaling]
        W1[Worker Node 1]
        W2[Worker Node 2]
        W3[Worker Node N]
    end

    subgraph Storage
        PG[(PostgreSQL<br/>Tasks · Executions)]
        RD[(Redis<br/>Cache · Leases · Rate Limits)]
        DLQ[(Dead Letter Queue)]
    end

    subgraph Observability
        PR[Prometheus]
        GR[Grafana]
        JG[Jaeger Tracing]
        ELK[ELK Stack<br/>Audit Logs]
    end

    subgraph Notification
        NB[Notification Bus]
        WH[Webhook Dispatcher]
    end

    C1 & C2 & C3 --> AG
    AG --> TS
    TS --> PG
    TS --> RD

    SC <--> ZK
    SC --> PG
    SC --> MQ

    MQ --> WM
    WM --> W1 & W2 & W3
    W1 & W2 & W3 --> PG
    W1 & W2 & W3 --> MQ
    W1 & W2 & W3 --> DLQ

    TS & SC & W1 --> PR
    PR --> GR
    TS & SC & W1 --> JG
    TS & SC & W1 --> ELK

    W1 & W2 & W3 --> NB
    NB --> WH
    WH --> C1 & C2 & C3
```

---

## 8. Component Deep Dive

### 8.1 API Gateway

- Terminates TLS, validates JWT/API keys, enforces per-tenant rate limits (Redis token bucket)
- Routes to Task Service, handles circuit breaking

### 8.2 Task Service

- Stateless REST service (horizontally scalable)
- On task submit: validates payload → writes to PostgreSQL (durable) → updates Redis cache → returns `201`
- Computes `next_run_at` from cron expression at write time
- Issues idempotency key deduplication via unique index

### 8.3 Scheduler Service

**The heart of the system.** Runs as a cluster with a single elected leader.

```
Leader responsibilities:
  1. Poll DB every second: SELECT ... WHERE next_run_at <= NOW() AND status='ACTIVE'
  2. For each due task: create execution record + push message to Kafka
  3. Advance next_run_at for recurring tasks (or mark COMPLETED for one-time)
  4. Claim tasks via optimistic locking to avoid duplicate scheduling

Followers:
  - Participate in leader election
  - Serve read traffic (task status queries)
  - Ready to take over within seconds if leader dies
```

**Leader election with etcd:**

```mermaid
sequenceDiagram
    participant S1 as Scheduler-1
    participant S2 as Scheduler-2
    participant ET as etcd

    S1->>ET: Campaign for /scheduler/leader (TTL=10s)
    ET-->>S1: Elected — lease granted
    S1->>ET: KeepAlive every 3s
    Note over S1: Doing scheduling work

    S1--xET: Crash — lease expires after 10s
    S2->>ET: Campaign for /scheduler/leader
    ET-->>S2: Elected
    Note over S2: Takes over scheduling
```

### 8.4 Message Broker (Kafka)

- **Topic per priority:** `tasks.high`, `tasks.medium`, `tasks.low`
- Each topic has N partitions (e.g., 32) for parallel consumption
- Retention: 24 hours (tasks older than that are already handled or dead)
- Messages include: `task_id`, `execution_id`, `scheduled_at`, `job_config`, `attempt`

### 8.5 Worker Nodes

- **Consumer group** per priority tier
- On message receipt:
  1. Acquire distributed lease (Redis `SET NX EX`) for `execution_id`
  2. Update execution status → `RUNNING`
  3. Execute the job (HTTP call, script, etc.)
  4. Update execution status → `SUCCEEDED` or `FAILED`
  5. Release lease
  6. Emit callback event if `callback_url` is set
- Workers are stateless — auto-scaled by Kubernetes HPA based on Kafka consumer lag

### 8.6 Storage

| Store | Role |
|-------|------|
| **PostgreSQL** | Source of truth for tasks and executions. Read replicas for query traffic. |
| **Redis** | Distributed leases, rate limiting counters, task metadata cache (TTL=60s) |
| **Kafka** | Durable task trigger delivery buffer |
| **DLQ (Kafka topic)** | Tasks that failed all retry attempts land here for manual inspection |

---

## 9. Workflows & Sequence Diagrams

### 9.1 Task Submission Flow

```mermaid
sequenceDiagram
    participant CL as Client
    participant AG as API Gateway
    participant TS as Task Service
    participant DB as PostgreSQL
    participant RD as Redis

    CL->>AG: POST /v1/tasks {payload}
    AG->>AG: Authenticate + rate-limit check
    AG->>TS: Forward request

    TS->>DB: Check idempotency_key (SELECT)
    alt Already exists
        DB-->>TS: Existing task record
        TS-->>CL: 200 OK (existing task_id)
    else New task
        TS->>TS: Validate cron / timestamp
        TS->>TS: Compute next_run_at
        TS->>DB: INSERT task (transactional)
        DB-->>TS: Commit OK
        TS->>RD: Cache task metadata (TTL 60s)
        TS-->>AG: 201 Created {task_id, next_run_at}
        AG-->>CL: 201 Created
    end
```

### 9.2 Task Scheduling Flow (Scheduler → Kafka)

```mermaid
sequenceDiagram
    participant SC as Scheduler (Leader)
    participant DB as PostgreSQL
    participant KF as Kafka

    loop Every 1 second
        SC->>DB: SELECT tasks WHERE next_run_at <= NOW()+5s AND status='ACTIVE' LIMIT 500
        DB-->>SC: Due tasks list

        loop For each due task
            SC->>DB: BEGIN TRANSACTION
            SC->>DB: INSERT INTO executions (execution_id, task_id, status='PENDING', ...)
            SC->>DB: UPDATE tasks SET next_run_at = compute_next(...) WHERE task_id = ? AND next_run_at = <old_value>
            Note over SC,DB: Optimistic lock — if 0 rows updated, another scheduler claimed it
            SC->>KF: Produce message to tasks.{priority} topic
            SC->>DB: COMMIT
        end
    end
```

### 9.3 Task Execution Flow (Worker)

```mermaid
sequenceDiagram
    participant KF as Kafka
    participant WK as Worker
    participant RD as Redis
    participant DB as PostgreSQL
    participant EX as External Service
    participant NB as Notification Bus

    KF->>WK: Message {execution_id, task_id, job_config, attempt}
    WK->>RD: SET NX EX 300 lock:exec:{execution_id}
    alt Lock not acquired (duplicate delivery)
        RD-->>WK: NIL
        WK->>KF: Acknowledge (skip — already running)
    else Lock acquired
        RD-->>WK: OK
        WK->>DB: UPDATE executions SET status='RUNNING', worker_id=?, started_at=NOW()
        WK->>EX: Execute job (HTTP/gRPC/script)

        alt Success
            EX-->>WK: 200 OK {result}
            WK->>DB: UPDATE executions SET status='SUCCEEDED', finished_at=NOW(), result_body=?
            WK->>RD: DEL lock:exec:{execution_id}
            WK->>NB: Emit task.succeeded event
            NB-->>Client: POST callback_url {status, result}
        else Failure (retryable)
            EX-->>WK: 500 / timeout
            WK->>DB: UPDATE executions SET status='FAILED', error_message=?
            WK->>WK: Compute backoff delay
            alt Attempts < max_attempts
                WK->>KF: Produce to same priority queue (delayed)
                Note over WK,KF: Kafka delayed delivery or retry topic
            else Exhausted retries
                WK->>KF: Produce to DLQ topic
                WK->>NB: Emit task.dead_lettered event
            end
        end
        WK->>KF: Acknowledge original message
    end
```

### 9.4 Task Cancellation Flow

```mermaid
sequenceDiagram
    participant CL as Client
    participant TS as Task Service
    participant DB as PostgreSQL
    participant RD as Redis
    participant KF as Kafka

    CL->>TS: DELETE /v1/tasks/{task_id}
    TS->>DB: UPDATE tasks SET status='CANCELLED' WHERE task_id=? AND status!='CANCELLED'
    TS->>RD: DEL cache:task:{task_id}
    TS->>RD: SET cancelled:{task_id} = 1 EX 86400

    Note over KF: Message may already be in queue
    Note over Worker: Worker checks Redis cancelled set before executing
    TS-->>CL: 200 OK

    KF->>Worker: Message {execution_id, task_id}
    Worker->>RD: GET cancelled:{task_id}
    alt Cancelled flag set
        RD-->>Worker: 1
        Worker->>DB: UPDATE executions SET status='CANCELLED'
        Worker->>KF: Acknowledge (skip execution)
    end
```

### 9.5 Failure Recovery — Scheduler Crash

```mermaid
sequenceDiagram
    participant SC1 as Scheduler-1 (old leader)
    participant SC2 as Scheduler-2 (new leader)
    participant ET as etcd
    participant DB as PostgreSQL

    SC1--xET: Crash — lease expires (TTL=10s)
    SC2->>ET: Campaign — elected new leader

    Note over SC2: Tasks that were in-flight (PENDING in DB but not yet consumed) are safe — they're in Kafka
    Note over SC2: Tasks scheduled but not yet written to Kafka need recovery

    SC2->>DB: Find executions WHERE status='PENDING' AND scheduled_at < NOW()-30s
    DB-->>SC2: Orphaned executions
    SC2->>DB: Check if message already in Kafka (via offset tracking)
    SC2->>KF: Re-produce missing messages (idempotent: execution_id deduplicates at worker)
```

### 9.6 Worker Crash Mid-Execution (Lease Timeout Recovery)

```mermaid
sequenceDiagram
    participant WK1 as Worker-1 (crashed)
    participant WK2 as Worker-2
    participant RD as Redis
    participant DB as PostgreSQL

    WK1->>DB: UPDATE status='RUNNING', lease_expires=NOW()+300s
    WK1--x Note: Worker crashes

    loop Watchdog (every 30s)
        WK2->>DB: SELECT FROM executions WHERE status='RUNNING' AND lease_expires < NOW()
        DB-->>WK2: Stale execution found
        WK2->>DB: UPDATE SET status='FAILED', error='lease_timeout'
        WK2->>WK2: Check attempt count
        alt Retryable
            WK2->>KF: Re-queue with incremented attempt
        else Max attempts
            WK2->>KF: Send to DLQ
        end
    end
```

---

## 10. Scheduling Algorithms

### 10.1 Poll-based Scheduling (chosen approach)

```
Scheduler polls DB every T seconds (T=1s):
  SELECT * FROM tasks
  WHERE next_run_at <= NOW() + T
    AND status = 'ACTIVE'
  ORDER BY priority DESC, next_run_at ASC
  LIMIT 500
```

**Pros:** Simple, reliable, works with any DB  
**Cons:** DB load, minimum resolution = poll interval

### 10.2 Time-Wheel (in-memory, complementary)

```
Scheduler maintains a circular buffer (wheel) of 3600 slots (one per second for 1 hour).
Tasks due within the hour are loaded from DB into the wheel.
A background thread advances the pointer each second and fires due tasks.

Benefits: microsecond precision, no DB polling for hot tasks
Drawback: state is in-memory → rebuild on restart (re-hydrate from DB)
```

```mermaid
graph LR
    subgraph Time Wheel - 3600 slots
        S0[Slot 0<br/>task-A]
        S1[Slot 1]
        S2[Slot 2<br/>task-B, task-C]
        S3[...]
        S3599[Slot 3599]
    end
    PTR[Current Pointer] --> S0
    S0 -->|fire| KF[(Kafka)]
    S0 -->|advance| S1
```

### 10.3 Cron Expression Parsing

```
Given: "0 9 * * MON"  (9am every Monday)
1. Parse into 5 fields: minute, hour, dom, month, dow
2. Use a library (cronexpr, quartz) to compute next_run_at
3. Store next_run_at in DB — don't re-parse cron on every poll
4. After firing, recompute next_run_at and update DB atomically
```

---

## 11. Failure Modes & Mitigations

```mermaid
graph TD
    subgraph Failure Scenarios
        F1[Scheduler crashes]
        F2[Worker crashes mid-task]
        F3[DB unavailable]
        F4[Kafka unavailable]
        F5[External job endpoint fails]
        F6[Clock skew between nodes]
        F7[Duplicate scheduling]
    end

    F1 -->|Mitigation| M1[Leader election via etcd<br/>New leader elected in < 10s<br/>Re-hydrate from DB]
    F2 -->|Mitigation| M2[Lease timeout watchdog<br/>Re-queue with backoff]
    F3 -->|Mitigation| M3[Read replicas for reads<br/>Retry with backoff<br/>Scheduler pauses — no task loss]
    F4 -->|Mitigation| M4[Kafka replication factor=3<br/>Producer acks=all<br/>Scheduler buffers locally]
    F5 -->|Mitigation| M5[Retry policy + exponential backoff<br/>DLQ after max_attempts]
    F6 -->|Mitigation| M6[NTP sync + use UTC everywhere<br/>Scheduler uses DB server time, not local]
    F7 -->|Mitigation| M7[Optimistic lock on next_run_at<br/>execution_id dedup in Redis]
```

### Failure Mode Matrix

| Failure | Detection | Recovery | Task Loss? |
|---------|-----------|----------|------------|
| Scheduler leader crash | etcd lease expiry (10s) | Follower elected, re-processes due tasks | No |
| Worker crash before ACK | Kafka at-least-once redelivery | Worker picks up again; Redis lock prevents double-run | No |
| Worker crash after ACK, before DB update | Lease timeout watchdog (30s scan) | Re-queued as retry | Possible duplicate result (idempotency key required) |
| DB primary fails | Patroni / AWS RDS failover (~30s) | Scheduler pauses poll; resumes on reconnect | No |
| Kafka broker fails | Kafka replication, auto-leader election | Transparent if RF=3, min-ISR=2 | No |
| All retries exhausted | DLQ | Alert + manual replay or discard | Intentional |

---

## 12. Scalability & Bottlenecks

### Bottleneck Analysis

```mermaid
graph LR
    subgraph Potential Bottlenecks
        B1[DB next_run_at scan<br/>O(active tasks)]
        B2[Scheduler single leader<br/>throughput ceiling]
        B3[Kafka consumer lag<br/>under burst load]
        B4[Worker pool saturation]
    end

    B1 -->|Solution| S1[Partial index on next_run_at<br/>Partition tasks by shard_key<br/>Multiple scheduler shards]
    B2 -->|Solution| S2[Shard task space by tenant or hash<br/>Each shard has own leader]
    B3 -->|Solution| S3[Increase partition count<br/>Add consumer instances<br/>Priority queues separate]
    B4 -->|Solution| S4[K8s HPA on Kafka consumer lag<br/>Pre-scale before known bursts]
```

### Sharding the Scheduler

For very high scale, partition the task namespace:

```
Shard key = hash(task_id) % N_shards

Scheduler-shard-0: owns tasks where hash(task_id) % 4 == 0
Scheduler-shard-1: owns tasks where hash(task_id) % 4 == 1
...

Each shard independently elects a leader via etcd path /scheduler/shard/{n}/leader
DB query adds: WHERE shard_id = ? to the poll
```

### Horizontal Scaling Summary

| Component | Scale Strategy |
|-----------|---------------|
| API Gateway | Stateless — add instances behind load balancer |
| Task Service | Stateless — add instances |
| Scheduler | Sharded leader election — add shards |
| Kafka | Add partitions + brokers |
| Workers | Kubernetes HPA (metric: Kafka consumer lag) |
| PostgreSQL | Read replicas for reads; partitioning by `created_at` for archival |
| Redis | Redis Cluster for horizontal sharding |

---

## 13. Key Trade-offs

### 13.1 At-least-once vs Exactly-once

```
At-least-once (chosen):
  ✅ Simpler to implement
  ✅ Higher throughput
  ❌ Requires workers/jobs to be idempotent
  → Enforce via idempotency_key in API contract

Exactly-once:
  ✅ No duplicate execution risk
  ❌ Requires distributed transactions (2PC) — slow, complex
  ❌ Kafka exactly-once semantics add overhead
  → Not worth it if jobs can be made idempotent
```

### 13.2 Push (Kafka) vs Pull (DB polling only)

```
Push via Kafka (chosen):
  ✅ Workers notified immediately — low latency
  ✅ Durable buffer absorbs spikes
  ✅ Priority lanes easy to implement
  ❌ Extra infrastructure component

Pull (workers poll DB directly):
  ✅ Simpler architecture
  ❌ DB becomes bottleneck at high QPS
  ❌ Hard to implement priorities
  ❌ Polling adds latency
```

### 13.3 DB Choice: PostgreSQL vs Cassandra

```
PostgreSQL (chosen):
  ✅ Strong consistency — safe for scheduler optimistic locking
  ✅ ACID transactions for task + execution atomicity
  ❌ Vertical scale ceiling (mitigated by sharding + read replicas)

Cassandra:
  ✅ Horizontal write scale
  ❌ No transactions — hard to prevent duplicate scheduling
  ❌ LWT (lightweight transactions) for optimistic locking are slow
```

### 13.4 Cron Granularity

```
Minute-level cron (standard):
  ✅ Simple, well-understood
  ❌ Cannot schedule sub-minute intervals

Second-level precision:
  ✅ Fine-grained control
  ❌ 60× more rows processed per minute in DB scan
  → Support both; sub-minute via one-time tasks chained by the client
```

---

## Component Summary Diagram

```mermaid
C4Context
    title Distributed Task Scheduler — Context Diagram

    Person(client, "Client", "Backend service or user submitting tasks")

    System(scheduler, "Distributed Task Scheduler", "Reliably schedules and executes tasks at specified times or on a recurring schedule")

    System_Ext(target, "Target Services", "HTTP endpoints, Lambda functions, or scripts executed by the scheduler")
    System_Ext(monitor, "Monitoring Stack", "Prometheus, Grafana, Jaeger, ELK")

    Rel(client, scheduler, "Submit, cancel, query tasks", "HTTPS/REST")
    Rel(scheduler, target, "Execute jobs", "HTTP/gRPC")
    Rel(scheduler, monitor, "Metrics, traces, logs", "Push/pull")
    Rel(scheduler, client, "Callback notifications", "HTTPS POST")
```

---

## Interview Cheat Sheet

| Question | Answer |
|----------|--------|
| How do you prevent duplicate task execution? | Optimistic lock on `next_run_at` + Redis distributed lease per `execution_id` |
| How do you handle scheduler crash? | etcd leader election; follower takes over in <10s; re-scans DB for missed tasks |
| How do you scale to 1M tasks/s? | Shard task namespace; multiple scheduler leaders; increase Kafka partitions + workers |
| How does retry work? | Worker re-queues to Kafka with incremented attempt; exponential backoff via delayed message |
| What if a worker crashes mid-execution? | Lease timeout watchdog detects stale RUNNING executions and re-queues |
| How do you guarantee task fires within ±5s? | 1s poll interval + time wheel for hot tasks; Kafka delivery latency <1s |
| How do you handle the thundering herd at midnight? | Priority queues smooth burst; HPA pre-scales workers; Kafka buffers overflow |
| What DB indexes are critical? | Partial index on `(next_run_at) WHERE status='ACTIVE'` |
| How do you support task dependencies? | DAG stored in DB; downstream tasks PENDING until upstream SUCCEEDED; scheduler checks deps before enqueuing |
| How do you handle clock skew? | All time stored/compared using DB server time (UTC); NTP enforced on all nodes |
