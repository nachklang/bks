# Мессенджер 1-на-1 — системный дизайн

> Скоуп документа сознательно узкий: только личная переписка один на один. Группы, e2e-шифрование, медиа, поиск — вне рамок (см. раздел 9).

## 1. Функциональные требования

1. **Отправка личных сообщений один на один.** Пользователь отправляет сообщение другому пользователю; сообщение сохраняется и получает уникальный `message_id`.
2. **Доставка онлайн- и офлайн-получателям.** Онлайн-пользователь получает сообщение почти сразу (< 200 мс p50). Офлайн-пользователь получает его при следующем подключении, плюс push-уведомление.
3. **История диалога и статусы.** Открытие чата — cursor-based пагинация. Каждое сообщение проходит через состояния `sent → delivered → read`.

## 2. Нефункциональные требования

| Параметр | Целевое значение | Комментарий |
|---|---|---|
| Задержка доставки (онлайн) | p50 < 150 мс, p99 < 500 мс | пользователь-получатель уже подключён по WebSocket |
| Доставка при переподключении | < 2 с от момента `connect` до получения бэклога | зависит от объёма неприкосланных сообщений |
| Долговечность сообщений | без потерь после ack клиенту | репликация x3 в хранилище |
| Доставка | at-least-once + дедупликация на клиенте/сервере | не exactly-once на транспорте, но идемпотентно по `client_message_id` |
| Порядок сообщений | строгий в рамках одного диалога | гарантируется монотонным `message_id` |
| Доступность | 99.9% | чтение истории может обслуживаться из реплики при деградации |
| Масштаб (ориентир) | 5 млн DAU, ~50 млн сообщений/сутки | ~580 msg/s в среднем, пиковая нагрузка x5–8 |

## 3. Высокоуровневая архитектура

```mermaid
flowchart LR
    subgraph Clients
        A[Клиент A]
        B[Клиент B]
    end

    GW1[WS Gateway]
    GW2[WS Gateway]
    API[REST API<br/>история и авторизация]
    CHAT[Chat Service]
    PRES[(Presence Store<br/>Redis)]
    MSG[(Message Store<br/>Cassandra / ScyllaDB)]
    PUSH[Push Service<br/>APNs / FCM]
    IDEMP[(Idempotency Cache<br/>Redis)]

    A <--> GW1
    B <--> GW2
    A -.history.-> API
    GW1 --> CHAT
    GW2 --> CHAT
    API --> CHAT
    CHAT --> MSG
    CHAT --> PRES
    CHAT --> IDEMP
    CHAT -->|получатель офлайн| PUSH
    CHAT -->|получатель онлайн, найден узел| GW2
```

**Компоненты:**

- **WS Gateway** — держит постоянное соединение с клиентом, stateless по бизнес-логике; при коннекте регистрирует `user_id → node_id` в Presence Store.
- **Chat Service** — генерирует `message_id`, пишет в Message Store, проверяет присутствие получателя, маршрутизирует доставку (WS-пуш или push-уведомление).
- **Message Store** — wide-column хранилище, партиционировано по `conversation_id`, что даёт дешёвую cursor-пагинацию по диалогу.
- **Presence Store** — Redis, `user_id → {node_id, last_seen}`, TTL на онлайн-статус.
- **Idempotency Cache** — Redis `SETNX(client_message_id) → message_id`, TTL ~24 ч, защита от дублей при retry.

## 4. Модель данных

### `messages` (партиция по `conversation_id`)

| Поле | Тип | Комментарий |
|---|---|---|
| `conversation_id` | UUID (partition key) | канонический для пары пользователей, `min(user_id) + max(user_id)` |
| `message_id` | int64 (clustering key, desc) | Snowflake-подобный: `timestamp \| shard \| sequence` — монотонный и сортируемый по времени |
| `client_message_id` | UUID | сгенерирован клиентом, для идемпотентности и optimistic UI |
| `sender_id` | UUID | |
| `body` | text | |
| `created_at` | timestamp | |
| `delivered_at` | timestamp, nullable | заполняется при доставке |
| `read_at` | timestamp, nullable | заполняется при прочтении |

Статус сообщения — производная величина: `read_at ≠ null → read`, иначе `delivered_at ≠ null → delivered`, иначе `sent`. Для 1-на-1 диалога одного получателя достаточно двух полей на строке сообщения — отдельная таблица receipts понадобится только для групп.

### `conversations`

| Поле | Тип | Комментарий |
|---|---|---|
| `conversation_id` | UUID (PK) | |
| `user_a_id`, `user_b_id` | UUID | отсортированная пара — уникальный индекс, чтобы не плодить дубликаты диалога |
| `last_message_id` | int64 | для списка чатов без full scan |

**Почему `message_id`, а не `created_at`, — курсор пагинации:** Snowflake-ID монотонно возрастает и уникален даже при коллизии таймстампов, так что `message_id` одновременно и первичный ключ, и надёжный курсор — не нужен отдельный `(timestamp, tie-breaker)`.

## 5. API

```
POST /v1/messages
  { conversation_id, client_message_id, text }
  → 201 { message_id, status: "sent", created_at }

GET /v1/conversations/{id}/messages?before={message_id}&limit=50
  → 200 { messages: [ {message_id, sender_id, text, created_at, status} ], next_cursor }
```

WebSocket-события (постоянное соединение с Gateway):

```
client → server   message.send   { client_message_id, conversation_id, text }
server → client   message.ack    { client_message_id, message_id, status: "sent" }
server → client   message.new    { message }
client → server   message.delivered_ack { message_id }
client → server   message.read   { conversation_id, up_to_message_id }
server → client   message.status { message_id | range, status: "delivered" | "read" }
```

`POST /v1/messages` — фолбэк-путь для отправки, если клиент временно без WS-соединения; основной путь для realtime — WS-событие `message.send`.

## 6. Сценарий: отправка, получатель онлайн

```mermaid
sequenceDiagram
    participant Sender as Клиент A
    participant GWa as Gateway A
    participant Chat as Chat Service
    participant DB as Message Store
    participant Pres as Presence
    participant GWb as Gateway B
    participant Recv as Клиент B

    Sender->>GWa: message.send(client_id, text)
    GWa->>Chat: forward
    Chat->>Chat: idempotency check (client_id)
    Chat->>DB: persist(message_id, status=sent)
    Chat-->>GWa: ack
    GWa-->>Sender: message.ack (sent)
    Chat->>Pres: lookup(user_B)
    Pres-->>Chat: online @ GWb
    Chat->>GWb: push message.new
    GWb->>Recv: message.new
    Recv-->>GWb: message.delivered_ack
    GWb-->>Chat: delivered_ack
    Chat->>DB: update delivered_at
    Chat-->>GWa: message.status(delivered)
    GWa-->>Sender: тик "доставлено"
```

## 7. Сценарий: получатель офлайн

```mermaid
sequenceDiagram
    participant Sender as Клиент A
    participant Chat as Chat Service
    participant DB as Message Store
    participant Pres as Presence
    participant Push as Push Service
    participant Recv as Клиент B

    Sender->>Chat: message.send
    Chat->>DB: persist(message_id, status=sent)
    Chat-->>Sender: ack (sent)
    Chat->>Pres: lookup(user_B)
    Pres-->>Chat: offline
    Chat->>Push: notify (silent payload, без текста)
    Push-->>Recv: push-уведомление

    Note over Recv: пользователь открывает приложение
    Recv->>Chat: connect(last_synced_message_id)
    Chat->>DB: fetch messages > last_synced
    Chat-->>Recv: message.new (backlog)
    Recv-->>Chat: delivered_ack (batch)
    Chat->>DB: update delivered_at
    Chat-->>Sender: message.status(delivered)
```

Пуш содержит минимальную полезную нагрузку (id диалога, без текста сообщения) — сам текст доставляется только по защищённому WS-соединению при синхронизации, чтобы не оседать в логах push-провайдера.

## 8. Сценарий: история и статусы прочтения

```mermaid
sequenceDiagram
    participant Client as Клиент
    participant API as REST API
    participant Chat as Chat Service
    participant DB as Message Store

    Client->>API: GET /messages?limit=50
    API->>DB: query conversation_id, latest 50
    DB-->>API: messages desc
    API-->>Client: messages + next_cursor

    Note over Client: скролл вверх
    Client->>API: GET /messages?before=next_cursor&limit=50
    API-->>Client: следующая страница

    Note over Client: сообщения видны на экране
    Client->>Chat: message.read(up_to_message_id)
    Chat->>DB: update read_at where message_id <= up_to
    Chat-->>Client: (собеседнику) message.status(read)
```

Пагинация всегда идёт "назад по времени" от `message_id`-курсора — без смещений (`OFFSET`), поэтому не деградирует при глубокой прокрутке и не ломается от новых сообщений, приходящих во время скролла.

## 9. Гарантии доставки и идемпотентность

- Клиент генерирует `client_message_id` (UUID) до отправки и сразу рисует сообщение в UI как "отправляется" — не дожидаясь сети.
- Сервер использует `client_message_id` как ключ идемпотентности: при повторной отправке (обрыв связи, retry) возвращает уже существующий `message_id` вместо создания дубликата.
- Транспорт — at-least-once: WS может доставить событие дважды при реконнекте, это безопасно благодаря дедупликации по `message_id` на клиенте.
- Статус *read* необратим и монотонен: `read_at` не откатывается, повторный `message.read` с меньшим `up_to_message_id` игнорируется.

## 10. Масштабирование

- **Партиционирование:** `messages` шардируется по `conversation_id` — для 1-на-1 чатов нагрузка на партицию естественно ограничена (в отличие от групп/каналов), поэтому проблема "горячих партиций" здесь не встаёт так остро, как в публичных лентах.
- **Gateway** — горизонтально масштабируемый пул stateful-узлов; маршрутизация "к какому узлу подключён пользователь" — через Presence Store (Redis Cluster, консистентное хеширование по `user_id`).
- **Message Store** — Cassandra/ScyllaDB: запись быстрая (append-only по партиции), репликация x3 через кворумную запись (`QUORUM`) для долговечности без потери latency при отказе одной реплики.
- **Push Service** — асинхронный, за очередью (Kafka/SQS), чтобы всплеск офлайн-получателей не блокировал путь записи сообщения.

## 11. Что осознанно не покрыто

Групповые чаты (нужна отдельная модель receipts на получателя), end-to-end шифрование, вложения/медиа, редактирование и удаление сообщений, полнотекстовый поиск по истории — каждое тянет за собой отдельный кусок архитектуры и не входит в заданные три требования.
