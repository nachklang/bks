// string_demo.cxx — что внутри std::string (libstdc++, новый ABI). Снимаем числа с этой машины.
//
// Сборка (флаг -fno-assume-sane-operators-new-delete обязателен для GCC ≥ 15: иначе компилятор
// считает, что заменённый operator new не имеет побочных эффектов, и кэширует наш счётчик):
//   g++ -std=c++20 -Wall -Wextra -O2 -fno-assume-sane-operators-new-delete -o string_demo string_demo.cxx && ./string_demo
// Старый ABI (COW-строка, до GCC 5):
//   g++ -std=c++20 -Wall -Wextra -O2 -D_GLIBCXX_USE_CXX11_ABI=0 -o string_demo_old string_demo.cxx && ./string_demo_old

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <new>
#include <string>
#include <string_view>
#include <utility>

// --- счётчик аллокаций ------------------------------------------------------------
static std::size_t g_allocs = 0, g_bytes = 0;
void* operator new(std::size_t n) {
    ++g_allocs; g_bytes += n;
    if (void* p = std::malloc(n)) return p;
    throw std::bad_alloc();
}
void operator delete(void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }

struct Probe {           // сбросить и показать, сколько аллокаций сделал блок кода
    const char* name; std::size_t a0, b0;
    explicit Probe(const char* n) : name(n), a0(g_allocs), b0(g_bytes) {}
    ~Probe() { std::printf("  %-52s аллокаций: %zu, байт: %zu\n", name, g_allocs - a0, g_bytes - b0); }
};

[[maybe_unused]] static const char* where(const std::string& s) {
    const char* obj = reinterpret_cast<const char*>(&s);
    const char* d   = s.data();
    return (d >= obj && d < obj + sizeof s) ? "внутри объекта (SSO)" : "в куче";
}

int main() {
    std::printf("_GLIBCXX_USE_CXX11_ABI = %d\n", _GLIBCXX_USE_CXX11_ABI);
    std::printf("sizeof(std::string) = %zu, sizeof(std::string_view) = %zu, sizeof(char*) = %zu\n\n",
                sizeof(std::string), sizeof(std::string_view), sizeof(char*));

#if _GLIBCXX_USE_CXX11_ABI
    // 1. Раскладка: указатель, размер, union{ буфер на 16 байт | capacity }
    {
        std::string s = "hi";
        const char* obj = reinterpret_cast<const char*>(&s);
        std::printf("1. раскладка короткой строки \"%s\":\n", s.c_str());
        std::printf("   &s = %p, data() = %p, смещение data() от &s = %td  → %s\n",
                    static_cast<const void*>(obj), static_cast<const void*>(s.data()), s.data() - obj, where(s));
        std::printf("   capacity() = %zu (SSO: буфер 16 байт минус '\\0')\n", s.capacity());
        char* p; std::memcpy(&p, obj, sizeof p);
        std::size_t n; std::memcpy(&n, obj + sizeof p, sizeof n);
        std::printf("   поле [0..8)  указатель  = %p (== data())\n   поле [8..16) size       = %zu\n", static_cast<void*>(p), n);
        std::printf("   поле [16..32) буфер     = \"%s\"\n\n", obj + 16);
    }

    // 2. Длинная строка: тот же union хранит capacity
    {
        std::string s(20, 'x');
        const char* obj = reinterpret_cast<const char*>(&s);
        std::size_t cap; std::memcpy(&cap, obj + 16, sizeof cap);
        std::printf("2. строка из 20 символов: data() %s, capacity() = %zu, поле [16..24) = %zu\n\n",
                    where(s), s.capacity(), cap);
    }
#else
    std::printf("1-2. старый ABI: объект — один указатель на буфер, перед которым лежит заголовок {length, capacity, refcount}\n\n");
#endif

    // 3. Сколько аллокаций стоят типичные операции
    std::printf("3. цена операций\n");
    { Probe p("std::string s;");                          std::string s; (void)s; }
    { Probe p("std::string s = \"123456789012345\" (15)");  std::string s = "123456789012345"; (void)s; }
    { Probe p("std::string s = \"1234567890123456\" (16)"); std::string s = "1234567890123456"; (void)s; }
    { std::string a(100, 'a'); Probe p("копия строки из 100");        std::string b = a; (void)b; }
    { std::string a(100, 'a'); Probe p("move строки из 100");         std::string b = std::move(a); (void)b; }
    { std::string a = "short";  Probe p("move короткой строки");      std::string b = std::move(a); (void)b; }
    { std::string a(100, 'a'); Probe p("substr(0, 10) — короткий");   auto b = a.substr(0, 10); (void)b; }
    { std::string a(100, 'a'); Probe p("string_view(a).substr(0,10)"); auto v = std::string_view(a).substr(0, 10); (void)v; }
    { std::string a(100, 'a'), b(100, 'b'); Probe p("a + b (200)");   auto c = a + b; (void)c; }
    { Probe p("push_back ×1000 без reserve");              std::string s; for (int i = 0; i < 1000; ++i) s.push_back('x'); }
    { Probe p("reserve(1000) + push_back ×1000");          std::string s; s.reserve(1000); for (int i = 0; i < 1000; ++i) s.push_back('x'); }
    { std::string s(1000, 'x'); s.resize(10); Probe p("shrink_to_fit после resize(10)"); s.shrink_to_fit(); }
    { std::string s(1000, 'x'); Probe p("clear() (память не отдаёт)"); s.clear(); std::printf("     capacity после clear = %zu\n", s.capacity()); }
    std::printf("\n");

    // 4. Политика роста capacity
    {
        std::printf("4. рост capacity при push_back: ");
        std::string s; std::size_t last = s.capacity();
        std::printf("%zu", last);
        for (int i = 0; i < 2000; ++i) { s.push_back('x'); if (s.capacity() != last) { last = s.capacity(); std::printf(" → %zu", last); } }
        std::printf("\n   (libstdc++: новая = max(2·старая, нужная); vector — тоже ×2, MSVC — ×1.5)\n\n");
    }

    // 5. Move короткой строки не крадёт буфер — копирует байты
    {
        std::string a = "short";
        const void* before = a.data();
        std::string b = std::move(a);
        std::printf("5. move SSO: data() источника %p, data() приёмника %p — %s; источник после move: \"%s\" (size %zu)\n",
                    before, static_cast<const void*>(b.data()), before == b.data() ? "тот же буфер" : "разные буферы", a.c_str(), a.size());
        std::string c(100, 'c');
        before = c.data();
        std::string d = std::move(c);
        std::printf("   move длинной: %s; источник после move: size %zu, capacity %zu\n\n",
                    before == d.data() ? "буфер украден" : "буфер скопирован", c.size(), c.capacity());
    }

    // 6. Инвалидация: data()/c_str()/итераторы живут до следующей реаллокации
    {
        std::string s = "123456789012345";          // ровно 15 — ещё SSO
        const char* p = s.data();
        s.push_back('6');                            // 16 — переезд в кучу
        std::printf("6. после push_back за пределы SSO data() %s\n", p == s.data() ? "не изменился" : "изменился — старый указатель мёртв");
        std::string_view v = std::string("временная").substr(0, 3);   // string_view на уничтоженную временную
        std::printf("   string_view на temp: UB, тут выведет мусор или случайно \"врем\": (не печатаем)\n\n"); (void)v;
    }

    // 7. Старый ABI: COW. Проверить сборкой с -D_GLIBCXX_USE_CXX11_ABI=0.
    //    Важно as_const: в C++17 неконстантный data() обязан «отцепить» буфер (unshare), иначе COW бы не увидели.
    {
        std::string a(100, 'a');
        std::string b = a;
        std::printf("7. копия: const data() %s (COW = общий буфер до первой записи; в новом ABI копия всегда глубокая)\n",
                    std::as_const(a).data() == std::as_const(b).data() ? "ОБЩИЙ" : "разные");
        b[0] = 'B';
        std::printf("   после b[0]='B': data() %s\n", std::as_const(a).data() == std::as_const(b).data() ? "общий" : "разные");
    }
    return 0;
}
