// Рабочий пример mmap: файл тиков, запись через MAP_SHARED, анонимная разделяемая
// память между процессами. Разбор — в doc/01-general-topics/11-mmap-and-memory-mapped-files.md
//
// Сборка:
//   g++ -std=c++20 -Wall -Wextra -O2 -o mmap_demo mmap_demo.cxx && ./mmap_demo
//   g++ -std=c++20 -g -fsanitize=address,undefined -o mmap_demo_asan mmap_demo.cxx && ./mmap_demo_asan

#include <fcntl.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

#include <atomic>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <new>
#include <numeric>
#include <stdexcept>
#include <vector>
#include <random>
#include <string>
#include <system_error>
#include <utility>

namespace {

// Запись рыночных данных. Цена — fixed-point (1e-4), не double: см. раздел 1.9.
struct Tick
{
    std::uint64_t ts_ns;
    std::int64_t  px;
    std::uint32_t qty;
    char          side;      // 'B' / 'S'
    char          _pad[3];
};
static_assert(sizeof(Tick) == 24, "layout должен быть стабильным: файл читают другие процессы");
static_assert(alignof(Tick) == 8);

[[noreturn]] void fail(const char* what)
{
    throw std::system_error(errno, std::generic_category(), what);
}

// --- RAII-обёртка -------------------------------------------------------------
// Владеет отображением, не файловым дескриптором: после mmap ядро держит на файл
// собственную ссылку, поэтому fd закрывается сразу и мапинг это переживает.
class MappedFile
{
public:
    MappedFile(const char* path, bool writable)
    {
        const int fd = ::open(path, writable ? O_RDWR : O_RDONLY);
        if (fd < 0)
            fail("open");

        struct stat st{};
        if (::fstat(fd, &st) != 0)
        {
            ::close(fd);
            fail("fstat");
        }
        size_ = static_cast<std::size_t>(st.st_size);

        // mmap длины 0 — это EINVAL. Пустой файл обрабатываем отдельно.
        if (size_ != 0)
        {
            void* p = ::mmap(nullptr,
                             size_,
                             writable ? (PROT_READ | PROT_WRITE) : PROT_READ,
                             writable ? MAP_SHARED : MAP_PRIVATE,
                             fd,
                             0);              // offset обязан быть кратен размеру страницы

            // Ошибка — это MAP_FAILED, то есть (void*)-1, а НЕ nullptr.
            if (p == MAP_FAILED)
            {
                ::close(fd);
                fail("mmap");
            }
            addr_ = p;
        }

        ::close(fd);
    }

    ~MappedFile()
    {
        if (addr_ != nullptr)
            ::munmap(addr_, size_);
    }

    MappedFile(const MappedFile&)            = delete;
    MappedFile& operator=(const MappedFile&) = delete;

    MappedFile(MappedFile&& o) noexcept
        : addr_(std::exchange(o.addr_, nullptr))
        , size_(std::exchange(o.size_, 0))
    {
    }

    MappedFile& operator=(MappedFile&& o) noexcept
    {
        if (this != &o)
        {
            if (addr_ != nullptr)
                ::munmap(addr_, size_);

            addr_ = std::exchange(o.addr_, nullptr);
            size_ = std::exchange(o.size_, 0);
        }
        return *this;
    }

    // Подсказать ядру шаблон доступа: для полного прохода по файлу
    // MADV_SEQUENTIAL включает агрессивный read-ahead.
    void advise(int adv) const
    {
        if (addr_ != nullptr && ::madvise(addr_, size_, adv) != 0)
            fail("madvise");
    }

    void flush() const
    {
        if (addr_ != nullptr && ::msync(addr_, size_, MS_SYNC) != 0)
            fail("msync");
    }

    const void* data() const noexcept { return addr_; }
    void*       data()       noexcept { return addr_; }
    std::size_t size() const noexcept { return size_; }

private:
    void*       addr_ = nullptr;
    std::size_t size_ = 0;
};

// --- 1. Готовим файл обычной записью ------------------------------------------
void write_ticks(const char* path, std::size_t count)
{
    const int fd = ::open(path, O_CREAT | O_TRUNC | O_WRONLY, 0644);
    if (fd < 0)
        fail("open for write");

    constexpr std::size_t kBatch = 64 * 1024;
    std::vector<Tick> buf;
    buf.reserve(kBatch);

    auto flush_buf = [&]
    {
        const std::size_t bytes = buf.size() * sizeof(Tick);
        if (bytes != 0 && ::write(fd, buf.data(), bytes) != static_cast<ssize_t>(bytes))
        {
            ::close(fd);
            fail("write");
        }
        buf.clear();
    };

    for (std::size_t i = 0; i < count; ++i)
    {
        buf.push_back(Tick{
            .ts_ns = 1'700'000'000'000'000'000ull + i * 1'000'000ull,
            .px    = 1'000'000 + static_cast<std::int64_t>(i % 97) * 25,
            .qty   = static_cast<std::uint32_t>(1 + i % 13),
            .side  = (i % 2 == 0) ? 'B' : 'S',
            ._pad  = {}});

        if (buf.size() == kBatch)
            flush_buf();
    }
    flush_buf();
    ::close(fd);
}

// --- 2. Чтение: файл как массив -----------------------------------------------
void scan_readonly(const char* path)
{
    MappedFile m(path, /*writable=*/false);
    m.advise(MADV_SEQUENTIAL);

    if (m.size() % sizeof(Tick) != 0)
        throw std::runtime_error("файл повреждён: размер не кратен записи");

    // Формально до C++23 это UB: в отображении нет объектов Tick, их никто не создавал.
    // В C++23 корректный способ — std::start_lifetime_as_array<Tick>(m.data(), n).
    // На практике весь мир пишет reinterpret_cast, и это надо уметь проговорить.
    const auto* ticks = static_cast<const Tick*>(m.data());
    const std::size_t n = m.size() / sizeof(Tick);

    __int128 notional = 0;
    std::uint64_t volume = 0;
    std::int64_t  hi = INT64_MIN;

    for (std::size_t i = 0; i < n; ++i)          // ни одного read(), только page fault'ы
    {
        notional += static_cast<__int128>(ticks[i].px) * ticks[i].qty;
        volume   += ticks[i].qty;
        if (ticks[i].px > hi)
            hi = ticks[i].px;
    }

    const double vwap = static_cast<double>(static_cast<std::int64_t>(notional / volume)) / 1e4;
    std::printf("  записей: %zu, объём: %llu, VWAP: %.4f, max px: %.4f\n",
                n, static_cast<unsigned long long>(volume), vwap, static_cast<double>(hi) / 1e4);
}

// --- 3. Запись через отображение ----------------------------------------------
void patch_first_tick(const char* path)
{
    MappedFile m(path, /*writable=*/true);

    auto* ticks = static_cast<Tick*>(m.data());
    ticks[0].qty  = 999;                 // это обычная запись в память, не системный вызов
    ticks[0].side = 'S';

    m.flush();                           // MAP_SHARED попадёт на диск и без msync,
                                         // но момент выбирает ядро; msync — это «сейчас»
    // Проверяем обычным чтением, что изменение реально ушло в файл.
    const int fd = ::open(path, O_RDONLY);
    if (fd < 0)
        fail("reopen");

    Tick check{};
    if (::pread(fd, &check, sizeof check, 0) != static_cast<ssize_t>(sizeof check))
    {
        ::close(fd);
        fail("pread");
    }
    ::close(fd);

    std::printf("  после правки через мапинг: qty=%u side=%c\n", check.qty, check.side);
}

// --- 4. Анонимная разделяемая память: IPC без файла ----------------------------
// Так живут shared-memory шины в трейдинге: писатель и читатель — разные процессы,
// общая память, ноль системных вызовов на сообщение.
void shared_anonymous_ipc()
{
    struct Slot
    {
        std::atomic<std::uint64_t> seq;
        std::int64_t px;
    };

    void* p = ::mmap(nullptr, sizeof(Slot), PROT_READ | PROT_WRITE,
                     MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (p == MAP_FAILED)
        fail("mmap anonymous");

    // MAP_ANONYMOUS отдаёт страницы, обнулённые ядром, поэтому placement new
    // формально нужен, но состояние уже корректное.
    auto* slot = new (p) Slot{};

    const pid_t pid = ::fork();
    if (pid < 0)
    {
        ::munmap(p, sizeof(Slot));
        fail("fork");
    }

    if (pid == 0)                                     // потомок: писатель
    {
        slot->px = 1'234'500;
        slot->seq.store(1, std::memory_order_release); // публикация
        ::_exit(0);
    }

    while (slot->seq.load(std::memory_order_acquire) == 0)  // родитель: читатель
        ;

    std::printf("  прочитано из чужого процесса: px=%.4f\n",
                static_cast<double>(slot->px) / 1e4);

    int status = 0;
    ::waitpid(pid, &status, 0);
    ::munmap(p, sizeof(Slot));
}


// --- 5. Замер: pread против mmap на последовательном и случайном доступе -------
// Все замеры «горячие»: файл уже в page cache. Именно так и надо сравнивать —
// иначе меряется скорость диска, а не механизм доступа.
struct Measured
{
    double        sec;
    long          minor_faults;
};

template <class F>
Measured measure(F&& f)
{
    rusage before{}, after{};
    ::getrusage(RUSAGE_SELF, &before);

    const auto t0 = std::chrono::steady_clock::now();
    f();
    const auto t1 = std::chrono::steady_clock::now();

    ::getrusage(RUSAGE_SELF, &after);

    return {std::chrono::duration<double>(t1 - t0).count(),
            after.ru_minflt - before.ru_minflt};
}

std::int64_t sum_via_pread(const char* path, std::size_t n)
{
    const int fd = ::open(path, O_RDONLY);
    if (fd < 0)
        fail("open bench");

    constexpr std::size_t kBatch = 4096;               // 96 КБ за вызов
    std::vector<Tick> buf(kBatch);
    std::int64_t acc = 0;

    for (std::size_t done = 0; done < n; )
    {
        const std::size_t want  = std::min(kBatch, n - done);
        const ssize_t     got   = ::pread(fd, buf.data(), want * sizeof(Tick),
                                          static_cast<off_t>(done * sizeof(Tick)));
        if (got <= 0)
        {
            ::close(fd);
            fail("pread bench");
        }

        const std::size_t recs = static_cast<std::size_t>(got) / sizeof(Tick);
        for (std::size_t i = 0; i < recs; ++i)
            acc += buf[i].px;

        done += recs;
    }

    ::close(fd);
    return acc;
}

std::int64_t sum_via_mmap(const char* path, std::size_t n, bool populate)
{
    const int fd = ::open(path, O_RDONLY);
    if (fd < 0)
        fail("open bench");

    const std::size_t bytes = n * sizeof(Tick);
    void* p = ::mmap(nullptr, bytes, PROT_READ,
                     MAP_PRIVATE | (populate ? MAP_POPULATE : 0), fd, 0);
    ::close(fd);
    if (p == MAP_FAILED)
        fail("mmap bench");

    const auto* ticks = static_cast<const Tick*>(p);
    std::int64_t acc = 0;
    for (std::size_t i = 0; i < n; ++i)
        acc += ticks[i].px;

    ::munmap(p, bytes);
    return acc;
}

// Случайный доступ: та же выборка индексов для обоих способов.
std::int64_t random_via_pread(const char* path, const std::vector<std::size_t>& idx)
{
    const int fd = ::open(path, O_RDONLY);
    if (fd < 0)
        fail("open bench");

    std::int64_t acc = 0;
    Tick t{};
    for (const std::size_t i : idx)
    {
        if (::pread(fd, &t, sizeof t, static_cast<off_t>(i * sizeof(Tick)))
            != static_cast<ssize_t>(sizeof t))
        {
            ::close(fd);
            fail("pread random");
        }
        acc += t.px;
    }

    ::close(fd);
    return acc;
}

std::int64_t random_via_mmap(const char* path, std::size_t n,
                             const std::vector<std::size_t>& idx)
{
    MappedFile m(path, /*writable=*/false);
    const auto* ticks = static_cast<const Tick*>(m.data());
    (void)n;

    std::int64_t acc = 0;
    for (const std::size_t i : idx)
        acc += ticks[i].px;

    return acc;
}

void benchmark(const char* path, std::size_t n)
{
    // Прогрев page cache: дальше сравниваем механизмы, а не скорость диска.
    volatile std::int64_t warm = sum_via_pread(path, n);
    (void)warm;

    std::int64_t a = 0, b = 0, c = 0;
    const Measured m_read = measure([&] { a = sum_via_pread(path, n); });
    const Measured m_map  = measure([&] { b = sum_via_mmap(path, n, /*populate=*/false); });
    const Measured m_pop  = measure([&] { c = sum_via_mmap(path, n, /*populate=*/true); });

    if (a != b || b != c)
        throw std::runtime_error("способы дали разный результат");

    std::printf("  последовательно, %zu записей (%.1f МБ), page cache горячий:\n",
                n, static_cast<double>(n * sizeof(Tick)) / (1024 * 1024));
    std::printf("    pread блоками  : %6.1f мс, минорных фолтов %6ld\n",
                m_read.sec * 1e3, m_read.minor_faults);
    std::printf("    mmap ленивый   : %6.1f мс, минорных фолтов %6ld\n",
                m_map.sec * 1e3, m_map.minor_faults);
    std::printf("    mmap POPULATE  : %6.1f мс, минорных фолтов %6ld\n",
                m_pop.sec * 1e3, m_pop.minor_faults);

    // Случайный доступ — сценарий, ради которого mmap и берут.
    std::mt19937_64 rng(42);
    std::uniform_int_distribution<std::size_t> dist(0, n - 1);
    std::vector<std::size_t> idx(200'000);
    for (auto& i : idx)
        i = dist(rng);

    std::int64_t d = 0, e = 0;
    const Measured r_read = measure([&] { d = random_via_pread(path, idx); });
    const Measured r_map  = measure([&] { e = random_via_mmap(path, n, idx); });

    if (d != e)
        throw std::runtime_error("случайный доступ дал разный результат");

    std::printf("  случайный доступ, %zu обращений:\n", idx.size());
    std::printf("    pread на запись: %6.1f мс  (системный вызов на каждое обращение)\n",
                r_read.sec * 1e3);
    std::printf("    mmap индексом  : %6.1f мс  (обычное разыменование указателя)\n",
                r_map.sec * 1e3);
}

}  // namespace

int main()
{
    const char* path = "mmap_demo.bin";

    try
    {
        std::printf("1. пишем файл обычным write()\n");
        write_ticks(path, 100'000);

        std::printf("2. читаем его как массив через mmap\n");
        scan_readonly(path);

        std::printf("3. правим запись прямо в отображении\n");
        patch_first_tick(path);

        std::printf("4. анонимная разделяемая память между процессами\n");
        shared_anonymous_ipc();

        std::printf("5. замер: pread против mmap\n");
        write_ticks(path, 2'000'000);
        benchmark(path, 2'000'000);
    }
    catch (const std::exception& e)
    {
        std::fprintf(stderr, "ошибка: %s\n", e.what());
        ::unlink(path);
        return 1;
    }

    ::unlink(path);
    return 0;
}
