// Рабочий пример weak_ptr: разрыв цикла, кэш, enable_shared_from_this,
// сравнение по владению и цена lock().
// Разбор — в doc/01-general-topics/12-weak-ptr.md
//
// Сборка:
//   g++ -std=c++20 -Wall -Wextra -O2 -o weak_ptr_demo weak_ptr_demo.cxx && ./weak_ptr_demo
//   g++ -std=c++20 -g -fsanitize=address,undefined -o wp_asan weak_ptr_demo.cxx && ./wp_asan

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <map>
#include <memory>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

namespace {

// --- 1. Цикл: утечка и починка -------------------------------------------------
struct Cyclic
{
    static inline int alive = 0;

    std::shared_ptr<Cyclic> peer;      // сильная ссылка в обе стороны — утечка

    Cyclic()  { ++alive; }
    ~Cyclic() { --alive; }
};

struct Acyclic
{
    static inline int alive = 0;

    std::shared_ptr<Acyclic> forward;  // владеющее направление
    std::weak_ptr<Acyclic>   back;     // наблюдающее — цикл разорван здесь

    Acyclic()  { ++alive; }
    ~Acyclic() { --alive; }
};

void demo_cycle()
{
    {
        auto a = std::make_shared<Cyclic>();
        auto b = std::make_shared<Cyclic>();
        a->peer = b;
        b->peer = a;
        std::printf("    внутри области: alive=%d, use_count(a)=%ld\n",
                    Cyclic::alive, a.use_count());
    }
    std::printf("    после выхода:   alive=%d  <- оба объекта утекли\n", Cyclic::alive);

    {
        auto a = std::make_shared<Acyclic>();
        auto b = std::make_shared<Acyclic>();
        a->forward = b;
        b->back    = a;                // weak_ptr не увеличивает strong count
        std::printf("    внутри области: alive=%d, use_count(a)=%ld\n",
                    Acyclic::alive, a.use_count());
    }
    std::printf("    после выхода:   alive=%d  <- цикла нет, всё освобождено\n",
                Acyclic::alive);
}

// --- 2. Кэш на weak_ptr --------------------------------------------------------
// Кэш не должен продлевать жизнь тому, что кэширует, иначе он становится утечкой.
struct Instrument
{
    static inline int alive = 0;

    std::string symbol;
    double      tick_size;

    explicit Instrument(std::string s) : symbol(std::move(s)), tick_size(0.01) { ++alive; }
    ~Instrument() { --alive; }
};

class InstrumentCache
{
public:
    std::shared_ptr<Instrument> get(const std::string& symbol)
    {
        if (const auto it = map_.find(symbol); it != map_.end())
        {
            // lock() атомарно проверяет и захватывает. Проверка expired() отдельно
            // от захвата была бы гонкой: объект может умереть между ними.
            if (auto sp = it->second.lock())
                return sp;
        }

        auto sp = std::make_shared<Instrument>(symbol);
        map_[symbol] = sp;             // храним НЕвладеющую ссылку
        return sp;
    }

    // Обязательная часть паттерна: словарь сам по себе не уменьшается.
    // Просроченные weak_ptr остаются в нём мусором, пока их не вычистить.
    std::size_t purge()
    {
        return std::erase_if(map_, [](const auto& kv) { return kv.second.expired(); });
    }

    std::size_t size() const noexcept { return map_.size(); }

private:
    std::unordered_map<std::string, std::weak_ptr<Instrument>> map_;
};

void demo_cache()
{
    InstrumentCache cache;

    auto a1 = cache.get("AAPL");
    auto a2 = cache.get("AAPL");       // тот же объект, второй раз не создаём
    std::printf("    два get(\"AAPL\"): один объект? %s, alive=%d\n",
                (a1.get() == a2.get()) ? "да" : "нет", Instrument::alive);

    { auto tmp = cache.get("MSFT"); }  // владельца больше нет

    std::printf("    после смерти MSFT: alive=%d, записей в словаре=%zu\n",
                Instrument::alive, cache.size());

    auto a3 = cache.get("MSFT");       // lock() вернул пустой — создаём заново
    std::printf("    повторный get(\"MSFT\"): создан новый объект, alive=%d\n",
                Instrument::alive);

    a1.reset();
    a2.reset();
    a3.reset();
    const std::size_t removed = cache.purge();
    std::printf("    purge() выкинул просроченных записей: %zu, осталось %zu\n",
                removed, cache.size());
}

// --- 3. enable_shared_from_this и bad_weak_ptr ---------------------------------
struct Session : std::enable_shared_from_this<Session>
{
    Session()
    {
        // weak_this внутри базового класса ещё НЕ заполнен: его инициализирует
        // конструктор shared_ptr, а он отработает только после конструктора Session.
        try
        {
            [[maybe_unused]] auto self = shared_from_this();
            std::printf("    shared_from_this() в конструкторе: сработал (так не бывает)\n");
        }
        catch (const std::bad_weak_ptr&)
        {
            std::printf("    shared_from_this() в конструкторе -> bad_weak_ptr\n");
        }

        // C++17: не бросает, просто отдаёт пустой weak_ptr.
        std::printf("    weak_from_this() в конструкторе: expired=%s\n",
                    weak_from_this().expired() ? "true" : "false");
    }

    std::shared_ptr<Session> self() { return shared_from_this(); }
};

void demo_shared_from_this()
{
    auto s = std::make_shared<Session>();
    auto again = s->self();
    std::printf("    после создания: shared_from_this() даёт тот же объект? %s, use_count=%ld\n",
                (s.get() == again.get()) ? "да" : "нет", s.use_count());
}

// --- 4. Сравнение по владению: owner_before ------------------------------------
struct Quote { double bid; double ask; };

void demo_owner_before()
{
    auto owner = std::make_shared<Quote>(Quote{100.0, 100.5});

    // Aliasing-конструктор: указывают на разные поля, но владеют одним блоком.
    std::shared_ptr<double> bid(owner, &owner->bid);
    std::shared_ptr<double> ask(owner, &owner->ask);

    const bool same_address = (bid.get() == ask.get());
    const bool same_owner   = !bid.owner_before(ask) && !ask.owner_before(bid);

    std::printf("    один адрес? %s; один владелец? %s\n",
                same_address ? "да" : "нет", same_owner ? "да" : "нет");

    // owner_less позволяет класть weak_ptr в упорядоченный контейнер:
    // ключом становится сам блок управления, а не адрес объекта.
    std::map<std::weak_ptr<Quote>, std::string, std::owner_less<std::weak_ptr<Quote>>> subs;
    subs[std::weak_ptr<Quote>(owner)] = "стратегия A";
    subs[std::weak_ptr<Quote>(owner)] = "стратегия B";   // тот же ключ, перезапишет

    std::printf("    два weak_ptr на один объект дали ключей в map: %zu\n", subs.size());
}

// --- 5. Цена lock() ------------------------------------------------------------
void demo_cost()
{
    constexpr int kIters = 5'000'000;

    auto sp = std::make_shared<Quote>(Quote{1.0, 2.0});
    std::weak_ptr<Quote> wp = sp;

    double sink = 0;

    const auto t0 = std::chrono::steady_clock::now();
    for (int i = 0; i < kIters; ++i)
    {
        auto copy = sp;                        // атомарный инкремент + декремент
        sink += copy->bid;
    }
    const auto t1 = std::chrono::steady_clock::now();

    for (int i = 0; i < kIters; ++i)
    {
        auto locked = wp.lock();               // CAS-цикл + инкремент + декремент
        sink += locked->bid;
    }
    const auto t2 = std::chrono::steady_clock::now();

    for (int i = 0; i < kIters; ++i)
    {
        const Quote& raw = *sp;                // ссылка: ноль атомарных операций
        sink += raw.bid;
    }
    const auto t3 = std::chrono::steady_clock::now();

    const auto ns = [](auto a, auto b)
    {
        return std::chrono::duration<double, std::nano>(b - a).count() / kIters;
    };

    std::printf("    копия shared_ptr : %5.2f нс/операция\n", ns(t0, t1));
    std::printf("    weak_ptr::lock() : %5.2f нс/операция\n", ns(t1, t2));
    std::printf("    сырая ссылка     : %5.2f нс/операция\n", ns(t2, t3));
    std::printf("    (sink=%.0f, чтобы оптимизатор не выбросил цикл)\n", sink);
}

}  // namespace

int main()
{
    std::printf("1. цикл shared_ptr: утечка и починка через weak_ptr\n");
    demo_cycle();

    std::printf("2. кэш на weak_ptr\n");
    demo_cache();

    std::printf("3. enable_shared_from_this\n");
    demo_shared_from_this();

    std::printf("4. сравнение по владению (owner_before / owner_less)\n");
    demo_owner_before();

    std::printf("5. цена доступа\n");
    demo_cost();

    return 0;
}
