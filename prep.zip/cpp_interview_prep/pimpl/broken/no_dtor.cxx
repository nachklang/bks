// НАМЕРЕННО НЕ КОМПИЛИРУЕТСЯ. Классическая ошибка pimpl: деструктор не объявлен.
// Заголовок и пользователь склеены в один файл, чтобы воспроизвести ситуацию
// «Impl неполный там, где объект уничтожается».
#include <memory>

class Widget {
public:
    Widget();
    // ~Widget();          <- забыли
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

int main()
{
    Widget w;              // здесь нужен ~Widget → ~unique_ptr<Impl> → delete неполного типа
}
