// НАМЕРЕННО НЕ КОМПИЛИРУЕТСЯ. Деструктор вынесен правильно, но move-конструктор
// сделан "= default" прямо в классе. Он генерируется там, где его используют,
// а сгенерированному move-конструктору нужен ~unique_ptr<Impl> (на случай, если
// после инициализации impl_ бросит инициализация следующего поля).
#include <memory>
#include <utility>

class Widget {
public:
    Widget();
    ~Widget();
    Widget(Widget&&) noexcept = default;   // <- ошибка: должно быть только объявление
private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

int main()
{
    Widget a;
    Widget b = std::move(a);
}
