// Pimpl (pointer to implementation) через std::unique_ptr.
//
// Что видит пользователь класса: только этот заголовок. В нём нет ни одного поля,
// кроме указателя на неполный тип Impl. Поэтому:
//   - изменение полей Impl не меняет sizeof(Instrument) и не требует перекомпиляции
//     тех, кто включает этот заголовок (ABI- и compile-time-щит);
//   - заголовки, нужные реализации (<vector>, <string>, <algorithm> и т.д.), сюда
//     не попадают и не тормозят сборку пользователей.
//
// Цена: одна аллокация при создании, косвенный доступ к каждому полю, функции нельзя
// заинлайнить через границу единицы трансляции (без LTO). Поэтому не в hot path.

#pragma once

#include <cstddef>
#include <memory>
#include <string_view>

class Instrument
{
public:
    explicit Instrument(std::string_view symbol);

    // ---- Особые функции-члены. Самая важная часть pimpl. ----------------------
    //
    // Деструктор ОБЪЯВЛЕН здесь, а ОПРЕДЕЛЁН в .cxx (там, где Impl полный).
    // Если его не объявить, компилятор сгенерирует неявный inline-деструктор прямо
    // в каждой единице трансляции, которая уничтожает Instrument. Там Impl неполный,
    // а ~unique_ptr<Impl> вызывает default_delete<Impl>, который делает
    // static_assert(sizeof(Impl) > 0) — и сборка падает (см. broken/no_dtor.cxx).
    ~Instrument();

    // Объявленный деструктор подавляет неявные операции перемещения — их нужно
    // объявить явно. И тоже определить в .cxx: move-конструктор, сгенерированный
    // здесь, требует ~unique_ptr<Impl> (см. broken/inline_move.cxx), а
    // move-присваивание уничтожает старый Impl.
    Instrument(Instrument&&) noexcept;
    Instrument& operator=(Instrument&&) noexcept;

    // unique_ptr не копируется, поэтому неявное копирование удалено. Если копия
    // нужна по смыслу, её пишут руками — глубокое копирование Impl.
    Instrument(const Instrument& other);
    Instrument& operator=(const Instrument& other);

    // ---- Интерфейс ----------------------------------------------------------------
    void add_trade(long price_ticks, long qty);

    std::string_view symbol() const;
    std::size_t      trade_count() const;
    long             last_price() const;       // 0, если сделок не было
    double           vwap() const;             // 0.0, если сделок не было

    // Состояние после перемещения: impl_ == nullptr. Честно сообщаем о нём,
    // вместо того чтобы молча падать.
    bool valid() const noexcept { return impl_ != nullptr; }

    void swap(Instrument& other) noexcept { impl_.swap(other.impl_); }

private:
    struct Impl;                  // только объявление: неполный тип
    std::unique_ptr<Impl> impl_;

    // const-корректность. unique_ptr::operator-> — const-функция, возвращающая
    // НЕконстантный Impl*. Значит, внутри const-метода можно случайно менять *impl_,
    // и компилятор промолчит (const «не распространяется» через указатель).
    // Два перегруженных аксессора возвращают const Impl& в const-методах.
    Impl&       impl();
    const Impl& impl() const;
};

inline void swap(Instrument& a, Instrument& b) noexcept { a.swap(b); }
