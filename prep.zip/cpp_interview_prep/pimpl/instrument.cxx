// Реализация. Только здесь Impl — полный тип.

#include "instrument.hxx"

#include <cassert>
#include <string>
#include <utility>
#include <vector>

struct Instrument::Impl
{
    std::string symbol;
    std::vector<long> prices;     // цены в тиках: fixed-point, не double
    std::vector<long> qtys;
    long   turnover = 0;          // сумма price * qty
    long   volume   = 0;          // сумма qty
};

// make_unique: одна аллокация, исключение из конструктора Impl не даст утечки.
Instrument::Instrument(std::string_view symbol)
    : impl_(std::make_unique<Impl>())
{
    impl_->symbol = symbol;
}

// Здесь Impl полный, поэтому default_delete<Impl> компилируется.
// "= default" в .cxx — это ровно тот же сгенерированный деструктор, просто
// сгенерированный в правильном месте.
Instrument::~Instrument() = default;

Instrument::Instrument(Instrument&&) noexcept = default;
Instrument& Instrument::operator=(Instrument&&) noexcept = default;

// Глубокая копия. Если у other нет Impl (объект перемещён), копия тоже пустая.
Instrument::Instrument(const Instrument& other)
    : impl_(other.impl_ ? std::make_unique<Impl>(*other.impl_) : nullptr)
{
}

// copy-and-swap: строгая гарантия исключений. Копия строится до того, как мы
// что-то меняем; если make_unique или копирование vector бросит, *this не тронут.
// Самоприсваивание корректно (лишняя копия, но без порчи).
Instrument& Instrument::operator=(const Instrument& other)
{
    Instrument tmp(other);
    swap(tmp);
    return *this;
}

Instrument::Impl& Instrument::impl()
{
    assert(impl_ && "use of moved-from Instrument");
    return *impl_;
}

const Instrument::Impl& Instrument::impl() const
{
    assert(impl_ && "use of moved-from Instrument");
    return *impl_;
}

void Instrument::add_trade(long price_ticks, long qty)
{
    Impl& d = impl();
    // Сначала резервируем место в обоих векторах, потом пишем: если второй
    // push_back бросит bad_alloc после первого, векторы разойдутся по длине.
    d.prices.reserve(d.prices.size() + 1);
    d.qtys.reserve(d.qtys.size() + 1);
    d.prices.push_back(price_ticks);   // после reserve не бросает
    d.qtys.push_back(qty);
    d.turnover += price_ticks * qty;
    d.volume   += qty;
}

std::string_view Instrument::symbol() const { return impl().symbol; }

std::size_t Instrument::trade_count() const { return impl().prices.size(); }

long Instrument::last_price() const
{
    const Impl& d = impl();
    // d.prices.clear();   // <- не скомпилируется: d — const Impl&.
    //                     //    С impl_->prices.clear() скомпилировалось бы!
    return d.prices.empty() ? 0 : d.prices.back();
}

double Instrument::vwap() const
{
    const Impl& d = impl();
    return d.volume == 0 ? 0.0 : static_cast<double>(d.turnover) / static_cast<double>(d.volume);
}
