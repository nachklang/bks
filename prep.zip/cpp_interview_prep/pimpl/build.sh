#!/usr/bin/env bash
# Собирает и запускает пример pimpl, затем показывает, что два сломанных варианта
# действительно не компилируются.
set -euo pipefail
cd "$(dirname "$0")"

FLAGS="-std=c++20 -Wall -Wextra -Wpedantic"

echo "== сборка: две единицы трансляции =="
g++ $FLAGS -O2 -c instrument.cxx -o instrument.o
g++ $FLAGS -O2 -c main.cxx       -o main.o
g++ instrument.o main.o -o pimpl_demo
./pimpl_demo

echo
echo "== то же под ASan и UBSan =="
g++ $FLAGS -g -O1 -fsanitize=address,undefined instrument.cxx main.cxx -o pimpl_demo_asan
./pimpl_demo_asan > /dev/null && echo "чисто"

for f in broken/no_dtor.cxx broken/inline_move.cxx; do
    echo
    echo "== $f: ожидаем ошибку компиляции =="
    if g++ $FLAGS -fsyntax-only "$f" 2> /tmp/pimpl_err.$$; then
        echo "НЕОЖИДАННО скомпилировалось"; exit 1
    fi
    grep -E 'error|required from' /tmp/pimpl_err.$$ | head -4
    rm -f /tmp/pimpl_err.$$
done

rm -f instrument.o main.o
