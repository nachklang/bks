// Пользователь Instrument: видит только заголовок, Impl здесь неполный.

#include "instrument.hxx"

#include <cstdio>
#include <type_traits>
#include <utility>
#include <vector>

// Весь объект — один указатель, как бы ни рос Impl.
static_assert(sizeof(Instrument) == sizeof(void*));
static_assert(std::is_nothrow_move_constructible_v<Instrument>);
static_assert(std::is_nothrow_move_assignable_v<Instrument>);
static_assert(std::is_copy_constructible_v<Instrument>);

static void print(const char* label, const Instrument& i)
{
    if (!i.valid()) { std::printf("%-12s <перемещён>\n", label); return; }
    std::printf("%-12s %.*s: сделок %zu, последняя %ld, vwap %.2f\n", label,
                static_cast<int>(i.symbol().size()), i.symbol().data(),
                i.trade_count(), i.last_price(), i.vwap());
}

int main()
{
    Instrument a("AAPL");
    a.add_trade(18925, 100);
    a.add_trade(18930, 300);
    print("a", a);

    Instrument copy = a;              // глубокая копия
    copy.add_trade(19000, 100);
    print("copy", copy);
    print("a (не изменился)", a);

    Instrument moved = std::move(a);  // крадём указатель, аллокации нет
    print("moved", moved);
    print("a после move", a);

    a = copy;                         // присваивание оживляет перемещённый объект
    print("a после =", a);

    a = a;                            // самоприсваивание через copy-and-swap
    print("a после a=a", a);

    // Перемещаемость noexcept => vector при росте перемещает, а не копирует.
    std::vector<Instrument> book;
    for (const char* s : {"MSFT", "NVDA", "GOOG", "AMZN", "META"})
        book.emplace_back(s);
    std::printf("в векторе %zu инструментов, sizeof(Instrument) = %zu\n",
                book.size(), sizeof(Instrument));
}
