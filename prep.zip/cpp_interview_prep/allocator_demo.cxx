// Аллокаторы: что стоит аллокация, как считать аллокации контейнеров, свой аллокатор,
// PMR. Спутник конспекта doc/01-general-topics/16-allocators.md.
//
//   g++ -std=c++20 -Wall -Wextra -O2 -fno-assume-sane-operators-new-delete -o allocator_demo allocator_demo.cxx
//   ./allocator_demo
//   g++ -std=c++20 -g -fsanitize=address,undefined -o alloc_asan allocator_demo.cxx && ./alloc_asan
//
// Про флаг. GCC 15 по умолчанию (-fassume-sane-operators-new-delete) считает, что
// заменённые operator new/delete не трогают память, видимую вызывающему. Поэтому
// глобальные счётчики внутри них он «не видит»: значение остаётся в регистре, и после
// миллиона push_back счётчик показывает 0. Флаг выключает это допущение. Второй эффект
// того же рода: пару malloc/free (или new/delete) без наблюдаемых побочных эффектов
// оптимизатор вправе удалить целиком (C++14 [expr.new]/10 для new, встроенная семантика
// malloc — для malloc). Поэтому в замерах указатель «сбегает» через asm-барьер escape().
//
// Замеры — микробенчмарки, они показывают порядок величины, а не точное число.

#include <algorithm>
#include <chrono>
#include <cstddef>
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <functional>
#include <list>
#include <malloc.h>
#include <sys/wait.h>
#include <unistd.h>
#include <map>
#include <memory>
#include <memory_resource>
#include <new>
#include <string>
#include <unordered_map>
#include <vector>

// =====================================================================================
// Счётчик глобальных operator new/delete. Заменять глобальный new можно — это
// стандартный механизм (replaceable allocation functions). Здесь считаем только
// количество и суммарный размер, память по-прежнему берём у malloc.
// =====================================================================================
namespace
{
std::size_t g_new_calls = 0;
std::size_t g_new_bytes = 0;
std::size_t g_del_calls = 0;
std::size_t g_aligned_calls = 0;   // operator new(size_t, align_val_t) — отдельная пара функций
}   // namespace

[[gnu::noinline]] void* operator new(std::size_t n)
{
    ++g_new_calls;
    g_new_bytes += n;
    if (void* p = std::malloc(n ? n : 1)) return p;
    throw std::bad_alloc();
}
[[gnu::noinline]] void operator delete(void* p) noexcept
{
    ++g_del_calls;
    std::free(p);
}
[[gnu::noinline]] void operator delete(void* p, std::size_t) noexcept
{
    ++g_del_calls;
    std::free(p);
}

// Выровненная пара (C++17). Её зовут new для типов с alignof > 16 и
// std::pmr::new_delete_resource (он всегда передаёт alignment явно).
// Если заменить только operator new(size_t), эти вызовы пройдут мимо счётчика.
[[gnu::noinline]] void* operator new(std::size_t n, std::align_val_t al)
{
    ++g_new_calls;
    ++g_aligned_calls;
    g_new_bytes += n;
    const std::size_t a = static_cast<std::size_t>(al);
    if (void* p = std::aligned_alloc(a, (n + a - 1) / a * a)) return p;
    throw std::bad_alloc();
}
[[gnu::noinline]] void operator delete(void* p, std::align_val_t) noexcept
{
    ++g_del_calls;
    std::free(p);
}
[[gnu::noinline]] void operator delete(void* p, std::size_t, std::align_val_t) noexcept
{
    ++g_del_calls;
    std::free(p);
}

namespace
{

struct Counter
{
    std::size_t calls, bytes, dels;
    static Counter now() { return {g_new_calls, g_new_bytes, g_del_calls}; }
    Counter        operator-(const Counter& o) const { return {calls - o.calls, bytes - o.bytes, dels - o.dels}; }
};

using Clock = std::chrono::steady_clock;

// Барьер оптимизатора: указатель «утёк» наружу, память могла быть прочитана —
// значит аллокацию нельзя выбросить, а запись в неё нельзя отложить.
inline void escape(void* p) { asm volatile("" : : "g"(p) : "memory"); }

template <class F>
double ns_per_op(F&& f, std::size_t ops)
{
    const auto t0 = Clock::now();
    f();
    const auto t1 = Clock::now();
    return std::chrono::duration<double, std::nano>(t1 - t0).count() / static_cast<double>(ops);
}

// =====================================================================================
// 1. Цена одной аллокации на разных путях glibc malloc
// =====================================================================================
void scenario_malloc_cost()
{
    std::puts("\n=== 1. Что стоит malloc/free ===");
    constexpr std::size_t kOps = 2'000'000;

    // tcache: per-thread кэш освобождённых чанков, без блокировки арены.
    {
        const double ns = ns_per_op([&] {
            for (std::size_t i = 0; i < kOps; ++i)
            {
                void* p = std::malloc(64);
                escape(p);
                std::free(p);
            }
        }, kOps);
        std::printf("  malloc(64)+free, сразу (tcache fast path):      %6.1f нс\n", ns);
    }

    // Много живых объектов одновременно: tcache переполняется, идём в bins арены.
    {
        std::vector<void*> live(4096);
        const double       ns = ns_per_op([&] {
            for (std::size_t i = 0; i < kOps; ++i)
            {
                void*& slot = live[i % live.size()];
                std::free(slot);
                slot = std::malloc(64 + (i % 7) * 16);
                escape(slot);
            }
        }, kOps);
        for (void* p : live) std::free(p);
        std::printf("  malloc/free с 4096 живыми, разные размеры:       %6.1f нс\n", ns);
    }

    // Большой блок: выше mmap-порога (по умолчанию 128 КБ, растёт динамически)
    // каждый malloc — системный вызов mmap, каждый free — munmap.
    {
        constexpr std::size_t kBig = 4 * 1024 * 1024;
        constexpr std::size_t kN   = 200;
        const double          ns   = ns_per_op([&] {
            for (std::size_t i = 0; i < kN; ++i)
            {
                void* p = std::malloc(kBig);
                static_cast<char*>(p)[0] = 1;   // одна страница — один page fault
                escape(p);
                std::free(p);
            }
        }, kN);
        std::printf("  malloc(4 МБ)+касание страницы+free, порог динамический: %6.0f нс\n", ns);
        std::puts("    подозрительно дёшево для mmap: после первого free glibc ПОДНЯЛ mmap-порог");
        std::puts("    до размера освобождённого блока, и дальше 4 МБ идут из кучи (brk), без syscall.");

        // Явный mallopt фиксирует порог и выключает динамику. Меряем в дочернем процессе:
        // в этом top chunk кучи уже вырос до 4 МБ после предыдущего цикла, и malloc
        // возьмёт память оттуда, даже не дойдя до решения «mmap или brk». Свежий процесс
        // (fork до роста кучи невозможен, но у ребёнка своя копия) даёт честную картину.
        std::fflush(stdout);   // иначе ребёнок унаследует несброшенный буфер и напечатает его второй раз
        if (pid_t pid = fork(); pid == 0)
        {
            mallopt(M_MMAP_THRESHOLD, 128 * 1024);
            mallopt(M_TRIM_THRESHOLD, 128 * 1024);
            const double ns_fixed = ns_per_op([&] {
                for (std::size_t i = 0; i < kN; ++i)
                {
                    void* p = std::malloc(kBig);
                    static_cast<char*>(p)[0] = 1;
                    escape(p);
                    std::free(p);
                }
            }, kN);
            std::printf("  то же с mallopt(M_MMAP_THRESHOLD, 128K), порог фиксирован:  %6.0f нс (mmap + page fault + munmap)\n",
                        ns_fixed);
            std::fflush(stdout);
            _exit(0);
        }
        else
        {
            int status = 0;
            waitpid(pid, &status, 0);
        }
    }

    // Первое касание каждой страницы — page fault. Это цена, которую платят
    // не в malloc, а позже, при первой записи.
    {
        constexpr std::size_t kBig = 64 * 1024 * 1024;
        char*                 p    = static_cast<char*>(std::malloc(kBig));
        const double          ns1  = ns_per_op([&] {
            for (std::size_t off = 0; off < kBig; off += 4096) p[off] = 1;
            escape(p);
        }, kBig / 4096);
        const double ns2 = ns_per_op([&] {
            for (std::size_t off = 0; off < kBig; off += 4096) p[off] = 2;
            escape(p);
        }, kBig / 4096);
        std::free(p);
        std::printf("  первое касание страницы (page fault):            %6.0f нс/стр\n", ns1);
        std::printf("  повторное касание той же страницы:               %6.1f нс/стр\n", ns2);
    }
}

// =====================================================================================
// 2. Сколько аллокаций делают контейнеры
// =====================================================================================
void scenario_container_allocs()
{
    std::puts("\n=== 2. Сколько аллокаций делают контейнеры (через счётчик operator new) ===");
    constexpr int kN = 1'000'000;

    {
        auto             c0 = Counter::now();
        std::vector<int> v;
        for (int i = 0; i < kN; ++i) v.push_back(i);
        auto d = Counter::now() - c0;
        std::printf("  vector<int> push_back x%d:      %3zu аллокаций, %5.1f МБ суммарно, capacity=%zu\n",
                    kN, d.calls, d.bytes / 1048576.0, v.capacity());
    }
    {
        auto             c0 = Counter::now();
        std::vector<int> v;
        v.reserve(kN);
        for (int i = 0; i < kN; ++i) v.push_back(i);
        auto d = Counter::now() - c0;
        std::printf("  vector<int> с reserve:           %3zu аллокация,  %5.1f МБ\n", d.calls, d.bytes / 1048576.0);
    }
    {
        auto           c0 = Counter::now();
        std::list<int> l;
        for (int i = 0; i < kN; ++i) l.push_back(i);
        auto d = Counter::now() - c0;
        std::printf("  list<int> push_back x%d:        %zu аллокаций по %zu байт (узел = 2 ptr + int + padding)\n",
                    kN, d.calls, d.bytes / d.calls);
    }
    {
        auto               c0 = Counter::now();
        std::map<int, int> m;
        for (int i = 0; i < kN; ++i) m.emplace(i, i);
        auto d = Counter::now() - c0;
        std::printf("  map<int,int> emplace x%d:       %zu аллокаций по %zu байт (rb-узел: цвет + 3 ptr + pair)\n",
                    kN, d.calls, d.bytes / d.calls);
    }
    {
        auto                         c0 = Counter::now();
        std::unordered_map<int, int> m;
        for (int i = 0; i < kN; ++i) m.emplace(i, i);
        auto d = Counter::now() - c0;
        std::printf("  unordered_map<int,int> x%d:     %zu аллокаций (узлы + %zu rehash'ей таблицы)\n",
                    kN, d.calls, d.calls - kN);
    }
    {
        auto        c0 = Counter::now();
        std::string s15(15, 'x');
        auto        d1 = Counter::now() - c0;
        std::string s16(16, 'x');
        auto        d2 = Counter::now() - c0 - d1;
        std::printf("  string из 15 символов: %zu аллокаций (SSO); из 16: %zu аллокация; sizeof(string)=%zu\n",
                    d1.calls, d2.calls, sizeof(std::string));
    }
    {
        struct Big { char payload[64]; };
        auto c0 = Counter::now();
        auto a  = std::shared_ptr<Big>(new Big{});
        auto d1 = Counter::now() - c0;
        auto b  = std::make_shared<Big>();
        auto d2 = Counter::now() - c0 - d1;
        std::printf("  shared_ptr(new T): %zu аллокации; make_shared<T>: %zu аллокация (объект + control block вместе)\n",
                    d1.calls, d2.calls);
        (void)a; (void)b;
    }
    {
        auto c0 = Counter::now();
        std::function<int(int)> small = [](int x) { return x + 1; };
        auto d1 = Counter::now() - c0;
        char big[64] = {};
        std::function<int(int)> large = [big](int x) { return x + big[0]; };
        auto d2 = Counter::now() - c0 - d1;
        std::printf("  std::function: лямбда без захвата — %zu аллокаций (SBO); с захватом 64 байт — %zu\n",
                    d1.calls, d2.calls);
        (void)small; (void)large;
    }
}

// =====================================================================================
// 3. Свой аллокатор: arena (bump) — минимальный интерфейс C++11+
// =====================================================================================
class Arena
{
public:
    explicit Arena(std::size_t bytes) : buf_(static_cast<std::byte*>(::operator new(bytes))), cap_(bytes) {}
    ~Arena() { ::operator delete(buf_); }
    Arena(const Arena&)            = delete;
    Arena& operator=(const Arena&) = delete;

    void* allocate(std::size_t n, std::size_t align)
    {
        std::size_t off = (used_ + align - 1) & ~(align - 1);   // выравниваем вверх
        if (off + n > cap_) throw std::bad_alloc();
        used_ = off + n;
        return buf_ + off;
    }
    void        deallocate(void*, std::size_t) noexcept {}   // bump-аллокатор ничего не освобождает
    std::size_t used() const noexcept { return used_; }
    void        reset() noexcept { used_ = 0; }             // всё сразу; объекты должны быть уже мертвы

private:
    std::byte*  buf_;
    std::size_t cap_;
    std::size_t used_ = 0;
};

// Аллокатор со состоянием: хранит указатель на арену. Всё остальное — value_type,
// allocate, deallocate, rebind-конструктор, operator== — минимум, который требует
// std::allocator_traits. construct/destroy/max_size/pointer писать не нужно с C++11.
template <class T>
class ArenaAllocator
{
public:
    using value_type = T;

    explicit ArenaAllocator(Arena& a) noexcept : arena_(&a) {}
    template <class U>
    ArenaAllocator(const ArenaAllocator<U>& o) noexcept : arena_(o.arena_) {}   // rebind: list<int> просит allocator<Node>

    T*   allocate(std::size_t n) { return static_cast<T*>(arena_->allocate(n * sizeof(T), alignof(T))); }
    void deallocate(T* p, std::size_t n) noexcept { arena_->deallocate(p, n * sizeof(T)); }

    // Два аллокатора равны, если память одного можно вернуть другому. Здесь — одна арена.
    template <class U>
    bool operator==(const ArenaAllocator<U>& o) const noexcept { return arena_ == o.arena_; }

    // Что делать с аллокатором при копировании/перемещении/swap контейнера.
    // По умолчанию всё false_type, и move между контейнерами с РАЗНЫМИ аренами
    // превращается в поэлементное перемещение. Вслух: почему это важно.
    using propagate_on_container_move_assignment = std::true_type;
    using propagate_on_container_swap            = std::true_type;
    using is_always_equal                        = std::false_type;

private:
    template <class U> friend class ArenaAllocator;
    Arena* arena_;
};

void scenario_custom_allocator()
{
    std::puts("\n=== 3. Свой arena-аллокатор против std::allocator (list<int>, 1M push_back) ===");
    constexpr int kN = 1'000'000;

    double ns_std = 0, ns_arena = 0;
    {
        auto c0 = Counter::now();
        ns_std = ns_per_op([&] {
            std::list<int> l;
            for (int i = 0; i < kN; ++i) l.push_back(i);
        }, kN);
        auto d = Counter::now() - c0;
        std::printf("  std::allocator:  %5.1f нс/узел, %zu вызовов new\n", ns_std, d.calls);
    }
    {
        Arena arena(kN * 32);
        auto  c0 = Counter::now();
        ns_arena = ns_per_op([&] {
            std::list<int, ArenaAllocator<int>> l{ArenaAllocator<int>(arena)};
            for (int i = 0; i < kN; ++i) l.push_back(i);
        }, kN);
        auto d = Counter::now() - c0;
        std::printf("  ArenaAllocator:  %5.1f нс/узел, %zu вызовов new (одна арена), использовано %.1f МБ\n",
                    ns_arena, d.calls, arena.used() / 1048576.0);
    }
    std::printf("  ускорение: x%.1f. Причины: нет free вообще, нет заголовков чанков, узлы подряд в памяти.\n",
                ns_std / ns_arena);

    // Ловушка: два контейнера на разных аренах и swap/move между ними.
    {
        Arena a1(4096), a2(4096);
        std::vector<int, ArenaAllocator<int>> v1{ArenaAllocator<int>(a1)};
        std::vector<int, ArenaAllocator<int>> v2{ArenaAllocator<int>(a2)};
        v1.assign({1, 2, 3});
        v2 = std::move(v1);   // POCMA=true: v2 забирает и буфер, и аллокатор a1. Без POCMA — поэлементный move.
        std::printf("  после move с POCMA=true: v2 использует арену №%d, буфер переехал, аллокаций 0\n",
                    v2.get_allocator() == ArenaAllocator<int>(a1) ? 1 : 2);
    }
}

// =====================================================================================
// 4. PMR: тот же эффект без своего типа аллокатора
// =====================================================================================
void scenario_pmr()
{
    std::puts("\n=== 4. std::pmr: полиморфный аллокатор и memory_resource ===");
    constexpr int kN = 1'000'000;

    std::printf("  тип не зависит от источника памяти: sizeof(pmr::vector<int>)=%zu против vector<int> %zu\n",
                sizeof(std::pmr::vector<int>), sizeof(std::vector<int>));

    // monotonic_buffer_resource: bump на буфере, при исчерпании идёт к upstream (по умолчанию new_delete).
    {
        std::vector<std::byte>             backing(static_cast<std::size_t>(kN) * 32);
        std::pmr::monotonic_buffer_resource mono(backing.data(), backing.size(), std::pmr::null_memory_resource());
        auto                               c0 = Counter::now();
        const double                       ns = ns_per_op([&] {
            std::pmr::list<int> l(&mono);
            for (int i = 0; i < kN; ++i) l.push_back(i);
        }, kN);
        auto d = Counter::now() - c0;
        std::printf("  pmr::list на monotonic_buffer_resource: %5.1f нс/узел, %zu вызовов new\n", ns, d.calls);
        std::puts("    upstream = null_memory_resource: переполнение буфера бросит bad_alloc, а не выделит тихо.");
    }

    // unsynchronized_pool_resource: пулы фиксированных размеров, память переиспользуется, без мьютекса.
    {
        std::pmr::unsynchronized_pool_resource pool;
        auto                                   c0 = Counter::now();
        const double                           ns = ns_per_op([&] {
            std::pmr::list<int> l(&pool);
            for (int i = 0; i < kN; ++i) l.push_back(i);
            for (int r = 0; r < 3; ++r)
            {
                for (int i = 0; i < kN / 2; ++i) l.pop_front();
                for (int i = 0; i < kN / 2; ++i) l.push_back(i);
            }
        }, kN * 4);
        auto d = Counter::now() - c0;
        std::printf("  pmr::list на unsynchronized_pool_resource, с оборотом узлов: %5.1f нс/оп, %zu new (чанками)\n",
                    ns, d.calls);
    }

    // Цена самого механизма: виртуальный вызов на каждый allocate.
    {
        std::pmr::polymorphic_allocator<int> pa(std::pmr::new_delete_resource());
        constexpr std::size_t                kOps = 2'000'000;
        const double ns_pmr = ns_per_op([&] {
            for (std::size_t i = 0; i < kOps; ++i)
            {
                int* p = pa.allocate(16);
                escape(p);
                pa.deallocate(p, 16);
            }
        }, kOps);
        std::allocator<int> sa;
        const double        ns_std = ns_per_op([&] {
            for (std::size_t i = 0; i < kOps; ++i)
            {
                int* p = sa.allocate(16);
                escape(p);
                sa.deallocate(p, 16);
            }
        }, kOps);
        std::printf("  allocate+deallocate 64 байт: std::allocator %.1f нс, polymorphic_allocator->new_delete %.1f нс\n",
                    ns_std, ns_pmr);
        std::puts("    разница — виртуальный вызов do_allocate/do_deallocate. Обычно тонет в цене malloc.");
    }
}

// =====================================================================================
// 5. Класс со своим operator new: пул фиксированного размера через free list
// =====================================================================================
class Order
{
public:
    Order(int id, double px) : id_(id), px_(px) {}
    int    id() const { return id_; }
    double px() const { return px_; }

    // Класс-специфичные operator new/delete: perfect fit для «горячего» типа,
    // которого создаётся и уничтожается много. Вызываются ТОЛЬКО для Order.
    static void* operator new(std::size_t n)
    {
        if (n != sizeof(Order)) return ::operator new(n);   // наследник большего размера
        if (free_list_)
        {
            Node* node = free_list_;
            free_list_ = node->next;
            return node;
        }
        return ::operator new(n);   // пул пуст — идём в общую кучу
    }
    static void operator delete(void* p, std::size_t n) noexcept
    {
        if (n != sizeof(Order)) { ::operator delete(p); return; }
        Node* node = static_cast<Node*>(p);
        node->next = free_list_;
        free_list_ = node;
    }
    static std::size_t pooled()
    {
        std::size_t n = 0;
        for (Node* p = free_list_; p; p = p->next) ++n;
        return n;
    }

private:
    struct Node { Node* next; };
    static inline Node* free_list_ = nullptr;   // не thread-safe — намеренно, вслух: что сделать

    int    id_;
    double px_;
};
static_assert(sizeof(Order) >= sizeof(void*), "узел free list должен помещаться в объект");

void scenario_class_new()
{
    std::puts("\n=== 5. operator new на уровне класса: free list ===");
    constexpr int kRounds = 100'000;

    auto c0 = Counter::now();
    for (int r = 0; r < kRounds; ++r)
    {
        Order* a = new Order(r, 1.0);
        Order* b = new Order(r, 2.0);
        delete a;
        delete b;
    }
    auto d = Counter::now() - c0;
    std::printf("  %d раундов по 2 new/2 delete: глобальных new — %zu, в пуле осталось %zu узлов\n",
                kRounds, d.calls, Order::pooled());
    std::puts("  первый раунд ушёл в кучу, дальше — только free list. Пул никогда не отдаёт память ОС.");
}

// =====================================================================================
// 6. Выравнивание: когда new обязан выделять выровненную память
// =====================================================================================
struct alignas(64) CacheLine { char data[64]; };

void scenario_alignment()
{
    std::puts("\n=== 6. Выравнивание и aligned new (C++17) ===");
    std::printf("  __STDCPP_DEFAULT_NEW_ALIGNMENT__ = %zu: столько гарантирует обычный operator new\n",
                static_cast<std::size_t>(__STDCPP_DEFAULT_NEW_ALIGNMENT__));
    const std::size_t before = g_aligned_calls;
    auto*             p      = new CacheLine{};
    std::printf("  new CacheLine (alignas 64): адрес %% 64 = %zu, вызовов operator new(size_t, align_val_t): %zu\n",
                reinterpret_cast<std::uintptr_t>(p) % 64, g_aligned_calls - before);
    delete p;
    std::puts("  компилятор сам выбрал выровненную перегрузку по alignof(T) > __STDCPP_DEFAULT_NEW_ALIGNMENT__.");
    std::puts("  до C++17 это молча давало невыровненный указатель; SIMD-загрузка с такого — segfault.");
}

}   // namespace

int main()
{
    std::puts("Аллокаторы. GCC 15.2, glibc malloc, x86-64.");
    scenario_malloc_cost();
    scenario_container_allocs();
    scenario_custom_allocator();
    scenario_pmr();
    scenario_class_new();
    scenario_alignment();
    std::puts("\nГотово.");
    return 0;
}
