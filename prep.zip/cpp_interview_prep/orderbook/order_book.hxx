// Эталонный limit order book для технического интервью.
//
// Скоуп: один инструмент, один поток, целые цены в тиках, лимитные и маркет-заявки,
// price-time priority (FIFO внутри уровня цены). Всё, что осталось за бортом,
// перечислено в README.md рядом.
//
// Три решения, которые стоит проговорить вслух, когда пишете это на доске:
//   1. Цена — целое число тиков, а не double.
//   2. Уровни — std::map, заявки внутри уровня — std::list. Итераторы обоих
//      стабильны, поэтому их можно запомнить в индексе и удалять за O(1).
//   3. Матчинг написан ОДИН раз для обеих сторон: и bids, и asks обходятся
//      "лучшая цена первой", а проверка на скрещивание выражается через
//      компаратор самой книги.

#pragma once

#include <algorithm>
#include <cassert>
#include <cstdint>
#include <functional>
#include <list>
#include <map>
#include <optional>
#include <unordered_map>
#include <vector>

namespace ob {

using OrderId  = std::uint64_t;
using Price    = std::int64_t;   // в тиках; знаковый — цена может быть отрицательной (WTI, апрель 2020)
using Quantity = std::uint64_t;
using Sequence = std::uint64_t;  // момент постановки в книгу, задаёт time priority

enum class Side : std::uint8_t { Buy, Sell };

struct Order
{
    OrderId  id;
    Side     side;
    Price    price;
    Quantity quantity;  // ОСТАТОК, а не исходный объём
    Sequence seq;
};

struct Trade
{
    OrderId  taker;
    OrderId  maker;
    Price    price;     // всегда цена maker-а: он стоял в книге и задал условие
    Quantity quantity;

    friend bool operator==(const Trade&, const Trade&) = default;
};

struct LevelView
{
    Price       price;
    Quantity    quantity;  // суммарный остаток на уровне
    std::size_t orders;    // сколько заявок стоит в очереди

    friend bool operator==(const LevelView&, const LevelView&) = default;
};

class OrderBook
{
public:
    // Остаток лимитной заявки встаёт в книгу. Возвращает сделки (может быть пусто).
    std::vector<Trade> add_limit(OrderId id, Side side, Price price, Quantity qty);

    // Остаток маркет-заявки ОТМЕНЯЕТСЯ, в книгу не встаёт: у неё нет цены,
    // по которой её можно было бы там оставить.
    std::vector<Trade> add_market(OrderId id, Side side, Quantity qty);

    // false, если заявки нет: уже исполнена, уже отменена или её никогда не было.
    // Это нормальный путь, а не исключение: гонка cancel/fill — штатная ситуация.
    bool cancel(OrderId id);

    // Уменьшение объёма сохраняет позицию в очереди; увеличение — нет,
    // поэтому оно здесь запрещено и делается через cancel + add_limit.
    bool reduce(OrderId id, Quantity new_quantity);

    std::optional<Price> best_bid() const;
    std::optional<Price> best_ask() const;

    std::vector<LevelView> depth(Side side, std::size_t levels) const;
    Quantity               quantity_at(Side side, Price price) const;

    std::size_t live_orders() const noexcept { return index_.size(); }
    bool        empty()       const noexcept { return index_.empty(); }

private:
    using Level = std::list<Order>;

    // Обе книги обходятся begin() -> "лучшая цена первой":
    // для бидов лучшая цена самая высокая, для асков самая низкая.
    using Bids = std::map<Price, Level, std::greater<Price>>;
    using Asks = std::map<Price, Level, std::less<Price>>;

    struct Locator
    {
        Side            side;
        Price           price;
        Level::iterator it;  // не инвалидируется вставками и удалениями соседей
    };

    // limit == nullptr означает маркет-заявку: берём всё, что есть.
    template <class Book>
    Quantity match(Book& book, OrderId taker, Quantity qty, const Price* limit,
                   std::vector<Trade>& out);

    void rest(OrderId id, Side side, Price price, Quantity qty);

    template <class Book>
    static void detach(Book& book, const Locator& loc);

    template <class Book>
    static std::vector<LevelView> snapshot(const Book& book, std::size_t levels);

    static Quantity level_quantity(const Level& level);

    Bids                                 bids_;
    Asks                                 asks_;
    std::unordered_map<OrderId, Locator> index_;  // O(1) cancel
    Sequence                             next_seq_ = 1;
};

// --------------------------------------------------------------------------
// Матчинг: одна функция на обе стороны.
//
// Book::key_compare упорядочивает книгу "лучшая первой". Отсюда следует, что
// cmp(limit, level_price) == true означает ровно "цена уровня хуже нашего лимита",
// то есть скрещивания больше нет:
//   asks (less):    cmp(L, P) = L < P  -> наш bid ниже аска  -> не берём
//   bids (greater): cmp(L, P) = L > P  -> наш ask выше бида  -> не берём
// --------------------------------------------------------------------------
template <class Book>
Quantity OrderBook::match(Book& book, OrderId taker, Quantity qty, const Price* limit,
                          std::vector<Trade>& out)
{
    typename Book::key_compare cmp;

    while (qty > 0 && !book.empty())
    {
        const auto level_it    = book.begin();
        const Price level_price = level_it->first;

        if (limit != nullptr && cmp(*limit, level_price))
            break;

        Level& level = level_it->second;

        while (qty > 0 && !level.empty())
        {
            Order& maker = level.front();  // FIFO: первым исполняется тот, кто пришёл раньше
            const Quantity traded = std::min(qty, maker.quantity);

            out.push_back(Trade{taker, maker.id, level_price, traded});

            qty            -= traded;
            maker.quantity -= traded;

            if (maker.quantity == 0)
            {
                index_.erase(maker.id);
                level.pop_front();
            }
        }

        if (level.empty())
            book.erase(level_it);  // пустых уровней в книге не держим
    }

    return qty;  // неисполненный остаток
}

template <class Book>
void OrderBook::detach(Book& book, const Locator& loc)
{
    const auto level_it = book.find(loc.price);
    assert(level_it != book.end() && "индекс разошёлся с книгой");

    level_it->second.erase(loc.it);

    if (level_it->second.empty())
        book.erase(level_it);
}

template <class Book>
std::vector<LevelView> OrderBook::snapshot(const Book& book, std::size_t levels)
{
    std::vector<LevelView> out;
    out.reserve(std::min(levels, book.size()));

    for (const auto& [price, level] : book)
    {
        if (out.size() == levels)
            break;
        out.push_back(LevelView{price, level_quantity(level), level.size()});
    }

    return out;
}

inline Quantity OrderBook::level_quantity(const Level& level)
{
    Quantity total = 0;
    for (const Order& o : level)
        total += o.quantity;
    return total;
}

inline std::vector<Trade> OrderBook::add_limit(OrderId id, Side side, Price price, Quantity qty)
{
    std::vector<Trade> trades;

    if (qty == 0 || index_.contains(id))
        return trades;  // отвергаем: нулевой объём и дубликат id

    const Quantity remaining = (side == Side::Buy)
        ? match(asks_, id, qty, &price, trades)
        : match(bids_, id, qty, &price, trades);

    if (remaining > 0)
        rest(id, side, price, remaining);

    return trades;
}

inline std::vector<Trade> OrderBook::add_market(OrderId id, Side side, Quantity qty)
{
    std::vector<Trade> trades;

    if (qty == 0)
        return trades;

    if (side == Side::Buy)
        match(asks_, id, qty, nullptr, trades);
    else
        match(bids_, id, qty, nullptr, trades);

    return trades;  // остаток молча отменён
}

inline void OrderBook::rest(OrderId id, Side side, Price price, Quantity qty)
{
    Level& level = (side == Side::Buy) ? bids_[price] : asks_[price];

    level.push_back(Order{id, side, price, qty, next_seq_++});
    index_.emplace(id, Locator{side, price, std::prev(level.end())});
}

inline bool OrderBook::cancel(OrderId id)
{
    const auto it = index_.find(id);
    if (it == index_.end())
        return false;

    const Locator loc = it->second;
    index_.erase(it);

    if (loc.side == Side::Buy)
        detach(bids_, loc);
    else
        detach(asks_, loc);

    return true;
}

inline bool OrderBook::reduce(OrderId id, Quantity new_quantity)
{
    const auto it = index_.find(id);
    if (it == index_.end())
        return false;

    Order& order = *it->second.it;

    if (new_quantity == 0 || new_quantity >= order.quantity)
        return false;

    order.quantity = new_quantity;  // позиция в очереди сохраняется
    return true;
}

inline std::optional<Price> OrderBook::best_bid() const
{
    if (bids_.empty())
        return std::nullopt;
    return bids_.begin()->first;
}

inline std::optional<Price> OrderBook::best_ask() const
{
    if (asks_.empty())
        return std::nullopt;
    return asks_.begin()->first;
}

inline std::vector<LevelView> OrderBook::depth(Side side, std::size_t levels) const
{
    return (side == Side::Buy) ? snapshot(bids_, levels) : snapshot(asks_, levels);
}

inline Quantity OrderBook::quantity_at(Side side, Price price) const
{
    if (side == Side::Buy)
    {
        const auto it = bids_.find(price);
        return (it == bids_.end()) ? 0 : level_quantity(it->second);
    }

    const auto it = asks_.find(price);
    return (it == asks_.end()) ? 0 : level_quantity(it->second);
}

}  // namespace ob
