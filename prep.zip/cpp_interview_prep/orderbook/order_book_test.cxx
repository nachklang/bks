#include "order_book.hxx"

#include <gtest/gtest.h>

using namespace ob;

namespace {

// Удобные сокращения, чтобы тесты читались как сценарий, а не как код.
constexpr Side Buy  = Side::Buy;
constexpr Side Sell = Side::Sell;

}  // namespace

// --- Пустая книга -----------------------------------------------------------

TEST(OrderBook, EmptyBookHasNoBestPrices)
{
    OrderBook book;

    EXPECT_FALSE(book.best_bid().has_value());
    EXPECT_FALSE(book.best_ask().has_value());
    EXPECT_TRUE(book.empty());
}

TEST(OrderBook, MarketOrderIntoEmptyBookDoesNothing)
{
    OrderBook book;

    const auto trades = book.add_market(1, Buy, 100);

    EXPECT_TRUE(trades.empty());
    EXPECT_TRUE(book.empty());  // остаток маркета не встаёт в книгу
}

// --- Постановка заявок ------------------------------------------------------

TEST(OrderBook, RestingOrdersFormBestBidAndAsk)
{
    OrderBook book;

    book.add_limit(1, Buy,  100, 10);
    book.add_limit(2, Buy,   99, 20);
    book.add_limit(3, Sell, 102, 30);
    book.add_limit(4, Sell, 103, 40);

    EXPECT_EQ(book.best_bid(), 100);
    EXPECT_EQ(book.best_ask(), 102);
    EXPECT_EQ(book.live_orders(), 4u);
}

TEST(OrderBook, ZeroQuantityAndDuplicateIdAreRejected)
{
    OrderBook book;

    EXPECT_TRUE(book.add_limit(1, Buy, 100, 0).empty());
    EXPECT_EQ(book.live_orders(), 0u);

    book.add_limit(1, Buy, 100, 10);
    book.add_limit(1, Buy, 101, 10);  // тот же id — игнорируем

    EXPECT_EQ(book.live_orders(), 1u);
    EXPECT_EQ(book.best_bid(), 100);
}

// --- Матчинг ----------------------------------------------------------------

TEST(OrderBook, FullCrossRemovesBothOrders)
{
    OrderBook book;
    book.add_limit(1, Sell, 100, 10);

    const auto trades = book.add_limit(2, Buy, 100, 10);

    ASSERT_EQ(trades.size(), 1u);
    EXPECT_EQ(trades[0], (Trade{2, 1, 100, 10}));
    EXPECT_TRUE(book.empty());
}

TEST(OrderBook, TradeHappensAtMakerPrice)
{
    OrderBook book;
    book.add_limit(1, Sell, 100, 10);

    // Покупатель готов заплатить 105, но maker стоял по 100 — сделка по 100.
    const auto trades = book.add_limit(2, Buy, 105, 10);

    ASSERT_EQ(trades.size(), 1u);
    EXPECT_EQ(trades[0].price, 100);
}

TEST(OrderBook, TakerRemainderRestsInBook)
{
    OrderBook book;
    book.add_limit(1, Sell, 100, 4);

    const auto trades = book.add_limit(2, Buy, 100, 10);

    ASSERT_EQ(trades.size(), 1u);
    EXPECT_EQ(trades[0].quantity, 4u);
    EXPECT_EQ(book.best_bid(), 100);            // остаток 6 встал в книгу
    EXPECT_EQ(book.quantity_at(Buy, 100), 6u);
    EXPECT_FALSE(book.best_ask().has_value());  // уровень 100 в асках опустел и удалён
}

TEST(OrderBook, MakerRemainderStaysInBook)
{
    OrderBook book;
    book.add_limit(1, Sell, 100, 10);

    const auto trades = book.add_limit(2, Buy, 100, 4);

    ASSERT_EQ(trades.size(), 1u);
    EXPECT_EQ(trades[0].quantity, 4u);
    EXPECT_EQ(book.best_ask(), 100);
    EXPECT_EQ(book.quantity_at(Sell, 100), 6u);
    EXPECT_EQ(book.live_orders(), 1u);
}

TEST(OrderBook, WalksSeveralPriceLevels)
{
    OrderBook book;
    book.add_limit(1, Sell, 100, 5);
    book.add_limit(2, Sell, 101, 5);
    book.add_limit(3, Sell, 102, 5);

    const auto trades = book.add_limit(10, Buy, 101, 12);

    // Съедаем 100 и 101 целиком, до 102 лимит не дотягивается.
    ASSERT_EQ(trades.size(), 2u);
    EXPECT_EQ(trades[0], (Trade{10, 1, 100, 5}));
    EXPECT_EQ(trades[1], (Trade{10, 2, 101, 5}));

    EXPECT_EQ(book.best_ask(), 102);
    EXPECT_EQ(book.best_bid(), 101);            // остаток 2 встал в книгу
    EXPECT_EQ(book.quantity_at(Buy, 101), 2u);
}

TEST(OrderBook, DoesNotCrossWhenPricesDoNotMeet)
{
    OrderBook book;
    book.add_limit(1, Sell, 102, 10);

    const auto trades = book.add_limit(2, Buy, 100, 10);

    EXPECT_TRUE(trades.empty());
    EXPECT_EQ(book.best_bid(), 100);
    EXPECT_EQ(book.best_ask(), 102);
    EXPECT_LT(*book.best_bid(), *book.best_ask());  // книга не скрещена
}

TEST(OrderBook, FifoPriorityInsideLevel)
{
    OrderBook book;
    book.add_limit(1, Sell, 100, 5);  // пришёл первым
    book.add_limit(2, Sell, 100, 5);
    book.add_limit(3, Sell, 100, 5);

    const auto trades = book.add_limit(10, Buy, 100, 12);

    ASSERT_EQ(trades.size(), 3u);
    EXPECT_EQ(trades[0].maker, 1u);
    EXPECT_EQ(trades[1].maker, 2u);
    EXPECT_EQ(trades[2].maker, 3u);
    EXPECT_EQ(trades[2].quantity, 2u);          // третьему досталось только 2
    EXPECT_EQ(book.quantity_at(Sell, 100), 3u);
}

// --- Маркет-заявки ----------------------------------------------------------

TEST(OrderBook, MarketOrderIgnoresPriceAndCancelsRemainder)
{
    OrderBook book;
    book.add_limit(1, Sell, 100, 3);
    book.add_limit(2, Sell, 500, 3);

    const auto trades = book.add_market(10, Buy, 10);

    ASSERT_EQ(trades.size(), 2u);
    EXPECT_EQ(trades[0].price, 100);
    EXPECT_EQ(trades[1].price, 500);            // маркет берёт по любой цене
    EXPECT_TRUE(book.empty());                  // остаток 4 отменён, в книгу не встал
}

// --- Отмена -----------------------------------------------------------------

TEST(OrderBook, CancelFromMiddleOfQueuePreservesOrderOfTheRest)
{
    OrderBook book;
    book.add_limit(1, Sell, 100, 5);
    book.add_limit(2, Sell, 100, 5);
    book.add_limit(3, Sell, 100, 5);

    EXPECT_TRUE(book.cancel(2));
    EXPECT_EQ(book.quantity_at(Sell, 100), 10u);

    const auto trades = book.add_limit(10, Buy, 100, 10);

    ASSERT_EQ(trades.size(), 2u);
    EXPECT_EQ(trades[0].maker, 1u);
    EXPECT_EQ(trades[1].maker, 3u);             // 3 остался позади 1
}

TEST(OrderBook, CancelIsIdempotentAndReportsFailure)
{
    OrderBook book;
    book.add_limit(1, Sell, 100, 5);

    EXPECT_TRUE(book.cancel(1));
    EXPECT_FALSE(book.cancel(1));    // повторная отмена — не исключение, а false
    EXPECT_FALSE(book.cancel(999));  // никогда не существовавшая заявка
}

TEST(OrderBook, CancelOfFilledOrderReturnsFalse)
{
    OrderBook book;
    book.add_limit(1, Sell, 100, 5);
    book.add_limit(2, Buy, 100, 5);  // исполнил заявку 1 целиком

    EXPECT_FALSE(book.cancel(1));
    EXPECT_TRUE(book.empty());
}

TEST(OrderBook, EmptyLevelIsRemovedFromBook)
{
    OrderBook book;
    book.add_limit(1, Sell, 100, 5);
    book.add_limit(2, Sell, 101, 5);

    book.cancel(1);

    EXPECT_EQ(book.best_ask(), 101);
    EXPECT_EQ(book.quantity_at(Sell, 100), 0u);
    ASSERT_EQ(book.depth(Sell, 10).size(), 1u);  // уровня 100 больше нет
}

// --- Изменение объёма -------------------------------------------------------

TEST(OrderBook, ReduceKeepsQueuePriority)
{
    OrderBook book;
    book.add_limit(1, Sell, 100, 10);
    book.add_limit(2, Sell, 100, 10);

    EXPECT_TRUE(book.reduce(1, 4));
    EXPECT_EQ(book.quantity_at(Sell, 100), 14u);

    const auto trades = book.add_limit(10, Buy, 100, 6);

    ASSERT_EQ(trades.size(), 2u);
    EXPECT_EQ(trades[0].maker, 1u);       // приоритет не потерян
    EXPECT_EQ(trades[0].quantity, 4u);
    EXPECT_EQ(trades[1].maker, 2u);
    EXPECT_EQ(trades[1].quantity, 2u);
}

TEST(OrderBook, ReduceRejectsIncreaseAndZero)
{
    OrderBook book;
    book.add_limit(1, Sell, 100, 10);

    EXPECT_FALSE(book.reduce(1, 20));  // увеличение — только через cancel + add
    EXPECT_FALSE(book.reduce(1, 0));   // обнуление — это cancel
    EXPECT_FALSE(book.reduce(42, 5));  // нет такой заявки
    EXPECT_EQ(book.quantity_at(Sell, 100), 10u);
}

// --- Глубина ----------------------------------------------------------------

TEST(OrderBook, DepthIsSortedBestFirstAndAggregated)
{
    OrderBook book;
    book.add_limit(1, Buy, 100, 10);
    book.add_limit(2, Buy, 100, 5);   // тот же уровень
    book.add_limit(3, Buy,  98, 7);
    book.add_limit(4, Buy,  99, 3);

    const auto bids = book.depth(Buy, 10);

    ASSERT_EQ(bids.size(), 3u);
    EXPECT_EQ(bids[0], (LevelView{100, 15, 2}));  // лучший бид первым
    EXPECT_EQ(bids[1], (LevelView{ 99,  3, 1}));
    EXPECT_EQ(bids[2], (LevelView{ 98,  7, 1}));

    EXPECT_EQ(book.depth(Buy, 2).size(), 2u);     // ограничение по числу уровней
}

TEST(OrderBook, NegativePricesAreSupported)
{
    OrderBook book;
    book.add_limit(1, Sell, -5, 10);
    book.add_limit(2, Buy,  -3, 10);  // готов купить дороже, чем просят

    EXPECT_TRUE(book.empty());
    EXPECT_EQ(book.live_orders(), 0u);
}
