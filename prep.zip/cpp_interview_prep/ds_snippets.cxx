#include <gtest/gtest.h>

#include <algorithm>

#include <set>
#include <string>
#include <list>
#include <ranges>

TEST(DataStructureSnippets, VectorEraseRemove)
{
    std::vector<int> v1 {1, 2, 3, 1, 1, 2, 3};

    auto it = std::remove_if(v1.begin(), v1.end(), [](int element) {
        return element == 1;
    });

    v1.erase(it, v1.end());

    auto expected = std::vector<int>{2,3,2,3}; 

    EXPECT_EQ(v1, expected);
}

TEST(DataStructureSnippets, VectorEraseIf)
{
    std::vector<int> v1 {1, 2, 3, 1, 1, 2, 3};

    std::erase_if(v1, [](int element)
    {
        return element == 1;
    });
    
    auto expected = std::vector<int>{2,3,2,3}; 
    EXPECT_EQ(v1, expected);
}

TEST(DataStructureSnippets, FromList)
{
    auto data = std::list<int> {1,1,2,3,4,5,6,7,8,9};

    data.remove_if([](const auto& element){
        return element & 1;
    });


    auto expected = std::list<int>{2, 4, 6, 8};

    EXPECT_EQ(data, expected);
}

TEST(DataStructureSnippets, SetToUpper)
{
    std::set<std::string> data{"anna" ,"Anna","bob","Bob","Kate", "kate", "helen"};

    for(auto it = data.begin(), ite = data.end(); ; it != ite)
    {
        auto currIt = it;
        ++it;

        if(currIt->empty())
        {
            continue;
        }
        auto curr  = data.extract(currIt);
        curr.value()[0] = std::toupper(curr.value()[0]);

        data.insert(std::move(curr));
    }

    std::set<std::string> expected{"Anna","Bob","Kate", "helen"};

    EXPECT_EQ(data, expected);
}

