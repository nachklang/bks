// Тренажёр №4: блокирующая ограниченная очередь (blocking bounded queue).
//
// Вторая по частоте «напиши прямо сейчас» задача на многопоточку после пула
// (а в паре с пулом — первая: пул обычно просят написать поверх такой очереди).
// В drills_mt.cxx задача 2 — урезанный вариант на трёх методах; здесь полный
// контракт, который спрашивают на самом деле.
//
// Правила прежние:
//   1. Не подглядывать в doc/, в drills_mt.cxx и не гуглить, пока не написал свой вариант.
//   2. Проговаривать КАЖДУЮ строчку вслух.
//   3. Первый заход — 30 минут под таймер. Потом разбор. Потом СТЕРЕТЬ и написать заново.
//   4. Зелёные тесты НЕ означают корректность: гонка может не выстрелить сто раз подряд.
//      Обязательно TSan и --gtest_repeat.
//
// Сборка:
//   g++ -std=c++20 -Wall -Wextra -O2 -o bounded_queue bounded_queue.cxx -lgtest -lgtest_main -pthread && ./bounded_queue
//
// Потом обязательно:
//   g++ -std=c++20 -g -fsanitize=thread -o bq_tsan bounded_queue.cxx -lgtest -lgtest_main -pthread && ./bq_tsan
//   g++ -std=c++20 -g -fsanitize=address,undefined -o bq_asan bounded_queue.cxx -lgtest -lgtest_main -pthread && ./bq_asan
//   ./bounded_queue --gtest_repeat=100 --gtest_break_on_failure
//
// Одну задачу за раз:
//   ./bounded_queue --gtest_filter=BoundedQueue.PushBlocksWhileFull
//
// Если бинарник ВИСНЕТ — это само по себе находка (кто-то не разбудил ждущего).
// Запускать так, чтобы увидеть, на каком тесте:
//   timeout 60 ./bounded_queue
//
// `[[maybe_unused]]` в заглушках стоит только затем, чтобы скелет собирался
// без единого warning'а. При реализации — убрать.

#include <gtest/gtest.h>

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstddef>
#include <ctime>
#include <deque>
#include <memory>
#include <mutex>
#include <thread>
#include <utility>
#include <vector>

// =====================================================================================
// Контракт, который проверяют тесты
// =====================================================================================
//   * Вместимость задаётся в конструкторе и не меняется. capacity >= 1;
//     что делать при capacity == 0 — твоё решение, тестом не закреплено (сказать вслух).
//   * push блокируется, пока нет места. Возвращает false, если очередь закрыта.
//   * pop блокируется, пока нет данных. Возвращает false, ТОЛЬКО если очередь
//     закрыта И пуста — закрытие не выбрасывает то, что уже лежит внутри.
//   * try_push / try_pop не блокируются никогда: нет места / нет данных → false сразу.
//   * push_for / pop_for ждут не дольше таймаута и возвращают false по его истечении.
//   * FIFO: порядок внутри одного производителя сохраняется.
//   * close() будит ВСЕХ ждущих и идемпотентен.
//   * Ничего не теряется и не дублируется при нескольких производителях
//     и нескольких потребителях.
//   * Тип-нагрузка может быть move-only; на передаче элемента нет ни одной копии.
//   * Ждущий поток не жжёт CPU.
//
// Вслух ПЕРЕД тем, как писать:
//   — почему две condition_variable, а не одна, и что конкретно ломается на одной;
//   — почему wait обязательно с предикатом, а не голый wait в if;
//   — notify под мьютексом или после unlock — что быстрее и почему оба корректны;
//   — в close() notify_one или notify_all, и почему тут ответ однозначный;
//   — почему pop отдаёт значение через T&, а не возвращает T по значению
//     (подсказка: что будет, если копирующий конструктор T бросит на выходе);
//   — почему внутри deque, а не list или vector;
//   — что вернуть из pop, когда очередь закрыта, но внутри ещё что-то лежит;
//   — зачем size() вообще нужен, если его значение протухает сразу после return;
//   — где здесь false sharing и стоит ли о нём думать на этой задаче;
//   — как эта очередь превращается в SPSC-ring без мьютекса и что для этого нужно.
// =====================================================================================

template <class T>
class BoundedQueue
{
public:
    explicit BoundedQueue([[maybe_unused]] std::size_t capacity)
    {
        // TODO
    }

    ~BoundedQueue()
    {
        // TODO: нужен ли тут вообще код — отдельный вопрос. Ответить вслух.
    }

    BoundedQueue(const BoundedQueue&)            = delete;
    BoundedQueue& operator=(const BoundedQueue&) = delete;
    BoundedQueue(BoundedQueue&&)                 = delete;
    BoundedQueue& operator=(BoundedQueue&&)      = delete;

    // --- блокирующие ---------------------------------------------------------------

    // Ждёт место. false — очередь закрыта, значение НЕ принято.
    bool push([[maybe_unused]] T value)
    {
        // TODO
        return false;
    }

    // Ждёт данные. false — очередь закрыта И пуста.
    bool pop([[maybe_unused]] T& out)
    {
        // TODO
        return false;
    }

    // --- неблокирующие --------------------------------------------------------------

    // Никогда не ждёт. false — нет места или закрыта.
    bool try_push([[maybe_unused]] T value)
    {
        // TODO
        return false;
    }

    // Никогда не ждёт. false — пусто.
    bool try_pop([[maybe_unused]] T& out)
    {
        // TODO
        return false;
    }

    // --- с таймаутом -----------------------------------------------------------------

    bool push_for([[maybe_unused]] T value,
                  [[maybe_unused]] std::chrono::milliseconds timeout)
    {
        // TODO
        return false;
    }

    bool pop_for([[maybe_unused]] T& out,
                 [[maybe_unused]] std::chrono::milliseconds timeout)
    {
        // TODO
        return false;
    }

    // --- завершение и наблюдение -------------------------------------------------------

    // Больше не принимать push, разбудить всех ждущих. Вызывать можно много раз.
    void close()
    {
        // TODO
    }

    bool closed() const
    {
        // TODO
        return false;
    }

    std::size_t size() const
    {
        // TODO
        return 0;
    }

    bool empty() const
    {
        // TODO
        return true;
    }

    std::size_t capacity() const
    {
        // TODO
        return 0;
    }

private:
    // TODO: mutable std::mutex, две condition_variable (not_full_ / not_empty_),
    //       std::deque<T>, capacity_, closed_.
};

// =====================================================================================
// Вспомогательное для тестов: везде дедлайны, чтобы падать, а не висеть
// =====================================================================================
namespace
{

using Clock = std::chrono::steady_clock;
using namespace std::chrono_literals;

// Ждать флага не дольше budget. false — не дождались.
bool wait_flag(const std::atomic<bool>& flag, std::chrono::milliseconds budget)
{
    const auto deadline = Clock::now() + budget;
    while (Clock::now() < deadline)
    {
        if (flag.load(std::memory_order_acquire)) return true;
        std::this_thread::sleep_for(1ms);
    }
    return flag.load(std::memory_order_acquire);
}

// Ждать, пока счётчик не дойдёт до target. false — не дошёл за budget.
bool wait_count(const std::atomic<int>& counter, int target, std::chrono::milliseconds budget)
{
    const auto deadline = Clock::now() + budget;
    while (Clock::now() < deadline)
    {
        if (counter.load(std::memory_order_acquire) >= target) return true;
        std::this_thread::sleep_for(1ms);
    }
    return counter.load(std::memory_order_acquire) >= target;
}

// CPU-время всего процесса — чтобы поймать busy-wait вместо честного ожидания.
double process_cpu_seconds()
{
    timespec ts{};
    clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &ts);
    return static_cast<double>(ts.tv_sec) + static_cast<double>(ts.tv_nsec) * 1e-9;
}

// Считает копии и перемещения — для проверки, что элемент не копируется.
struct Tracer
{
    static inline std::atomic<int> copies{0};
    static inline std::atomic<int> moves{0};

    int value = 0;

    Tracer() = default;
    explicit Tracer(int v) : value(v) {}

    Tracer(const Tracer& o) : value(o.value) { copies.fetch_add(1, std::memory_order_relaxed); }
    Tracer& operator=(const Tracer& o)
    {
        value = o.value;
        copies.fetch_add(1, std::memory_order_relaxed);
        return *this;
    }

    Tracer(Tracer&& o) noexcept : value(o.value) { moves.fetch_add(1, std::memory_order_relaxed); }
    Tracer& operator=(Tracer&& o) noexcept
    {
        value = o.value;
        moves.fetch_add(1, std::memory_order_relaxed);
        return *this;
    }

    static void reset() { copies.store(0); moves.store(0); }
};

// Страховка для тестов, которые поднимают потоки.
//
// Без неё любой ASSERT_* делает return из теста, живой std::thread попадает
// в деструктор joinable — и std::terminate роняет ВЕСЬ бинарник вместо одного
// красного теста. Это та же ошибка, что была в конструкторе ThreadPool
// (см. doc/reference/my-mistakes.md, B3).
//
// Деструктор сначала закрывает очередь — только это и может разбудить тех,
// кто висит в push/pop, — и лишь потом join'ит.
template <class Q>
class ScopedThreads
{
public:
    explicit ScopedThreads(Q& q) : q_(q) {}

    ScopedThreads(const ScopedThreads&)            = delete;
    ScopedThreads& operator=(const ScopedThreads&) = delete;

    ~ScopedThreads()
    {
        q_.close();
        join_all();
    }

    template <class F>
    void spawn(F&& f) { threads_.emplace_back(std::forward<F>(f)); }

    void join_all()
    {
        for (auto& t : threads_)
            if (t.joinable()) t.join();
    }

private:
    Q&                       q_;
    std::vector<std::thread> threads_;
};

}  // namespace

// =====================================================================================
// 1. Однопоточная база: порядок, размер, вместимость
// =====================================================================================

TEST(BoundedQueue, BasicPushPopIsFifo)
{
    BoundedQueue<int> q(4);

    EXPECT_EQ(q.capacity(), 4u);
    EXPECT_TRUE(q.empty());
    EXPECT_EQ(q.size(), 0u);
    EXPECT_FALSE(q.closed());

    for (int i = 1; i <= 4; ++i) EXPECT_TRUE(q.push(i));

    EXPECT_EQ(q.size(), 4u);
    EXPECT_FALSE(q.empty());

    for (int i = 1; i <= 4; ++i)
    {
        int v = 0;
        ASSERT_TRUE(q.pop(v));
        EXPECT_EQ(v, i) << "нарушен FIFO";
    }

    EXPECT_TRUE(q.empty());
}

// =====================================================================================
// 2. Неблокирующие варианты не блокируются
// =====================================================================================

TEST(BoundedQueue, TryPushRefusesWhenFullAndReturnsImmediately)
{
    BoundedQueue<int> q(2);

    ASSERT_TRUE(q.try_push(1));
    ASSERT_TRUE(q.try_push(2));

    const auto start = Clock::now();
    EXPECT_FALSE(q.try_push(3)) << "принял третий элемент в очередь на два";
    EXPECT_LT(Clock::now() - start, 100ms) << "try_push заблокировался";

    EXPECT_EQ(q.size(), 2u);
}

TEST(BoundedQueue, TryPopRefusesWhenEmptyAndReturnsImmediately)
{
    BoundedQueue<int> q(2);

    int v = -1;
    const auto start = Clock::now();
    EXPECT_FALSE(q.try_pop(v));
    EXPECT_LT(Clock::now() - start, 100ms) << "try_pop заблокировался";
    EXPECT_EQ(v, -1) << "out тронут, хотя доставать было нечего";
}

// =====================================================================================
// 3. Блокировка — то, ради чего очередь и пишется
// =====================================================================================

TEST(BoundedQueue, PushBlocksWhileFull)
{
    BoundedQueue<int> q(1);
    ASSERT_TRUE(q.push(1));

    std::atomic<bool> entered{false};
    std::atomic<bool> finished{false};
    std::atomic<bool> accepted{false};

    ScopedThreads threads(q);
    threads.spawn([&] {
        entered.store(true, std::memory_order_release);
        const bool ok = q.push(2);
        accepted.store(ok, std::memory_order_relaxed);
        finished.store(true, std::memory_order_release);
    });

    ASSERT_TRUE(wait_flag(entered, 2s));
    EXPECT_FALSE(wait_flag(finished, 150ms)) << "push вернулся, хотя очередь полна";

    int v = 0;
    ASSERT_TRUE(q.pop(v));
    EXPECT_EQ(v, 1);

    EXPECT_TRUE(wait_flag(finished, 2s)) << "pop не разбудил ждущего производителя";
    EXPECT_TRUE(accepted.load(std::memory_order_relaxed));
}

TEST(BoundedQueue, PopBlocksWhileEmpty)
{
    BoundedQueue<int> q(4);

    std::atomic<bool> entered{false};
    std::atomic<bool> finished{false};
    std::atomic<int>  got{-1};

    ScopedThreads threads(q);
    threads.spawn([&] {
        entered.store(true, std::memory_order_release);
        int v = 0;
        if (q.pop(v)) got.store(v, std::memory_order_relaxed);
        finished.store(true, std::memory_order_release);
    });

    ASSERT_TRUE(wait_flag(entered, 2s));
    EXPECT_FALSE(wait_flag(finished, 150ms)) << "pop вернулся на пустой очереди";

    ASSERT_TRUE(q.push(42));

    EXPECT_TRUE(wait_flag(finished, 2s)) << "push не разбудил ждущего потребителя";
    EXPECT_EQ(got.load(std::memory_order_relaxed), 42);
}

// =====================================================================================
// 4. Таймауты
// =====================================================================================

TEST(BoundedQueue, PopForGivesUpAfterTimeout)
{
    BoundedQueue<int> q(4);

    int v = -1;
    const auto start = Clock::now();
    EXPECT_FALSE(q.pop_for(v, 120ms));
    const auto spent = Clock::now() - start;

    EXPECT_GE(spent, 110ms) << "вернулся раньше собственного таймаута";
    EXPECT_LT(spent, 3s)    << "не проснулся по таймауту";
}

TEST(BoundedQueue, PushForSucceedsWhenSpaceAppearsInTime)
{
    BoundedQueue<int> q(1);
    ASSERT_TRUE(q.push(1));

    std::atomic<bool> finished{false};
    std::atomic<bool> accepted{false};

    ScopedThreads threads(q);
    threads.spawn([&] {
        const bool ok = q.push_for(2, 3s);
        accepted.store(ok, std::memory_order_relaxed);
        finished.store(true, std::memory_order_release);
    });

    std::this_thread::sleep_for(100ms);
    int v = 0;
    ASSERT_TRUE(q.pop(v));

    EXPECT_TRUE(wait_flag(finished, 3s)) << "push_for не проснулся на освободившемся месте";
    EXPECT_TRUE(accepted.load(std::memory_order_relaxed)) << "сдался, хотя место появилось";
}

// =====================================================================================
// 5. Завершение
// =====================================================================================

TEST(BoundedQueue, CloseWakesAllBlockedProducers)
{
    constexpr int kProducers = 4;

    BoundedQueue<int> q(1);
    ASSERT_TRUE(q.push(0));

    std::atomic<int> refused{0};
    std::atomic<int> done{0};

    ScopedThreads threads(q);
    for (int i = 0; i < kProducers; ++i)
        threads.spawn([&] {
            if (!q.push(1)) refused.fetch_add(1, std::memory_order_relaxed);
            done.fetch_add(1, std::memory_order_release);
        });

    std::this_thread::sleep_for(150ms);
    EXPECT_EQ(done.load(std::memory_order_acquire), 0) << "кто-то пролез в полную очередь";

    q.close();

    EXPECT_TRUE(wait_count(done, kProducers, 3s)) << "close разбудил не всех производителей";
    threads.join_all();
    EXPECT_EQ(refused.load(std::memory_order_relaxed), kProducers);
}

TEST(BoundedQueue, CloseWakesAllBlockedConsumers)
{
    constexpr int kConsumers = 4;

    BoundedQueue<int> q(8);

    std::atomic<int> refused{0};
    std::atomic<int> done{0};

    ScopedThreads threads(q);
    for (int i = 0; i < kConsumers; ++i)
        threads.spawn([&] {
            int v = 0;
            if (!q.pop(v)) refused.fetch_add(1, std::memory_order_relaxed);
            done.fetch_add(1, std::memory_order_release);
        });

    std::this_thread::sleep_for(150ms);
    EXPECT_EQ(done.load(std::memory_order_acquire), 0) << "pop вернулся на пустой очереди";

    q.close();

    EXPECT_TRUE(wait_count(done, kConsumers, 3s)) << "close разбудил не всех потребителей";
    threads.join_all();
    EXPECT_EQ(refused.load(std::memory_order_relaxed), kConsumers);
}

// Главная семантическая ловушка: закрытие НЕ выбрасывает то, что уже внутри.
TEST(BoundedQueue, CloseLetsConsumersDrainWhatIsAlreadyInside)
{
    BoundedQueue<int> q(8);

    ASSERT_TRUE(q.push(1));
    ASSERT_TRUE(q.push(2));
    ASSERT_TRUE(q.push(3));

    q.close();
    EXPECT_TRUE(q.closed());

    for (int expected = 1; expected <= 3; ++expected)
    {
        int v = 0;
        ASSERT_TRUE(q.pop(v)) << "потерял элемент " << expected << " после close()";
        EXPECT_EQ(v, expected);
    }

    int v = 0;
    EXPECT_FALSE(q.pop(v)) << "закрыта и пуста, а pop всё ещё отдаёт true";
}

TEST(BoundedQueue, PushAfterCloseIsRefused)
{
    BoundedQueue<int> q(8);
    q.close();

    EXPECT_FALSE(q.push(1));
    EXPECT_FALSE(q.try_push(2));
    EXPECT_FALSE(q.push_for(3, 50ms));
    EXPECT_EQ(q.size(), 0u) << "что-то всё-таки легло в закрытую очередь";
}

TEST(BoundedQueue, CloseIsIdempotent)
{
    BoundedQueue<int> q(4);
    ASSERT_TRUE(q.push(7));

    q.close();
    q.close();
    q.close();

    int v = 0;
    EXPECT_TRUE(q.pop(v));
    EXPECT_EQ(v, 7);
    EXPECT_FALSE(q.pop(v));
}

// =====================================================================================
// 6. Нагрузка: ничего не потеряно и не продублировано
// =====================================================================================

TEST(BoundedQueue, MultiProducerMultiConsumerLosesAndDuplicatesNothing)
{
    constexpr int kProducers   = 3;
    constexpr int kConsumers   = 4;
    constexpr int kPerProducer = 5000;
    constexpr int kTotal       = kProducers * kPerProducer;

    BoundedQueue<int> q(64);
    std::vector<std::atomic<int>> seen(kTotal);

    std::atomic<int> rejected{0};

    // Порядок объявления важен: потребители разрушаются последними.
    ScopedThreads consumers(q);
    ScopedThreads producers(q);

    for (int p = 0; p < kProducers; ++p)
        producers.spawn([&, p] {
            for (int i = 0; i < kPerProducer; ++i)
                if (!q.push(p * kPerProducer + i)) rejected.fetch_add(1, std::memory_order_relaxed);
        });

    for (int c = 0; c < kConsumers; ++c)
        consumers.spawn([&] {
            int v = 0;
            while (q.pop(v)) seen[static_cast<std::size_t>(v)].fetch_add(1, std::memory_order_relaxed);
        });

    producers.join_all();
    q.close();                                   // без этого потребители не выйдут никогда
    consumers.join_all();

    EXPECT_EQ(rejected.load(std::memory_order_relaxed), 0) << "push отказал до close()";

    int lost = 0;
    int duplicated = 0;
    for (const auto& c : seen)
    {
        const int n = c.load(std::memory_order_relaxed);
        if (n == 0) ++lost;
        if (n > 1)  ++duplicated;
    }

    EXPECT_EQ(lost, 0)       << "потеряно элементов: " << lost << " из " << kTotal;
    EXPECT_EQ(duplicated, 0) << "выдано дважды: " << duplicated << " из " << kTotal;
    EXPECT_TRUE(q.empty());
}

// Один производитель — порядок обязан сохраниться даже под нагрузкой.
TEST(BoundedQueue, SingleProducerOrderIsPreserved)
{
    constexpr int kCount = 20000;

    BoundedQueue<int> q(16);

    ScopedThreads threads(q);
    threads.spawn([&] {
        for (int i = 0; i < kCount; ++i) q.push(i);
        q.close();
    });

    int expected = 0;
    int out_of_order = 0;
    int v = 0;
    while (q.pop(v))
    {
        if (v != expected) ++out_of_order;
        ++expected;
    }

    threads.join_all();

    EXPECT_EQ(expected, kCount) << "дошло не всё";
    EXPECT_EQ(out_of_order, 0)  << "порядок нарушен " << out_of_order << " раз";
}

// =====================================================================================
// 7. Требования к типу-нагрузке
// =====================================================================================

TEST(BoundedQueue, WorksWithMoveOnlyPayload)
{
    BoundedQueue<std::unique_ptr<int>> q(4);

    ASSERT_TRUE(q.push(std::make_unique<int>(11)));
    ASSERT_TRUE(q.push(std::make_unique<int>(22)));

    std::unique_ptr<int> out;
    ASSERT_TRUE(q.pop(out));
    ASSERT_NE(out, nullptr);
    EXPECT_EQ(*out, 11);

    ASSERT_TRUE(q.pop(out));
    ASSERT_NE(out, nullptr);
    EXPECT_EQ(*out, 22);
}

TEST(BoundedQueue, TransferDoesNotCopyThePayload)
{
    BoundedQueue<Tracer> q(4);
    Tracer::reset();

    ASSERT_TRUE(q.push(Tracer{7}));

    Tracer out;
    ASSERT_TRUE(q.pop(out));

    EXPECT_EQ(out.value, 7);
    EXPECT_EQ(Tracer::copies.load(), 0)
        << "элемент копируется: "
        << Tracer::copies.load() << " копий, " << Tracer::moves.load() << " перемещений";
}

// =====================================================================================
// 8. Детектор busy-wait: на скелете зелёный, краснеет от спина
// =====================================================================================

TEST(BoundedQueue, BlockedConsumerDoesNotBurnCpu)
{
    BoundedQueue<int> q(4);

    ScopedThreads threads(q);
    threads.spawn([&] {
        int v = 0;
        q.pop(v);
    });

    std::this_thread::sleep_for(50ms);          // дать потоку упереться в wait
    const double before = process_cpu_seconds();
    std::this_thread::sleep_for(300ms);
    const double after = process_cpu_seconds();

    q.close();
    threads.join_all();

    EXPECT_LT(after - before, 0.05)
        << "за 300 мс ожидания сожжено " << (after - before) << " с CPU — похоже на busy-wait";
}
