// Рабочий пример: как работает condition_variable::wait, что такое потерянное
// пробуждение и сколько стоит поход в ядро.
// Разбор — в doc/01-general-topics/14-condition-variable.md
//
// Сборка:
//   g++ -std=c++20 -Wall -Wextra -O2 -o cv_demo condvar_demo.cxx -pthread && ./cv_demo
//   g++ -std=c++20 -g -O1 -fsanitize=thread -o cv_tsan condvar_demo.cxx -pthread && ./cv_tsan
//
// Под TSan сценарий 1 ДОЛЖЕН выдать data race: там условие намеренно читается без
// мьютекса. Это и есть демонстрируемая ошибка, а не дефект примера.

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdio>
#include <mutex>
#include <queue>
#include <thread>
#include <vector>

namespace {

using namespace std::chrono_literals;
using Clock = std::chrono::steady_clock;

// --- 1. Потерянное пробуждение, воспроизводимо ---------------------------------
// Условие проверяется БЕЗ мьютекса. В окно между проверкой и wait() успевает
// пройти notify — и оно уходит в пустоту: cv не помнит уведомлений.
void demo_lost_wakeup()
{
    std::mutex              m;
    std::condition_variable cv;
    bool                    ready = false;

    std::thread producer([&]
    {
        std::this_thread::sleep_for(50ms);       // попадаем ровно в окно
        {
            std::lock_guard lk(m);
            ready = true;
        }
        cv.notify_one();                         // ждущих ещё нет — уведомление потеряно
    });

    bool timed_out = false;
    if (!ready)                                  // <- проверка без мьютекса: ошибка
    {
        std::this_thread::sleep_for(100ms);      // окно, в котором отработал producer
        std::unique_lock lk(m);
        timed_out = (cv.wait_for(lk, 300ms) == std::cv_status::timeout);
    }
    producer.join();

    std::printf("    без мьютекса и без предиката: %s\n",
                timed_out ? "проснулись по ТАЙМАУТУ — уведомление потеряно"
                          : "успели поймать notify");

    // Правильный вариант: захватить мьютекс ДО проверки и ждать с предикатом.
    // Тогда «проверить и уснуть» атомарно относительно мьютекса, и notify,
    // прошедший раньше wait, уже отражён в состоянии.
    ready = false;
    std::thread producer2([&]
    {
        std::this_thread::sleep_for(50ms);
        {
            std::lock_guard lk(m);
            ready = true;
        }
        cv.notify_one();
    });

    const auto t0 = Clock::now();
    bool ok = false;
    {
        std::unique_lock lk(m);
        ok = cv.wait_for(lk, 300ms, [&] { return ready; });   // predicate-форма
    }
    const auto waited = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
    producer2.join();

    std::printf("    с мьютексом и предикатом:     %s, ждали %.0f мс\n",
                ok ? "условие выполнено" : "таймаут", waited);
}

// --- 2. Сколько стоит разбудить поток ------------------------------------------
// Пинг-понг двух потоков: через condition_variable и через спин по атомику.
void demo_cost()
{
    constexpr int kRounds = 20'000;

    // (а) condition_variable
    {
        std::mutex              m;
        std::condition_variable cv;
        int                     turn = 0;

        const auto t0 = Clock::now();
        std::thread b([&]
        {
            for (int i = 0; i < kRounds; ++i)
            {
                std::unique_lock lk(m);
                cv.wait(lk, [&] { return turn == 1; });
                turn = 0;
                lk.unlock();
                cv.notify_one();
            }
        });

        for (int i = 0; i < kRounds; ++i)
        {
            std::unique_lock lk(m);
            turn = 1;
            lk.unlock();
            cv.notify_one();
            lk.lock();
            cv.wait(lk, [&] { return turn == 0; });
        }
        b.join();

        const auto ns = std::chrono::duration<double, std::nano>(Clock::now() - t0).count();
        std::printf("    condition_variable: %6.0f нс на круг\n", ns / kRounds);
    }

    // (б) спин по атомику
    {
        std::atomic<int> turn{0};

        const auto t0 = Clock::now();
        std::thread b([&]
        {
            for (int i = 0; i < kRounds; ++i)
            {
                while (turn.load(std::memory_order_acquire) != 1)
                    ;
                turn.store(0, std::memory_order_release);
            }
        });

        for (int i = 0; i < kRounds; ++i)
        {
            turn.store(1, std::memory_order_release);
            while (turn.load(std::memory_order_acquire) != 0)
                ;
        }
        b.join();

        const auto ns = std::chrono::duration<double, std::nano>(Clock::now() - t0).count();
        std::printf("    спин по атомику:    %6.0f нс на круг  (ценой сожжённого CPU)\n",
                    ns / kRounds);
    }
}

// --- 3. notify_one против notify_all: эффект стада -----------------------------
void demo_thundering_herd(bool use_notify_all)
{
    constexpr int kWaiters = 8;
    constexpr int kEvents  = 20'000;

    std::mutex              m;
    std::condition_variable cv;
    int                     tickets = 0;
    int                     served  = 0;
    bool                    done    = false;

    std::vector<std::thread> waiters;
    waiters.reserve(kWaiters);

    for (int i = 0; i < kWaiters; ++i)
    {
        waiters.emplace_back([&]
        {
            for (;;)
            {
                std::unique_lock lk(m);
                cv.wait(lk, [&] { return tickets > 0 || done; });
                if (tickets == 0 && done)
                    return;
                --tickets;
                ++served;
                if (served == kEvents)
                    lk.unlock(), cv.notify_all();
            }
        });
    }

    const auto t0 = Clock::now();
    for (int i = 0; i < kEvents; ++i)
    {
        {
            std::lock_guard lk(m);
            ++tickets;
        }
        if (use_notify_all)
            cv.notify_all();
        else
            cv.notify_one();
    }
    {
        std::lock_guard lk(m);
        done = true;
    }
    cv.notify_all();

    for (auto& t : waiters)
        t.join();

    const auto ms = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
    std::printf("    %-11s %d событий на %d ждущих: %6.1f мс\n",
                use_notify_all ? "notify_all:" : "notify_one:", kEvents, kWaiters, ms);
}

// --- 4. Канонический пример: закрываемая очередь -------------------------------
template <class T>
class BlockingQueue
{
public:
    void push(T v)
    {
        {
            std::lock_guard lk(m_);      // состояние меняем ТОЛЬКО под мьютексом
            q_.push(std::move(v));
        }
        cv_.notify_one();                // notify вне лока
    }

    bool pop(T& out)
    {
        std::unique_lock lk(m_);
        cv_.wait(lk, [this] { return !q_.empty() || closed_; });

        if (q_.empty())                  // закрыто и пусто — штатный выход
            return false;

        out = std::move(q_.front());
        q_.pop();
        return true;
    }

    void close()
    {
        {
            std::lock_guard lk(m_);
            closed_ = true;
        }
        cv_.notify_all();                // разбудить ВСЕХ: условие изменилось для всех
    }

private:
    std::mutex              m_;
    std::condition_variable cv_;
    std::queue<T>           q_;
    bool                    closed_ = false;
};

void demo_queue()
{
    BlockingQueue<int> q;
    std::atomic<int>   sum{0};
    std::atomic<int>   drained{0};

    std::vector<std::thread> consumers;
    for (int i = 0; i < 4; ++i)
        consumers.emplace_back([&]
        {
            int v = 0;
            while (q.pop(v))
                sum.fetch_add(v, std::memory_order_relaxed);
            drained.fetch_add(1, std::memory_order_relaxed);
        });

    for (int i = 1; i <= 1000; ++i)
        q.push(i);

    q.close();
    for (auto& t : consumers)
        t.join();

    std::printf("    сумма 1..1000 = %d (ожидалось 500500), потребителей завершилось: %d\n",
                sum.load(), drained.load());
}

}  // namespace

int main()
{
    std::printf("1. потерянное пробуждение\n");
    demo_lost_wakeup();

    std::printf("2. цена пробуждения\n");
    demo_cost();

    std::printf("3. эффект стада\n");
    demo_thundering_herd(false);
    demo_thundering_herd(true);

    std::printf("4. закрываемая очередь\n");
    demo_queue();

    return 0;
}
