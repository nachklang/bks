// Раскладка vtable: что физически лежит в объекте и в таблице.
// Спутник конспекта doc/01-general-topics/15-vtable-layout.md.
//
// ВАЖНО: собирать без оптимизаций — часть сценариев читает память сырыми
// указателями и формально нарушает strict aliasing. Это диагностика, не образец кода.
//   g++ -std=c++20 -Wall -Wextra -O0 -o vtable_demo vtable_demo.cxx && ./vtable_demo
//
// Полную раскладку от самого компилятора можно получить так:
//   g++ -std=c++20 -fdump-lang-class=layout.txt -c vtable_demo.cxx -o /dev/null

#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <typeinfo>

namespace
{

// --- одиночное наследование -----------------------------------------------------
struct A
{
    virtual ~A() = default;
    virtual void f() { std::puts("    A::f"); }
    virtual void g() { std::puts("    A::g"); }
    int a = 1;
};

struct D : A
{
    void f() override { std::puts("    D::f"); }
    virtual void h() { std::puts("    D::h"); }
    int d = 2;
};

// --- множественное наследование -------------------------------------------------
struct L
{
    virtual void lf() { std::puts("    L::lf"); }
    virtual void common() { std::puts("    L::common"); }
    int l = 10;
};

struct R
{
    virtual void rf() { std::puts("    R::rf"); }
    virtual void common() { std::puts("    R::common"); }
    int r = 20;
};

struct M : L, R
{
    void lf() override { std::puts("    M::lf"); }
    void rf() override { std::puts("    M::rf"); }
    void common() override
    {
        std::printf("    M::common, this = %p\n", static_cast<const void*>(this));
    }
    int m = 30;
};

// --- виртуальное наследование ----------------------------------------------------
struct VB
{
    virtual void vf() { std::puts("    VB::vf"); }
    int vb = 100;
};
struct V1 : virtual VB
{
    void vf() override { std::puts("    V1::vf"); }
    int v1 = 101;
};
struct V2 : virtual VB
{
    int v2 = 102;
};
struct VD : V1, V2
{
    void vf() override { std::puts("    VD::vf"); }
    int vd = 103;
};

// --- вспомогательное: прочитать vptr и слоты таблицы ------------------------------
using VTable = void**;

VTable vptr_of(const void* obj)
{
    VTable slot = nullptr;
    __builtin_memcpy(&slot, obj, sizeof slot);
    return slot;
}

// vptr указывает НЕ на начало таблицы, а на первый слот с функциями.
// Служебные поля лежат перед ним: [-2] offset-to-top, [-1] указатель на typeinfo.
std::ptrdiff_t offset_to_top(const void* obj)
{
    VTable        v = vptr_of(obj);
    std::ptrdiff_t off;
    __builtin_memcpy(&off, &v[-2], sizeof off);
    return off;
}

const std::type_info* rtti_of(const void* obj)
{
    VTable                v = vptr_of(obj);
    const std::type_info* ti;
    __builtin_memcpy(&ti, &v[-1], sizeof ti);
    return ti;
}

void dump_slots(const char* what, const void* obj, int n)
{
    VTable v = vptr_of(obj);
    std::printf("  %-22s vptr=%p  offset-to-top=%+td  typeinfo=%s\n", what,
                static_cast<void*>(v), offset_to_top(obj), rtti_of(obj)->name());
    for (int i = 0; i < n; ++i)
        std::printf("      slot[%d] @ vptr+%2d = %p\n", i, i * 8, v[i]);
}

std::ptrdiff_t bytes_between(const void* a, const void* b)
{
    return static_cast<const char*>(b) - static_cast<const char*>(a);
}

// --- 1. Размеры и смещения --------------------------------------------------------
void scenario_sizes()
{
    std::puts("\n=== 1. Размеры: vptr — это невидимое поле в начале объекта ===");
    struct NoVirt { int a; };
    std::printf("  struct{int}          sizeof=%2zu\n", sizeof(NoVirt));
    std::printf("  A  (1 int + vptr)    sizeof=%2zu  (vptr 8 + int 4 + padding 4)\n", sizeof(A));
    std::printf("  D  (A + 1 int)       sizeof=%2zu  (padding в A переиспользован под D::d)\n", sizeof(D));
    std::printf("  M  (L + R + 1 int)   sizeof=%2zu  (ДВА vptr)\n", sizeof(M));
    std::printf("  VD (ромб с virtual)  sizeof=%2zu\n", sizeof(VD));

    D d;
    std::printf("  в D: vptr @+%td, A::a @+%td, D::d @+%td\n", bytes_between(&d, &d),
                bytes_between(&d, &d.a), bytes_between(&d, &d.d));
}

// --- 2. Содержимое таблицы при одиночном наследовании -------------------------------
void scenario_single()
{
    std::puts("\n=== 2. Одиночное наследование: один vptr, порядок слотов сохраняется ===");
    A a;
    D d;
    dump_slots("A", &a, 4);
    dump_slots("D", &d, 5);
    std::puts("  слоты идут в порядке объявления: ~dtor, ~dtor(deleting), f, g, [h у D].");
    std::puts("  D::f заменил слот A::f на месте, A::g остался — потому vtable D длиннее на h.");
    std::puts("  вызов p->f() — это (*(vptr[2]))(p): одна загрузка + косвенный call.");
}

// --- 3. Два vptr при множественном наследовании -------------------------------------
void scenario_multiple()
{
    std::puts("\n=== 3. Множественное наследование: два подобъекта, два vptr ===");
    M m;
    L* pl = &m;
    R* pr = &m;

    std::printf("  &m = %p\n", static_cast<void*>(&m));
    std::printf("  static_cast<L*> = %p  (сдвиг %+td)\n", static_cast<void*>(pl), bytes_between(&m, pl));
    std::printf("  static_cast<R*> = %p  (сдвиг %+td)\n", static_cast<void*>(pr), bytes_between(&m, pr));

    dump_slots("подобъект L (он же M)", pl, 3);
    dump_slots("подобъект R", pr, 2);
    std::puts("  у второй таблицы offset-to-top = -16: столько надо вычесть из this,");
    std::puts("  чтобы из R* получить адрес полного объекта. Этим живёт dynamic_cast.");

    std::puts("  вызов common() через R*: в слоте лежит НЕ M::common, а thunk _ZThn16_,");
    std::puts("  который сначала правит this на -16, потом прыгает в M::common:");
    std::printf("    через M*: ");
    m.common();
    std::printf("    через R*: ");
    pr->common();
    std::puts("  оба раза печатается один и тот же this — thunk уже вычел 16.");
}

// --- 4. Касты и что бывает без сдвига ------------------------------------------------
void scenario_casts()
{
    std::puts("\n=== 4. static_cast правит указатель, reinterpret_cast — нет ===");
    M  m;
    R* good = static_cast<R*>(&m);
    R* bad  = reinterpret_cast<R*>(&m);

    std::printf("  static_cast<R*>      -> %p, r = %d  (верно, 20)\n", static_cast<void*>(good), good->r);
    std::printf("  reinterpret_cast<R*> -> %p, r = %d  (мусор: читает поле L по смещению R)\n",
                static_cast<void*>(bad), bad->r);
    std::puts("  UB. -Wall -Wextra молчит. Ровно этот вопрос задавали на первом раунде.");

    std::puts("  dynamic_cast обратно вверх берёт offset-to-top из таблицы:");
    M* back = dynamic_cast<M*>(good);
    std::printf("    dynamic_cast<M*>(R*) -> %p, сдвиг %+td\n", static_cast<void*>(back),
                bytes_between(good, back));
}

// --- 5. vptr меняется по ходу конструирования -----------------------------------------
struct CtorBase
{
    CtorBase() { std::printf("    в CtorBase():    typeid = %s\n", typeid(*this).name()); report(); }
    virtual ~CtorBase() { std::printf("    в ~CtorBase():   typeid = %s\n", typeid(*this).name()); }
    virtual void report() { std::puts("    CtorBase::report"); }
};
struct CtorDerived : CtorBase
{
    CtorDerived() { std::printf("    в CtorDerived(): typeid = %s\n", typeid(*this).name()); report(); }
    void report() override { std::puts("    CtorDerived::report"); }
};

void scenario_construction()
{
    std::puts("\n=== 5. vptr переписывается на каждом уровне иерархии ===");
    { CtorDerived d; (void)d; }
    std::puts("  пока тело базового конструктора не закончилось, объект ЕЩЁ базового типа:");
    std::puts("  vptr смотрит на vtable базы, виртуальный вызов уходит в базу.");
    std::puts("  то же в деструкторе, только в обратную сторону. Чисто виртуальный вызов");
    std::puts("  оттуда — не UB-в-никуда, а честный __cxa_pure_virtual и terminate.");
}

// --- 6. Виртуальное наследование --------------------------------------------------------
void scenario_virtual_base()
{
    std::puts("\n=== 6. Виртуальный базовый класс: ещё один уровень косвенности ===");
    VD  vd;
    VB* pv = &vd;
    std::printf("  sizeof(VD) = %zu, &vd = %p\n", sizeof(VD), static_cast<void*>(&vd));
    std::printf("  подобъект VB @ +%td (единственный на весь ромб)\n", bytes_between(&vd, pv));
    std::printf("  V1::v1 @+%td, V2::v2 @+%td, VD::vd @+%td, VB::vb @+%td\n",
                bytes_between(&vd, &vd.v1), bytes_between(&vd, &vd.v2), bytes_between(&vd, &vd.vd),
                bytes_between(&vd, &static_cast<VB&>(vd).vb));
    std::puts("  смещение до VB нельзя знать на этапе компиляции: у V1 в одиночку оно одно,");
    std::puts("  внутри VD — другое. Поэтому оно лежит В ТАБЛИЦЕ (vbase offset), и каждое");
    std::puts("  обращение к полю виртуальной базы — это лишняя загрузка смещения.");
    std::printf("  static_cast<VB*>(&vd) стоит одной загрузки, а dynamic_cast вниз — вызова:\n");
    std::printf("    VB* -> VD*: %p\n", static_cast<void*>(dynamic_cast<VD*>(pv)));
    std::puts("  а static_cast<VD*>(pv) вообще НЕ КОМПИЛИРУЕТСЯ: из виртуальной базы вниз");
    std::puts("  статически нельзя, компилятор не знает смещения.");
}

// --- 7. Цена ---------------------------------------------------------------------------
struct FinalD final : A
{
    void f() override {}
};

void scenario_cost()
{
    std::puts("\n=== 7. Чем это стоит ===");
    std::puts("  память: +8 байт на объект за каждый vptr (у M их два — +16).");
    std::puts("  вызов: загрузка vptr + загрузка слота + indirect call. Две зависимые");
    std::puts("         загрузки в критическом пути и предсказатель ветвлений на indirect.");
    std::puts("  инлайнинг: через указатель невозможен, пока компилятор не доказал тип.");
    std::puts("  final/по значению/девиртуализация через if по enum — обычные ответы");
    std::puts("  на 'как убрать виртуальность в low-latency коде'.");
    std::puts("  тип с виртуальными функциями перестаёт быть тривиально копируемым:");
    std::printf("    is_trivially_copyable<A> = %d, <FinalD> = %d\n",
                __is_trivially_copyable(A), __is_trivially_copyable(FinalD));
    std::puts("    значит memcpy объекта между процессами/по сети ломает vptr.");
}

}   // namespace

int main()
{
    std::puts("Раскладка vtable, GCC/Itanium ABI, x86-64.");
    scenario_sizes();
    scenario_single();
    scenario_multiple();
    scenario_casts();
    scenario_construction();
    scenario_virtual_base();
    scenario_cost();
    std::puts("\nГотово. Полная раскладку от компилятора: -fdump-lang-class=layout.txt");
    return 0;
}
