// std::memory_order и барьеры памяти: проверка утверждений конспекта
// doc/01-general-topics/22-memory-order-and-fences.md на этой машине.
//
// Сборка и запуск:
//   g++ -std=c++20 -Wall -Wextra -O2 -pthread -o memory_order_demo memory_order_demo.cxx
//   ./memory_order_demo              — все корректные сценарии, litmus-тесты и замеры
//   ./memory_order_demo unsafe       — плюс НАМЕРЕННО некорректные сценарии (гонки, UB)
//   ./memory_order_demo quick        — меньше итераций (для быстрой проверки)
//
// Под ThreadSanitizer (только корректные сценарии; unsafe под TSan не запускается):
//   g++ -std=c++20 -Wall -Wextra -O1 -g -fsanitize=thread -pthread -o memory_order_demo_tsan memory_order_demo.cxx
//   ./memory_order_demo_tsan
//   GCC выдаст предупреждения -Wtsan: «'atomic_thread_fence' is not supported with
//   '-fsanitize=thread'». Это само по себе факт из конспекта (раздел 13): TSan не
//   моделирует отдельные барьеры. Поэтому под TSan сценарии, где барьер защищает
//   неатомарные данные, заменены вариантом без барьера или пропущены — иначе TSan
//   сообщил бы ложную гонку.
//
// Замечание про litmus-тесты. Исход, который модель памяти РАЗРЕШАЕТ, не обязан
// наблюдаться: железо x86 сильнее, чем требует C++ для relaxed. Ноль в счётчике —
// это «на этой машине не видно», а не «гарантировано стандартом».

#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <memory>
#include <new>
#include <pthread.h>
#include <sched.h>
#include <thread>
#include <type_traits>
#include <vector>
#if defined(__x86_64__)
#include <immintrin.h>
#endif

#if defined(__SANITIZE_THREAD__)
constexpr bool kTsan = true;
#else
constexpr bool kTsan = false;
#endif

namespace {

using clk = std::chrono::steady_clock;
constexpr auto relaxed = std::memory_order_relaxed;
constexpr auto acquire = std::memory_order_acquire;
constexpr auto release = std::memory_order_release;
constexpr auto acq_rel = std::memory_order_acq_rel;
constexpr auto seq_cst = std::memory_order_seq_cst;

bool g_quick = false;

inline void cpu_relax() {
#if defined(__x86_64__)
    _mm_pause();                       // PAUSE: подсказка ядру «я кручусь в цикле ожидания»
#endif
}

// Привязка текущего потока к ядру. Под WSL2 работает (проверено), но виртуальные
// CPU гипервизора не обязаны совпадать с физическими ядрами один к одному.
bool pin(int cpu) {
    cpu_set_t s;
    CPU_ZERO(&s);
    CPU_SET(cpu % static_cast<int>(std::thread::hardware_concurrency()), &s);
    return pthread_setaffinity_np(pthread_self(), sizeof s, &s) == 0;
}

// Снять привязку: новые потоки наследуют маску CPU родителя, поэтому главный поток
// после замеров с привязкой обязан её снять, иначе все следующие потоки окажутся
// на одном ядре.
void unpin() {
    cpu_set_t all;
    CPU_ZERO(&all);
    for (unsigned c = 0; c < std::thread::hardware_concurrency(); ++c) CPU_SET(c, &all);
    pthread_setaffinity_np(pthread_self(), sizeof all, &all);
}

void header(const char* title) { std::printf("\n=== %s ===\n", title); }

// ---------------------------------------------------------------------------
// Каркас litmus-теста. NT потоков, n итераций. На каждой итерации все потоки
// встречаются на барьере-счётчике и сразу выполняют своё тело body(tid, i).
// Переменные теста — свежие ячейки массивов на каждой итерации, поэтому их не нужно
// обнулять между итерациями, и прошлые итерации не мешают следующим.
// ---------------------------------------------------------------------------
template <class Body>
void run_litmus(int nt, std::size_t n, const int* cpus, Body body) {
    alignas(64) std::atomic<std::uint64_t> arrive{0};
    std::vector<std::thread> ts;
    for (int t = 0; t < nt; ++t) {
        ts.emplace_back([&, t] {
            if (cpus) pin(cpus[t]);
            for (std::size_t i = 0; i < n; ++i) {
                arrive.fetch_add(1, acq_rel);
                const std::uint64_t target = static_cast<std::uint64_t>(nt) * (i + 1);
                while (arrive.load(acquire) < target) cpu_relax();
                body(t, i);
            }
        });
    }
    for (auto& t : ts) t.join();
}

const int kCpus[4] = {2, 5, 9, 14};

std::size_t iters(std::size_t full) {
    if (kTsan) return full / 100;
    return g_quick ? full / 10 : full;
}

// ------------------------------- 1. Окружение ------------------------------
struct Q16 { double bid, ask; };
struct S3 { char a, b, c; };
struct S6 { std::int32_t a; std::int16_t b; };

// is_lock_free() намеренно не вызывается: для не-lock-free T он зовёт
// __atomic_is_lock_free из libatomic, и без -latomic линковка падает
// («undefined reference to `__atomic_is_lock_free'»).
template <class T>
void show_atomic(const char* name) {
    std::printf("  %-12s sizeof(T)=%2zu alignof(T)=%2zu alignof(atomic<T>)=%2zu is_always_lock_free=%d\n",
                name, sizeof(T), alignof(T), alignof(std::atomic<T>),
                static_cast<int>(std::atomic<T>::is_always_lock_free));
}

void scenario_env() {
    header("1. Окружение и lock-free");
    std::printf("  hardware_concurrency=%u\n", std::thread::hardware_concurrency());
    show_atomic<bool>("bool");
    show_atomic<int>("int");
    show_atomic<long>("long");
    show_atomic<void*>("void*");
    show_atomic<S3>("S3{3xchar}");
    show_atomic<S6>("S6{i32,i16}");
    show_atomic<Q16>("Q16{2xdbl}");
    std::printf("  hardware_destructive_interference_size=%zu constructive=%zu\n",
                std::hardware_destructive_interference_size,
                std::hardware_constructive_interference_size);
    std::printf("  atomic_ref<int>::required_alignment=%zu, atomic_ref<Q16>::required_alignment=%zu\n",
                std::atomic_ref<int>::required_alignment, std::atomic_ref<Q16>::required_alignment);
    std::printf("  pthread_setaffinity_np: %s\n", pin(0) ? "работает" : "НЕ работает");
    unpin();
}

// ------------------------- 2. Store buffering (Dekker) ----------------------
//   T0: X = 1; r0 = Y        T1: Y = 1; r1 = X
//   Исход r0 == 0 && r1 == 0 разрешён для relaxed и acquire/release,
//   запрещён для seq_cst (и для relaxed + fence(seq_cst) между store и load).
enum class Sb { Relaxed, AcqRel, SeqCst, FenceSeqCst };

std::size_t litmus_sb(Sb v, std::size_t n) {
    std::vector<std::atomic<int>> X(n), Y(n);
    std::vector<int> r0(n), r1(n);
    run_litmus(2, n, kCpus, [&](int t, std::size_t i) {
        std::atomic<int>& mine = t == 0 ? X[i] : Y[i];
        std::atomic<int>& other = t == 0 ? Y[i] : X[i];
        int r = 0;
        switch (v) {
        case Sb::Relaxed:     mine.store(1, relaxed); r = other.load(relaxed); break;
        case Sb::AcqRel:      mine.store(1, release); r = other.load(acquire); break;
        case Sb::SeqCst:      mine.store(1, seq_cst); r = other.load(seq_cst); break;
        case Sb::FenceSeqCst: mine.store(1, relaxed);
                              std::atomic_thread_fence(seq_cst);
                              r = other.load(relaxed); break;
        }
        (t == 0 ? r0 : r1)[i] = r;
    });
    std::size_t both_zero = 0;
    for (std::size_t i = 0; i < n; ++i) both_zero += (r0[i] == 0 && r1[i] == 0);
    return both_zero;
}

void scenario_sb() {
    header("2. Store buffering: r0==0 && r1==0");
    const std::size_t n = iters(2'000'000);
    struct { Sb v; const char* name; } vs[] = {
        {Sb::Relaxed, "relaxed store / relaxed load"},
        {Sb::AcqRel, "release store / acquire load"},
        {Sb::SeqCst, "seq_cst store / seq_cst load"},
        {Sb::FenceSeqCst, "relaxed + fence(seq_cst) + relaxed"},
    };
    for (auto& x : vs) {
        const std::size_t c = litmus_sb(x.v, n);
        std::printf("  %-36s %9zu из %zu (%.3f%%)\n", x.name, c, n, 100.0 * c / n);
    }
}

// ------------------------- 3. Message passing ------------------------------
//   T0: D = 1; F = 1          T1: r0 = F; r1 = D
//   Запрещённый для release/acquire исход: r0 == 1 && r1 == 0.
//   Для relaxed он разрешён стандартом. На x86 (TSO) железо его не показывает.
std::size_t litmus_mp_relaxed(std::size_t n) {
    std::vector<std::atomic<int>> D(n), F(n);
    std::vector<int> r0(n), r1(n);
    run_litmus(2, n, kCpus, [&](int t, std::size_t i) {
        if (t == 0) {
            D[i].store(1, relaxed);
            F[i].store(1, relaxed);
        } else {
            r0[i] = F[i].load(relaxed);
            r1[i] = D[i].load(relaxed);
        }
    });
    std::size_t bad = 0, seen = 0;
    for (std::size_t i = 0; i < n; ++i) {
        seen += r0[i] == 1;
        bad += (r0[i] == 1 && r1[i] == 0);
    }
    std::printf("  relaxed MP: флаг увиден в %zu итерациях, из них данные НЕ видны: %zu (n=%zu)\n",
                seen, bad, n);
    return bad;
}

// Корректная публикация неатомарных данных через release/acquire.
struct Payload { long a, b, c; };

void mp_release_acquire(std::size_t rounds) {
    std::size_t bad = 0;
    for (std::size_t k = 0; k < rounds; ++k) {
        Payload p{};
        std::atomic<bool> ready{false};
        std::thread w([&] {
            p.a = 1; p.b = 2; p.c = 3;             // обычные записи
            ready.store(true, release);            // публикация
        });
        while (!ready.load(acquire)) cpu_relax();  // парное чтение
        bad += !(p.a == 1 && p.b == 2 && p.c == 3);
        w.join();
    }
    std::printf("  release/acquire MP с неатомарными данными: нарушений %zu из %zu\n", bad, rounds);
}

// То же через барьеры. Под TSan пропускается: TSan не понимает atomic_thread_fence
// и сообщил бы ложную гонку на p (проверено отдельно, см. конспект, раздел 13).
void mp_fences(std::size_t rounds) {
    if (kTsan) {
        std::printf("  fence-публикация: пропущено под TSan (ложное срабатывание на fence)\n");
        return;
    }
    std::size_t bad = 0;
    for (std::size_t k = 0; k < rounds; ++k) {
        Payload p{};
        std::atomic<bool> ready{false};
        std::thread w([&] {
            p.a = 1; p.b = 2; p.c = 3;
            std::atomic_thread_fence(release);
            ready.store(true, relaxed);
        });
        while (!ready.load(relaxed)) cpu_relax();
        std::atomic_thread_fence(acquire);
        bad += !(p.a == 1 && p.b == 2 && p.c == 3);
        w.join();
    }
    std::printf("  fence(release)+relaxed / relaxed+fence(acquire): нарушений %zu из %zu\n", bad, rounds);
}

void scenario_mp() {
    header("3. Message passing");
    litmus_mp_relaxed(iters(2'000'000));
    mp_release_acquire(kTsan ? 200 : 2000);
    mp_fences(kTsan ? 200 : 2000);
}

// ------------------------- 4. Load buffering -------------------------------
//   T0: r0 = X; Y = 1          T1: r1 = Y; X = 1
//   Исход r0 == 1 && r1 == 1 разрешён для relaxed. x86 не переставляет load->store.
void scenario_lb() {
    header("4. Load buffering: r0==1 && r1==1");
    const std::size_t n = iters(2'000'000);
    std::vector<std::atomic<int>> X(n), Y(n);
    std::vector<int> r0(n), r1(n);
    run_litmus(2, n, kCpus, [&](int t, std::size_t i) {
        if (t == 0) { r0[i] = X[i].load(relaxed); Y[i].store(1, relaxed); }
        else        { r1[i] = Y[i].load(relaxed); X[i].store(1, relaxed); }
    });
    std::size_t c = 0;
    for (std::size_t i = 0; i < n; ++i) c += (r0[i] == 1 && r1[i] == 1);
    std::printf("  relaxed: %zu из %zu\n", c, n);
}

// ------------------------- 5. IRIW ----------------------------------------
//   W0: X = 1     W1: Y = 1     R2: a = X; b = Y     R3: c = Y; d = X
//   Исход a==1,b==0,c==1,d==0 (читатели увидели записи в разном порядке)
//   разрешён для relaxed и acquire, запрещён для seq_cst.
//   x86 «multi-copy atomic»: запись становится видна всем другим ядрам одновременно.
void scenario_iriw() {
    header("5. IRIW: читатели не согласны о порядке двух независимых записей");
    const std::size_t n = iters(1'000'000);
    std::vector<std::atomic<int>> X(n), Y(n);
    std::vector<int> a(n), b(n), c(n), d(n);
    run_litmus(4, n, kCpus, [&](int t, std::size_t i) {
        switch (t) {
        case 0: X[i].store(1, relaxed); break;
        case 1: Y[i].store(1, relaxed); break;
        case 2: a[i] = X[i].load(acquire); b[i] = Y[i].load(acquire); break;
        case 3: c[i] = Y[i].load(acquire); d[i] = X[i].load(acquire); break;
        }
    });
    std::size_t bad = 0, r2_first = 0, r3_first = 0;
    for (std::size_t i = 0; i < n; ++i) {
        bad += (a[i] == 1 && b[i] == 0 && c[i] == 1 && d[i] == 0);
        r2_first += (a[i] == 1 && b[i] == 0);
        r3_first += (c[i] == 1 && d[i] == 0);
    }
    std::printf("  acquire-чтения: запрещённый для seq_cst исход %zu из %zu "
                "(R2 видел только X: %zu, R3 видел только Y: %zu)\n",
                bad, n, r2_first, r3_first);
}

// ------------------------- 6. 2+2W ----------------------------------------
//   T0: X = 1; Y = 2          T1: Y = 1; X = 2
//   Итог X == 1 && Y == 1 означает, что обе вторые записи «проиграли» в modification
//   order своих переменных: цикл «X=1 до Y=2 до Y=1 до X=2 до X=1».
//   Стандарт C++ разрешает его для relaxed и даже для release-записей (между потоками
//   нет ни одного чтения, значит нет happens-before). Запрещает только seq_cst.
//   x86 не переставляет store-store, поэтому железо его не покажет.
void scenario_2p2w() {
    header("6. 2+2W: итог X==1 && Y==1");
    const std::size_t n = iters(2'000'000);
    std::vector<std::atomic<int>> X(n), Y(n);
    run_litmus(2, n, kCpus, [&](int t, std::size_t i) {
        if (t == 0) { X[i].store(1, relaxed); Y[i].store(2, relaxed); }
        else        { Y[i].store(1, relaxed); X[i].store(2, relaxed); }
    });
    std::size_t c = 0;
    for (std::size_t i = 0; i < n; ++i) c += (X[i].load(relaxed) == 1 && Y[i].load(relaxed) == 1);
    std::printf("  relaxed: %zu из %zu\n", c, n);
}

// ------------------------- 6b. WRC -----------------------------------------
//   T0: X = 1     T1: r0 = X; Y = 1     T2: r1 = Y; r2 = X
//   Исход r0==1, r1==1, r2==0 — нарушение транзитивности (write-to-read causality).
//   Разрешён для relaxed, запрещён для release/acquire (happens-before транзитивно).
void scenario_wrc() {
    header("6b. WRC: r0==1 && r1==1 && r2==0");
    const std::size_t n = iters(1'000'000);
    std::vector<std::atomic<int>> X(n), Y(n);
    std::vector<int> r0(n), r1(n), r2(n);
    run_litmus(3, n, kCpus, [&](int t, std::size_t i) {
        switch (t) {
        case 0: X[i].store(1, relaxed); break;
        case 1: r0[i] = X[i].load(relaxed); Y[i].store(1, relaxed); break;
        case 2: r1[i] = Y[i].load(relaxed); r2[i] = X[i].load(relaxed); break;
        }
    });
    std::size_t bad = 0, chain = 0;
    for (std::size_t i = 0; i < n; ++i) {
        chain += (r0[i] == 1 && r1[i] == 1);
        bad += (r0[i] == 1 && r1[i] == 1 && r2[i] == 0);
    }
    std::printf("  relaxed: цепочка X->T1->Y->T2 случилась %zu раз, из них T2 не увидел X: %zu (n=%zu)\n",
                chain, bad, n);
}

// ------------------------- 7. Когерентность -------------------------------
//   CoRR: T0: X = 1           T1: r0 = X; r1 = X
//   Исход r0 == 1 && r1 == 0 запрещён ДАЖЕ для relaxed: read-read coherence.
void scenario_coherence() {
    header("7. Когерентность CoRR: r0==1 && r1==0 (запрещено для всех порядков)");
    const std::size_t n = iters(2'000'000);
    std::vector<std::atomic<int>> X(n);
    std::vector<int> r0(n), r1(n);
    run_litmus(2, n, kCpus, [&](int t, std::size_t i) {
        if (t == 0) X[i].store(1, relaxed);
        else { r0[i] = X[i].load(relaxed); r1[i] = X[i].load(relaxed); }
    });
    std::size_t bad = 0, mid = 0;
    for (std::size_t i = 0; i < n; ++i) {
        bad += (r0[i] == 1 && r1[i] == 0);
        mid += (r0[i] == 0 && r1[i] == 1);
    }
    std::printf("  relaxed: запрещённый исход %zu, «запись попала между чтениями» %zu, n=%zu\n",
                bad, mid, n);
}

// ------------------------- 8. Цена операций --------------------------------
std::atomic<long> g_x{0};
long g_sink = 0;

// Если f возвращает значение, оно копится в локальной переменной: её адрес никуда
// не утекает, поэтому она живёт в регистре и не создаёт цепочку через память.
template <class F>
double ns_per_op(long n, F f) {
    const auto t0 = clk::now();
    if constexpr (std::is_void_v<decltype(f(0L))>) {
        for (long i = 0; i < n; ++i) f(i);
    } else {
        long s = 0;
        for (long i = 0; i < n; ++i) s += f(i);
        g_sink += s;
    }
    const auto t1 = clk::now();
    return std::chrono::duration<double, std::nano>(t1 - t0).count() / static_cast<double>(n);
}

void scenario_cost() {
    header("8. Цена операций, один поток, линия в L1 (нс на операцию, пропускная способность)");
    if (kTsan) { std::printf("  пропущено под TSan\n"); return; }
    const long n = g_quick ? 20'000'000 : 100'000'000;
    struct Row { const char* name; double ns; };
    std::vector<Row> rows;
    auto add = [&](const char* name, auto f) {
        ns_per_op(n / 10, f);                       // прогрев
        double best = 1e9;
        for (int k = 0; k < 3; ++k) best = std::min(best, ns_per_op(n, f));
        rows.push_back({name, best});
    };
    add("empty loop (asm memory barrier)", [](long) { asm volatile("" ::: "memory"); });
    add("store relaxed        mov", [](long i) { g_x.store(i, relaxed); });
    add("store release        mov", [](long i) { g_x.store(i, release); });
    add("store seq_cst        xchg", [](long i) { g_x.store(i, seq_cst); });
#if defined(__x86_64__)
    add("store relaxed+mfence mov;mfence", [](long i) {
        g_x.store(i, relaxed);
        asm volatile("mfence" ::: "memory");
    });
#endif
    add("load relaxed         mov", [](long) { return g_x.load(relaxed); });
    add("load acquire         mov", [](long) { return g_x.load(acquire); });
    add("load seq_cst         mov", [](long) { return g_x.load(seq_cst); });
    add("fetch_add relaxed    lock xadd", [](long) { return g_x.fetch_add(1, relaxed); });
    add("fetch_add seq_cst    lock xadd", [](long) { return g_x.fetch_add(1, seq_cst); });
    add("exchange relaxed     xchg", [](long i) { return g_x.exchange(i, relaxed); });
    add("CAS strong, success  lock cmpxchg", [](long i) {
        long e = g_x.load(relaxed);
        return static_cast<long>(g_x.compare_exchange_strong(e, i, acq_rel, acquire));
    });
    add("fence acquire        (nothing)", [](long) { std::atomic_thread_fence(acquire); });
    add("fence release        (nothing)", [](long) { std::atomic_thread_fence(release); });
    add("fence seq_cst        lock orq", [](long) { std::atomic_thread_fence(seq_cst); });
#if defined(__x86_64__)
    add("asm mfence", [](long) { asm volatile("mfence" ::: "memory"); });
    add("asm lfence", [](long) { asm volatile("lfence" ::: "memory"); });
    add("asm sfence", [](long) { asm volatile("sfence" ::: "memory"); });
#endif
    for (auto& r : rows) std::printf("  %-34s %6.2f нс\n", r.name, r.ns);
    std::printf("  (sink=%ld)\n", g_sink);
}

// -------------------- 9. Межъядерные замеры --------------------------------
struct alignas(64) PaddedLong { std::atomic<long> v{0}; };

template <bool Pause>
double pingpong(int ca, int cb, long n, bool do_pin) {
    PaddedLong cell;
    std::thread t([&] {
        if (do_pin) pin(cb);
        for (long k = 0; k < n; ++k) {
            while (cell.v.load(acquire) != 2 * k + 1) if (Pause) cpu_relax();
            cell.v.store(2 * k + 2, release);
        }
    });
    if (do_pin) pin(ca);
    const auto t0 = clk::now();
    for (long k = 0; k < n; ++k) {
        while (cell.v.load(acquire) != 2 * k) if (Pause) cpu_relax();
        cell.v.store(2 * k + 1, release);
    }
    while (cell.v.load(acquire) != 2 * n) cpu_relax();
    const auto t1 = clk::now();
    t.join();
    unpin();
    return std::chrono::duration<double, std::nano>(t1 - t0).count() / static_cast<double>(n);
}

// Пинг-понг через wait/notify (C++20): поток спит в futex, а не крутится.
double pingpong_wait(long n) {
    PaddedLong cell;
    std::thread t([&] {
        for (long k = 0; k < n; ++k) {
            cell.v.wait(2 * k, acquire);          // ждём, пока значение != 2k
            cell.v.store(2 * k + 2, release);
            cell.v.notify_one();
        }
    });
    const auto t0 = clk::now();
    for (long k = 0; k < n; ++k) {
        cell.v.store(2 * k + 1, release);
        cell.v.notify_one();
        cell.v.wait(2 * k + 1, acquire);
    }
    const auto t1 = clk::now();
    t.join();
    return std::chrono::duration<double, std::nano>(t1 - t0).count() / static_cast<double>(n);
}

struct TwoCounters { std::atomic<long> a{0}; std::atomic<long> b{0}; };           // одна линия
struct TwoPadded { alignas(64) std::atomic<long> a{0}; alignas(64) std::atomic<long> b{0}; };

template <class Fa, class Fb>
double two_threads(long n, Fa fa, Fb fb) {
    const auto t0 = clk::now();
    std::thread t1([&] { pin(kCpus[0]); for (long i = 0; i < n; ++i) fa(); });
    std::thread t2([&] { pin(kCpus[1]); for (long i = 0; i < n; ++i) fb(); });
    t1.join(); t2.join();
    const auto t1e = clk::now();
    return std::chrono::duration<double, std::nano>(t1e - t0).count() / static_cast<double>(n);
}

void scenario_intercore() {
    header("9. Межъядерные замеры");
    if (kTsan) { std::printf("  пропущено под TSan\n"); return; }
    const long n = g_quick ? 100'000 : 1'000'000;
    std::printf("  пинг-понг release/acquire, ядра %d<->%d, спин с pause:    %.1f нс на круг\n",
                kCpus[0], kCpus[1], pingpong<true>(kCpus[0], kCpus[1], n, true));
    std::printf("  пинг-понг release/acquire, ядра %d<->%d, спин без pause:  %.1f нс на круг\n",
                kCpus[0], kCpus[1], pingpong<false>(kCpus[0], kCpus[1], n, true));
    std::printf("  пинг-понг release/acquire, без привязки, с pause:     %.1f нс на круг\n",
                pingpong<true>(0, 0, n, false));
    std::printf("  пинг-понг через atomic::wait/notify_one:          %.1f нс на круг\n",
                pingpong_wait(n / 10));
    const long m = g_quick ? 2'000'000 : 20'000'000;
    PaddedLong shared;
    TwoCounters same;
    TwoPadded padded;
    const double t_shared = two_threads(m, [&] { shared.v.fetch_add(1, relaxed); },
                                           [&] { shared.v.fetch_add(1, relaxed); });
    const double t_false = two_threads(m, [&] { same.a.fetch_add(1, relaxed); },
                                          [&] { same.b.fetch_add(1, relaxed); });
    const double t_pad = two_threads(m, [&] { padded.a.fetch_add(1, relaxed); },
                                        [&] { padded.b.fetch_add(1, relaxed); });
    std::printf("  2 потока x %ld fetch_add(relaxed):\n", m);
    std::printf("    один счётчик на двоих:            %6.2f нс на операцию потока (итог %ld)\n",
                t_shared, shared.v.load());
    std::printf("    два счётчика в одной линии:       %6.2f нс  (false sharing)\n", t_false);
    std::printf("    два счётчика в разных линиях:     %6.2f нс\n", t_pad);
}

// ------------------------- 10. Паттерны ------------------------------------

// 10.1 TTAS spinlock
class Spinlock {
    std::atomic<bool> locked_{false};
public:
    void lock() {
        for (;;) {
            if (!locked_.exchange(true, acquire)) return;          // test-and-set
            while (locked_.load(relaxed)) cpu_relax();             // test: ждём чтением
        }
    }
    void unlock() { locked_.store(false, release); }
};

void pattern_spinlock() {
    Spinlock sl;
    long counter = 0;                                   // обычная переменная под замком
    const int nt = 4;
    const long per = kTsan ? 20'000 : 1'000'000;
    std::vector<std::thread> ts;
    for (int t = 0; t < nt; ++t)
        ts.emplace_back([&] { for (long i = 0; i < per; ++i) { sl.lock(); ++counter; sl.unlock(); } });
    for (auto& t : ts) t.join();
    std::printf("  TTAS spinlock: %d потоков x %ld инкрементов = %ld (ожидалось %ld)\n",
                nt, per, counter, nt * per);
}

// 10.1b Замок Петерсона: классика, которой нужен store-load порядок.
// Счётчик внутри — atomic с ОТДЕЛЬНЫМИ relaxed load и store: гонки данных нет (TSan молчит),
// но если замок пропустит в секцию оба потока, инкременты потеряются.
template <std::memory_order StoreMo, std::memory_order LoadMo>
long peterson_run(long per) {
    struct alignas(64) Flag { std::atomic<bool> v{false}; };
    Flag want[2];
    alignas(64) std::atomic<int> turn{0};
    alignas(64) std::atomic<long> counter{0};
    auto body = [&](int me) {
        pin(kCpus[me]);
        const int other = 1 - me;
        for (long i = 0; i < per; ++i) {
            want[me].v.store(true, StoreMo);              // «хочу войти»
            turn.store(other, StoreMo);                   // «уступаю»
            while (want[other].v.load(LoadMo) && turn.load(LoadMo) == other) cpu_relax();
            counter.store(counter.load(relaxed) + 1, relaxed);   // не RMW намеренно
            want[me].v.store(false, release);             // выход
        }
    };
    std::thread a(body, 0), b(body, 1);
    a.join(); b.join();
    return 2 * per - counter.load();
}

void pattern_peterson() {
    const long per = kTsan ? 20'000 : 2'000'000;
    std::printf("  Петерсон, seq_cst:          потеряно %ld из %ld инкрементов\n",
                peterson_run<seq_cst, seq_cst>(per), 2 * per);
    std::printf("  Петерсон, release/acquire:  потеряно %ld из %ld инкрементов\n",
                peterson_run<release, acquire>(per), 2 * per);
}

// 10.2 SPSC ring buffer
template <class T, std::size_t N>
class SpscRing {
    static_assert((N & (N - 1)) == 0, "N — степень двойки");
    alignas(64) std::atomic<std::size_t> head_{0};   // пишет только consumer
    alignas(64) std::size_t cached_tail_ = 0;        // только consumer
    alignas(64) std::atomic<std::size_t> tail_{0};   // пишет только producer
    alignas(64) std::size_t cached_head_ = 0;        // только producer
    alignas(64) T buf_[N];
public:
    bool push(const T& v) {
        const std::size_t t = tail_.load(relaxed);               // своя переменная
        if (t - cached_head_ == N) {                             // по кэшу полно
            cached_head_ = head_.load(acquire);                  // чужая: acquire
            if (t - cached_head_ == N) return false;
        }
        buf_[t & (N - 1)] = v;
        tail_.store(t + 1, release);                             // публикуем элемент
        return true;
    }
    bool pop(T& out) {
        const std::size_t h = head_.load(relaxed);
        if (h == cached_tail_) {
            cached_tail_ = tail_.load(acquire);
            if (h == cached_tail_) return false;
        }
        out = buf_[h & (N - 1)];
        head_.store(h + 1, release);                             // отдаём слот
        return true;
    }
};

void pattern_spsc() {
    auto q = std::make_unique<SpscRing<long, 1024>>();
    const long n = kTsan ? 200'000 : (g_quick ? 2'000'000 : 20'000'000);
    long bad = 0;
    const auto t0 = clk::now();
    std::thread prod([&] { pin(kCpus[0]); for (long i = 0; i < n; ++i) while (!q->push(i)) cpu_relax(); });
    std::thread cons([&] {
        pin(kCpus[1]);
        for (long i = 0; i < n; ++i) {
            long v;
            while (!q->pop(v)) cpu_relax();
            bad += v != i;
        }
    });
    prod.join(); cons.join();
    const double s = std::chrono::duration<double>(clk::now() - t0).count();
    std::printf("  SPSC ring: %ld элементов, нарушений порядка %ld, %.1f млн эл/с\n",
                n, bad, n / s / 1e6);
}

// 10.3 Seqlock: один писатель, много читателей, данные — atomic relaxed.
class SeqLock {
    std::atomic<unsigned> seq_{0};
    std::atomic<long> a_{0}, b_{0};
public:
    void write(long v) {                                         // только один писатель
        const unsigned s = seq_.load(relaxed);
        seq_.store(s + 1, relaxed);                              // нечётное: идёт запись
        std::atomic_thread_fence(release);                       // (W) seq+1 не уедет ниже данных
        a_.store(v, relaxed);
        b_.store(2 * v, relaxed);
        seq_.store(s + 2, release);                              // данные не уедут ниже
    }
    bool try_read(long& a, long& b) const {
        const unsigned s1 = seq_.load(acquire);                  // данные не всплывут выше
        if (s1 & 1) return false;
        a = a_.load(relaxed);
        b = b_.load(relaxed);
        std::atomic_thread_fence(acquire);                       // (R) данные не уедут ниже s2
        const unsigned s2 = seq_.load(relaxed);
        return s1 == s2;
    }
};

void pattern_seqlock() {
    SeqLock sl;
    std::atomic<bool> stop{false};
    const int readers = 3;
    std::vector<long> ok(readers), retry(readers), torn(readers);
    std::vector<std::thread> ts;
    for (int r = 0; r < readers; ++r)
        ts.emplace_back([&, r] {
            pin(kCpus[1 + r]);
            while (!stop.load(relaxed)) {
                long a, b;
                if (sl.try_read(a, b)) { ++ok[r]; torn[r] += (b != 2 * a); }
                else ++retry[r];
            }
        });
    std::thread w([&] {
        pin(kCpus[0]);
        const long n = kTsan ? 100'000 : 5'000'000;
        for (long v = 1; v <= n; ++v) sl.write(v);
        stop.store(true, relaxed);
    });
    w.join();
    for (auto& t : ts) t.join();
    long o = 0, re = 0, to = 0;
    for (int r = 0; r < readers; ++r) { o += ok[r]; re += retry[r]; to += torn[r]; }
    std::printf("  seqlock: успешных чтений %ld, повторов %ld, рваных чтений %ld\n", o, re, to);
}

// 10.4 Счётчик ссылок как в shared_ptr.
struct RcObj {
    std::atomic<int> rc;
    long slot[8];                                                // обычные данные
};

void rc_release(RcObj* o, int nt, std::atomic<long>& bad) {
    if constexpr (kTsan) {
        // TSan не понимает fence(acquire), поэтому acq_rel на самом декременте.
        if (o->rc.fetch_sub(1, acq_rel) == 1) {
            for (int t = 0; t < nt; ++t) bad += o->slot[t] != t + 1;
            delete o;
        }
    } else {
        if (o->rc.fetch_sub(1, release) == 1) {                  // release: мои записи в объект — до
            std::atomic_thread_fence(acquire);                   // acquire: чужие записи видны мне
            for (int t = 0; t < nt; ++t) bad += o->slot[t] != t + 1;
            delete o;
        }
    }
}

void pattern_refcount() {
    const int nt = 8;
    const int rounds = kTsan ? 300 : 20'000;
    std::atomic<long> bad{0};
    std::atomic<RcObj*> cur{nullptr};
    std::atomic<int> round_seen{-1};
    std::vector<std::thread> ts;
    std::atomic<int> done{0};
    for (int t = 0; t < nt; ++t)
        ts.emplace_back([&, t] {
            for (int k = 0; k < rounds; ++k) {
                while (round_seen.load(acquire) < k) cpu_relax();
                RcObj* o = cur.load(acquire);
                o->slot[t] = t + 1;                              // пишем в объект до своего release
                rc_release(o, nt, bad);
                done.fetch_add(1, relaxed);
            }
        });
    for (int k = 0; k < rounds; ++k) {
        RcObj* o = new RcObj{};
        o->rc.store(nt, relaxed);                                // по ссылке на каждый поток
        cur.store(o, release);
        round_seen.store(k, release);
        while (done.load(relaxed) < nt * (k + 1)) cpu_relax();   // ждём конца раунда
    }
    for (auto& t : ts) t.join();
    std::printf("  refcount (release-декремент + fence acquire%s): %d объектов, "
                "удаливший поток не увидел чужую запись %ld раз\n",
                kTsan ? ", под TSan acq_rel" : "", rounds, bad.load());
}

// 10.5 DCLP
struct Config { long v[4]{1, 2, 3, 4}; };
std::atomic<Config*> g_cfg{nullptr};
std::atomic<int> g_cfg_ctor{0};
Spinlock g_cfg_lock;

Config& get_config() {
    Config* c = g_cfg.load(acquire);                    // быстрый путь
    if (!c) {
        g_cfg_lock.lock();
        c = g_cfg.load(relaxed);                        // под замком хватает relaxed
        if (!c) {
            g_cfg_ctor.fetch_add(1, relaxed);
            c = new Config();
            g_cfg.store(c, release);                    // публикация построенного объекта
        }
        g_cfg_lock.unlock();
    }
    return *c;
}

void pattern_dclp() {
    std::vector<std::thread> ts;
    std::atomic<long> sum{0};
    std::atomic<bool> go{false};
    for (int t = 0; t < 16; ++t)
        ts.emplace_back([&] {
            while (!go.load(acquire)) cpu_relax();
            const Config& c = get_config();
            sum.fetch_add(c.v[0] + c.v[1] + c.v[2] + c.v[3], relaxed);
        });
    go.store(true, release);
    for (auto& t : ts) t.join();
    std::printf("  DCLP: 16 потоков, конструктор вызван %d раз, сумма полей %ld (ожидалось 160)\n",
                g_cfg_ctor.load(), sum.load());
    delete g_cfg.exchange(nullptr);
}

// 10.6 Флаг остановки и статистические счётчики: relaxed достаточно.
void pattern_stop_and_stats() {
    std::atomic<bool> stop{false};
    std::atomic<long> stat{0};                           // статистика: только атомарность
    long local_total = 0;                                // передаётся через join
    std::thread w([&] {
        long k = 0;
        while (!stop.load(relaxed)) { ++k; stat.fetch_add(1, relaxed); }
        local_total = k;
    });
    std::this_thread::sleep_for(std::chrono::milliseconds(20));
    stop.store(true, relaxed);
    w.join();                                            // join синхронизирует: local_total виден
    std::printf("  stop-флаг relaxed: поток остановился, итераций %ld, stat=%ld, совпадают: %s\n",
                local_total, stat.load(relaxed), local_total == stat.load(relaxed) ? "да" : "нет");

    std::atomic<long> hits{0};
    std::vector<std::thread> ts;
    const long per = kTsan ? 20'000 : 1'000'000;
    for (int t = 0; t < 8; ++t)
        ts.emplace_back([&] { for (long i = 0; i < per; ++i) hits.fetch_add(1, relaxed); });
    for (auto& t : ts) t.join();
    std::printf("  статистический счётчик: 8 x %ld fetch_add(relaxed) = %ld\n", per, hits.load());
}

// 10.7 RMW читает последнее значение: fetch_add раздаёт уникальные номера.
void pattern_rmw_unique() {
    const int nt = 8;
    const long per = kTsan ? 10'000 : 500'000;
    std::atomic<long> ticket{0};
    std::vector<std::vector<long>> got(nt);
    std::vector<std::thread> ts;
    for (int t = 0; t < nt; ++t)
        ts.emplace_back([&, t] {
            got[t].reserve(per);
            for (long i = 0; i < per; ++i) got[t].push_back(ticket.fetch_add(1, relaxed));
        });
    for (auto& t : ts) t.join();
    std::vector<char> seen(nt * per, 0);
    long dup = 0;
    for (auto& v : got) for (long x : v) dup += seen[x]++ != 0;
    std::printf("  fetch_add(relaxed) из %d потоков: выдано %ld номеров, повторов %ld\n",
                nt, nt * per, dup);
}

// 10.8 compare_exchange_weak без конкуренции: бывают ли ложные отказы на x86?
void pattern_cas_weak() {
    std::atomic<long> x{0};
    const long n = kTsan ? 100'000 : 50'000'000;
    long spurious = 0;
    for (long i = 0; i < n; ++i) {
        long e = i;
        if (!x.compare_exchange_weak(e, i + 1, relaxed)) ++spurious;
    }
    std::printf("  compare_exchange_weak без конкуренции: %ld вызовов, ложных отказов %ld\n", n, spurious);
}

void scenario_patterns() {
    header("10. Паттерны");
    pattern_spinlock();
    pattern_peterson();
    pattern_spsc();
    pattern_seqlock();
    pattern_refcount();
    pattern_dclp();
    pattern_stop_and_stats();
    pattern_rmw_unique();
    pattern_cas_weak();
}

// ------------------------- 11. НАМЕРЕННО некорректное ----------------------
// Всё ниже — data race или UB. Запускается только с аргументом unsafe и не под TSan.

long g_plain_counter = 0;
long g_barrier_counter = 0;
volatile long g_volatile_counter = 0;

void unsafe_counters() {
    const long per = 5'000'000;
    // GCC сворачивает этот цикл в одну инструкцию addq $5000000 (см. конспект).
    std::thread a([&] { for (long i = 0; i < per; ++i) g_plain_counter = g_plain_counter + 1; });
    std::thread b([&] { for (long i = 0; i < per; ++i) g_plain_counter = g_plain_counter + 1; });
    a.join(); b.join();
    // Компиляторный барьер заставляет читать и писать память на каждой итерации,
    // но атомарности не даёт.
    std::thread e([&] { for (long i = 0; i < per; ++i) { g_barrier_counter = g_barrier_counter + 1; asm volatile("" ::: "memory"); } });
    std::thread f([&] { for (long i = 0; i < per; ++i) { g_barrier_counter = g_barrier_counter + 1; asm volatile("" ::: "memory"); } });
    e.join(); f.join();
    std::thread c([&] { for (long i = 0; i < per; ++i) g_volatile_counter = g_volatile_counter + 1; });
    std::thread d([&] { for (long i = 0; i < per; ++i) g_volatile_counter = g_volatile_counter + 1; });
    c.join(); d.join();
    std::printf("  [UB] обычный long, 2 x %ld инкрементов:  %ld (потеряно %ld)\n",
                per, g_plain_counter, 2 * per - g_plain_counter);
    std::printf("  [UB] long + asm-барьер в цикле:       %ld (потеряно %ld)\n",
                g_barrier_counter, 2 * per - g_barrier_counter);
    std::printf("  [UB] volatile long, 2 x %ld инкрементов: %ld (потеряно %ld)\n",
                per, static_cast<long>(g_volatile_counter), 2 * per - g_volatile_counter);
}

// Компилятор выносит чтение data из-за relaxed-цикла: см. конспект, раздел 2.1.
int g_data = 0;
std::atomic<int> g_flag{0};

[[gnu::noinline]] int reader_relaxed() {
    int a = g_data;                                       // первое чтение
    while (!g_flag.load(relaxed)) {}
    return a + g_data;                                    // второе чтение: ожидаем 0 + 1
}
[[gnu::noinline]] int reader_acquire() {
    int a = g_data;
    while (!g_flag.load(acquire)) {}
    return a + g_data;
}

template <class F>
int run_hoist(F reader) {
    g_data = 0; g_flag.store(0);
    int result = -1;
    std::thread r([&] { result = reader(); });
    std::this_thread::sleep_for(std::chrono::milliseconds(2));   // читатель уже в цикле
    g_data = 1;
    g_flag.store(1, release);
    r.join();
    return result;
}

void unsafe_hoist() {
    int bad = 0, good = 0;
    for (int k = 0; k < 100; ++k) { bad += run_hoist(reader_relaxed) == 0; good += run_hoist(reader_acquire) == 1; }
    std::printf("  [UB] читатель с relaxed-флагом вернул устаревшие данные (0) в %d из 100 запусков\n", bad);
    std::printf("       читатель с acquire-флагом вернул свежие данные (1)      в %d из 100 запусков\n", good);
}

// Цикл ожидания на неатомарном флаге: при -O2 GCC удаляет цикл целиком.
bool g_plain_flag = false;
[[gnu::noinline]] void wait_plain() { while (!g_plain_flag) {} }

void unsafe_plain_flag() {
    static std::atomic<int> state{0};                    // static: поток может пережить функцию
    std::thread t([] { wait_plain(); state.store(1, release); });
    t.detach();                                          // при -O1 поток повиснет навсегда
    std::this_thread::sleep_for(std::chrono::milliseconds(200));
    std::printf("  [UB] ожидание неатомарного флага, флаг НИКТО не выставлял: %s\n",
                state.load(acquire) ? "функция сразу вернулась (цикл удалён компилятором)"
                                    : "поток висит (цикл с одним чтением до входа)");
}

void scenario_unsafe() {
    header("11. НАМЕРЕННО некорректный код (data race = UB)");
    unsafe_counters();
    unsafe_hoist();
    unsafe_plain_flag();
}

}  // namespace

int main(int argc, char** argv) {
    bool unsafe = false;
    for (int i = 1; i < argc; ++i) {
        if (!std::strcmp(argv[i], "unsafe")) unsafe = true;
        if (!std::strcmp(argv[i], "quick")) g_quick = true;
    }
    std::setvbuf(stdout, nullptr, _IOLBF, 0);            // построчно: виден прогресс
    std::printf("memory_order_demo%s%s\n", kTsan ? " [TSan]" : "", g_quick ? " [quick]" : "");
    scenario_env();
    scenario_sb();
    scenario_mp();
    scenario_lb();
    scenario_iriw();
    scenario_2p2w();
    scenario_wrc();
    scenario_coherence();
    scenario_cost();
    scenario_intercore();
    scenario_patterns();
    if (unsafe && !kTsan) scenario_unsafe();
    else if (unsafe) std::printf("\nunsafe под TSan не запускается\n");
    std::fflush(stdout);
    return 0;
}
