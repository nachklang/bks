// Тренажёр: список с мелкозернистой блокировкой (hand-over-hand / lock coupling).
//
// Задача с интервью:
//
//     template <typename T> class List {
//         struct Node { T value; Node* next; };
//         Node* head;
//         void enter(void* obj);   // как mutex::lock   для ЭТОГО объекта
//         void leave(void* obj);   // как mutex::unlock для ЭТОГО объекта
//     public:
//         std::optional<T> remove(T value);   // <-- писать здесь
//     };
//
// Смысл: глобального лока нет. Есть лок НА КАЖДЫЙ объект (enter/leave принимают
// адрес). Значит, поток, который удаляет узел в середине списка, не мешает
// потоку, который в этот момент работает в другом месте списка — отсюда
// throughput. Формально это НЕ lock-free (поток, уснувший с залоченным узлом,
// останавливает соседей), это fine-grained locking; настоящий lock-free вариант
// (Harris list, CAS + marked pointers) — в комментарии в самом низу файла.
//
// Правила как в drills_mt.cxx:
//   1. Сначала пишем remove() с чистого листа, вслух, потом компилируем.
//   2. Зелёный тест НЕ означает корректность: гонка может не выстрелить сто раз
//      подряд. Обязательно TSan и --gtest_repeat.
//
// Сборка:
//   g++ -std=c++20 -Wall -Wextra -O2 -o nonblocking_list nonblocking_list.cxx -lgtest -lgtest_main -pthread && ./nonblocking_list
//
// Потом обязательно:
//   g++ -std=c++20 -g -fsanitize=thread  -o nbl_tsan nonblocking_list.cxx -lgtest -lgtest_main -pthread && ./nbl_tsan
//   ASAN_OPTIONS=detect_leaks=0 ./nbl_asan          # файл намеренно течёт снятыми узлами, см. ниже
//   ./nonblocking_list --gtest_repeat=100 --gtest_break_on_failure
//
// Одну задачу за раз:
//   ./nonblocking_list --gtest_filter=NbList.RemoveHead
//
// ВАЖНО про утечку. Снятый из списка узел здесь НЕ удаляется (retire() просто
// копит его). Это не лень, а честная формулировка проблемы: пока ты держишь
// локи pred и curr, другой поток уже может СТОЯТЬ внутри enter(curr) — он
// проснётся на памяти, которую ты собрался освободить. Это reclamation problem;
// решения — hazard pointers, EBR/RCU, deferred free. На интервью про это надо
// сказать вслух, а в тренажёре — просто не удалять.

#include <gtest/gtest.h>

#include <algorithm>
#include <atomic>
#include <barrier>
#include <cstddef>
#include <memory>
#include <mutex>
#include <optional>
#include <random>
#include <thread>
#include <unordered_map>
#include <utility>
#include <vector>

// --- инфраструктура: enter/leave как «мьютекс на адрес» -------------------------
// В боевом коде лок лежал бы прямо в Node (или это была бы striped-таблица).
// Здесь — честная таблица «адрес -> свой мьютекс», чтобы ДВА РАЗНЫХ адреса
// никогда не делили один мьютекс: иначе hand-over-hand может само-заклиниться.
namespace lock_table {

struct Entry
{
    std::mutex m;
    int refs = 0;  // сколько потоков сейчас держат/ждут этот адрес
};

inline std::mutex& registry_mutex()
{
    static std::mutex m;
    return m;
}

inline std::unordered_map<const void*, std::unique_ptr<Entry>>& registry()
{
    static std::unordered_map<const void*, std::unique_ptr<Entry>> t;
    return t;
}

inline void enter(const void* obj)
{
    Entry* e = nullptr;
    {
        std::lock_guard<std::mutex> lk(registry_mutex());
        auto& slot = registry()[obj];
        if (!slot) slot = std::make_unique<Entry>();
        e = slot.get();
        ++e->refs;  // держим запись живой, пока мы её ждём
    }
    e->m.lock();
}

inline void leave(const void* obj)
{
    Entry* e = nullptr;
    {
        std::lock_guard<std::mutex> lk(registry_mutex());
        e = registry().at(obj).get();
    }
    e->m.unlock();
    {
        std::lock_guard<std::mutex> lk(registry_mutex());
        auto it = registry().find(obj);
        if (--it->second->refs == 0) registry().erase(it);
    }
}

}  // namespace lock_table

// --- сам список ----------------------------------------------------------------

template <typename T>
class List
{
private:
    struct Node
    {
        T value;
        Node* next;
    };

    // Голова — узел-страж (sentinel/dummy). Его value не используется, он никогда
    // не удаляется. Смысл: у ПЕРВОГО настоящего элемента появляется предшественник,
    // которого можно залочить, и в remove() не нужен отдельный случай «удаляем head».
    Node* head;

    void enter(void* obj) { lock_table::enter(obj); }
    void leave(void* obj) { lock_table::leave(obj); }

    // Снятые узлы не освобождаются, см. шапку файла (reclamation problem).
    void retire(Node* n)
    {
        std::lock_guard<std::mutex> lk(retired_mutex_);
        retired_.push_back(n);
    }

    std::mutex retired_mutex_;
    std::vector<Node*> retired_;

public:
    List() : head(new Node{T{}, nullptr}) {}

    ~List()
    {
        for (Node* p = head; p != nullptr;)
        {
            Node* next = p->next;
            delete p;
            p = next;
        }
        for (Node* p : retired_) delete p;
    }

    List(const List&) = delete;
    List& operator=(const List&) = delete;

    // ================= ЗАДАЧА =================================================
    // Удалить ПЕРВЫЙ узел со значением value, вернуть значение из узла
    // (не аргумент!) или std::nullopt, если такого нет.
    //
    // Разрешено пользоваться только enter()/leave() — никаких std::mutex,
    // никакого лока «на весь список».
    //
    // Вслух по ходу: в каком порядке берутся локи; почему нельзя отпустить
    // pred раньше, чем снял curr; что происходит, если два потока удаляют
    // соседние узлы; что происходит, если два потока удаляют ОДИН узел;
    // почему узел нельзя delete'ить сразу.
    std::optional<T> remove(T value)
    {
        (void)value;
        return std::nullopt;  // TODO
    }
    // ==========================================================================

    // --- ниже — уже написанное, трогать не надо -------------------------------

    // Образец того, как выглядит работа с enter/leave: вставка в начало.
    // Лочим страж (он же владелец указателя на первый элемент) — и всё.
    void push_front(T value)
    {
        enter(head);
        head->next = new Node{std::move(value), head->next};
        leave(head);
    }

    // Снимок для проверок. Только для однопоточных участков теста.
    std::vector<T> snapshot() const
    {
        std::vector<T> out;
        for (Node* p = head->next; p != nullptr; p = p->next) out.push_back(p->value);
        return out;
    }

    std::size_t size() const { return snapshot().size(); }
};

// --- вспомогательные типы для тестов -------------------------------------------

// Отличает «вернул значение из узла» от «вернул свой аргумент»: сравниваются
// только key, а tag у одинаковых по key объектов разный.
struct Item
{
    int key = 0;
    int tag = 0;

    friend bool operator==(const Item& lhs, const Item& rhs) { return lhs.key == rhs.key; }
};

// ================================ ТЕСТЫ =========================================

TEST(NbList, RemoveFromEmptyReturnsNullopt)
{
    List<int> list;
    EXPECT_FALSE(list.remove(42).has_value());
    EXPECT_EQ(list.size(), 0u);
}

TEST(NbList, RemoveHead)
{
    List<int> list;
    list.push_front(3);
    list.push_front(2);
    list.push_front(1);  // список: 1 2 3

    auto got = list.remove(1);
    ASSERT_TRUE(got.has_value());
    EXPECT_EQ(*got, 1);
    EXPECT_EQ(list.snapshot(), (std::vector<int>{2, 3}));
}

TEST(NbList, RemoveMiddle)
{
    List<int> list;
    list.push_front(3);
    list.push_front(2);
    list.push_front(1);

    auto got = list.remove(2);
    ASSERT_TRUE(got.has_value());
    EXPECT_EQ(*got, 2);
    EXPECT_EQ(list.snapshot(), (std::vector<int>{1, 3}));
}

TEST(NbList, RemoveTail)
{
    List<int> list;
    list.push_front(3);
    list.push_front(2);
    list.push_front(1);

    auto got = list.remove(3);
    ASSERT_TRUE(got.has_value());
    EXPECT_EQ(*got, 3);
    EXPECT_EQ(list.snapshot(), (std::vector<int>{1, 2}));

    // и список после этого ещё пригоден: можно дописать в конец логики вставки
    list.push_front(9);
    EXPECT_EQ(list.snapshot(), (std::vector<int>{9, 1, 2}));
}

TEST(NbList, RemoveMissingLeavesListIntact)
{
    List<int> list;
    list.push_front(3);
    list.push_front(2);
    list.push_front(1);

    EXPECT_FALSE(list.remove(77).has_value());
    EXPECT_EQ(list.snapshot(), (std::vector<int>{1, 2, 3}));
}

TEST(NbList, RemoveOnlyFirstOccurrence)
{
    List<int> list;
    list.push_front(5);
    list.push_front(7);
    list.push_front(5);  // список: 5 7 5

    auto got = list.remove(5);
    ASSERT_TRUE(got.has_value());
    EXPECT_EQ(list.snapshot(), (std::vector<int>{7, 5}));

    ASSERT_TRUE(list.remove(5).has_value());
    EXPECT_EQ(list.snapshot(), (std::vector<int>{7}));

    EXPECT_FALSE(list.remove(5).has_value());
}

TEST(NbList, RemoveAllOneByOne)
{
    List<int> list;
    for (int i = 0; i < 100; ++i) list.push_front(i);

    for (int i = 0; i < 100; ++i)
    {
        auto got = list.remove(i);
        ASSERT_TRUE(got.has_value()) << "i = " << i;
        EXPECT_EQ(*got, i);
    }
    EXPECT_EQ(list.size(), 0u);
    EXPECT_FALSE(list.remove(0).has_value());
}

TEST(NbList, ReturnsValueStoredInNodeNotTheArgument)
{
    List<Item> list;
    list.push_front(Item{1, /*tag=*/111});

    auto got = list.remove(Item{1, /*tag=*/999});
    ASSERT_TRUE(got.has_value());
    EXPECT_EQ(got->tag, 111) << "вернул аргумент вместо значения из узла";
}

// --- многопоточные ---------------------------------------------------------------

// Каждый поток удаляет свой непересекающийся набор. Никто не должен промахнуться,
// список в конце пуст. Ловит: потерю узлов при одновременном удалении соседей.
TEST(NbList, ConcurrentRemoveDisjointValues)
{
    constexpr int kThreads = 8;
    constexpr int kPerThread = 500;

    List<int> list;
    for (int i = kThreads * kPerThread - 1; i >= 0; --i) list.push_front(i);

    std::barrier sync(kThreads);
    std::atomic<int> missed{0};
    std::vector<std::thread> threads;

    for (int t = 0; t < kThreads; ++t)
    {
        threads.emplace_back([&, t] {
            sync.arrive_and_wait();
            for (int i = 0; i < kPerThread; ++i)
            {
                const int value = t * kPerThread + i;
                auto got = list.remove(value);
                if (!got || *got != value) ++missed;
            }
        });
    }
    for (auto& th : threads) th.join();

    EXPECT_EQ(missed.load(), 0);
    EXPECT_EQ(list.size(), 0u) << "остались узлы: " << list.size();
}

// Все потоки гоняются за ОДНИМ значением. Ровно один должен его забрать.
// Ловит: двойное снятие одного узла (два потока вернули один и тот же элемент).
TEST(NbList, ConcurrentRemoveSameValueExactlyOneWinner)
{
    constexpr int kThreads = 16;
    constexpr int kRounds = 200;

    for (int round = 0; round < kRounds; ++round)
    {
        List<int> list;
        list.push_front(3);
        list.push_front(2);
        list.push_front(1);  // 1 2 3, удаляем 2 — он в середине

        std::barrier sync(kThreads);
        std::atomic<int> winners{0};
        std::vector<std::thread> threads;

        for (int t = 0; t < kThreads; ++t)
        {
            threads.emplace_back([&] {
                sync.arrive_and_wait();
                if (list.remove(2).has_value()) ++winners;
            });
        }
        for (auto& th : threads) th.join();

        ASSERT_EQ(winners.load(), 1) << "round " << round;
        ASSERT_EQ(list.snapshot(), (std::vector<int>{1, 3})) << "round " << round;
    }
}

// Дубликаты одного значения: сколько положили, столько и должны снять, не больше.
TEST(NbList, ConcurrentRemoveDuplicatesAccounting)
{
    constexpr int kDuplicates = 500;
    constexpr int kThreads = 8;

    List<int> list;
    for (int i = 0; i < kDuplicates; ++i) list.push_front(42);

    std::barrier sync(kThreads);
    std::atomic<int> taken{0};
    std::vector<std::thread> threads;

    for (int t = 0; t < kThreads; ++t)
    {
        threads.emplace_back([&] {
            sync.arrive_and_wait();
            while (list.remove(42).has_value()) ++taken;
        });
    }
    for (auto& th : threads) th.join();

    EXPECT_EQ(taken.load(), kDuplicates);
    EXPECT_EQ(list.size(), 0u);
}

// Вставки и удаления одновременно. Инвариант: множество (снятое + оставшееся)
// совпадает с тем, что положили, без потерь и без дублей.
TEST(NbList, ConcurrentRemoveWhileInserting)
{
    constexpr int kProducers = 4;
    constexpr int kConsumers = 4;
    constexpr int kPerProducer = 1000;

    List<int> list;
    std::barrier sync(kProducers + kConsumers);
    std::vector<std::vector<int>> taken(kConsumers);
    std::atomic<int> produced{0};
    std::vector<std::thread> threads;

    for (int p = 0; p < kProducers; ++p)
    {
        threads.emplace_back([&, p] {
            sync.arrive_and_wait();
            for (int i = 0; i < kPerProducer; ++i)
            {
                list.push_front(p * kPerProducer + i);
                produced.fetch_add(1, std::memory_order_relaxed);
            }
        });
    }
    for (int c = 0; c < kConsumers; ++c)
    {
        threads.emplace_back([&, c] {
            std::mt19937 rng(static_cast<unsigned>(c) + 1u);
            std::uniform_int_distribution<int> pick(0, kProducers * kPerProducer - 1);
            sync.arrive_and_wait();
            for (int i = 0; i < kPerProducer * 2; ++i)
            {
                if (auto got = list.remove(pick(rng))) taken[c].push_back(*got);
            }
        });
    }
    for (auto& th : threads) th.join();

    std::vector<int> all;
    for (auto& v : taken) all.insert(all.end(), v.begin(), v.end());
    const std::size_t removed_count = all.size();

    for (int v : list.snapshot()) all.push_back(v);
    std::sort(all.begin(), all.end());

    EXPECT_EQ(all.size(), static_cast<std::size_t>(produced.load()))
        << "узлы потерялись или задвоились";
    EXPECT_EQ(std::adjacent_find(all.begin(), all.end()), all.end())
        << "одно и то же значение снято дважды";
    EXPECT_EQ(list.size(), all.size() - removed_count);
}

// Стресс без проверок инварианта на каждом шаге — просто долго дёргать под TSan.
TEST(NbList, StressMixed)
{
    constexpr int kThreads = 8;
    constexpr int kIters = 5000;
    constexpr int kKeys = 64;

    List<int> list;
    for (int i = 0; i < kKeys; ++i) list.push_front(i);

    std::barrier sync(kThreads);
    std::vector<std::thread> threads;
    for (int t = 0; t < kThreads; ++t)
    {
        threads.emplace_back([&, t] {
            std::mt19937 rng(static_cast<unsigned>(t) + 7u);
            std::uniform_int_distribution<int> key(0, kKeys - 1);
            sync.arrive_and_wait();
            for (int i = 0; i < kIters; ++i)
            {
                const int k = key(rng);
                if (auto got = list.remove(k))
                    list.push_front(*got);
                else
                    list.push_front(k);
            }
        });
    }
    for (auto& th : threads) th.join();

    SUCCEED();
}

// --- шпаргалка, читать ПОСЛЕ своей попытки --------------------------------------
//
// Каркас hand-over-hand (lock coupling):
//
//   заходим: enter(pred = head)  — страж всегда есть, значит есть кого лочить;
//   цикл:    curr = pred->next;
//            если curr == nullptr  -> leave(pred), вернуть nullopt;
//            enter(curr);                      // ДВА лока одновременно
//            если curr->value == value:
//                 pred->next = curr->next;     // снимаем под двумя локами
//                 result = std::move(curr->value);
//                 leave(curr); leave(pred);
//                 retire(curr);                // НЕ delete, см. шапку
//                 вернуть result;
//            иначе: leave(pred); pred = curr;  // «перешагиваем»: отпустили старый,
//                                              // новый уже в руках
//
// Ключевое, что спросят:
//   * локи всегда берутся в одном направлении (от головы к хвосту) — поэтому нет
//     цикла ожидания, поэтому нет дедлока;
//   * момент снятия узла защищён ОБОИМИ локами: без лока pred другой поток может
//     одновременно менять pred->next и одна из правок потеряется; без лока curr
//     другой поток может снять curr->next и мы прилинкуем мёртвый узел;
//   * страж (dummy head) убирает особый случай «удаляем первый элемент» — иначе
//     предшественника у него нет, и head пришлось бы лочить отдельным правилом;
//   * два потока на одном значении: первый снимает узел под локами, второй
//     физически не может оказаться на curr, не забрав лок pred, который занят —
//     он пройдёт дальше по УЖЕ обновлённому pred->next и вернёт nullopt;
//   * delete сразу нельзя: соседний поток может спать внутри enter(curr).
//     Решения — hazard pointers / EBR / RCU / deferred free.
//
// Настоящий lock-free (Harris, 2001), если спросят «а без локов совсем»:
//   next хранится в std::atomic<Node*>, младший бит указателя — «логически удалён».
//   remove = два CAS: сначала пометить curr->next (логическое удаление,
//   в этот момент значение уже «наше» и гонка выиграна), потом попытаться
//   физически отцепить pred->next. Если второй CAS не прошёл — не беда,
//   узел снимет следующий проходящий мимо поток. Реклейм — те же hazard pointers.
//   Плюс: спящий поток никого не блокирует. Минус: ABA, сложность, отладка.
