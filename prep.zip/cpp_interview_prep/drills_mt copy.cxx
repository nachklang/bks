// Тренажёр №2: многопоточность. Писать с чистого листа, вслух, потом компилировать.
//
// Правила те же, что в drills.cxx:
//   1. Не подглядывать в doc/ и не гуглить, пока не написал свой вариант.
//   2. Проговаривать КАЖДУЮ строчку вслух. На интервью после кода идёт допрос.
//   3. Норма на задачу — 8-12 минут вместе с объяснением (больше, чем на STL-сниппеты).
//   4. Зелёный тест здесь НЕ означает корректность: гонка может не выстрелить
//      сто раз подряд. Обязательно прогонять под TSan и по многу раз.
//
// Сборка:
//   g++ -std=c++20 -Wall -Wextra -O2 -o drills_mt drills_mt.cxx -lgtest -lgtest_main -pthread && ./drills_mt
//
// Потом обязательно:
//   g++ -std=c++20 -g -fsanitize=thread -o mt_tsan drills_mt.cxx -lgtest -lgtest_main -pthread && ./mt_tsan
//   g++ -std=c++20 -g -fsanitize=address,undefined -o mt_asan drills_mt.cxx -lgtest -lgtest_main -pthread && ./mt_asan
//   ./drills_mt --gtest_repeat=100 --gtest_break_on_failure
//
// Одну задачу за раз:
//   ./drills_mt --gtest_filter=DrillsMt.ReusableBarrier
//
// Задача 12 намеренно течёт узлами (проблема reclamation — это тема для разговора),
// так что под ASan её гонять с ASAN_OPTIONS=detect_leaks=0.
//
// Скелеты компилируются, но ничего не делают: тела помечены TODO, тесты красные.
// Параметры намеренно без имён (/*value*/) — впишешь сам.

#include <gtest/gtest.h>

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <mutex>
#include <numeric>
#include <queue>
#include <thread>
#include <vector>

// --- 1. Параллельная сумма ------------------------------------------------------
// Разминка, но её реально просят. Вслух: почему += в общую переменную — это
// data race и UB, а не «иногда неточно»; сколько потоков брать
// (hardware_concurrency — это подсказка, а не гарантия); почему частичные суммы
// нельзя складывать в соседние ячейки vector<long long> — false sharing,
// кэш-линия 64 байта, std::hardware_destructive_interference_size.
TEST(DrillsMt, ParallelSum)
{
    std::vector<int> data(1'000'000);
    std::iota(data.begin(), data.end(), 1);

    long long sum = 0;
    std::mutex m;

    auto foo = [&sum, &m, &data](int lhs, int rhs) {
        thread_local long long currSum = 0; 
        for(int i = lhs; i < rhs; ++i)
        {
            currSum += data[i];
        }

        std::unique_lock<std::mutex> l(m);
        sum += currSum;
    };

    std::vector<std::thread> threads;

    for(int i = 0, offset = data.size() / 4; i < 4; ++i)
    {
        threads.emplace_back(foo, i * offset, (i + 1) * offset);
    }

    for(auto& t: threads)
    {
        t.join();
    }

    // TODO: посчитать сумму в 4 потоках. Частичная сумма — локальная переменная
    //       внутри потока, в общий результат кладём один раз в конце.

    EXPECT_EQ(sum, 500000500000LL);
}

// --- 2. Ограниченная очередь producer/consumer ----------------------------------
// Самая частая «напиши прямо сейчас» задача на многопоточку.
// Вслух: почему две condition_variable, а не одна; почему wait обязательно
// с предикатом (spurious wakeup); notify под локом или после разблокировки;
// как выглядит graceful shutdown и почему без close() потребители повиснут навсегда.
template <class T>
class BoundedQueue
{
public:
    explicit BoundedQueue(std::size_t capacity) : capacity_(capacity) {}

    // Блокируется, пока нет места. false — очередь закрыта, значение не принято.
    bool push(T value) { 
        std::unique_lock<std::mutex> lk(m_);
        cv_.wait(lk,[this](){
            return closed_ || data.size() < capacity_;
        });

        if(closed_)
        {
            return false;
        }

        data.emplace(std::move(value));

        cv_.notify_one();
        
        return true; 
    }

    // Блокируется, пока нет данных. false — очередь закрыта И пуста.
    bool pop(T& out) {
        std::unique_lock<std::mutex> lk(m_);

        cv_.wait(lk, [this](){
            return closed_ || !data.empty();
        });

        if(closed_ || data.empty())
        {
            return false;
        }

        out = data.front();
        data.pop();

        cv_.notify_one();

        return true; 
    }

    // Больше не принимать push, разбудить всех ждущих.
    void close() {
        std::unique_lock<std::mutex> lk(m_);
        closed_ = true;
        cv_.notify_all();
    }

private:
     std::size_t capacity_ = 0;
     bool closed_ = false;
     std::mutex m_;
     std::condition_variable cv_;
     std::queue<T> data;

    // TODO: mutex, not_full_, not_empty_, std::deque<T>, capacity_, closed_.
};

TEST(DrillsMt, BoundedQueueProducerConsumer)
{
    constexpr int kPerProducer = 5000;
    constexpr int kProducers   = 2;
    constexpr int kConsumers   = 3;

    BoundedQueue<int> q(64);
    std::atomic<long long> consumed_sum{0};
    std::atomic<int> consumed_count{0};

    std::vector<std::thread> producers;
    for (int p = 0; p < kProducers; ++p)
        producers.emplace_back([&q] {
            for (int i = 1; i <= kPerProducer; ++i)
                q.push(i);
        });

    std::vector<std::thread> consumers;
    for (int c = 0; c < kConsumers; ++c)
        consumers.emplace_back([&] {
            int value = 0;
            while (q.pop(value))
            {
                consumed_sum.fetch_add(value, std::memory_order_relaxed);
                consumed_count.fetch_add(1, std::memory_order_relaxed);
            }
        });

    for (auto& t : producers) t.join();
    q.close();                                  // без этого consumers не выйдут
    for (auto& t : consumers) t.join();

    constexpr long long kOneProducerSum = 1LL * kPerProducer * (kPerProducer + 1) / 2;

    EXPECT_EQ(consumed_count.load(), kProducers * kPerProducer);
    EXPECT_EQ(consumed_sum.load(), kProducers * kOneProducerSum);
}

// --- 3. Переиспользуемый барьер --------------------------------------------------
// Вслух: почему одного счётчика мало и зачем номер поколения; что случится,
// если поток, вышедший из барьера, влетит в него второй раз раньше, чем
// проснутся остальные; чем это отличается от std::barrier (C++20, есть ещё
// completion function) и от std::latch (одноразовый).
class Barrier
{
public:
    explicit Barrier(int count): required_(count) {}

    void arrive_and_wait() {
        std::unique_lock<std::mutex> lk(m_);

        auto id = std::this_thread::get_id();

        auto currLevel = ++levels_[id];

        maxLevel = std::max(maxLevel, currLevel);

        if(auto it = counters.find(currLevel); it != counters.end())
        {
            --counters[levels_[id]];
        }
        else
        {
            counters[levels_[id]] = required_ - 1;
        }
        
        cv_.wait(lk, [this, id] {
            return counters[levels_[id]] == 0;
        });
        cv_.notify_all();
    }

private:
    std::mutex m_;
    std::condition_variable cv_;
    size_t curr_ = 0;
    std::size_t required_ = 0;
    std::unordered_map<std::thread::id, int> levels_;
    std::unordered_map<int,int> counters;
    int maxLevel = 0;
    // TODO: mutex, condition_variable, count_ (сколько всего),
    //       waiting_ (сколько уже пришло), generation_.
};

TEST(DrillsMt, ReusableBarrier)
{
    constexpr int kThreads = 4;
    constexpr int kRounds  = 50;

    Barrier barrier(kThreads);
    std::vector<int> progress(kThreads, 0);
    std::atomic<int> errors{0};

    std::vector<std::thread> workers;
    for (int id = 0; id < kThreads; ++id)
        workers.emplace_back([&, id] {
            for (int round = 1; round <= kRounds; ++round)
            {
                progress[id] = round;         // своя ячейка — гонки нет
                barrier.arrive_and_wait();    // после него обязаны быть видны чужие записи

                for (int other = 0; other < kThreads; ++other)
                    if (progress[other] != round)
                        errors.fetch_add(1, std::memory_order_relaxed);

                barrier.arrive_and_wait();    // не даём убежать в следующий раунд
            }
        });

    for (auto& t : workers) t.join();

    EXPECT_EQ(errors.load(), 0);
}

// --- 4. Счётный семафор ----------------------------------------------------------
// Вслух: чем семафор отличается от мьютекса (владельца нет, release может звать
// не тот поток, что делал acquire); почему счётчик не уходит в минус; где нужен
// в проде — backpressure, пул соединений, ограничение числа задач в полёте.
// Плюс: что даёт std::counting_semaphore (C++20) и почему acquire там не бросает.
class Semaphore
{
public:
    explicit Semaphore(int /*initial*/) {}

    void acquire() {}
    void release() {}
    bool try_acquire() { return false; }

private:
    // TODO: mutex, condition_variable, счётчик разрешений.
};

TEST(DrillsMt, SemaphoreLimitsConcurrency)
{
    constexpr int kPermits = 3;
    constexpr int kThreads = 16;

    Semaphore sem(kPermits);
    std::atomic<int> inside{0};
    std::atomic<int> peak{0};
    std::atomic<int> done{0};

    std::vector<std::thread> workers;
    for (int i = 0; i < kThreads; ++i)
        workers.emplace_back([&] {
            sem.acquire();

            const int now = inside.fetch_add(1, std::memory_order_relaxed) + 1;
            int prev = peak.load(std::memory_order_relaxed);
            while (now > prev &&
                   !peak.compare_exchange_weak(prev, now, std::memory_order_relaxed))
            {
            }

            std::this_thread::sleep_for(std::chrono::milliseconds(2));

            inside.fetch_sub(1, std::memory_order_relaxed);
            done.fetch_add(1, std::memory_order_relaxed);
            sem.release();
        });

    for (auto& t : workers) t.join();

    EXPECT_EQ(done.load(), kThreads);
    EXPECT_LE(peak.load(), kPermits);
    EXPECT_GT(peak.load(), 1);   // если 1 — ты просто сериализовал всех мьютексом
}

// --- 5. Latch: дождаться N завершений ---------------------------------------------
// Вслух: почему latch одноразовый и чем он удобнее барьера, когда ждущий сам
// не участник; какой ровно happens-before обязан дать wait() (иначе чтение
// результатов после wait — гонка); почему count_down зовёт notify_all только
// на последнем декременте.
class Latch
{
public:
    explicit Latch(int /*count*/) {}

    void count_down() {}
    void wait() {}

private:
    // TODO: mutex, condition_variable, счётчик оставшихся.
};

TEST(DrillsMt, LatchHappensBefore)
{
    constexpr int kWorkers = 8;

    Latch latch(kWorkers);
    std::vector<int> results(kWorkers, -1);

    std::vector<std::thread> workers;
    for (int i = 0; i < kWorkers; ++i)
        workers.emplace_back([&, i] {
            results[i] = i * i;
            latch.count_down();
        });

    latch.wait();

    for (int i = 0; i < kWorkers; ++i)
        EXPECT_EQ(results[i], i * i) << "не дождались воркера " << i;

    for (auto& t : workers) t.join();
}

// --- 6. TTAS spinlock --------------------------------------------------------------
// Вслух: чем test-and-test-and-set лучше голого test_and_set (кэш-линия не гоняется
// между ядрами в состоянии M); почему lock — acquire, а unlock — release, и что
// добавляет seq_cst сверх этого; зачем backoff (_mm_pause / yield); и главное —
// когда spinlock ХУЖЕ мьютекса: oversubscription, вытеснение владельца внутри
// критической секции, приоритетная инверсия.
class SpinLock
{
public:
    void lock() {}
    void unlock() {}
    bool try_lock() { return false; }

private:
    // TODO: std::atomic<bool> или std::atomic_flag.
};

TEST(DrillsMt, SpinLockProtectsCounter)
{
    constexpr int kThreads = 8;
    constexpr int kIters   = 20000;

    SpinLock lock;
    long long counter = 0;   // НЕ атомик: тест проверяет именно взаимное исключение

    std::vector<std::thread> workers;
    for (int i = 0; i < kThreads; ++i)
        workers.emplace_back([&] {
            for (int k = 0; k < kIters; ++k)
            {
                std::lock_guard<SpinLock> guard(lock);   // класс обязан быть BasicLockable
                ++counter;
            }
        });

    for (auto& t : workers) t.join();

    EXPECT_EQ(counter, 1LL * kThreads * kIters);
}

// --- 7. Пул потоков с future --------------------------------------------------------
// Вслух: почему очередь хранит std::function<void()>; зачем packaged_task, а не
// promise руками; что обязан сделать деструктор (флаг + notify_all + join) и почему
// join нельзя пропустить; что будет, если задача бросит исключение (без
// packaged_task — std::terminate); почему std::async не заменяет пул.
// Стретч: сделать submit шаблонным —
//   template <class F> auto submit(F&& f) -> std::future<std::invoke_result_t<F>>.
class ThreadPool
{
public:
    explicit ThreadPool(unsigned /*threads*/) {}
    ~ThreadPool() {}

    ThreadPool(const ThreadPool&)            = delete;
    ThreadPool& operator=(const ThreadPool&) = delete;

    std::future<int> submit(std::function<int()> /*task*/)
    {
        std::promise<int> stub;   // TODO: завернуть задачу в packaged_task и положить в очередь
        stub.set_value(0);
        return stub.get_future();
    }

private:
    // TODO: vector<thread>, deque<function<void()>>, mutex, condition_variable, stopping_.
};

TEST(DrillsMt, ThreadPoolRunsTasks)
{
    constexpr int kTasks = 200;

    std::vector<std::future<int>> results;
    results.reserve(kTasks);

    {
        ThreadPool pool(4);
        for (int i = 0; i < kTasks; ++i)
            results.push_back(pool.submit([i] { return i * i; }));
    }   // деструктор обязан дождаться уже принятых задач

    long long sum = 0;
    for (auto& f : results) sum += f.get();

    long long expected = 0;
    for (int i = 0; i < kTasks; ++i) expected += 1LL * i * i;

    EXPECT_EQ(sum, expected);
}

// --- 8. SPSC lock-free ring buffer ---------------------------------------------------
// Вслух: какая именно пара release/acquire даёт потребителю видимость данных;
// почему размер — степень двойки и индекс маскируется, а не берётся по модулю;
// почему «занято = head - tail» корректно даже при переполнении беззнакового
// счётчика; зачем alignas на head_/tail_ (false sharing) и что даёт кэширование
// чужого индекса в локальной переменной. wait-free это или lock-free?
template <class T, std::size_t Capacity>
class SpscRing
{
    static_assert((Capacity & (Capacity - 1)) == 0, "Capacity должна быть степенью двойки");

public:
    bool push(const T& /*value*/) { return false; }   // false — буфер полон
    bool pop(T& /*out*/)          { return false; }   // false — буфер пуст

private:
    // TODO: T buffer_[Capacity], std::atomic<std::size_t> head_/tail_,
    //       каждый на своей кэш-линии.
};

TEST(DrillsMt, SpscRingKeepsOrder)
{
    constexpr int kItems = 100000;

    SpscRing<int, 1024> ring;
    std::atomic<bool> timed_out{false};
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);

    std::thread producer([&] {
        for (int i = 0; i < kItems; ++i)
            while (!ring.push(i))
            {
                if (std::chrono::steady_clock::now() > deadline)
                {
                    timed_out.store(true);
                    return;
                }
                std::this_thread::yield();
            }
    });

    long long sum = 0;
    int expected_next = 0;
    bool order_ok = true;

    for (int i = 0; i < kItems; ++i)
    {
        int value = 0;
        while (!ring.pop(value))
        {
            if (std::chrono::steady_clock::now() > deadline)
            {
                timed_out.store(true);
                break;
            }
            std::this_thread::yield();
        }

        if (timed_out.load()) break;

        if (value != expected_next++) order_ok = false;
        sum += value;
    }

    producer.join();

    ASSERT_FALSE(timed_out.load()) << "5 секунд без прогресса — push/pop не реализованы";
    EXPECT_TRUE(order_ok) << "FIFO нарушен";
    EXPECT_EQ(sum, 1LL * kItems * (kItems - 1) / 2);
}

// --- 9. Seqlock: снапшот котировки без блокировки читателей ---------------------------
// Прямо в тему маркет-даты: один писатель, много читателей, читатели не тормозят
// писателя и никогда его не блокируют. Вслух: как читатель понимает, что прочитал
// рваные данные (нечётный seq или seq изменился за время чтения); зачем два
// acquire-загрузки/фенса; почему seqlock плох, если читателей надо не задерживать
// или писателей больше одного; и формально — почему поля payload обязаны быть
// атомарными (иначе гонка = UB), хотя в проде часто пишут memcpy и живут с этим.
struct Quote
{
    std::int64_t  bid = 0;
    std::int64_t  ask = 0;
    std::uint64_t ts  = 0;
};

class SeqlockSlot
{
public:
    void write(const Quote& /*q*/) {}
    Quote read() const { return Quote{}; }

private:
    // TODO: std::atomic<std::uint64_t> seq_{0} + сам Quote.
};

TEST(DrillsMt, SeqlockNeverReturnsTornQuote)
{
    constexpr int kWrites  = 200000;
    constexpr int kReaders = 3;

    SeqlockSlot slot;
    slot.write(Quote{1, 2, 1});          // инвариант: ask == bid + 1, ts == bid

    std::atomic<bool> writing{true};
    std::atomic<int>  torn{0};

    std::vector<std::thread> readers;
    for (int r = 0; r < kReaders; ++r)
        readers.emplace_back([&] {
            while (writing.load(std::memory_order_relaxed))
            {
                const Quote q = slot.read();
                if (q.ask != q.bid + 1 || q.ts != static_cast<std::uint64_t>(q.bid))
                    torn.fetch_add(1, std::memory_order_relaxed);
            }
        });

    for (int i = 1; i <= kWrites; ++i)
        slot.write(Quote{i, i + 1, static_cast<std::uint64_t>(i)});

    writing.store(false, std::memory_order_relaxed);
    for (auto& t : readers) t.join();

    EXPECT_EQ(torn.load(), 0) << "читатель увидел половину одной котировки и половину другой";
}

// --- 10. Счётчик ссылок с правильными memory order -------------------------------------
// Вслух: почему инкремент можно relaxed, а декремент нельзя; какой happens-before
// нужен перед delete (fetch_sub(acq_rel) либо release + acquire-фенс) и что именно
// сломается без него; почему деструктор виртуальный; и почему атомарность счётчика
// НЕ делает атомарным сам умный указатель.
// Это же место намеренно сломано в ../shared_ptr_fix — сверься после починки.
class RefCounted
{
public:
    RefCounted()                             = default;
    RefCounted(const RefCounted&)            = delete;
    RefCounted& operator=(const RefCounted&) = delete;

    void add_ref() noexcept { /* TODO: какой memory_order и почему? */ }
    void release() noexcept { /* TODO: последний владелец делает delete this */ }

    long use_count() const noexcept { return strong_.load(std::memory_order_relaxed); }

protected:
    virtual ~RefCounted() = default;

private:
    std::atomic<long> strong_{1};
};

struct Payload : RefCounted
{
    static inline std::atomic<int> destroyed{0};

    int value = 42;

    ~Payload() override { destroyed.fetch_add(1, std::memory_order_relaxed); }
};

TEST(DrillsMt, RefCountDestroysExactlyOnce)
{
    Payload::destroyed.store(0);

    constexpr int kThreads = 8;
    constexpr int kIters   = 50000;

    auto* obj = new Payload();

    std::vector<std::thread> workers;
    for (int i = 0; i < kThreads; ++i)
        workers.emplace_back([&] {
            for (int k = 0; k < kIters; ++k)
            {
                obj->add_ref();
                obj->release();
            }
        });

    for (auto& t : workers) t.join();

    EXPECT_EQ(obj->use_count(), 1);
    EXPECT_EQ(Payload::destroyed.load(), 0) << "объект убили, пока им ещё владели";

    obj->release();
    EXPECT_EQ(Payload::destroyed.load(), 1) << "последний release обязан удалить объект";
}

// --- 11. call_once своими руками --------------------------------------------------------
// Вслух: почему наивный double-checked locking на сыром bool сломан (нет
// happens-before, второй поток может увидеть флаг раньше, чем содержимое объекта);
// как это чинится на atomic + release/acquire; почему magic statics (C++11) решают
// ту же задачу бесплатно; что делает std::call_once, если инициализатор бросил.
class OnceFlag
{
public:
    template <class F>
    void call_once(F&& /*init*/) { /* TODO */ }

private:
    // TODO: std::atomic<bool> done_ + std::mutex (или atomic<int> с тремя состояниями).
};

TEST(DrillsMt, CallOnceRunsExactlyOnce)
{
    constexpr int kThreads = 16;

    OnceFlag flag;
    std::atomic<int> initialized{0};
    std::atomic<int> wrong_size{0};
    std::atomic<bool> go{false};
    std::vector<int> payload;

    std::vector<std::thread> workers;
    for (int i = 0; i < kThreads; ++i)
        workers.emplace_back([&] {
            while (!go.load(std::memory_order_acquire))   // стартуем все разом
                std::this_thread::yield();

            flag.call_once([&] {
                payload.assign(1000, 7);
                initialized.fetch_add(1, std::memory_order_relaxed);
            });

            if (payload.size() != 1000)
                wrong_size.fetch_add(1, std::memory_order_relaxed);
        });

    go.store(true, std::memory_order_release);
    for (auto& t : workers) t.join();

    EXPECT_EQ(initialized.load(), 1) << "инициализатор отработал не ровно один раз";
    EXPECT_EQ(wrong_size.load(), 0) << "поток вышел из call_once до того, как объект достроили";
}

// --- 12. Lock-free стек Треибера (Treiber stack) — стретч --------------------------------------------------
// Вслух: как выглядит CAS-цикл на push и почему compare_exchange_weak, а не strong;
// что такое ABA и почему pop «в лоб» небезопасен в общем случае; почему здесь мы
// осознанно не освобождаем узлы (проблема reclamation: hazard pointers, RCU,
// epoch-based); чем lock-free отличается от wait-free и от obstruction-free.
// Стретч поверх стретча: сделать pop тоже конкурентным и объяснить, почему тест
// на это поймает не всякий баг.
template <class T>
class TreiberStack
{
public:
    void push(const T& /*value*/) {}
    bool pop(T& /*out*/) { return false; }

private:
    struct Node
    {
        T     value{};
        Node* next = nullptr;
    };

    // TODO: std::atomic<Node*> head_{nullptr};
    //       узлы намеренно не удаляем — это утечка, и это тема для разговора.
};

TEST(DrillsMt, TreiberStackKeepsEveryElement)
{
    constexpr int kThreads   = 4;
    constexpr int kPerThread = 10000;

    TreiberStack<int> stack;

    std::vector<std::thread> pushers;
    for (int t = 0; t < kThreads; ++t)
        pushers.emplace_back([&] {
            for (int i = 0; i < kPerThread; ++i) stack.push(i);
        });

    for (auto& t : pushers) t.join();

    long long sum   = 0;
    int       count = 0;
    int       value = 0;

    while (stack.pop(value))
    {
        sum += value;
        ++count;
    }

    EXPECT_EQ(count, kThreads * kPerThread) << "часть push потерялась в CAS-гонке";
    EXPECT_EQ(sum, 1LL * kThreads * kPerThread * (kPerThread - 1) / 2);
}
