// Тренажёр: писать с чистого листа, вслух, потом компилировать.
//
// Правила:
//   1. Не подглядывать в doc/ и не гуглить, пока не написал свой вариант.
//   2. Проговаривать КАЖДУЮ строчку вслух, пока пишешь. Именно это спросят.
//   3. Сначала скомпилировать, потом сверяться с разбором в doc/02-interview-questions/.
//   4. Засекать время. Норма на одну задачу — 5-8 минут вместе с объяснением.
//
// Сборка:
//   g++ -std=c++20 -Wall -Wextra -O2 -o drills drills.cxx -lgtest -lgtest_main -pthread && ./drills
//
// Обязательно с -Wall -Wextra: вчерашний баг с секциями for ловится именно так.

#include <gtest/gtest.h>

#include <algorithm>
#include <list>
#include <map>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>
#include <unordered_set>
#include <queue>

// --- 1. vector: удалить все вхождения значения --------------------------------
// Вслух: что делает remove, что остаётся в хвосте, почему нужен второй шаг.
TEST(Drills, EraseAllOccurrences)
{
    std::vector<int> v{1, 2, 3, 1, 1, 2, 3};

    v.erase(std::remove_if(v.begin(), v.end(),[](int element) {
        return element == 1;
    }), v.end());

    // TODO: удалить все единицы. Двумя способами: erase-remove и C++20.

    EXPECT_EQ(v, (std::vector<int>{2, 3, 2, 3}));
}

// --- 2. vector: удалить по предикату, посчитав сколько удалено -----------------
// Вслух: что возвращает std::erase_if и почему это удобнее пары итераторов.
TEST(Drills, EraseIfCountingRemoved)
{
    std::vector<int> v{1, 2, 3, 4, 5, 6, 7, 8};
    std::size_t removed = 0;

    std::erase_if(v, [beginPtr = v.data(), &removed](int& element)
    {
        if ((&element - beginPtr) & 1)
        {
            ++removed;
            return true;
        }

        return false;
    });
    // TODO: удалить чётные, записать количество в removed.

    EXPECT_EQ(removed, 4u);
    EXPECT_EQ(v, (std::vector<int>{1, 3, 5, 7}));
}

// --- 3. set<string>: capitalize первой буквы ----------------------------------
// Вслух: почему элемент нельзя менять на месте; зачем итератор двигают заранее;
// что вернёт insert при коллизии и кто владеет узлом после неудачи.
TEST(Drills, SetCapitalizeFirstLetter)
{
    std::set<std::string> names{"anna", "Anna", "bob", "Bob", "kate", "Kate", "helen"};

    for(auto it = names.begin(), ite = names.end(); it != ite; )
    {
        auto& val = *it;

        if(val.empty() || std::isupper(val[0]))
        {
            ++it;
            continue;
        }

        auto curr = it;
        ++it; // Shift gears before extraction

        auto node = names.extract(curr);
        auto& fst = node.value()[0];
        fst = std::toupper(fst);

        names.insert(std::move(node));
    }

    // TODO: сделать первую букву заглавной у каждого элемента.
    //       Дубликаты схлопнуть ОСОЗНАННО, а не молча.

    EXPECT_EQ(names, (std::set<std::string>{"Anna", "Bob", "Helen", "Kate"}));
}

// --- 4. map: удалить записи по условию во время обхода ------------------------
// Вслух: что инвалидирует erase у map и что не инвалидирует; почему it = erase(it).
TEST(Drills, EraseFromMapWhileIterating)
{
    std::map<std::string, int> scores{{"a", 5}, {"b", 50}, {"c", 3}, {"d", 100}};

    for(auto it = scores.begin(), ite = scores.end(); it != ite;)
    {
        auto& val = it->second;

        if(val < 10)
        {
            it = scores.erase(it);
            continue;
        }

        ++it;
    }
    
    EXPECT_EQ(scores, (std::map<std::string, int>{{"b", 50}, {"d", 100}}));
}

// --- 5. map: переименовать ключ, не трогая значение ---------------------------
// Вслух: чем node handle у map отличается от set; что будет, если новый ключ занят.
TEST(Drills, RenameMapKey)
{
    std::map<std::string, int> m{{"old", 42}, {"other", 7}};

    auto it = m.find("old");
    auto node = m.extract(it);
    node.key() = "new";

    m.insert(std::move(node));

    // TODO: переименовать ключ "old" в "new", сохранив значение 42.
    //       Без лишних копий значения.

    EXPECT_EQ(m, (std::map<std::string, int>{{"new", 42}, {"other", 7}}));
}

// --- 6. vector<string>: убрать дубликаты, сохранив порядок первых вхождений ----
// Вслух: почему sort+unique здесь не подходит; какая сложность у вашего решения.
TEST(Drills, DedupPreservingOrder)
{
    std::vector<std::string> v{"b", "a", "b", "c", "a", "d"};

    std::erase_if(v, [visited = std::unordered_set<std::string>{}](std::string& str) mutable {

        auto [_, inserted] = visited.insert(str);
        return !inserted;
    });

    // TODO: оставить первые вхождения в исходном порядке.

    EXPECT_EQ(v, (std::vector<std::string>{"b", "a", "c", "d"}));
}

// --- 7. Top-K по частоте ------------------------------------------------------
// Вслух: почему nth_element/partial_sort, а не полная сортировка; сложность.
TEST(Drills, TopKFrequent)
{
    std::vector<std::string> words{"go", "cpp", "go", "rust", "cpp", "go"};
    std::unordered_map<std::string, int> freqs;

    for(auto& w: words)
    {
        ++freqs[w];
    }

    using Data = std::pair<std::string, int>;

    auto cmp = [](const auto& lhs, const auto& rhs)
    {
        return lhs.second > rhs.second;
    };

    std::priority_queue<Data, std::vector<Data>, decltype(cmp)> pq(cmp);

    auto it = freqs.begin();
    auto ite = freqs.end();

    for(; it != ite && pq.size() < 2; ++it)
    {
        pq.emplace(it->first, it->second);
    }

    for(; it != ite; ++it)
    {
        auto topFreq = pq.top().second;

        if(topFreq < it->second)
        {
            pq.pop();
            pq.emplace(it->first, it->second);
        }
    }

    std::vector<std::pair<std::string, int>> top;  // TODO: заполнить top-2 по частоте

    while(!pq.empty())
    {
        top.push_back(pq.top());
        pq.pop();
    }

    std::ranges::reverse(top);

    

    ASSERT_EQ(top.size(), 2u);
    EXPECT_EQ(top[0], std::make_pair(std::string("go"), 3));
    EXPECT_EQ(top[1], std::make_pair(std::string("cpp"), 2));
}

// --- 8. Стабильная сортировка по двум ключам ----------------------------------
// Вслух: что такое strict weak ordering и что будет, если написать <= вместо <.
TEST(Drills, SortByPriceThenTime)
{
    struct Order { int price; int time; };
    std::vector<Order> orders{{100, 3}, {99, 1}, {100, 1}, {99, 2}};

    // TODO: отсортировать по возрастанию цены, при равной цене — по возрастанию времени.

    std::ranges::sort(orders, [](const auto& lhs, const auto& rhs)
    {
        if(lhs.price == rhs.price)
        {
            return lhs.time < rhs.time;
        }

        return lhs.price < rhs.price;
    });

    ASSERT_EQ(orders.size(), 4u);
    EXPECT_EQ(orders[0].price, 99);  EXPECT_EQ(orders[0].time, 1);
    EXPECT_EQ(orders[1].price, 99);  EXPECT_EQ(orders[1].time, 2);
    EXPECT_EQ(orders[2].price, 100); EXPECT_EQ(orders[2].time, 1);
    EXPECT_EQ(orders[3].price, 100); EXPECT_EQ(orders[3].time, 3);
}
