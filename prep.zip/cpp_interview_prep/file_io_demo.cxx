// Четыре способа прочитать файл: read(), stdio (FILE*), iostream (std::ifstream), mmap.
// Каждый сценарий проверяет одно утверждение из конспекта
// doc/01-general-topics/20-file-io-read-stdio-iostream-mmap.md
//
// Сборка:
//   g++ -std=c++20 -Wall -Wextra -O2 -o file_io_demo file_io_demo.cxx && ./file_io_demo
//   g++ -std=c++20 -g -fsanitize=address,undefined -o file_io_demo_asan file_io_demo.cxx && ./file_io_demo_asan
//
//   ./file_io_demo [каталог]   — по умолчанию текущий каталог.
// Временный файл (64 МБ) создаётся в этом каталоге и удаляется в конце.
// Каталог должен лежать на настоящей дисковой ФС (ext4, xfs). На tmpfs — а /tmp часто
// именно tmpfs — файл и есть page cache: выгрузить его некуда, O_DIRECT ничего не значит,
// и сценарии 3 и 6 теряют смысл. Программа предупредит.
//
// Как читать счётчики:
//   syscr   — сколько системных вызовов чтения сделал процесс (/proc/self/io);
//   minflt  — минорные page fault'ы: страница уже в памяти, ядро только прописало её
//             в таблицу страниц процесса;
//   majflt  — мажорные: страницу пришлось читать с диска.

#include <fcntl.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/statfs.h>
#include <linux/magic.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio_ext.h>   // __fbufsize: размер буфера FILE* (расширение glibc)

#include <algorithm>
#include <chrono>
#include <csetjmp>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {

// ---------------------------------------------------------------- утилиты

[[noreturn]] void die(const char* what)
{
    std::perror(what);
    std::exit(1);
}

// Проверка результата системного вызова: в демо любая ошибка фатальна.
long long ck(long long rc, const char* what)
{
    if (rc < 0) die(what);
    return rc;
}

// printf("%-34s") считает байты, а кириллица в UTF-8 — два байта на букву.
// Дополняем пробелами по числу символов.
std::string pad(const char* s, std::size_t width)
{
    std::size_t chars = 0;
    for (const char* q = s; *q; ++q) chars += (static_cast<unsigned char>(*q) & 0xC0) != 0x80;
    std::string r(s);
    if (chars < width) r.append(width - chars, ' ');
    return r;
}

// Сколько страниц файла сейчас лежит в page cache (mincore по временному отображению).
long resident_pages(const char* path)
{
    int fd = ::open(path, O_RDONLY);
    struct stat st{};
    ::fstat(fd, &st);
    void* m = ::mmap(nullptr, std::size_t(st.st_size), PROT_READ, MAP_SHARED, fd, 0);
    std::vector<unsigned char> v((std::size_t(st.st_size) + 4095) / 4096);
    ::mincore(m, std::size_t(st.st_size), v.data());
    long r = 0;
    for (unsigned char c : v) r += c & 1;
    ::munmap(m, std::size_t(st.st_size));
    ::close(fd);
    return r;
}

struct IoCounters
{
    long long syscr = 0;   // системные вызовы read/pread/readv и т.п.
    long long rchar = 0;   // байт, прошедших через эти вызовы
    long long read_bytes = 0; // байт, реально прочитанных с блочного устройства
};

IoCounters read_io()
{
    IoCounters c;
    std::FILE* f = std::fopen("/proc/self/io", "r");
    if (!f) die("fopen /proc/self/io");
    char key[64];
    long long val;
    while (std::fscanf(f, "%63[^:]: %lld\n", key, &val) == 2) {
        if (!std::strcmp(key, "syscr")) c.syscr = val;
        else if (!std::strcmp(key, "rchar")) c.rchar = val;
        else if (!std::strcmp(key, "read_bytes")) c.read_bytes = val;
    }
    std::fclose(f);
    // Сам fopen/fscanf выше тоже делает read(); эта цена вычитается через g_probe_syscr.
    return c;
}

struct Faults { long minflt, majflt; };

Faults faults()
{
    rusage ru{};
    getrusage(RUSAGE_SELF, &ru);
    return {ru.ru_minflt, ru.ru_majflt};
}

double now_ms()
{
    using namespace std::chrono;
    return duration<double, std::milli>(steady_clock::now().time_since_epoch()).count();
}

// Стоимость самого чтения /proc/self/io, чтобы вычесть её из замеров.
long long g_probe_syscr = 0;

void calibrate_probe()
{
    IoCounters a = read_io();
    IoCounters b = read_io();
    g_probe_syscr = b.syscr - a.syscr;
}

// ---------------------------------------------------------------- тестовый файл

// Текстовый файл из строк вида "1700000000123456789,AAPL,189.2500,100,B\n".
// Работа во всех способах одинаковая: посчитать '\n'. Так сравниваются механизмы доступа.
std::size_t make_file(const fs::path& p, std::size_t target_bytes)
{
    std::FILE* f = std::fopen(p.c_str(), "w");
    if (!f) die("fopen for write");
    std::size_t written = 0, lines = 0;
    char line[128];
    unsigned long long ts = 1700000000000000000ULL;
    while (written < target_bytes) {
        int n = std::snprintf(line, sizeof line, "%llu,AAPL,%d.%04d,%d,%c\n",
                              ts, 180 + int(lines % 20), int(lines % 10000),
                              int(1 + lines % 500), (lines & 1) ? 'B' : 'S');
        std::fwrite(line, 1, std::size_t(n), f);
        written += std::size_t(n);
        ++lines;
        ts += 1000;
    }
    std::fclose(f);
    return lines;
}

// ---------------------------------------------------------------- способы чтения
// Каждая функция возвращает число '\n'.

std::size_t via_read(const char* path, std::size_t buf_size)
{
    int fd = ::open(path, O_RDONLY | O_CLOEXEC);
    if (fd < 0) die("open");
    std::vector<char> buf(buf_size);
    std::size_t lines = 0;
    for (;;) {
        ssize_t n = ::read(fd, buf.data(), buf.size());
        if (n < 0) {
            if (errno == EINTR) continue;   // сигнал прервал вызов — повторить
            die("read");
        }
        if (n == 0) break;                  // 0 — это конец файла, не ошибка
        lines += std::size_t(std::count(buf.data(), buf.data() + n, '\n'));
    }
    ::close(fd);
    return lines;
}

std::size_t via_fread(const char* path, std::size_t chunk)
{
    std::FILE* f = std::fopen(path, "rb");
    if (!f) die("fopen");
    std::vector<char> buf(chunk);
    std::size_t lines = 0, n;
    while ((n = std::fread(buf.data(), 1, buf.size(), f)) > 0)
        lines += std::size_t(std::count(buf.data(), buf.data() + n, '\n'));
    std::fclose(f);
    return lines;
}

std::size_t via_fgetc(const char* path)
{
    std::FILE* f = std::fopen(path, "rb");
    if (!f) die("fopen");
    std::size_t lines = 0;
    int c;
    while ((c = std::fgetc(f)) != EOF) lines += (c == '\n');
    std::fclose(f);
    return lines;
}

std::size_t via_getc_unlocked(const char* path)
{
    std::FILE* f = std::fopen(path, "rb");
    if (!f) die("fopen");
    std::size_t lines = 0;
    int c;
    while ((c = getc_unlocked(f)) != EOF) lines += (c == '\n');
    std::fclose(f);
    return lines;
}

std::size_t via_posix_getline(const char* path)
{
    std::FILE* f = std::fopen(path, "rb");
    if (!f) die("fopen");
    char* line = nullptr;   // getline сам выделяет и растит буфер
    std::size_t cap = 0, lines = 0;
    while (::getline(&line, &cap, f) != -1) ++lines;
    std::free(line);
    std::fclose(f);
    return lines;
}

std::size_t via_ifstream_read(const char* path, std::size_t chunk)
{
    std::ifstream in(path, std::ios::binary);
    if (!in) die("ifstream");
    std::vector<char> buf(chunk);
    std::size_t lines = 0;
    while (in.read(buf.data(), std::streamsize(buf.size())) || in.gcount() > 0)
        lines += std::size_t(std::count(buf.data(), buf.data() + in.gcount(), '\n'));
    return lines;
}

std::size_t via_ifstream_get(const char* path)
{
    std::ifstream in(path, std::ios::binary);
    if (!in) die("ifstream");
    std::size_t lines = 0;
    char c;
    while (in.get(c)) lines += (c == '\n');
    return lines;
}

std::size_t via_istreambuf_iterator(const char* path)
{
    std::ifstream in(path, std::ios::binary);
    if (!in) die("ifstream");
    return std::size_t(std::count(std::istreambuf_iterator<char>(in),
                                  std::istreambuf_iterator<char>(), '\n'));
}

std::size_t via_std_getline(const char* path)
{
    std::ifstream in(path);
    if (!in) die("ifstream");
    std::string s;
    std::size_t lines = 0;
    while (std::getline(in, s)) ++lines;
    return lines;
}

std::size_t via_mmap(const char* path, int extra_flags, int advice)
{
    int fd = ::open(path, O_RDONLY | O_CLOEXEC);
    if (fd < 0) die("open");
    struct stat st{};
    if (::fstat(fd, &st) < 0) die("fstat");
    std::size_t len = std::size_t(st.st_size);
    if (len == 0) { ::close(fd); return 0; }  // mmap длины 0 — EINVAL
    void* p = ::mmap(nullptr, len, PROT_READ, MAP_PRIVATE | extra_flags, fd, 0);
    if (p == MAP_FAILED) die("mmap");
    ::close(fd);   // отображение держит свою ссылку на файл, fd больше не нужен
    if (advice >= 0) ::madvise(p, len, advice);
    const char* b = static_cast<const char*>(p);
    std::size_t lines = std::size_t(std::count(b, b + len, '\n'));
    ::munmap(p, len);
    return lines;
}

// ---------------------------------------------------------------- 1. буферы

void scenario_buffers(const char* path)
{
    std::puts("\n=== 1. Где и какого размера буферы ===");
    struct stat st{};
    ::stat(path, &st);
    std::printf("  размер страницы (sysconf)        : %ld\n", ::sysconf(_SC_PAGESIZE));
    std::printf("  st_blksize файла                 : %ld\n", long(st.st_blksize));
    std::printf("  BUFSIZ из <cstdio>               : %d\n", BUFSIZ);

    std::FILE* f = std::fopen(path, "rb");
    std::printf("  буфер FILE* до первого чтения    : %zu байт (ещё не выделен)\n", __fbufsize(f));
    (void)std::fgetc(f);
    std::printf("  буфер FILE* после fgetc          : %zu байт (= st_blksize)\n", __fbufsize(f));
    std::fclose(f);

    // Буфер std::filebuf снаружи не виден — вычисляем по числу системных вызовов:
    // сколько байт в среднем приносит один read(), когда читаем по символу.
    auto per_call = [&](auto fn) {
        IoCounters a = read_io();
        fn();
        IoCounters b = read_io();
        long long calls = b.syscr - a.syscr - g_probe_syscr;
        long long bytes = b.rchar - a.rchar;
        return std::pair{calls, calls ? bytes / calls : 0};
    };
    auto [c1, b1] = per_call([&] { via_fgetc(path); });
    auto [c2, b2] = per_call([&] { via_ifstream_get(path); });
    std::printf("  fgetc по байту         : %7lld вызовов read(), в среднем %lld байт за вызов\n", c1, b1);
    std::printf("  ifstream::get по байту : %7lld вызовов read(), в среднем %lld байт за вызов\n", c2, b2);
}

// ---------------------------------------------------------------- 2. скорость

struct Method { const char* name; std::size_t (*fn)(const char*); };

void scenario_speed(const char* path, std::size_t expect_lines, std::size_t bytes)
{
    std::puts("\n=== 2. Горячий page cache: один и тот же файл четырнадцатью способами ===");
    std::printf("  файл %.1f МБ, %zu строк; время — лучшее из 5 прогонов\n",
                double(bytes) / (1 << 20), expect_lines);
    std::printf("  %s %9s %8s %9s %8s\n", pad("способ", 32).c_str(), "мс", "ГБ/с", "syscr", "minflt");

    static const Method methods[] = {
        {"read(), буфер 4 КБ",              [](const char* p) { return via_read(p, 4096); }},
        {"read(), буфер 64 КБ",             [](const char* p) { return via_read(p, 64 << 10); }},
        {"read(), буфер 1 МБ",              [](const char* p) { return via_read(p, 1 << 20); }},
        {"fread() кусками 64 КБ",           [](const char* p) { return via_fread(p, 64 << 10); }},
        {"fgetc() по байту",                via_fgetc},
        {"getc_unlocked() по байту",        via_getc_unlocked},
        {"getline() POSIX по строке",       via_posix_getline},
        {"ifstream::read кусками 64 КБ",    [](const char* p) { return via_ifstream_read(p, 64 << 10); }},
        {"ifstream::get по байту",          via_ifstream_get},
        {"istreambuf_iterator по байту",    via_istreambuf_iterator},
        {"std::getline по строке",          via_std_getline},
        {"mmap, ленивый",                   [](const char* p) { return via_mmap(p, 0, -1); }},
        {"mmap + MADV_SEQUENTIAL",          [](const char* p) { return via_mmap(p, 0, MADV_SEQUENTIAL); }},
        {"mmap + MAP_POPULATE",             [](const char* p) { return via_mmap(p, MAP_POPULATE, -1); }},
    };

    for (const Method& m : methods) {
        double best = 1e18;
        long long calls = 0;
        long minflt = 0;
        for (int rep = 0; rep < 5; ++rep) {
            IoCounters io0 = read_io();
            Faults f0 = faults();
            double t0 = now_ms();
            std::size_t got = m.fn(path);
            double t1 = now_ms();
            Faults f1 = faults();
            IoCounters io1 = read_io();
            if (got != expect_lines) {
                std::fprintf(stderr, "%s: насчитано %zu строк вместо %zu\n", m.name, got, expect_lines);
                std::exit(1);
            }
            if (t1 - t0 < best) {
                best = t1 - t0;
                calls = io1.syscr - io0.syscr - g_probe_syscr;
                minflt = f1.minflt - f0.minflt;
            }
        }
        std::printf("  %s %9.1f %8.2f %9lld %8ld\n", pad(m.name, 32).c_str(), best,
                    double(bytes) / best / 1e6, calls, minflt);
    }
}

// ---------------------------------------------------------------- 3. холодный кэш

void scenario_cold(const char* path, std::size_t bytes)
{
    std::puts("\n=== 3. Холодный кэш: страницы выброшены через posix_fadvise(DONTNEED) ===");
    auto drop = [&] {
        int fd = ::open(path, O_RDONLY);
        ::fdatasync(fd);                                  // грязные страницы не выгружаются
        ::posix_fadvise(fd, 0, 0, POSIX_FADV_DONTNEED);   // без root, только чистые страницы
        ::close(fd);
    };
    long total = long((bytes + 4095) / 4096);
    std::printf("  страниц файла в page cache: до сброса %ld из %ld", resident_pages(path), total);
    drop();
    std::printf(", после сброса %ld\n", resident_pages(path));
    auto run = [&](const char* name, auto fn) {
        drop();
        IoCounters io0 = read_io();
        Faults f0 = faults();
        double t0 = now_ms();
        fn();
        double t1 = now_ms();
        Faults f1 = faults();
        IoCounters io1 = read_io();
        std::printf("  %s %8.1f мс  с диска %6.1f МБ  majflt %5ld  minflt %6ld\n", pad(name, 24).c_str(), t1 - t0,
                    double(io1.read_bytes - io0.read_bytes) / (1 << 20),
                    f1.majflt - f0.majflt, f1.minflt - f0.minflt);
    };
    run("read(), буфер 1 МБ", [&] { via_read(path, 1 << 20); });
    run("mmap, ленивый", [&] { via_mmap(path, 0, -1); });
    run("mmap + MADV_SEQUENTIAL", [&] { via_mmap(path, 0, MADV_SEQUENTIAL); });
    run("mmap + MAP_POPULATE", [&] { via_mmap(path, MAP_POPULATE, -1); });
}

// ---------------------------------------------------------------- 4. видимость записей

std::string read_all_fd(const char* path)
{
    int fd = ::open(path, O_RDONLY);
    std::string s(4096, '\0');
    ssize_t n = ::read(fd, s.data(), s.size());
    ::close(fd);
    s.resize(n > 0 ? std::size_t(n) : 0);
    return s;
}

void scenario_visibility(const fs::path& dir)
{
    std::puts("\n=== 4. Кто чью запись видит ===");
    fs::path p = dir / "file_io_demo_vis.txt";
    const char* path = p.c_str();

    // 4a. stdio копит запись в своём буфере в памяти процесса.
    {
        std::FILE* f = std::fopen(path, "w");
        std::fputs("hello", f);
        std::printf("  4a. fputs без fflush, соседний read() видит %zu байт\n", read_all_fd(path).size());
        std::fflush(f);
        std::printf("      после fflush                       видит %zu байт\n", read_all_fd(path).size());
        std::fclose(f);
    }

    // 4b. write() и MAP_SHARED смотрят в одни и те же страницы page cache.
    {
        int fd = ::open(path, O_RDWR | O_TRUNC);
        ck(::ftruncate(fd, 4096), "ftruncate");
        char* m = static_cast<char*>(::mmap(nullptr, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0));
        char* priv = static_cast<char*>(::mmap(nullptr, 4096, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0));
        ck(::pwrite(fd, "AAAA", 4, 0), "pwrite");
        std::printf("  4b. pwrite \"AAAA\": MAP_SHARED видит \"%.4s\", MAP_PRIVATE видит \"%.4s\"\n", m, priv);
        std::memcpy(m, "BBBB", 4);
        char back[5] = {};
        ck(::pread(fd, back, 4, 0), "pread");
        std::printf("      запись через MAP_SHARED \"BBBB\", pread без msync видит \"%s\"\n", back);
        priv[0] = 'p';   // первая запись в MAP_PRIVATE: копирование страницы (COW)
        ck(::pwrite(fd, "CCCC", 4, 0), "pwrite");
        std::printf("      после записи в MAP_PRIVATE его страница — копия: видит \"%.4s\", файл \"%.4s\"\n",
                    priv, m);
        ::munmap(m, 4096);
        ::munmap(priv, 4096);
        ::close(fd);
    }

    // 4c. Что переживает внезапную смерть процесса (_exit не сбрасывает буферы stdio).
    auto crash_child = [&](const char* name, auto body) {
        ck(::truncate(path, 0), "truncate");
        pid_t pid = ::fork();
        if (pid == 0) { body(); ::_exit(0); }
        ::waitpid(pid, nullptr, 0);
        std::printf("      %s в файле %zu байт\n", pad(name, 30).c_str(), std::size_t(fs::file_size(p)));
    };
    std::puts("  4c. ребёнок пишет 5 байт и умирает через _exit(), не закрыв файл:");
    crash_child("fwrite() без fflush", [&] {
        std::FILE* f = std::fopen(path, "w");
        std::fwrite("hello", 1, 5, f);
    });
    crash_child("std::ofstream << без flush", [&] {
        std::ofstream o(path);
        o << "hello";
        ::_exit(0);          // деструктор ofstream не успевает
    });
    crash_child("write()", [&] {
        int fd = ::open(path, O_WRONLY);
        ck(::write(fd, "hello", 5), "write");
    });
    crash_child("запись через MAP_SHARED", [&] {
        int fd = ::open(path, O_RDWR);
        ck(::ftruncate(fd, 5), "ftruncate");
        char* m = static_cast<char*>(::mmap(nullptr, 5, PROT_WRITE, MAP_SHARED, fd, 0));
        std::memcpy(m, "hello", 5);
    });
    fs::remove(p);
}

// ---------------------------------------------------------------- 5. конец файла и SIGBUS

sigjmp_buf g_jmp;
void on_sigbus(int) { siglongjmp(g_jmp, 1); }

void scenario_sigbus(const fs::path& dir)
{
    std::puts("\n=== 5. Конец файла: read() возвращает 0, mmap бьёт сигналом ===");
    fs::path p = dir / "file_io_demo_bus.bin";
    int fd = ::open(p.c_str(), O_RDWR | O_CREAT | O_TRUNC, 0644);
    ck(::ftruncate(fd, 100), "ftruncate");   // файл 100 байт, отображаем 2 страницы
    char* m = static_cast<char*>(::mmap(nullptr, 8192, PROT_READ, MAP_SHARED, fd, 0));

    char buf[16];
    std::printf("  read() на позиции 100 (конец файла) вернул %zd\n", ::pread(fd, buf, 16, 100));
    std::printf("  mmap: байт 200 — внутри последней страницы, за концом файла: %d (нули)\n", m[200]);

    struct sigaction sa{}, old{};
    sa.sa_handler = on_sigbus;
    ::sigaction(SIGBUS, &sa, &old);
    if (sigsetjmp(g_jmp, 1) == 0) {
        volatile char c = m[4096];   // вторая страница: за концом файла целиком
        (void)c;
        std::puts("  mmap: байт 4096 прочитан без сигнала (неожиданно)");
    } else {
        std::puts("  mmap: байт 4096 — страница целиком за концом файла: SIGBUS");
    }
    ck(::ftruncate(fd, 0), "ftruncate");     // кто-то обрезал файл, пока он отображён
    if (sigsetjmp(g_jmp, 1) == 0) {
        volatile char c = m[0];
        (void)c;
        std::puts("  после ftruncate(0) байт 0 прочитан (неожиданно)");
    } else {
        std::puts("  после ftruncate(0) даже байт 0: SIGBUS — read() в той же ситуации вернул бы 0");
    }
    ::sigaction(SIGBUS, &old, nullptr);
    ::munmap(m, 8192);
    ::close(fd);
    fs::remove(p);
}

// ---------------------------------------------------------------- 6. O_DIRECT

void scenario_odirect(const char* path)
{
    std::puts("\n=== 6. O_DIRECT: мимо page cache, но с требованиями к выравниванию ===");
    struct statx sx{};
    if (::statx(AT_FDCWD, path, 0, STATX_DIOALIGN, &sx) == 0 && (sx.stx_mask & STATX_DIOALIGN))
        std::printf("  statx(STATX_DIOALIGN): адрес буфера кратен %u, смещение и длина кратны %u\n",
                    sx.stx_dio_mem_align, sx.stx_dio_offset_align);
    int fd = ::open(path, O_RDONLY | O_DIRECT);
    if (fd < 0) { std::printf("  O_DIRECT не поддерживается этой ФС: %s\n", std::strerror(errno)); return; }
    void* raw = nullptr;
    if (::posix_memalign(&raw, 4096, 8192) != 0) die("posix_memalign");
    char* b = static_cast<char*>(raw);
    struct Case { const char* name; char* buf; std::size_t len; off_t off; };
    const Case cases[] = {
        {"буфер выровнен, 4096 байт с 0", b, 4096, 0},
        {"буфер сдвинут на 1 байт", b + 1, 4096, 0},
        {"длина 100 байт", b, 100, 0},
        {"смещение 3 байта", b, 4096, 3},
        {"512 байт со смещения 512", b, 512, 512},
    };
    for (const Case& c : cases) {
        ssize_t n = ::pread(fd, c.buf, c.len, c.off);
        std::printf("  %s pread = %5zd  %s\n", pad(c.name, 30).c_str(), n, n < 0 ? std::strerror(errno) : "");
    }
    std::free(raw);
    ::close(fd);
}

} // namespace

int main(int argc, char** argv)
{
    calibrate_probe();

    fs::path dir = argc > 1 ? fs::path(argv[1]) : fs::current_path();
    struct statfs sfs{};
    if (::statfs(dir.c_str(), &sfs) == 0 && sfs.f_type == TMPFS_MAGIC)
        std::printf("ВНИМАНИЕ: %s — это tmpfs. Файл целиком живёт в page cache,\n"
                    "сценарии 3 (холодный кэш) и 6 (O_DIRECT) покажут не то. Укажите каталог на диске.\n",
                    dir.c_str());
    fs::path p = dir / "file_io_demo.bin";
    const std::size_t target = std::size_t(64) << 20;   // 64 МБ
    std::size_t lines = make_file(p, target);
    std::size_t bytes = fs::file_size(p);
    via_read(p.c_str(), 1 << 20);                        // прогреть page cache

    scenario_buffers(p.c_str());
    scenario_speed(p.c_str(), lines, bytes);
    scenario_cold(p.c_str(), bytes);
    scenario_visibility(dir);
    scenario_sigbus(dir);
    scenario_odirect(p.c_str());

    fs::remove(p);
    return 0;
}
