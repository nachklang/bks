// План на 2026-09-09 (день -2 до интервью). 2-3 часа.
//
// Здесь только то, что сегодня красное. Ничего лишнего.
//   Блок A, ~90 мин — 7 STL-задач, порядок в файле = порядок решения (от простого).
//   Блок B, ~45 мин — Semaphore, Latch, OnceFlag. Все три — один паттерн
//                     mutex + condition_variable + счётчик, который ты уже
//                     отработал на bounded queue. Делать подряд, одним заходом.
//
// Правила прежние:
//   1. Не подглядывать в drills.cxx, drills_mt.cxx, doc/ и не гуглить,
//      пока не написал свой вариант и не скомпилировал.
//   2. Проговаривать КАЖДУЮ строчку вслух. На интервью после кода идёт допрос.
//   3. Засекать время. STL — 5-8 минут на задачу вместе с объяснением,
//      блок B — 10-12 минут на задачу.
//   4. Зелёный тест в блоке B НЕ означает корректность: гонка может не выстрелить
//      сто раз подряд. Обязательно прогнать под TSan.
//
// Сборка:
//   g++ -std=c++20 -Wall -Wextra -O2 -o today today_09_09.cxx -lgtest -lgtest_main -pthread && ./today
//
// Одну задачу за раз:
//   ./today --gtest_filter=Today.SetCapitalizeFirstLetter
//
// После блока B обязательно:
//   g++ -std=c++20 -g -fsanitize=thread -o today_tsan today_09_09.cxx -lgtest -lgtest_main -pthread && ./today_tsan
//   ./today --gtest_repeat=100 --gtest_break_on_failure

#include <gtest/gtest.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstddef>
#include <iterator>
#include <map>
#include <mutex>
#include <set>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

// ================================================================================
// БЛОК A — STL. Семь долгов из drills_blank.cxx.
// ================================================================================

// --- A1. map: удалить записи по условию во время обхода ------------------------
// Вслух: что инвалидирует erase у map и что не инвалидирует; почему it = erase(it);
// почему `for (auto it = m.begin(); it != m.end(); ++it)` с erase внутри — UB.
TEST(Today, EraseFromMapWhileIterating)
{
    std::map<std::string, int> scores{{"a", 5}, {"b", 50}, {"c", 3}, {"d", 100}};

    for(auto it = scores.begin(), ite = scores.end(); it != ite; )
    {
        auto& [_, val] = *it;

        if(val < 10)
        {
            it = scores.erase(it);
            continue;
        }

        ++it;
    }

    // TODO: удалить все записи со значением меньше 10 прямо во время обхода.
    //       Потом сказать вслух, как то же самое пишется одной строкой в C++20.

    EXPECT_EQ(scores, (std::map<std::string, int>{{"b", 50}, {"d", 100}}));
}

// --- A2. set: удалить элементы по условию --------------------------------------
// Вслух: почему идиома erase-remove здесь не компилируется в принципе и при чём
// тут const у ключа; что возвращает set::erase(it) и с какого стандарта;
// какие итераторы инвалидирует erase у set, а какие нет.
TEST(Today, EraseRemoveFromSet)
{
    std::set<int> a{1, 2, 3, 4, 5, 6, 7, 8};
    std::set<int> b = a;
    std::size_t removed = 0;

    // Итератор на семёрку. Она нечётная и остаётся — но переживёт ли итератор?
    auto watch = a.find(7);

    for(auto it = a.begin(), ite = a.end(); it != ite; )
    {
        if((*it & 1) == 0)
        {
            it = a.erase(it);
            continue;
        }
        ++it;
    }

    removed = std::erase_if(b, [](int element) {
        return (element & 1) == 0;
    } );

    // TODO: способ 1 — удалить чётные из a вручную, циклом по итераторам.
    //       Предикат по ЗНАЧЕНИЮ элемента, а не по позиции в обходе.
    // TODO: способ 2 — удалить чётные из b одной строкой C++20,
    //       записав количество удалённых в removed.

    EXPECT_EQ(a, (std::set<int>{1, 3, 5, 7}));
    EXPECT_EQ(b, (std::set<int>{1, 3, 5, 7}));
    EXPECT_EQ(removed, 4u);

    // erase у set инвалидирует только удалённые итераторы — узел с семёркой цел.
    EXPECT_EQ(*watch, 7);
}

// --- A3. Стабильная сортировка по двум ключам ----------------------------------
// Вслух: что такое strict weak ordering и что конкретно сломается, если написать
// <= вместо <; чем sort отличается от stable_sort и нужен ли здесь stable_sort,
// раз компаратор и так сравнивает оба поля.
TEST(Today, SortByPriceThenTime)
{
    struct Order { int price; int time; };
    std::vector<Order> orders{{100, 3}, {99, 1}, {100, 1}, {99, 2}};

    // TODO: отсортировать по возрастанию цены, при равной цене — по возрастанию времени.

    std::ranges::sort(orders, [](const auto& lhs, const auto& rhs) {
        if(lhs.price == rhs.price)
        {
            return lhs.time < rhs.time;
        }

        return lhs.price < rhs.price;
    });

    ASSERT_EQ(orders.size(), 4u);
    EXPECT_EQ(orders[0].price, 99);  EXPECT_EQ(orders[0].time, 1);
    EXPECT_EQ(orders[1].price, 99);  EXPECT_EQ(orders[1].time, 2);
    EXPECT_EQ(orders[2].price, 100); EXPECT_EQ(orders[2].time, 1);
    EXPECT_EQ(orders[3].price, 100); EXPECT_EQ(orders[3].time, 3);
}

// --- A4. map: переименовать ключ, не трогая значение ---------------------------
// Вслух: чем node handle у map отличается от set (что именно там неconst);
// что будет, если новый ключ уже занят — куда денется узел и как это проверить;
// почему extract дешевле, чем insert новой пары + erase старой.
TEST(Today, RenameMapKey)
{
    std::map<std::string, int> m{{"old", 42}, {"other", 7}};

    auto it = m.find("old");
    auto node = m.extract(it);
    node.key() = "new";
    m.insert(std::move(node));

    // TODO: переименовать ключ "old" в "new", сохранив значение 42.
    //       Без лишних копий значения.

    EXPECT_EQ(m, (std::map<std::string, int>{{"new", 42}, {"other", 7}}));
}

// --- A5. set<string>: capitalize первой буквы ----------------------------------
// Вслух: почему элемент set нельзя менять на месте; зачем итератор двигают заранее;
// что вернёт insert при коллизии и кто владеет узлом после неудачной вставки.
// ЛОВУШКА: std::toupper от char — UB на отрицательных значениях.
// Обязательно сказать про static_cast<unsigned char> и объяснить, почему.
TEST(Today, SetCapitalizeFirstLetter)
{
    std::set<std::string> names{"anna", "Anna", "bob", "Bob", "kate", "Kate", "helen"};

    for(auto it = names.begin(), ite = names.end(); it != ite; )
    {
        if(auto curr = *it; curr.empty() || std::isupper(curr[0]))
        {
            ++it;
            continue;
        }

        auto curr = it;
        ++it;

        auto node = names.extract(curr);
        auto& val = node.value();
        val[0] = std::toupper(val[0]);

        names.insert(std::move(node));
    }

    // TODO: сделать первую букву заглавной у каждого элемента.
    //       Дубликаты схлопнуть ОСОЗНАННО, а не молча.

    EXPECT_EQ(names, (std::set<std::string>{"Anna", "Bob", "Helen", "Kate"}));
}

// --- A6. vector<string>: убрать дубликаты, сохранив порядок первых вхождений ----
// Вслух: почему sort+unique здесь не подходит; какая сложность у твоего решения
// и сколько памяти оно просит; что изменится, если строк миллионы и они длинные.

#include <unordered_set>

TEST(Today, DedupPreservingOrder)
{
    std::vector<std::string> v{"b", "a", "b", "c", "a", "d"};

    std::unordered_set<std::string> tracking;

    std::erase_if(v, [&tracking](const std::string& str) {
        return !tracking.insert(str).second;
    });

    // TODO: оставить первые вхождения в исходном порядке.

    EXPECT_EQ(v, (std::vector<std::string>{"b", "a", "c", "d"}));
}

#include <queue>
// --- A7. Top-K по частоте ------------------------------------------------------
// Вслух: почему nth_element/partial_sort, а не полная сортировка; сложность
// каждого шага; что будет при равных частотах и детерминирован ли тогда ответ.
TEST(Today, TopKFrequent)
{
    std::vector<std::string> words{"go", "cpp", "go", "rust", "cpp", "go"};

    std::unordered_map<std::string, int> f;
    for(auto& str: words)
    {
        ++f[str];
    }

    using Pair = std::pair<std::string, int>;
    auto cmp = [] (const Pair& lhs, const Pair& rhs)
    {
        return lhs.second > rhs.second;
    };

    std::priority_queue<Pair, std::vector<Pair>, decltype(cmp)> pq(cmp);
    
    auto it = f.begin();
    for(int i = 0; i < 2; ++i)
    {
        pq.push(std::move(*it));
        ++it;
    }

    for(auto ite = f.end(); it != ite; ++it)
    {
        if(pq.top().second < it->second)
        {
            pq.pop();
            pq.push(std::move(*it));
        }
    }

    std::vector<std::pair<std::string, int>> top;  // TODO: заполнить top-2 по частоте
    while(!pq.empty())
    {
        top.push_back(std::move(pq.top()));
        pq.pop();
    }

    std::ranges::reverse(top);

    ASSERT_EQ(top.size(), 2u);
    EXPECT_EQ(top[0], std::make_pair(std::string("go"), 3));
    EXPECT_EQ(top[1], std::make_pair(std::string("cpp"), 2));
}

// ================================================================================
// БЛОК B — многопоточка. Три задачи на один паттерн: mutex + CV + счётчик.
// ================================================================================

// --- B1. Счётный семафор ----------------------------------------------------------
// Вслух: чем семафор отличается от мьютекса (владельца нет, release может звать
// не тот поток, что делал acquire); почему счётчик не уходит в минус; где нужен
// в проде — backpressure, пул соединений, ограничение числа задач в полёте.
// Плюс: что даёт std::counting_semaphore (C++20) и почему acquire там не бросает.
class Semaphore
{
public:
    explicit Semaphore(int initial): counter_(initial) {}

    void acquire() {
        std::unique_lock<std::mutex> lk(m_);
        cv_.wait(lk, [this](){
            return counter_ > 0;
        });
        --counter_;
    }
    void release() {
        std::unique_lock<std::mutex> lk(m_);
        ++counter_;
        cv_.notify_all();
    }
    bool try_acquire() { 
        std::unique_lock<std::mutex> lk(m_);

        if(counter_ == 0)
        {
            return false;
        }
        
        --counter_;
        return true;
    }

private:
    std::condition_variable cv_;
    mutable std::mutex m_;
    int counter_ = 0;
    // TODO: mutex, condition_variable, счётчик разрешений.
};

TEST(Today, SemaphoreLimitsConcurrency)
{
    constexpr int kPermits = 3;
    constexpr int kThreads = 16;

    Semaphore sem(kPermits);
    std::atomic<int> inside{0};
    std::atomic<int> peak{0};
    std::atomic<int> done{0};

    std::vector<std::thread> workers;
    for (int i = 0; i < kThreads; ++i)
        workers.emplace_back([&] {
            sem.acquire();

            const int now = inside.fetch_add(1, std::memory_order_relaxed) + 1;
            int prev = peak.load(std::memory_order_relaxed);
            while (now > prev &&
                   !peak.compare_exchange_weak(prev, now, std::memory_order_relaxed))
            {
            }

            std::this_thread::sleep_for(std::chrono::milliseconds(2));

            inside.fetch_sub(1, std::memory_order_relaxed);
            done.fetch_add(1, std::memory_order_relaxed);
            sem.release();
        });

    for (auto& t : workers) t.join();

    EXPECT_EQ(done.load(), kThreads);
    EXPECT_LE(peak.load(), kPermits);
    EXPECT_GT(peak.load(), 1);   // если 1 — ты просто сериализовал всех мьютексом
}

// --- B2. Latch: дождаться N завершений ---------------------------------------------
// Вслух: почему latch одноразовый и чем он удобнее барьера, когда ждущий сам
// не участник; какой ровно happens-before обязан дать wait() (иначе чтение
// results после wait — гонка, и TSan это покажет); почему count_down зовёт
// notify_all только на последнем декременте.
class Latch
{
public:
    explicit Latch(int count) : count_(count) {
        if(count_ <= 0)
        {
            throw std::runtime_error("Invalid count");
        }
    }

    void count_down() {
        std::unique_lock<std::mutex> lk(m_);
        if(--count_ == 0)
        {
            cv_.notify_all();
        }
    }

    void wait() {
        std::unique_lock<std::mutex> lk(m_);

        cv_.wait(lk, [this](){
            return count_ == 0;
        });
    }

private:
    mutable std::mutex m_;
    std::condition_variable cv_;
    int count_ = 0;
    // TODO: mutex, condition_variable, счётчик оставшихся.
};

TEST(Today, LatchHappensBefore)
{
    constexpr int kWorkers = 8;

    Latch latch(kWorkers);
    std::vector<int> results(kWorkers, -1);

    std::vector<std::thread> workers;
    for (int i = 0; i < kWorkers; ++i)
        workers.emplace_back([&, i] {
            results[i] = i * i;
            latch.count_down();
        });

    latch.wait();

    for (int i = 0; i < kWorkers; ++i)
        EXPECT_EQ(results[i], i * i) << "не дождались воркера " << i;

    for (auto& t : workers) t.join();
}

// --- B3. call_once своими руками --------------------------------------------------
// Вслух: почему наивный double-checked locking на сыром bool сломан (нет
// happens-before, второй поток может увидеть флаг раньше, чем содержимое объекта);
// как это чинится на atomic + release/acquire; почему magic statics (C++11) решают
// ту же задачу бесплатно; что делает std::call_once, если инициализатор бросил.
class OnceFlag
{
public:
    template <class F>
    void call_once(F&& init) { 
         if(done_.load())
         {
            return;
         }

         std::lock_guard<std::mutex> lk(m_);
         if(done_.load())
         {
            return;
         }

         std::forward<F>(init)();

         done_.store(true);
    }

private:
    mutable std::mutex m_;
    std::atomic<bool> done_ = false;
    // TODO: std::atomic<bool> done_ + std::mutex (или atomic<int> с тремя состояниями).
};

TEST(Today, CallOnceRunsExactlyOnce)
{
    constexpr int kThreads = 16;

    OnceFlag flag;
    std::atomic<int> initialized{0};
    std::atomic<int> wrong_size{0};
    std::atomic<bool> go{false};
    std::vector<int> payload;

    std::vector<std::thread> workers;
    for (int i = 0; i < kThreads; ++i)
        workers.emplace_back([&] {
            while (!go.load(std::memory_order_acquire))   // стартуем все разом
                std::this_thread::yield();

            flag.call_once([&] {
                payload.assign(1000, 7);
                initialized.fetch_add(1, std::memory_order_relaxed);
            });

            if (payload.size() != 1000)
                wrong_size.fetch_add(1, std::memory_order_relaxed);
        });

    go.store(true, std::memory_order_release);
    for (auto& t : workers) t.join();

    EXPECT_EQ(initialized.load(), 1) << "инициализатор отработал не ровно один раз";
    EXPECT_EQ(wrong_size.load(), 0) << "поток вышел из call_once до того, как объект достроили";
}
