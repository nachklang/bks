// mmap_interview.cxx — два коротких сценария на mmap для устного разбора «по строчкам».
//
//   A. Файл: прочитать как массив байт, поправить на месте (MAP_SHARED) и показать,
//      что MAP_PRIVATE правки в файл не попадают (copy-on-write).
//   B. Разделяемая память: (1) анонимная MAP_SHARED + fork — счётчик на std::atomic;
//      (2) именованная shm_open — обмен между процессами, которые знают только имя.
//
// Сборка:
//   g++ -std=c++20 -Wall -Wextra -O2 -o mmap_interview mmap_interview.cxx && ./mmap_interview
//   g++ -std=c++20 -g -fsanitize=address,undefined -o mi_asan mmap_interview.cxx && ./mi_asan
//
// Большой демо-файл с замерами — mmap_demo.cxx; конспект — doc/01-general-topics/11-mmap-and-memory-mapped-files.md

#include <fcntl.h>      // open, O_*
#include <sys/mman.h>   // mmap, munmap, msync, shm_open, shm_unlink
#include <sys/stat.h>   // fstat
#include <sys/wait.h>   // waitpid
#include <unistd.h>     // close, ftruncate, fork, pread, _exit

#include <atomic>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <new>
#include <stdexcept>
#include <string>
#include <system_error>

namespace {

[[noreturn]] void fail(const char* what) {
    throw std::system_error(errno, std::generic_category(), what);   // errno — сразу, до других вызовов
}

// --- Две RAII-обёртки. Без них любой throw между open и close (или mmap и munmap) — утечка. ---

struct Fd {
    int fd;
    explicit Fd(int f) : fd(f) { if (fd < 0) fail("open"); }
    ~Fd() { ::close(fd); }
    Fd(const Fd&) = delete;
    Fd& operator=(const Fd&) = delete;
};

struct Mapping {
    void*       addr;
    std::size_t len;
    // munmap нужно звать ровно с той парой (addr, len), что вернул mmap; len можно округлять
    // вверх до страницы — ядро само работает страницами.
    Mapping(std::size_t length, int prot, int flags, int fd, off_t offset = 0)
        : addr(::mmap(nullptr, length, prot, flags, fd, offset)), len(length) {
        if (addr == MAP_FAILED) fail("mmap");   // не nullptr! MAP_FAILED == (void*)-1
    }
    ~Mapping() { ::munmap(addr, len); }
    Mapping(const Mapping&) = delete;
    Mapping& operator=(const Mapping&) = delete;

    char*       bytes()       { return static_cast<char*>(addr); }
    const char* bytes() const { return static_cast<const char*>(addr); }
};

// =====================================================================================
// A. Файл
// =====================================================================================

void make_file(const char* path, const std::string& text) {
    std::FILE* f = std::fopen(path, "wb");
    if (!f) fail("fopen");
    std::fwrite(text.data(), 1, text.size(), f);
    std::fclose(f);
}

std::string read_whole(const char* path) {          // обычный read — контроль, что в файле «на самом деле»
    Fd fd(::open(path, O_RDONLY));
    std::string out;
    char buf[4096];
    for (ssize_t n; (n = ::read(fd.fd, buf, sizeof buf)) > 0;) out.append(buf, n);
    return out;
}

// Файл как массив байт: ни одного read(), данные приходят из page cache по page fault.
std::size_t count_lines(const char* path) {
    Fd fd(::open(path, O_RDONLY | O_CLOEXEC));
    struct stat st{};
    if (::fstat(fd.fd, &st) < 0) fail("fstat");
    if (st.st_size == 0) return 0;                  // mmap длины 0 — EINVAL, проверяем до вызова

    const auto size = static_cast<std::size_t>(st.st_size);
    Mapping m(size, PROT_READ, MAP_PRIVATE, fd.fd);
    // Отсюда fd уже не нужен: отображение держит свою ссылку на файл (struct file),
    // close(fd) его не сломает. Fd закроется при выходе — тоже нормально.

    std::size_t lines = 0;
    for (const char* p = m.bytes(), *end = p + size; (p = static_cast<const char*>(std::memchr(p, '\n', end - p))); ++p)
        ++lines;
    return lines;
    // Выход из области: сначала ~Mapping (munmap), потом ~Fd (close) — обратный порядок объявления.
}

// Правка на месте. MAP_SHARED: запись в страницу = запись в page cache = запись в файл
// (на диск попадёт при writeback или по msync).
void patch_shared(const char* path, std::size_t offset, const char* replacement) {
    Fd fd(::open(path, O_RDWR));                    // PROT_WRITE + MAP_SHARED требует fd, открытого на запись
    struct stat st{};
    if (::fstat(fd.fd, &st) < 0) fail("fstat");
    const auto size = static_cast<std::size_t>(st.st_size);
    const auto n = std::strlen(replacement);
    if (offset + n > size) throw std::out_of_range("patch beyond EOF");   // mmap файл не растит: нужен ftruncate

    Mapping m(size, PROT_READ | PROT_WRITE, MAP_SHARED, fd.fd);
    std::memcpy(m.bytes() + offset, replacement, n);
    if (::msync(m.addr, size, MS_SYNC) < 0) fail("msync");   // необязательно: munmap не теряет данные,
                                                             // msync — только про момент попадания на диск
}

// Тот же код, но MAP_PRIVATE: при первой записи ядро делает копию страницы процессу,
// файл не меняется. Так загружают исполняемые файлы (.data секция).
void patch_private(const char* path, std::size_t offset, const char* replacement) {
    Fd fd(::open(path, O_RDONLY));                  // MAP_PRIVATE + PROT_WRITE работает и с O_RDONLY
    struct stat st{};
    if (::fstat(fd.fd, &st) < 0) fail("fstat");
    const auto size = static_cast<std::size_t>(st.st_size);

    Mapping m(size, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd.fd);
    std::memcpy(m.bytes() + offset, replacement, std::strlen(replacement));
    std::printf("  [private] в отображении: %.*s\n", 8, m.bytes());   // видим свою правку...
}

void scenario_file() {
    const char* path = "/tmp/mmap_interview.txt";
    make_file(path, "line one\nline two\nline three\n");
    std::printf("A. файл\n  строк: %zu\n", count_lines(path));

    patch_private(path, 0, "LINE");
    std::printf("  [private] в файле:       %.*s\n", 8, read_whole(path).c_str());   // ...а файл прежний

    patch_shared(path, 0, "LINE");
    std::printf("  [shared]  в файле:       %.*s\n", 8, read_whole(path).c_str());   // а тут файл изменился
    ::unlink(path);
}

// =====================================================================================
// B. Разделяемая память
// =====================================================================================

// (1) Анонимная: без файла вообще. Живёт, пока есть хоть одно отображение.
//     Единственный способ поделиться — fork: ребёнок наследует отображения.
void scenario_anonymous_fork() {
    constexpr int kChildren = 4, kIters = 100'000;

    Mapping m(sizeof(std::atomic<long long>), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, /*fd=*/-1);
    // Память есть, объекта нет. Создаём его placement new, чтобы не полагаться на «нули — это ноль».
    auto* counter = new (m.addr) std::atomic<long long>(0);
    static_assert(std::atomic<long long>::is_always_lock_free);   // иначе внутри был бы мьютекс, не разделяемый между процессами

    for (int i = 0; i < kChildren; ++i) {
        const pid_t pid = ::fork();
        if (pid < 0) fail("fork");
        if (pid == 0) {                                             // ребёнок: тот же адрес, та же физическая страница
            for (int k = 0; k < kIters; ++k) counter->fetch_add(1, std::memory_order_relaxed);
            ::_exit(0);   // не exit(): не гасим atexit/буферы stdio, унаследованные от родителя
        }
    }
    for (int i = 0; i < kChildren; ++i)
        if (::waitpid(-1, nullptr, 0) < 0) fail("waitpid");        // иначе дети остаются зомби

    std::printf("B1. анонимная MAP_SHARED + fork\n  счётчик: %lld (ожидали %d)\n",
                counter->load(), kChildren * kIters);
    // С MAP_PRIVATE каждый ребёнок писал бы в свою COW-копию, родитель увидел бы 0.
}

// (2) Именованная: объект в /dev/shm (tmpfs). Любой процесс, знающий имя, откроет его.
//     Здесь второй процесс — тоже fork, но он НЕ использует унаследованное отображение:
//     открывает сегмент по имени, как сделал бы совершенно посторонний процесс.
struct Message {
    std::atomic<int> ready;   // 0 — пусто, 1 — текст записан
    char             text[64];
};

void scenario_named_shm() {
    const char* name = "/mmap_interview_demo";       // именно с ведущим '/', без других '/'
    ::shm_unlink(name);                              // сотрём хвост от прошлого упавшего запуска

    const pid_t pid = ::fork();
    if (pid < 0) fail("fork");

    if (pid == 0) {                                  // --- писатель ---
        Fd fd(::shm_open(name, O_CREAT | O_EXCL | O_RDWR, 0600));   // O_EXCL: мы создатели, не «кто-то уже есть»
        if (::ftruncate(fd.fd, sizeof(Message)) < 0) fail("ftruncate"); // свежий сегмент имеет размер 0 — задать обязательно
        Mapping m(sizeof(Message), PROT_READ | PROT_WRITE, MAP_SHARED, fd.fd);
        auto* msg = new (m.addr) Message{};          // tmpfs даёт нули, но placement new честнее
        std::strcpy(msg->text, "hello from writer");
        msg->ready.store(1, std::memory_order_release);   // release: текст виден раньше флага
        ::_exit(0);
    }

    // --- читатель --- ждёт появления сегмента по имени (писатель может ещё не создать)
    int raw = -1;
    while ((raw = ::shm_open(name, O_RDONLY, 0)) < 0 && errno == ENOENT) ::usleep(1000);
    Fd fd(raw);
    struct stat st{};
    while (::fstat(fd.fd, &st) == 0 && st.st_size == 0) ::usleep(1000);   // создан, но ещё не ftruncate'нут
    Mapping m(sizeof(Message), PROT_READ, MAP_SHARED, fd.fd);              // только чтение: fd открыт O_RDONLY
    const auto* msg = static_cast<const Message*>(m.addr);                 // объект создал писатель — новый не создаём
    while (msg->ready.load(std::memory_order_acquire) == 0) ::usleep(1000);
    std::printf("B2. именованная shm_open\n  прочитано: \"%s\" (см. ls -l /dev/shm)\n", msg->text);

    if (::waitpid(pid, nullptr, 0) < 0) fail("waitpid");
    if (::shm_unlink(name) < 0) fail("shm_unlink");  // имя удалено; память живёт, пока живо наше отображение
}

}  // namespace

int main() try {
    scenario_file();
    scenario_anonymous_fork();
    scenario_named_shm();
    return 0;
} catch (const std::exception& e) {
    std::fprintf(stderr, "error: %s\n", e.what());
    return 1;
}
