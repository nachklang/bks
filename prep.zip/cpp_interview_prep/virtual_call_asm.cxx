// virtual_call_asm.cxx — как виртуальный вызов выглядит в машинном коде.
//
// Сборка и дизассемблер (x86-64, GCC 15.2):
//   g++ -std=c++20 -Wall -Wextra -O1 -fno-inline -c virtual_call_asm.cxx -o virtual_call_asm.o
//   objdump -d -C -M intel --no-show-raw-insn virtual_call_asm.o      # код
//   objdump -s -j .rodata -j '.data.rel.ro' virtual_call_asm.o        # таблицы, сырые байты
//   objdump -r -j '.data.rel.ro' virtual_call_asm.o                   # релокации = какие функции лежат в vtable
//   g++ -std=c++20 -O1 -fno-inline -S -masm=intel -o - virtual_call_asm.cxx | c++filt   # ассемблер с именами
// Запуск:
//   g++ -std=c++20 -Wall -Wextra -O1 -fno-inline -o virtual_call_asm virtual_call_asm.cxx && ./virtual_call_asm
//
// -O1 -fno-inline: код чистый, но конструкторы и вызовы не заинлайнены, и devirtualization
// в call_through_base невозможна (компилятор не знает динамический тип аргумента).
// Разбор вывода — doc/01-general-topics/18-virtual-call-disassembly.md

#include <cstdio>

struct Base {
    virtual void foo() { std::puts("Base::foo"); }
    virtual void bar() { std::puts("Base::bar"); }
    virtual ~Base() = default;
    int x = 1;
};

struct Derived : Base {
    void foo() override { std::puts("Derived::foo"); }   // bar не переопределён — в vtable Derived останется Base::bar
    int y = 2;
};

// --- Глобальные объекты, чтобы в дампе были заняты все секции данных -----------------
// Что реально получилось (см. virtual_call_asm.dump, раздел 2 — nm, и разделы 4–7):
int         g_initialized   = 42;              // .data  (D): в файле лежат байты 2a 00 00 00
int         g_zero          = 0;               // .bss   (B): в файле только размер, страница нулей от ядра
int         g_uninitialized;                   // .bss   (B): то же самое
const int   g_const         = 7;               // символа НЕТ: свёрнут в константу в месте использования
const char* g_ptr_to_lit    = "literal";       // .data  (D): 8-байтный слот под адрес + R_X86_64_RELATIVE; текст — в .rodata
const char  g_arr[]         = "const array";   // .rodata (r): адрес берётся → байты нужны
static int  s_static        = 1;               // символа НЕТ: static + нигде не меняется → свёрнут
Derived     g_derived;                         // .data  (D)! constant initialization: GCC записал vptr, x=1, y=2
                                               //   прямо в образ, _GLOBAL__sub_I_ пустой (одна ret) — динамического
                                               //   конструктора нет; деструктор тривиальный → и __cxa_atexit нет
Base* const  g_base_ptr    = &g_derived;      // символа НЕТ: свёрнут; но вызов через него — настоящий виртуальный,
                                               //   GCC не девиртуализует чтение vptr из изменяемого глобального объекта

// Единственное место, где компилятор ОБЯЗАН сделать настоящий виртуальный вызов:
// динамический тип b неизвестен.
void call_through_base(Base& b) {
    b.foo();
    b.bar();
}

// Тот же вызов, но объект известен целиком — GCC может подставить Derived::foo напрямую.
void call_known_type() {
    Derived d;
    d.foo();
    d.bar();
}

// Невиртуальный вызов для сравнения: просто call по адресу.
void nonvirtual_for_comparison(Base& b) {
    b.Base::foo();
}

int main() {
    Derived d;
    call_through_base(d);
    call_known_type();
    nonvirtual_for_comparison(d);
    std::printf("sizeof(Base) = %zu, sizeof(Derived) = %zu\n", sizeof(Base), sizeof(Derived));
    std::printf("g_initialized=%d g_zero=%d g_uninitialized=%d g_const=%d %s %s s_static=%d g_derived.y=%d\n",
                g_initialized, g_zero, g_uninitialized, g_const, g_ptr_to_lit, g_arr, s_static, g_derived.y);
    g_base_ptr->foo();   // виртуальный вызов через глобальный объект: vptr записан статическим конструктором
}
