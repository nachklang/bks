// Раскладка объекта, vptr, четыре каста. Запускать и СМОТРЕТЬ адреса.
//
// Сборка (обязательно -O0: часть сценариев — UB, на -O2 оптимизатор
// вправе сделать с ними что угодно, и разбор поплывёт):
//   g++ -std=c++20 -Wall -Wextra -O0 -o casts_demo casts_demo.cxx && ./casts_demo
//
// Полезно посмотреть саму раскладку глазами компилятора:
//   g++ -std=c++20 -fdump-lang-class=/dev/stdout -c casts_demo.cxx | grep -A20 "Class C"

#include <cstddef>
#include <cstdio>
#include <cstdint>
#include <typeinfo>
#include <stdexcept>

namespace {

void title(const char* s) { std::printf("\n=== %s ===\n", s); }

// ---------------------------------------------------------------- 1. раскладка
struct Plain { int x = 1; };                       // без виртуальных функций
struct Poly  { virtual ~Poly() = default; int x = 1; };

// ------------------------------------------------- 2. множественное наследование
struct A {                        // полиморфная база: несёт vptr
    virtual void who() const { std::puts("  A::who"); }
    int a = 0xAAAA;
};

struct B {                        // НЕполиморфная база: vptr нет
    void print() const { std::printf("  B::print, b = 0x%X\n", b); }
    int b = 0xBBBB;
};

struct C : A, B {
    void who() const override { std::puts("  C::who"); }
    int c = 0xCCCC;
};

// --------------------------------------------------------- 3. виртуальный вызов
struct VBase { virtual void speak() const { std::puts("  VBase::speak"); } virtual ~VBase() = default; };
struct VDer : VBase { void speak() const override { std::puts("  VDer::speak"); } };

// ------------------------------------------------------------- 4. dynamic_cast
struct Animal { virtual ~Animal() = default; };
struct Dog : Animal { void bark() const { std::puts("  Woof"); } };
struct Cat : Animal { void meow() const { std::puts("  Meow"); } };

// -------------------------------------------------- 5. вызов в конструкторе
struct CtorBase {
    CtorBase() { std::printf("  CtorBase(): "); tag(); }
    virtual ~CtorBase() { std::printf("  ~CtorBase(): "); tag(); }
    virtual void tag() const { std::puts("это CtorBase"); }
};
struct CtorDer : CtorBase {
    int payload = 42;
    void tag() const override { std::printf("это CtorDer, payload=%d\n", payload); }
};

// ------------------------------------------------------------------ 6. срезка
struct Shape { virtual double area() const { return 0.0; } virtual ~Shape() = default; };
struct Square : Shape { double s = 3.0; double area() const override { return s * s; } };

} // namespace

int main()
{
    title("1. что vptr делает с размером");
    std::printf("sizeof(Plain) = %zu   (только int)\n", sizeof(Plain));
    std::printf("sizeof(Poly)  = %zu   (vptr 8 + int 4 + выравнивание 4)\n", sizeof(Poly));
    std::printf("Poly полиморфен? %s\n", std::is_polymorphic_v<Poly> ? "да" : "нет");

    title("2. множественное наследование: static_cast против reinterpret_cast");
    C obj;
    C* pc = &obj;
    std::printf("sizeof(A)=%zu sizeof(B)=%zu sizeof(C)=%zu\n", sizeof(A), sizeof(B), sizeof(C));
    // offsetof на C формально условно-поддерживаемый (не standard-layout: есть
    // виртуальные функции и две базы), GCC на это ругается. Считаем смещения
    // честно — вычитанием адресов полей конкретного объекта.
    const auto base = reinterpret_cast<const std::byte*>(&obj);
    std::printf("смещения полей в C: a=%+td  b=%+td  c=%+td\n",
                reinterpret_cast<const std::byte*>(&obj.a) - base,
                reinterpret_cast<const std::byte*>(&obj.b) - base,
                reinterpret_cast<const std::byte*>(&obj.c) - base);
    std::printf("pc                   = %p\n", static_cast<void*>(pc));
    std::printf("static_cast<A*>      = %p  сдвиг %+td\n",
                static_cast<void*>(static_cast<A*>(pc)),
                reinterpret_cast<std::byte*>(static_cast<A*>(pc)) - reinterpret_cast<std::byte*>(pc));
    std::printf("static_cast<B*>      = %p  сдвиг %+td  <- компилятор знает иерархию\n",
                static_cast<void*>(static_cast<B*>(pc)),
                reinterpret_cast<std::byte*>(static_cast<B*>(pc)) - reinterpret_cast<std::byte*>(pc));
    std::printf("reinterpret_cast<B*> = %p  сдвиг +0        <- просто переобъявил биты\n",
                reinterpret_cast<void*>(pc));

    std::puts("через static_cast (корректно):");
    static_cast<B*>(pc)->print();
    std::puts("через reinterpret_cast (UB, читает из vptr):");
    reinterpret_cast<B*>(pc)->print();

    title("3. обратно вверх по иерархии — и почему это тоже сдвиг");
    B* pb = static_cast<B*>(pc);
    std::printf("B*  = %p\n", static_cast<void*>(pb));
    std::printf("static_cast<C*>(pb) = %p  <- сдвиг обратно, адрес совпал с pc: %s\n",
                static_cast<void*>(static_cast<C*>(pb)),
                static_cast<C*>(pb) == pc ? "да" : "нет");

    title("4. виртуальный вызов идёт по vptr, а не по типу указателя");
    VDer d;
    const VBase* pv = &d;
    std::printf("тип указателя VBase*, статический тип: %s\n", typeid(pv).name());
    std::printf("динамический тип объекта:              %s\n", typeid(*pv).name());
    std::puts("pv->speak() ->");
    pv->speak();

    title("5. dynamic_cast: проверка в рантайме");
    Dog dog;
    Animal* animal = &dog;
    if (Dog* pd = dynamic_cast<Dog*>(animal)) { std::puts("dynamic_cast<Dog*> удался:"); pd->bark(); }
    if (Cat* pcat = dynamic_cast<Cat*>(animal)) { (void)pcat; std::puts("Cat?!"); }
    else std::puts("dynamic_cast<Cat*> вернул nullptr — типы не совпали");
    try { (void)dynamic_cast<Cat&>(*animal); }
    catch (const std::bad_cast& e) { std::printf("dynamic_cast<Cat&> бросил std::bad_cast: %s\n", e.what()); }
    std::puts("а static_cast<Cat*>(animal) скомпилировался бы и молча дал мусор");

    title("6. виртуальный вызов в конструкторе и деструкторе");
    std::puts("создаём CtorDer:");
    { CtorDer cd; (void)cd; std::puts("  разрушаем:"); }
    std::puts("в конструкторе базы объект ЕЩЁ CtorBase, в деструкторе — УЖЕ CtorBase");

    title("7. срезка при копировании по значению");
    Square sq;
    Shape by_value = sq;                 // срезка: остался только подобъект Shape
    const Shape& by_ref = sq;
    std::printf("Square::area()      = %.1f\n", sq.area());
    std::printf("копия в Shape       = %.1f  <- срезано\n", by_value.area());
    std::printf("ссылка на Shape     = %.1f  <- полиморфизм жив\n", by_ref.area());
    std::printf("sizeof(Square)=%zu sizeof(Shape)=%zu\n", sizeof(Square), sizeof(Shape));

    return 0;
}
