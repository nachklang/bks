// Тренажёр: писать с чистого листа, вслух, потом компилировать.
//
// ЧИСТАЯ КОПИЯ без решений. Свой разобранный вариант — в drills.cxx,
// не открывать его, пока не написал здесь свой и не скомпилировал.
//
// Правила:
//   1. Не подглядывать в doc/, в drills.cxx и не гуглить, пока не написал свой вариант.
//   2. Проговаривать КАЖДУЮ строчку вслух, пока пишешь. Именно это спросят.
//   3. Сначала скомпилировать, потом сверяться с разбором в doc/02-interview-questions/.
//   4. Засекать время. Норма на одну задачу — 5-8 минут вместе с объяснением.
//
// Сборка:
//   g++ -std=c++20 -Wall -Wextra -O2 -o drills_blank drills_blank.cxx -lgtest -lgtest_main -pthread && ./drills_blank
//
// Обязательно с -Wall -Wextra: баги с секциями for ловятся именно так.

#include <gtest/gtest.h>

#include <algorithm>
#include <iterator>
#include <list>
#include <map>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>
#include <unordered_set>
#include <queue>

// --- 1. vector: удалить все вхождения значения --------------------------------
// Вслух: что делает remove, что остаётся в хвосте, почему нужен второй шаг.
TEST(Drills, EraseAllOccurrences)
{
    std::vector<int> v{1, 2, 3, 1, 1, 2, 3};

    // TODO: удалить все единицы. Двумя способами: erase-remove и C++20.

    // std::erase_if(v, [](int element) {
    //     return element == 1;
    // });

    v.erase(std::remove_if(v.begin(), v.end(),[](int element)
    {
        return element == 1;
    }), v.end());

    EXPECT_EQ(v, (std::vector<int>{2, 3, 2, 3}));
}

// --- 2. vector: удалить по предикату, посчитав сколько удалено -----------------
// Вслух: что возвращает std::erase_if и почему это удобнее пары итераторов.
TEST(Drills, EraseIfCountingRemoved)
{
    std::vector<int> v{1, 2, 3, 4, 5, 6, 7, 8};
    std::size_t removed = 0;

    v.erase(std::remove_if(v.begin(), v.end(), [counter=1, &removed](int) mutable {
        auto prev = counter;
        ++counter;

        if( !(prev & 1))
        {
            ++removed;
            return true;
        };

        return false;
    }), v.end());

    // TODO: удалить чётные, записать количество в removed.

    EXPECT_EQ(removed, 4u);
    EXPECT_EQ(v, (std::vector<int>{1, 3, 5, 7}));
}

// --- 3. set<string>: capitalize первой буквы ----------------------------------
// Вслух: почему элемент нельзя менять на месте; зачем итератор двигают заранее;
// что вернёт insert при коллизии и кто владеет узлом после неудачи.
TEST(Drills, SetCapitalizeFirstLetter)
{
    std::set<std::string> names{"anna", "Anna", "bob", "Bob", "kate", "Kate", "helen"};

    // TODO: сделать первую букву заглавной у каждого элемента.
    //       Дубликаты схлопнуть ОСОЗНАННО, а не молча.

    EXPECT_EQ(names, (std::set<std::string>{"Anna", "Bob", "Helen", "Kate"}));
}

// --- 4. map: удалить записи по условию во время обхода ------------------------
// Вслух: что инвалидирует erase у map и что не инвалидирует; почему it = erase(it).
TEST(Drills, EraseFromMapWhileIterating)
{
    std::map<std::string, int> scores{{"a", 5}, {"b", 50}, {"c", 3}, {"d", 100}};

    // TODO: удалить все записи со значением меньше 10 прямо во время обхода.

    EXPECT_EQ(scores, (std::map<std::string, int>{{"b", 50}, {"d", 100}}));
}

// --- 5. map: переименовать ключ, не трогая значение ---------------------------
// Вслух: чем node handle у map отличается от set; что будет, если новый ключ занят.
TEST(Drills, RenameMapKey)
{
    std::map<std::string, int> m{{"old", 42}, {"other", 7}};

    // TODO: переименовать ключ "old" в "new", сохранив значение 42.
    //       Без лишних копий значения.

    EXPECT_EQ(m, (std::map<std::string, int>{{"new", 42}, {"other", 7}}));
}

// --- 6. vector<string>: убрать дубликаты, сохранив порядок первых вхождений ----
// Вслух: почему sort+unique здесь не подходит; какая сложность у вашего решения.
TEST(Drills, DedupPreservingOrder)
{
    std::vector<std::string> v{"b", "a", "b", "c", "a", "d"};

    // TODO: оставить первые вхождения в исходном порядке.

    EXPECT_EQ(v, (std::vector<std::string>{"b", "a", "c", "d"}));
}

// --- 7. Top-K по частоте ------------------------------------------------------
// Вслух: почему nth_element/partial_sort, а не полная сортировка; сложность.
TEST(Drills, TopKFrequent)
{
    std::vector<std::string> words{"go", "cpp", "go", "rust", "cpp", "go"};

    std::vector<std::pair<std::string, int>> top;  // TODO: заполнить top-2 по частоте

    ASSERT_EQ(top.size(), 2u);
    EXPECT_EQ(top[0], std::make_pair(std::string("go"), 3));
    EXPECT_EQ(top[1], std::make_pair(std::string("cpp"), 2));
}

// --- 8. Стабильная сортировка по двум ключам ----------------------------------
// Вслух: что такое strict weak ordering и что будет, если написать <= вместо <.
TEST(Drills, SortByPriceThenTime)
{
    struct Order { int price; int time; };
    std::vector<Order> orders{{100, 3}, {99, 1}, {100, 1}, {99, 2}};

    // TODO: отсортировать по возрастанию цены, при равной цене — по возрастанию времени.

    ASSERT_EQ(orders.size(), 4u);
    EXPECT_EQ(orders[0].price, 99);  EXPECT_EQ(orders[0].time, 1);
    EXPECT_EQ(orders[1].price, 99);  EXPECT_EQ(orders[1].time, 2);
    EXPECT_EQ(orders[2].price, 100); EXPECT_EQ(orders[2].time, 1);
    EXPECT_EQ(orders[3].price, 100); EXPECT_EQ(orders[3].time, 3);
}

// --- 9. list: удалить все вхождения значения ----------------------------------
// Вслух: почему у list есть собственный remove и чем он лучше erase-remove;
// что std::remove делает с УЗЛАМИ списка, а что — со значениями; кто из двух
// способов дороже для list<string> и почему; что возвращает list::remove
// в C++20 и что он возвращал до этого.
TEST(Drills, EraseRemoveFromList)
{
    std::list<int> a{1, 2, 3, 1, 1, 2, 3};
    std::list<int> b = a;

    // Итератор на последний элемент b. Один из двух способов его переживёт.
    auto watch = std::prev(b.end());

    // TODO: способ 1 — удалить единицы из a идиомой erase-remove, через std::remove.
    // TODO: способ 2 — удалить единицы из b член-функцией list. Одной строкой.

    a.erase(std::remove_if(a.begin(), a.end(),[](int element) {
        return element == 1;
    }), a.end());

    b.remove_if([](int element){
        return element == 1;
    });

    EXPECT_EQ(a, (std::list<int>{2, 3, 2, 3}));
    EXPECT_EQ(b, (std::list<int>{2, 3, 2, 3}));

    // Член-функция только расцепляет узлы: узел с последней тройкой не двигался.
    EXPECT_EQ(*watch, 3);
    EXPECT_TRUE(watch == std::prev(b.end()));

    // Вслух: а если бы watch указывал в a, что стало бы с ним после способа 1?
}

// --- 10. set: удалить элементы по условию -------------------------------------
// Вслух: почему идиома erase-remove здесь не компилируется в принципе и при чём
// тут const у ключа; что возвращает set::erase(it) и с какого стандарта;
// какие итераторы инвалидирует erase у set, а какие нет.
TEST(Drills, EraseRemoveFromSet)
{
    std::set<int> a{1, 2, 3, 4, 5, 6, 7, 8};
    std::set<int> b = a;
    std::size_t removed = 0;

    // Итератор на семёрку. Она нечётная и остаётся — но переживёт ли итератор?
    auto watch = a.find(7);

    // TODO: способ 1 — удалить чётные из a вручную, циклом по итераторам.
    // TODO: способ 2 — удалить чётные из b одной строкой C++20,
    //       записав количество удалённых в removed.

    int counter = 0;
    for(auto it = a.begin(), ite = a.end(); it != ite;)
    {
        ++counter;

        if(!(counter & 1))
        {
            it = a.erase(it);
        }
        else
        {
            ++it;
        }
    }

    EXPECT_EQ(a, (std::set<int>{1, 3, 5, 7}));
    EXPECT_EQ(b, (std::set<int>{1, 3, 5, 7}));
    EXPECT_EQ(removed, 4u);

    // erase у set инвалидирует только удалённые итераторы — узел с семёркой цел.
    EXPECT_EQ(*watch, 7);
}
