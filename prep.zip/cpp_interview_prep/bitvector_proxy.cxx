// Drill: proxy reference. Write your own std::vector<bool> — bits packed 64 per
// word, and operator[] returns not bool& (you cannot take a reference to a bit)
// but a proxy object that behaves like one.
//
// Goal: make this work exactly like vector<bool> does:
//
//     BitVector v(10);
//     v[3] = true;            // write through the proxy
//     bool b = v[3];          // read through the proxy
//     v[0] = v[3];            // copies the BIT, does not rebind the proxy
//     v[1].flip();
//     BitVector::swap(v[0], v[1]);
//
// Scope: the active tests cover ONLY the proxy and operator[]. Everything else
// (push_back, resize, whole-vector flip, count, the std::vector<bool> oracle) is
// parked behind BV_FULL_API and does not even compile unless you ask for it.
//
// The class below is intentionally empty: write every member yourself, from the
// list in the comment. The file therefore does NOT compile until you do — the
// compiler errors are your task list. Cheat sheet is at the very bottom; read it
// only after your own attempt.
//
// Build (proxy + operator[] only):
//   g++ -std=c++20 -Wall -Wextra -O2 -o bitvector_proxy bitvector_proxy.cxx -lgtest -lgtest_main -pthread && ./bitvector_proxy
//   g++ -std=c++20 -g -fsanitize=address,undefined -o bv_asan bitvector_proxy.cxx -lgtest -lgtest_main -pthread && ./bv_asan
//
// Build with the rest of the container switched on:
//   g++ -std=c++20 -Wall -Wextra -O2 -DBV_FULL_API -o bitvector_proxy bitvector_proxy.cxx -lgtest -lgtest_main -pthread && ./bitvector_proxy
//
// One test at a time:
//   ./bitvector_proxy --gtest_filter=BitVector.WriteThroughProxy

#include <gtest/gtest.h>

#include <cstddef>
#include <cstdint>
#include <string>
#include <type_traits>
#include <vector>

#ifdef BV_FULL_API
#include <random>
#endif

class BitVector
{
    // ---- implement -------------------------------------------------------
    //
    // nested class reference        // the proxy: a word pointer + a bit mask
    //   reference(const reference&)         // copies the BINDING (same bit)
    //   operator bool() const               // implicit, so `if (v[i])` works
    //   reference& operator=(bool)
    //   reference& operator=(const reference&)   // copies the VALUE — the trap
    //   void flip()
    //   bool operator~() const              // reads inverted, mutates nothing
    //   private ctor from (word*, bit index), friend BitVector
    //
    // BitVector
    //   explicit BitVector(size_t count, bool value = false)
    //   reference operator[](size_t)
    //   bool      operator[](size_t) const   // by value, not by reference
    //   size_t size() const
    //   static void swap(reference, reference)
    //
    // Only needed with -DBV_FULL_API:
    //   BitVector() = default
    //   void push_back(bool)
    //   void resize(size_t count, bool value = false)
    //   void flip()                          // whole vector, word at a time
    //   size_t count() const                 // popcount of the used bits
    //   bool empty() const
    //
    // Suggested storage (nothing else is needed):
    //   std::vector<std::uint64_t> words_;
    //   std::size_t size_ = 0;
    // ----------------------------------------------------------------------
    public:
    BitVector(size_t size): size_(size)
    {
        auto wordsSize = (size_ / 64) + ((size_ % 64) == 0 ? 0 : 1);  
        words_ = std::vector<std::uint64_t>(wordsSize, 0);
    }

    BitVector(size_t size, bool val): size_(size)
    {
        auto wordsSize = (size_ / 64);
        words_ = std::vector<std::uint64_t>(wordsSize, val ? 0xFF : 0);

        if(auto reminder = (size_ % 64); reminder != 0)
        {
            // words_.push_back(0);
            // for(size_t i = 0; i < reminder; ++i)
            // {
            //     set(i, val);
            // }
            words_.push_back(0);
            if(val)
            {
                auto mask = (1U << reminder) - 1;
                words_.back() |= mask;
            }
            
        }
    }

    struct reference {
        BitVector* owner;
        size_t idx;

        friend class BitVector;

        reference& operator=(bool value)
        {
            owner->set(idx, value);
            return *this;
        }

        bool operator~() const
        {
            return !owner->operator[](idx);
        }

        operator bool() const {
            std::as_const(owner)->operator[](idx);
        }

        private:
        reference() = default;
        reference(BitVector* o, size_t i): owner(o), idx(i) {};
    };

    reference operator[](size_t idx)
    {
        return reference{this, idx};
    }

    void push_back(bool val)
    {

    }

    void set(size_t idx, bool val)
    {
        words_[idx / 64] = words_[idx / 64] | (static_cast<std::uint8_t>(val) << (idx % 64));
    }

    bool operator[](size_t idx) const
    {
        return static_cast<bool>(words_[idx / 64] & 1u << (idx % 64));
    }

    size_t size() const
    {
        return size_;
    }

    std::size_t size_ = 0;
    std::vector<std::uint64_t> words_;
    size_t count_ = 0;
};

// --- test helpers ---------------------------------------------------------------

static std::string to_string(const BitVector& bv)
{
    std::cout << "words size: " << bv.words_.size() << std::endl;
    std::cout << "bits: " << bv.size() << std::endl;
    std::string s;
    for (std::size_t i = 0; i < bv.size(); ++i) s += bv[i] ? '1' : '0';
    return s;
}

// ================================ TESTS =========================================

// --- types first: a proxy for mutable access, a plain bool for const access -----

static_assert(std::is_same_v<decltype(std::declval<BitVector&>()[0]), BitVector::reference>,
              "operator[] on a mutable vector must return the proxy");
static_assert(std::is_same_v<decltype(std::declval<const BitVector&>()[0]), bool>,
              "const operator[] must return bool BY VALUE");
static_assert(!std::is_default_constructible_v<BitVector::reference>,
              "a proxy cannot be created out of thin air — only via operator[]");

TEST(BitVector, ReadsInitialValue)
{
    BitVector zeros(10);
    EXPECT_EQ(to_string(zeros), "0000000000");

    BitVector ones(10, true);
    EXPECT_EQ(to_string(ones), "1111111111");
}

TEST(BitVector, WriteThroughProxy)
{
    BitVector v(8);
    v[3] = true;
    v[7] = true;

    EXPECT_EQ(to_string(v), "00010001");
    EXPECT_TRUE(v[3]);
    EXPECT_FALSE(v[4]);
}

TEST(BitVector, WriteFalseClearsBit)
{
    BitVector v(8, true);
    v[2] = false;
    EXPECT_EQ(to_string(v), "11011111");
}

TEST(BitVector, ConstAccessReadsSameBits)
{
    BitVector v(4);
    v[1] = true;

    const BitVector& cv = v;
    EXPECT_TRUE(cv[1]);
    EXPECT_FALSE(cv[0]);
}

// Neighbours must not move — the classic mask bug.
TEST(BitVector, NeighboursAreNotDisturbed)
{
    BitVector v(64, true);
    for (std::size_t i = 0; i < 64; i += 2) v[i] = false;

    for (std::size_t i = 0; i < 64; ++i) EXPECT_EQ(v[i], i % 2 == 1) << "bit " << i;
}

// THE trap: operator= from another proxy must copy the bit. A defaulted one would
// copy word_/mask_ instead — i.e. rebind the reference — and this test catches it.
TEST(BitVector, ProxyAssignmentCopiesBitNotBinding)
{
    BitVector v(4);
    v[1] = true;

    v[0] = v[1];
    EXPECT_TRUE(v[0]);
    EXPECT_TRUE(v[1]);
    EXPECT_EQ(to_string(v), "1100");

    v[1] = v[2];  // now copy a zero
    EXPECT_FALSE(v[1]);
    EXPECT_EQ(to_string(v), "1000");
}

TEST(BitVector, ProxySelfAssignment)
{
    BitVector v(2);
    v[0] = true;
    v[0] = v[0];
    EXPECT_TRUE(v[0]);
}

// auto does not decay the proxy — the variable stays a reference to that bit.
// That is vector<bool> behaviour, and this test pins it down on purpose.
TEST(BitVector, AutoKeepsProxySemantics)
{
    BitVector v(4);
    auto r = v[2];
    static_assert(std::is_same_v<decltype(r), BitVector::reference>);

    r = true;
    EXPECT_TRUE(v[2]) << "an auto copy of the proxy must write to the same bit";

    bool b = v[2];  // this one is a value
    v[2] = false;
    EXPECT_TRUE(b) << "bool is copied by value and must not follow the bit";
}

// TEST(BitVector, FlipSingleBit)
// {
//     BitVector v(3);
//     v[1].flip();
//     EXPECT_EQ(to_string(v), "010");
//     v[1].flip();
//     EXPECT_EQ(to_string(v), "000");
// }

TEST(BitVector, OperatorTildeReadsInverted)
{
    BitVector v(2);
    v[0] = true;

    EXPECT_FALSE(~v[0]);
    EXPECT_TRUE(~v[1]);
    EXPECT_EQ(to_string(v), "10") << "operator~ reads, it does not modify";
}

// TEST(BitVector, SwapTwoBits)
// {
//     BitVector v(4);
//     v[0] = true;

//     BitVector::swap(v[0], v[3]);
//     EXPECT_EQ(to_string(v), "0001");

//     BitVector::swap(v[1], v[2]);  // both zero — nothing changes
//     EXPECT_EQ(to_string(v), "0001");
// }

TEST(BitVector, ProxyInIfAndBoolContexts)
{
    BitVector v(2);
    v[1] = true;

    EXPECT_FALSE(v[0] && v[1]);
    EXPECT_TRUE(v[0] || v[1]);
    if (v[1]) SUCCEED(); else ADD_FAILURE() << "proxy does not convert to bool in if";
    EXPECT_EQ(static_cast<int>(v[1]) + static_cast<int>(v[0]), 1);
}

// More than one word: 63/64/65 is where index arithmetic breaks.
TEST(BitVector, CrossesWordBoundary)
{
    BitVector v(200);
    v[63] = true;
    v[64] = true;
    v[65] = true;
    v[199] = true;

    EXPECT_TRUE(v[63]);
    EXPECT_TRUE(v[64]);
    EXPECT_TRUE(v[65]);
    EXPECT_TRUE(v[199]);
    EXPECT_FALSE(v[62]);
    EXPECT_FALSE(v[66]);
}

// ===== the rest of the container: off unless you build with -DBV_FULL_API =======
#ifdef BV_FULL_API

static std::vector<bool> to_vector(const BitVector& bv)
{
    std::vector<bool> out;
    out.reserve(bv.size());
    for (std::size_t i = 0; i < bv.size(); ++i) out.push_back(bv[i]);
    return out;
}

TEST(BitVector, EmptyByDefault)
{
    BitVector v;
    EXPECT_EQ(v.size(), 0u);
    EXPECT_TRUE(v.empty());
    EXPECT_EQ(v.count(), 0u);
}

TEST(BitVector, PushBackGrows)
{
    BitVector v;
    v.push_back(true);
    v.push_back(false);
    v.push_back(true);

    EXPECT_EQ(v.size(), 3u);
    EXPECT_EQ(to_string(v), "101");
    EXPECT_EQ(v.count(), 2u);
}

TEST(BitVector, PushBackAcrossManyWords)
{
    BitVector v;
    for (std::size_t i = 0; i < 300; ++i) v.push_back(i % 3 == 0);

    EXPECT_EQ(v.size(), 300u);
    EXPECT_EQ(v.count(), 100u);
    for (std::size_t i = 0; i < 300; ++i) EXPECT_EQ(v[i], i % 3 == 0) << "bit " << i;
}

// TEST(BitVector, FlipWholeVector)
// {
//     BitVector v(70);
//     v[0] = true;
//     v[69] = true;
//     v.flip();

//     EXPECT_FALSE(v[0]);
//     EXPECT_FALSE(v[69]);
//     EXPECT_EQ(v.count(), 68u) << "padding bits of the last word must stay out of count()";
// }

TEST(BitVector, ResizeGrowFillsWithValue)
{
    BitVector v(3, true);
    v.resize(70, true);

    EXPECT_EQ(v.size(), 70u);
    EXPECT_EQ(v.count(), 70u);

    v.resize(140, false);
    EXPECT_EQ(v.size(), 140u);
    EXPECT_EQ(v.count(), 70u) << "grown with zeros — the number of ones must not change";
    EXPECT_FALSE(v[139]);
}

TEST(BitVector, ResizeShrinkThenGrowGivesCleanBits)
{
    BitVector v(128, true);
    v.resize(10);
    EXPECT_EQ(v.size(), 10u);
    EXPECT_EQ(v.count(), 10u);

    v.resize(128, false);
    EXPECT_EQ(v.count(), 10u) << "stale ones were left behind when shrinking";
}

// Oracle: the same random operations against std::vector<bool>.
TEST(BitVector, MatchesStdVectorBool)
{
    std::mt19937 rng(20260923);
    std::uniform_int_distribution<int> op(0, 3);
    std::bernoulli_distribution coin(0.5);

    BitVector mine;
    std::vector<bool> golden;

    for (int step = 0; step < 20000; ++step)
    {
        switch (op(rng))
        {
            case 0:
            {
                const bool b = coin(rng);
                mine.push_back(b);
                golden.push_back(b);
                break;
            }
            case 1:
            {
                if (golden.empty()) break;
                std::uniform_int_distribution<std::size_t> pick(0, golden.size() - 1);
                const std::size_t i = pick(rng);
                const bool b = coin(rng);
                mine[i] = b;
                golden[i] = b;
                break;
            }
            case 2:
            {
                if (golden.empty()) break;
                std::uniform_int_distribution<std::size_t> pick(0, golden.size() - 1);
                const std::size_t i = pick(rng);
                const std::size_t j = pick(rng);
                mine[i] = mine[j];
                golden[i] = golden[j];
                break;
            }
            case 3:
            {
                std::uniform_int_distribution<std::size_t> len(0, 300);
                const std::size_t n = len(rng);
                const bool b = coin(rng);
                mine.resize(n, b);
                golden.resize(n, b);
                break;
            }
        }
    }

    ASSERT_EQ(mine.size(), golden.size());
    EXPECT_EQ(to_vector(mine), golden);
}

#endif  // BV_FULL_API

// --- cheat sheet: read AFTER your own attempt -----------------------------------
//
// There is no reference to a bit (the smallest addressable object is a byte), so
// operator[] returns an object that BEHAVES like one: a pointer to the word plus
// a mask of the bit.
//
//   reference(word_type* w, std::size_t bit) : word_(w), mask_(word_type{1} << bit) {}
//   operator bool() const            { return (*word_ & mask_) != 0; }
//   reference& operator=(bool v)     { v ? (*word_ |= mask_) : (*word_ &= ~mask_); return *this; }
//   reference& operator=(const reference& o) { return *this = static_cast<bool>(o); }  // the key line
//   void flip()                      { *word_ ^= mask_; }
//   bool operator~() const           { return (*word_ & mask_) == 0; }
//
//   operator[](pos)       -> reference(&words_[pos / 64], pos % 64)
//   const operator[](pos) -> (words_[pos / 64] >> (pos % 64)) & 1
//
// What you will be asked:
//   * why `v[i] = v[j]` needs its own operator=: the defaulted one would copy
//     word_/mask_, i.e. rebind the reference, leaving bit i untouched. The copy
//     CONSTRUCTOR is the opposite — it must copy word_/mask_, so that
//     `auto r = v[i]` yields a second reference to the same bit;
//   * why the const overload returns bool by value: handing out a proxy into a
//     const object would allow writing through it, and a `const bool&` to a
//     temporary would dangle;
//   * why operator bool is NOT explicit: `bool b = v[i]` and `if (v[i])` would
//     break otherwise; the price is implicit conversions to int and surprising
//     comparisons, which is why vector<bool> carries extra overloads;
//   * in C++23 std::vector<bool>::reference::operator= is const-qualified
//     (`const reference& operator=(bool) const`) so `const auto r = v[i]; r = true;` works;
//   * why vector<bool> is not a container by the formal requirements: `&v[0]` is
//     not a `bool*`, there is no `T& operator[]`, no data(), and `std::for_each`
//     taking `bool&` will not compile — hence vector<char>/bitset/deque<bool>
//     when you really want an array of flags;
//   * a proxy is invalidated by resize/push_back exactly like an iterator: it holds
//     a pointer into a buffer that may have moved;
//   * threading: two threads writing ADJACENT bits write to the same word, which is
//     a data race and UB — unlike adjacent elements of a normal vector, which the
//     standard guarantees to be independent;
//   * padding bits of the last word must be kept zero, or count() via popcount
//     starts lying — that is what the Flip/ResizeShrink tests are for.
