// Учебная реализация shared_ptr. В ней ЕСТЬ ОШИБКИ — это задача, а не образец.
//
// Правила игры:
//   * Тесты в my_shared_ptr_test.cxx падают. Чинить надо ЭТОТ файл, не тесты.
//   * Ожидания в тестах верные: если тест красный, виновата реализация.
//   * Часть тестов зелёная изначально. Они должны остаться зелёными —
//     самая частая ошибка при починке в том, что чиня одно, ломают другое.
//
// Не подглядывайте в README.md, пока не застряли всерьёз.

#pragma once

#include <atomic>
#include <cstddef>
#include <utility>

namespace mine {

struct ControlBlock
{
    // Диагностика для тестов: сколько блоков сейчас не освобождено.
    static inline int alive = 0;

    std::atomic<int> strong = 1;

    ControlBlock()  { ++alive; }
    ~ControlBlock() { --alive; }
};

template <class T>
class SharedPtr
{
public:
    SharedPtr() noexcept = default;

    explicit SharedPtr(T* raw)
        : ptr_(raw)
        , ctrl_(raw != nullptr ? new ControlBlock() : nullptr)
    {
    }

    SharedPtr(const SharedPtr& other) noexcept
        : ptr_(other.ptr_)
        , ctrl_(other.ctrl_)
    {
        if (ctrl_ != nullptr)
            ++ctrl_->strong;
    }

    SharedPtr& operator=(const SharedPtr& other) noexcept
    {
        if(this == &other)
        {
            return *this;
        }

        if(ctrl_ != nullptr && !--ctrl_->strong)
        {
            delete ptr_;
            delete ctrl_;
        }

        ptr_  = other.ptr_;
        ctrl_ = other.ctrl_;

        if (ctrl_ != nullptr)
            ++ctrl_->strong;

        return *this;
    }

    SharedPtr(SharedPtr&& other) noexcept
    {
        if(ctrl_ && !--ctrl_->strong)
        {
            delete ptr_;
            delete ctrl_;
        }

        ptr_ = std::exchange(other.ptr_, nullptr);
        ctrl_ = std::exchange(other.ctrl_, nullptr);
    }
    
    SharedPtr& operator=(SharedPtr&& other) noexcept
    {
        if(this == &other)
        {
            return *this;
        }

        if(ctrl_ && !--ctrl_->strong)
        {
            delete ptr_;
            delete ctrl_;
        }

        ptr_ = std::exchange(other.ptr_, nullptr);
        ctrl_ = std::exchange(other.ctrl_, nullptr);

        return *this;
    }

    ~SharedPtr()
    {
        release();
    }

    void reset(T* raw = nullptr)
    {
        if(ctrl_ && !--ctrl_->strong)
        {
            delete ctrl_;
            delete ptr_;
        }
        
        ptr_  = raw;
        ctrl_ = raw != nullptr ? new ControlBlock() : nullptr;
    }

    T*   get()        const noexcept { return ptr_; }
    T&   operator*()  const noexcept { return *ptr_; }
    T*   operator->() const noexcept { return ptr_; }

    explicit operator bool() const noexcept { return ptr_ != nullptr; }

    long use_count() const noexcept
    {
        return ctrl_ != nullptr ? ctrl_->strong.load() : 0;
    }

private:
    void release() noexcept
    {
        if (ctrl_ == nullptr)
            return;

        if (--ctrl_->strong == 0)
        {
            delete ptr_;
            delete ctrl_;
        }

        ptr_  = nullptr;
        ctrl_ = nullptr;
    }

    T*            ptr_  = nullptr;
    ControlBlock* ctrl_ = nullptr;
};

}  // namespace mine
