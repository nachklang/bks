// Тесты к mine::SharedPtr. Ожидания здесь ВЕРНЫЕ — чинить нужно my_shared_ptr.hxx.
//
// ВАЖНО: часть тестов зелёная с самого начала. Они должны остаться зелёными.
// Два из них — ловушки: самая естественная «починка» их ломает.
//
// Сборка:
//   g++ -std=c++20 -Wall -Wextra -O2 -o sp my_shared_ptr_test.cxx -lgtest -lgtest_main -pthread && ./sp
//
// Потом обязательно прогнать под санитайзерами:
//   g++ -std=c++20 -g -fsanitize=address,undefined -o sp_asan my_shared_ptr_test.cxx -lgtest -lgtest_main -pthread
//   g++ -std=c++20 -g -fsanitize=thread            -o sp_tsan my_shared_ptr_test.cxx -lgtest -lgtest_main -pthread

#include "my_shared_ptr.hxx"

#include <gtest/gtest.h>

#include <thread>
#include <utility>
#include <vector>

namespace {

struct Tracked
{
    static inline int alive     = 0;
    static inline int destroyed = 0;

    int value;

    explicit Tracked(int v = 0) : value(v) { ++alive; }
    ~Tracked() { --alive; ++destroyed; }

    Tracked(const Tracked&)            = delete;
    Tracked& operator=(const Tracked&) = delete;
};

class SharedPtrFix : public ::testing::Test
{
protected:
    void SetUp() override
    {
        Tracked::alive            = 0;
        Tracked::destroyed        = 0;
        mine::ControlBlock::alive = 0;
    }
};

}  // namespace

// --- База --------------------------------------------------------------------

TEST_F(SharedPtrFix, SingleOwnerHasCountOne)
{
    mine::SharedPtr<Tracked> p(new Tracked(42));

    EXPECT_EQ(p.use_count(), 1);
    EXPECT_EQ(p->value, 42);
    EXPECT_EQ((*p).value, 42);
    EXPECT_TRUE(static_cast<bool>(p));
    EXPECT_EQ(Tracked::alive, 1);
}

TEST_F(SharedPtrFix, DestructorReleasesObject)
{
    {
        mine::SharedPtr<Tracked> p(new Tracked(1));
        EXPECT_EQ(Tracked::alive, 1);
    }

    EXPECT_EQ(Tracked::destroyed, 1);
    EXPECT_EQ(Tracked::alive, 0);
}

TEST_F(SharedPtrFix, CopySharesOwnership)
{
    mine::SharedPtr<Tracked> a(new Tracked(7));
    {
        mine::SharedPtr<Tracked> b = a;

        EXPECT_EQ(a.use_count(), 2);
        EXPECT_EQ(b.use_count(), 2);
        EXPECT_EQ(a.get(), b.get());
        EXPECT_EQ(Tracked::destroyed, 0);
    }

    EXPECT_EQ(a.use_count(), 1);
    EXPECT_EQ(Tracked::destroyed, 0);  // владелец ещё есть
}

TEST_F(SharedPtrFix, DefaultConstructedIsEmpty)
{
    mine::SharedPtr<Tracked> p;

    EXPECT_EQ(p.get(), nullptr);
    EXPECT_FALSE(static_cast<bool>(p));
    EXPECT_EQ(p.use_count(), 0);  // у пустого указателя владельцев нет
}

// --- Копирующее присваивание -------------------------------------------------

TEST_F(SharedPtrFix, CopyAssignmentReleasesPreviousObject)
{
    mine::SharedPtr<Tracked> a(new Tracked(1));
    mine::SharedPtr<Tracked> b(new Tracked(2));

    b = a;  // прежний объект b (значение 2) обязан быть разрушен

    EXPECT_EQ(Tracked::destroyed, 1);
    EXPECT_EQ(Tracked::alive, 1);
    EXPECT_EQ(a.use_count(), 2);
    EXPECT_EQ(b->value, 1);
}

// ЛОВУШКА: этот тест зелёный. Самая естественная починка предыдущего
// (сначала release(), потом копирование) его убивает.
TEST_F(SharedPtrFix, SelfAssignmentIsSafe)
{
    mine::SharedPtr<Tracked> p(new Tracked(5));

    p = p;

    EXPECT_EQ(Tracked::destroyed, 0) << "самоприсваивание разрушило объект";
    EXPECT_EQ(Tracked::alive, 1);
    EXPECT_EQ(p->value, 5);
}

// --- Перемещение -------------------------------------------------------------

TEST_F(SharedPtrFix, MoveConstructorEmptiesSource)
{
    mine::SharedPtr<Tracked> a(new Tracked(3));
    mine::SharedPtr<Tracked> b(std::move(a));

    EXPECT_EQ(b.use_count(), 1);  // перемещение не добавляет владельца
    EXPECT_EQ(b->value, 3);
    EXPECT_EQ(a.get(), nullptr) << "источник обязан опустеть";
    EXPECT_EQ(a.use_count(), 0);
    EXPECT_EQ(Tracked::destroyed, 0);
}

TEST_F(SharedPtrFix, MoveAssignmentEmptiesSourceAndReleasesTarget)
{
    mine::SharedPtr<Tracked> a(new Tracked(1));
    mine::SharedPtr<Tracked> b(new Tracked(2));

    b = std::move(a);

    EXPECT_EQ(Tracked::destroyed, 1) << "прежний объект b не разрушен";
    EXPECT_EQ(b->value, 1);
    EXPECT_EQ(b.use_count(), 1);
    EXPECT_EQ(a.get(), nullptr) << "источник обязан опустеть";
}

// ЛОВУШКА: этот тест зелёный. Наивный move-assign через release() его убивает.
TEST_F(SharedPtrFix, SelfMoveAssignmentKeepsObjectAlive)
{
#if defined(__GNUC__)
#    pragma GCC diagnostic push
#    pragma GCC diagnostic ignored "-Wself-move"
#endif
    mine::SharedPtr<Tracked> p(new Tracked(9));

    p = std::move(p);
#if defined(__GNUC__)
#    pragma GCC diagnostic pop
#endif

    EXPECT_EQ(Tracked::alive, 1) << "самоперемещение уничтожило объект";
    EXPECT_EQ(Tracked::destroyed, 0);
}

// --- reset -------------------------------------------------------------------

TEST_F(SharedPtrFix, ResetReleasesPreviousObject)
{
    mine::SharedPtr<Tracked> p(new Tracked(1));

    p.reset(new Tracked(2));

    EXPECT_EQ(Tracked::destroyed, 1);
    EXPECT_EQ(Tracked::alive, 1);
    EXPECT_EQ(p->value, 2);
    EXPECT_EQ(p.use_count(), 1);
}

TEST_F(SharedPtrFix, ResetToNullEmptiesPointer)
{
    mine::SharedPtr<Tracked> p(new Tracked(1));

    p.reset();

    EXPECT_EQ(Tracked::destroyed, 1);
    EXPECT_EQ(p.get(), nullptr);
    EXPECT_EQ(p.use_count(), 0);
}

TEST_F(SharedPtrFix, ResetOnSharedObjectDoesNotKillOtherOwners)
{
    mine::SharedPtr<Tracked> a(new Tracked(1));
    mine::SharedPtr<Tracked> b = a;

    b.reset();

    EXPECT_EQ(Tracked::destroyed, 0) << "объект убит, хотя у него остался владелец";
    EXPECT_EQ(a.use_count(), 1);
    EXPECT_EQ(a->value, 1);
}

// --- Утечки ------------------------------------------------------------------

TEST_F(SharedPtrFix, NoObjectLeaksInTypicalUsage)
{
    {
        mine::SharedPtr<Tracked> a(new Tracked(1));
        mine::SharedPtr<Tracked> b(new Tracked(2));

        b = a;
        mine::SharedPtr<Tracked> c = a;
        c.reset(new Tracked(3));
    }

    EXPECT_EQ(Tracked::alive, 0) << "объекты утекли";
    EXPECT_EQ(Tracked::destroyed, 3);
}

TEST_F(SharedPtrFix, NoControlBlockLeaks)
{
    {
        mine::SharedPtr<Tracked> a(new Tracked(1));
        mine::SharedPtr<Tracked> b = a;
        mine::SharedPtr<Tracked> c(new Tracked(2));
        c = a;
    }

    EXPECT_EQ(mine::ControlBlock::alive, 0) << "control block утёк";
}

// --- Многопоточность ---------------------------------------------------------

TEST_F(SharedPtrFix, RefCountIsThreadSafe)
{
    // Только инкременты: копии живут до самой проверки. Так гонка видна
    // по итоговому счётчику, но объект не может быть удалён раньше времени.
    mine::SharedPtr<Tracked> p(new Tracked(1));

    constexpr int kThreads = 8;
    constexpr int kCopies  = 20000;

    std::vector<std::vector<mine::SharedPtr<Tracked>>> held(kThreads);
    std::vector<std::thread>                           workers;
    workers.reserve(kThreads);

    for (int i = 0; i < kThreads; ++i)
    {
        workers.emplace_back([&p, &bucket = held[i]] {
            bucket.reserve(kCopies);
            for (int j = 0; j < kCopies; ++j)
                bucket.push_back(p);
        });
    }

    for (std::thread& t : workers)
        t.join();

    // 1 исходный владелец + kThreads * kCopies копий.
    EXPECT_EQ(p.use_count(), 1 + kThreads * kCopies)
        << "счётчик потерял инкременты — неатомарный ++ под гонкой";
    EXPECT_EQ(Tracked::alive, 1);
}
