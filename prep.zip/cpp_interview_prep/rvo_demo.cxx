// rvo_demo.cxx — RVO, NRVO и где они ломаются. Трассируем каждый конструктор.
//
//   g++ -std=c++20 -Wall -Wextra -O2 -o rvo_demo rvo_demo.cxx && ./rvo_demo
//   g++ -std=c++20 -Wall -Wextra -O2 -fno-elide-constructors -o rvo_noelide rvo_demo.cxx && ./rvo_noelide
//   (второй вариант выключает НЕобязательную элизию — NRVO; гарантированную C++17 выключить нельзя)
//   g++ -std=c++20 -Wall -Wextra -Wnrvo -O2 -c rvo_demo.cxx   # GCC 14+: предупреждает, где NRVO не сработала

#include <cstdio>
#include <utility>

struct T {
    int v;
    explicit T(int x) : v(x)   { std::printf("  T(%d)             @%p\n", v, static_cast<void*>(this)); }
    T(const T& o) : v(o.v)     { std::printf("  copy T(%d)        @%p <- %p\n", v, static_cast<void*>(this), static_cast<const void*>(&o)); }
    T(T&& o) noexcept : v(o.v) { std::printf("  move T(%d)        @%p <- %p\n", v, static_cast<void*>(this), static_cast<const void*>(&o)); }
    ~T()                       { std::printf("  ~T(%d)            @%p\n", v, static_cast<void*>(this)); }
};

// 1. RVO: возвращаем prvalue. С C++17 это не оптимизация, а правило языка: временного нет вовсе.
T rvo() { return T(1); }

// 2. NRVO: одна именованная локальная переменная, возвращается по всем путям. Разрешено, не обязано.
T nrvo() { T t(2); t.v += 0; return t; }

// 3. Сломано: два разных объекта в разных return — компилятор не знает, какой строить на месте.
T two_locals(bool b) { T a(3); T c(4); if (b) return a; return c; }

// 4. Сломано: return std::move(local) — xvalue, NRVO запрещена по букве, будет move.
T explicit_move() { T t(5); return std::move(t); }

// 5. Сломано: параметр функции. Место под него выделил вызывающий, на слот результата его не положишь.
T return_param(T p) { return p; }

// 6. Сломано: член объекта / не-локальный — копия (lvalue) или move, если написать std::move.
struct Holder { T t{6}; T get() { return t; } };

// 7. Условный оператор с prvalue в обеих ветках — всё ещё prvalue, RVO работает.
T ternary_prvalue(bool b) { return b ? T(7) : T(70); }

// 8. Условный оператор с lvalue — уже нет.
T ternary_lvalue(bool b) { T a(8); T c(80); return b ? a : c; }

// 9. Неявный move при return локальной переменной: если NRVO не удалась, local всё равно
//    трактуется как rvalue (перегрузка move выбирается первой) — C++11, расширено в C++20/23.


struct Base { int b = 9; Base() = default; Base(const Base&) { std::puts("  copy Base"); } Base(Base&&) noexcept { std::puts("  move Base"); } };
struct Derived : Base {};
Base slicing_return() { Derived d; return d; }   // тип другой → NRVO невозможна, но move, не copy

int main() {
    std::puts("1. RVO (prvalue) — ожидаем один T(1) и ни одной копии/move:");
    { T x = rvo(); std::printf("  результат @%p\n", static_cast<void*>(&x)); }

    std::puts("2. NRVO (named) — при -O2 то же самое; с -fno-elide-constructors появится move:");
    { T x = nrvo(); std::printf("  результат @%p\n", static_cast<void*>(&x)); }

    std::puts("3. два локальных объекта в разных return — move одного из них:");
    { T x = two_locals(true); (void)x; }

    std::puts("4. return std::move(local) — move вместо NRVO (пессимизация):");
    { T x = explicit_move(); (void)x; }

    std::puts("5. return параметра по значению — move (NRVO невозможна):");
    { T x = return_param(T(5)); (void)x; }

    std::puts("6. return члена — copy:");
    { Holder h; T x = h.get(); (void)x; }

    std::puts("7. тернарник из prvalue — RVO есть:");
    { T x = ternary_prvalue(true); (void)x; }

    std::puts("8. тернарник из lvalue — copy (это даже не move!):");
    { T x = ternary_lvalue(true); (void)x; }

    std::puts("9. return Derived как Base — NRVO нет, но неявный move:");
    { Base b = slicing_return(); (void)b; }

    std::puts("10. цепочка: T x = T(T(T(1))) — гарантированно один объект:");
    { T x = T(T(T(10))); (void)x; }
}
