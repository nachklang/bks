// Наследование и множественное наследование: каждый сценарий проверяет одно утверждение
// из конспекта doc/01-general-topics/21-inheritance-and-multiple-inheritance.md
//
// Сборка (обязательно -O0: сценарии 9, 10 и 15 намеренно содержат UB, чтобы показать,
// что происходит «под капотом»; на -O2 оптимизатор вправе сделать с ними что угодно):
//   g++ -std=c++20 -Wall -Wextra -O0 -o inheritance_demo inheritance_demo.cxx && ./inheritance_demo
//
// Раскладку глазами компилятора можно посмотреть так:
//   g++ -std=c++20 -fdump-lang-class=/dev/stdout -c inheritance_demo.cxx | less

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <typeinfo>

namespace {

void title(const char* s) { std::printf("\n=== %s ===\n", s); }

// Смещение подобъекта или поля от начала объекта, в байтах.
template <class Whole, class Part>
long off(const Whole* whole, const Part* part)
{
    return reinterpret_cast<const char*>(part) - reinterpret_cast<const char*>(whole);
}

// ============================================================ 1. одиночное наследование
namespace s1 {
struct Base    { int a = 1; };
struct Derived : Base { int b = 2; };

struct PBase    { virtual ~PBase() = default; int a = 1; };
struct PDerived : PBase { int b = 2; };
}

void scenario_single()
{
    title("1. Одиночное наследование: база лежит в начале объекта");
    s1::Derived d;
    std::printf("  sizeof(Base)=%zu sizeof(Derived)=%zu\n", sizeof(s1::Base), sizeof(s1::Derived));
    std::printf("  Derived: подобъект Base @+%ld, a @+%ld, b @+%ld\n",
                off(&d, static_cast<s1::Base*>(&d)), off(&d, &d.a), off(&d, &d.b));
    s1::PDerived pd;
    std::printf("  полиморфный: sizeof(PBase)=%zu sizeof(PDerived)=%zu; vptr @+0, a @+%ld, b @+%ld\n",
                sizeof(s1::PBase), sizeof(s1::PDerived), off(&pd, &pd.a), off(&pd, &pd.b));
    s1::Base* pb = &d;
    std::printf("  адрес Derived %p, после неявного перехода к Base* %p — совпадают\n",
                static_cast<void*>(&d), static_cast<void*>(pb));
}

// ============================================================ 2. хвостовой padding
namespace s2 {
struct PodBase    { int x; char c; };                 // POD для целей раскладки
struct NonPodBase { int x; char c; NonPodBase() {} }; // есть пользовательский конструктор
struct FromPod    : PodBase    { char d; };
struct FromNonPod : NonPodBase { char d; };
}

void scenario_tail_padding()
{
    title("2. Хвостовой padding базы: переиспользуется только у не-POD базы");
    std::printf("  sizeof(PodBase)=%zu, sizeof(FromPod)=%zu\n", sizeof(s2::PodBase), sizeof(s2::FromPod));
    std::printf("  sizeof(NonPodBase)=%zu, sizeof(FromNonPod)=%zu\n",
                sizeof(s2::NonPodBase), sizeof(s2::FromNonPod));
    s2::FromNonPod f;
    std::printf("  FromNonPod::d лежит @+%ld — внутри 8 байт базы\n", off(&f, &f.d));
}

// ============================================================ 3. порядок конструирования
namespace s3 {
struct Tracer {
    const char* name;
    explicit Tracer(const char* n) : name(n) { std::printf("  + %s\n", name); }
    ~Tracer() { std::printf("  - %s\n", name); }
};
struct Base1 { Tracer t{"Base1 (первая база)"}; };
struct Base2 { Tracer t{"Base2 (вторая база)"}; };
// Список инициализации ниже намеренно в «неправильном» порядке. GCC предупреждает об этом
// (-Wreorder): порядок всё равно определяется объявлением, а не списком.
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wreorder"
struct Derived : Base1, Base2 {
    Tracer m1{"Derived::m1 (первое поле)"};
    Tracer m2{"Derived::m2 (второе поле)"};
    // Список инициализации написан в "неправильном" порядке — он ни на что не влияет.
    Derived() : m2("Derived::m2 (второе поле)"), m1("Derived::m1 (первое поле)")
    { std::puts("  тело Derived()"); }
    ~Derived() { std::puts("  тело ~Derived()"); }
};
#pragma GCC diagnostic pop
}

void scenario_order()
{
    title("3. Порядок: базы слева направо, поля сверху вниз, потом тело; разрушение наоборот");
    s3::Derived d;
    std::puts("  --- объект построен, выходим из области видимости");
}

// ============================================================ 4. сокрытие имён
namespace s4 {
struct Base {
    void f(int)    { std::puts("  Base::f(int)"); }
    void f(double) { std::puts("  Base::f(double)"); }
};
struct Hides : Base {
    void f(double) { std::puts("  Hides::f(double)"); }   // прячет ОБЕ Base::f
};
struct Unhides : Base {
    using Base::f;                                         // вернуть Base::f в область поиска
    void f(double) { std::puts("  Unhides::f(double)"); }  // эта заменяет Base::f(double)
};
}

void scenario_hiding()
{
    title("4. Сокрытие: имя в производном классе прячет ВСЕ одноимённые функции базы");
    s4::Hides h;
    std::printf("  h.f(1)  -> "); std::fflush(stdout); h.f(1);
    s4::Unhides u;
    std::printf("  u.f(1)  -> "); std::fflush(stdout); u.f(1);
    std::printf("  u.f(1.0)-> "); std::fflush(stdout); u.f(1.0);
    std::printf("  h.Base::f(1) -> "); std::fflush(stdout); h.Base::f(1);
}

// ============================================================ 5. аргументы по умолчанию
namespace s5 {
struct Base {
    virtual ~Base() = default;
    virtual void g(int x = 1) { std::printf("  Base::g(x=%d)\n", x); }
};
struct Derived : Base {
    void g(int x = 2) override { std::printf("  Derived::g(x=%d)\n", x); }
};
}

void scenario_default_args()
{
    title("5. Аргумент по умолчанию берётся по статическому типу, функция — по динамическому");
    s5::Derived d;
    s5::Base* pb = &d;
    std::printf("  pb->g() ->"); pb->g();
    std::printf("  d.g()   ->"); d.g();
}

// ============================================================ 6. доступ по статическому типу
namespace s6 {
struct Base {
    virtual ~Base() = default;
    virtual void hook() { std::puts("  Base::hook"); }
};
struct Derived : Base {
private:
    void hook() override { std::puts("  Derived::hook (private!)"); }
};
}

void scenario_access()
{
    title("6. Права доступа проверяются по статическому типу");
    s6::Derived d;
    s6::Base& b = d;
    std::printf("  через Base&: "); std::fflush(stdout); b.hook();   // d.hook() не скомпилируется
}

// ============================================================ 7. vptr в конструкторе
namespace s7 {
struct Base;
const char* type_name(const Base& b);
struct Base {
    Base() { std::printf("  в Base():     typeid=%s, speak -> ", type_name(*this)); speak(); }
    virtual ~Base() { std::printf("  в ~Base():    typeid=%s, speak -> ", type_name(*this)); speak(); }
    virtual void speak() const { std::puts("Base::speak"); }
};
struct Derived : Base {
    int payload = 42;
    Derived() { std::printf("  в Derived():  typeid=%s, speak -> ", type_name(*this)); speak(); }
    ~Derived() override { std::printf("  в ~Derived(): typeid=%s, speak -> ", type_name(*this)); speak(); }
    void speak() const override { std::printf("Derived::speak, payload=%d\n", payload); }
};
const char* type_name(const Base& b) { return typeid(b) == typeid(Derived) ? "Derived" : "Base"; }
}

void scenario_ctor_virtual()
{
    title("7. Виртуальный вызов в конструкторе и деструкторе уходит в текущий класс");
    s7::Derived d;
}

// ============================================================ 8. срезка
namespace s8 {
struct Shape {
    virtual ~Shape() = default;
    virtual const char* name() const { return "Shape"; }
    double x = 0;
};
struct Circle : Shape {
    const char* name() const override { return "Circle"; }
    double r = 5;
};
}

void scenario_slicing()
{
    title("8. Срезка: копия в базовый тип получает vptr базы и теряет поля производного");
    s8::Circle c;
    s8::Shape copy = c;          // конструктор копирования Shape: копирует x, ставит vptr Shape
    s8::Shape& ref = c;
    std::printf("  sizeof(Circle)=%zu, sizeof(Shape)=%zu\n", sizeof(s8::Circle), sizeof(s8::Shape));
    std::printf("  copy.name() = %s, ref.name() = %s\n", copy.name(), ref.name());
}

// ============================================================ 9. невиртуальный деструктор
namespace s9 {
struct Base { ~Base() { std::puts("  ~Base"); } };                // НЕ виртуальный
struct Derived : Base { ~Derived() { std::puts("  ~Derived"); } };
}

void scenario_nonvirtual_dtor()
{
    title("9. delete через базу без виртуального деструктора (UB): ~Derived не вызван");
    s9::Base* p = new s9::Derived;
    delete p;    // UB. Под ASan: new-delete-type-mismatch не ловится (размеры равны), но ~Derived пропущен
}

// ============================================================ 10. МН: сдвиг указателя
namespace s10 {
struct A {
    virtual void who() const { std::puts("A::who"); }
    int a = 0xAAAA;
};
struct B {
    void print() const { std::printf("B::print, this=%p, b=0x%X\n", static_cast<const void*>(this), b); }
    int b = 0xBBBB;
};
struct C;
// C здесь НЕПОЛНЫЙ тип: компилятор не знает, что C наследует B.
B* c_style_while_incomplete(C* p) { return (B*)p; }
struct C : A, B {
    void who() const override { std::puts("C::who"); }
    int c = 0xCCCC;
};
B* c_style_when_complete(C* p) { return (B*)p; }
}

void scenario_mi_adjust()
{
    title("10. Множественное наследование: static_cast сдвигает, reinterpret_cast нет");
    using namespace s10;
    C obj;
    std::printf("  sizeof A=%zu B=%zu C=%zu\n", sizeof(A), sizeof(B), sizeof(C));
    std::printf("  в C: vptr @+0, a @+%ld, подобъект B @+%ld, b @+%ld, c @+%ld\n",
                off(&obj, &obj.a), off(&obj, static_cast<B*>(&obj)), off(&obj, &obj.b), off(&obj, &obj.c));
    C* pc = &obj;
    B* s  = static_cast<B*>(pc);
    B* r  = reinterpret_cast<B*>(pc);
    B* c1 = c_style_while_incomplete(pc);
    B* c2 = c_style_when_complete(pc);
    std::printf("  pc                              = %p\n", static_cast<void*>(pc));
    std::printf("  static_cast<B*>                 = %p (сдвиг %+ld)\n", static_cast<void*>(s), off(pc, s));
    std::printf("  reinterpret_cast<B*>            = %p (сдвиг %+ld)\n", static_cast<void*>(r), off(pc, r));
    std::printf("  (B*) при неполном C             = %p (сдвиг %+ld)\n", static_cast<void*>(c1), off(pc, c1));
    std::printf("  (B*) при полном C               = %p (сдвиг %+ld)\n", static_cast<void*>(c2), off(pc, c2));
    std::printf("  s->print(): "); s->print();
    std::printf("  r->print(): "); r->print();   // UB: читает старшие 4 байта vptr как b
    std::printf("  pc == s ? %s   (сравнение сначала приводит pc к B*)\n", pc == s ? "да" : "нет");
    std::printf("  (void*)pc == (void*)s ? %s\n",
                static_cast<void*>(pc) == static_cast<void*>(s) ? "да" : "нет");
    C* null_c = nullptr;
    std::printf("  static_cast<B*>(nullptr C*) = %p — ноль не сдвигается\n",
                static_cast<void*>(static_cast<B*>(null_c)));
    B* back = s;
    std::printf("  static_cast<C*>(B*) обратно: сдвиг %+ld\n", off(back, static_cast<C*>(back)));
}

// ============================================================ 11. МН: два vptr и thunk
namespace s11 {
struct L {
    virtual ~L() = default;
    virtual void lf() { std::puts("L::lf"); }
    virtual void common() { std::puts("L::common"); }
    int l = 10;
};
struct R {
    virtual ~R() = default;
    virtual void rf() { std::puts("R::rf"); }
    virtual void common() { std::puts("R::common"); }
    int r = 20;
};
struct M : L, R {
    void lf() override { std::puts("M::lf"); }
    void rf() override { std::puts("M::rf"); }
    void common() override { std::printf("M::common, this=%p\n", static_cast<void*>(this)); }
    int m = 30;
};
}

void scenario_mi_thunk()
{
    title("11. Две полиморфные базы: два vptr, thunk правит this, dynamic_cast ходит вбок");
    using namespace s11;
    M obj;
    L* pl = &obj;
    R* pr = &obj;
    std::printf("  sizeof L=%zu R=%zu M=%zu\n", sizeof(L), sizeof(R), sizeof(M));
    std::printf("  M @%p, L-часть @+%ld, R-часть @+%ld, m @+%ld\n",
                static_cast<void*>(&obj), off(&obj, pl), off(&obj, pr), off(&obj, &obj.m));
    auto vptr = [](const void* p) { return *static_cast<void* const*>(p); };
    std::printf("  vptr по +0 = %p, vptr по +16 = %p — два разных указателя\n", vptr(pl), vptr(pr));
    std::printf("  offset-to-top в R-части таблицы: %ld\n",
                static_cast<long>(static_cast<const std::ptrdiff_t*>(vptr(pr))[-2]));
    std::printf("  pl->common(): "); pl->common();
    std::printf("  pr->common(): "); pr->common();   // через thunk: this исправлен на начало M
    L* from_r = dynamic_cast<L*>(pr);                 // кросс-каст: из R-части в L-часть
    std::printf("  dynamic_cast<L*>(pr) = %p (== pl? %s)\n", static_cast<void*>(from_r), from_r == pl ? "да" : "нет");
    std::printf("  dynamic_cast<void*>(pr) = %p — начало полного объекта\n", dynamic_cast<void*>(pr));
    std::printf("  static_cast<void*>(pr)  = %p — адрес R-части, не объекта\n", static_cast<void*>(pr));
}

// ============================================================ 12. неоднозначность имён
namespace s12 {
struct Left  { int id() const { return 1; } int x = 1; };
struct Right { int id() const { return 2; } int x = 2; };
struct Both : Left, Right {};
struct BothFixed : Left, Right { using Left::id; };
}

void scenario_ambiguity()
{
    title("12. Одно имя в двух базах: без уточнения не компилируется");
    s12::Both b;
    std::printf("  b.Left::id()=%d, b.Right::id()=%d, b.Left::x=%d, b.Right::x=%d\n",
                b.Left::id(), b.Right::id(), b.Left::x, b.Right::x);
    s12::BothFixed f;
    std::printf("  с using Left::id: f.id()=%d\n", f.id());
}

// ============================================================ 13. ромб без virtual
namespace s13 {
struct Top   { int t = 0; };
struct Left  : Top { int l = 1; };
struct Right : Top { int r = 2; };
struct Bottom : Left, Right { int b = 3; };
}

void scenario_plain_diamond()
{
    title("13. Ромб без virtual: в объекте ДВА подобъекта Top");
    using namespace s13;
    Bottom obj;
    Top* via_left  = static_cast<Left*>(&obj);
    Top* via_right = static_cast<Right*>(&obj);
    std::printf("  sizeof(Bottom)=%zu; Top через Left @+%ld, Top через Right @+%ld\n",
                sizeof(Bottom), off(&obj, via_left), off(&obj, via_right));
    obj.Left::t = 100;
    std::printf("  после obj.Left::t = 100: Left::t=%d, Right::t=%d\n", obj.Left::t, obj.Right::t);
}

// ============================================================ 14. виртуальный ромб
namespace s14 {
struct Top {
    explicit Top(const char* who = "по умолчанию") : tag(who) { std::printf("  Top(%s)\n", who); }
    virtual ~Top() = default;
    const char* tag;
    int t = 0;
};
struct Left : virtual Top {
    Left() : Top("из Left") { std::puts("  Left()"); }
    int l = 1;
};
struct Right : virtual Top {
    Right() : Top("из Right") { std::puts("  Right()"); }
    int r = 2;
};
struct Bottom : Left, Right {
    Bottom() : Top("из Bottom") { std::puts("  Bottom()"); }
    int b = 3;
};
struct BottomSilent : Left, Right {
    BottomSilent() { std::puts("  BottomSilent()"); }   // Top не упомянут
};
}

void scenario_virtual_diamond()
{
    title("14. Виртуальный ромб: один Top, его строит самый производный класс");
    using namespace s14;
    std::puts("  -- создаём Bottom:");
    Bottom obj;
    std::printf("  obj.tag = %s\n", obj.tag);
    std::puts("  -- создаём BottomSilent:");
    BottomSilent silent;
    std::printf("  silent.tag = %s\n", silent.tag);
    std::puts("  -- создаём отдельный Left:");
    Left alone;
    std::printf("  sizeof Top=%zu Left=%zu Right=%zu Bottom=%zu\n",
                sizeof(Top), sizeof(Left), sizeof(Right), sizeof(Bottom));
    std::printf("  Top внутри отдельного Left @+%ld, внутри Left-части Bottom @+%ld от Left\n",
                off(&alone, static_cast<Top*>(&alone)),
                off(static_cast<Left*>(&obj), static_cast<Top*>(static_cast<Left*>(&obj))));
    Top* t1 = static_cast<Left*>(&obj);
    Top* t2 = static_cast<Right*>(&obj);
    std::printf("  Top через Left и через Right — один адрес? %s (@+%ld)\n",
                t1 == t2 ? "да" : "нет", off(&obj, t1));
}

// ============================================================ 15. неверный даункаст
namespace s15 {
struct Animal { virtual ~Animal() = default; int legs = 4; };
struct Dog : Animal { int good_boy = 1; };
struct Cat : Animal { int lives = 9; };
}

void scenario_downcast()
{
    title("15. Даункаст: static_cast верит на слово, dynamic_cast проверяет");
    using namespace s15;
    Cat cat;
    Animal* a = &cat;
    Dog* d_static = static_cast<Dog*>(a);        // UB: объект не Dog
    Dog* d_dyn    = dynamic_cast<Dog*>(a);
    std::printf("  static_cast<Dog*>  = %p, good_boy читает lives кошки: %d\n",
                static_cast<void*>(d_static), d_static->good_boy);
    std::printf("  dynamic_cast<Dog*> = %p\n", static_cast<void*>(d_dyn));
    try {
        (void)dynamic_cast<Dog&>(*a);
    } catch (const std::bad_cast& e) {
        std::printf("  dynamic_cast<Dog&> бросил std::bad_cast (%s)\n", e.what());
    }
}

// ============================================================ 16. указатель на член
namespace s16 {
struct A { virtual ~A() = default; int a = 1; };
struct B { void hello() { std::printf("B::hello, this=%p\n", static_cast<void*>(this)); } int b = 2; };
struct C : A, B {};
}

void scenario_member_pointer()
{
    title("16. Указатель на функцию-член при МН хранит сдвиг this");
    using namespace s16;
    void (C::*pm)() = &C::hello;                 // на самом деле &B::hello, приведённый к C
    std::uintptr_t raw[2];
    static_assert(sizeof pm == sizeof raw);
    std::memcpy(raw, &pm, sizeof raw);
    std::printf("  sizeof(void (C::*)()) = %zu, sizeof(void*) = %zu\n", sizeof pm, sizeof(void*));
    std::printf("  слово 0 (адрес функции) = %#lx, слово 1 (сдвиг this) = %ld\n",
                static_cast<unsigned long>(raw[0]), static_cast<long>(raw[1]));
    C obj;
    std::printf("  C @%p; (obj.*pm)(): ", static_cast<void*>(&obj)); (obj.*pm)();
    int C::*pd = &C::b;
    std::printf("  указатель на поле: sizeof = %zu\n", sizeof pd);
}

// ============================================================ 17. ковариантный возврат
namespace s17 {
struct Other { virtual ~Other() = default; long pad = 0; };
struct Base  { virtual ~Base() = default; virtual Base* self() { return this; } int b = 0; };
struct Derived : Other, Base {
    Derived* self() override { return this; }   // возвращает Derived*, база ждёт Base*
};
}

void scenario_covariant()
{
    title("17. Ковариантный возврат при МН: thunk сдвигает и возвращаемое значение");
    using namespace s17;
    Derived d;
    Base* pb = &d;
    Base* got = pb->self();
    std::printf("  Derived @%p, Base-часть @+%ld; pb->self() вернул @+%ld — это снова Base-часть\n",
                static_cast<void*>(&d), off(&d, pb), off(&d, got));
}

// ============================================================ 18. пустые базы
namespace s18 {
struct Empty {};
struct Holder        { Empty e; int i; };
struct ViaBase       : Empty { int i; };
struct SameTypeClash : Empty { Empty e; int i; };      // база Empty и поле Empty
struct NoUnique      { [[no_unique_address]] Empty e; int i; };
}

void scenario_empty()
{
    title("18. Пустые базы: EBO и почему два Empty не могут лечь по одному адресу");
    using namespace s18;
    std::printf("  sizeof(Empty)=%zu Holder=%zu ViaBase=%zu SameTypeClash=%zu NoUnique=%zu\n",
                sizeof(Empty), sizeof(Holder), sizeof(ViaBase), sizeof(SameTypeClash), sizeof(NoUnique));
    SameTypeClash s;
    std::printf("  SameTypeClash: база Empty @+%ld, поле e @+%ld, i @+%ld\n",
                off(&s, static_cast<Empty*>(&s)), off(&s, &s.e), off(&s, &s.i));
}

// ============================================================ 19. цена кастов
namespace s19 {
struct Base  { virtual ~Base() = default; };
struct Mid   : Base {};
struct Leaf  : Mid {};
struct Other { virtual ~Other() = default; };
struct Multi : Leaf, Other {};
}

template <class F>
double ns_per_op(F f, int n)
{
    auto t0 = std::chrono::steady_clock::now();
    for (int i = 0; i < n; ++i) f();
    auto t1 = std::chrono::steady_clock::now();
    return std::chrono::duration<double, std::nano>(t1 - t0).count() / n;
}

void scenario_cost()
{
    title("19. Цена кастов (порядок величин, -O0)");
    using namespace s19;
    Multi obj;
    Base* volatile pb = &obj;
    Other* volatile po = &obj;
    void* volatile sink = nullptr;
    constexpr int N = 5'000'000;
    double t_static = ns_per_op([&] { sink = static_cast<Leaf*>(static_cast<Mid*>(pb)); }, N);
    double t_down   = ns_per_op([&] { sink = dynamic_cast<Leaf*>(pb); }, N);
    double t_cross  = ns_per_op([&] { sink = dynamic_cast<Base*>(po); }, N);
    double t_full   = ns_per_op([&] { sink = dynamic_cast<Multi*>(pb); }, N);
    (void)sink;
    std::printf("  static_cast вниз по цепочке : %5.1f нс\n", t_static);
    std::printf("  dynamic_cast вниз на 2 уровня: %5.1f нс\n", t_down);
    std::printf("  dynamic_cast вбок (Other->Base): %5.1f нс\n", t_cross);
    std::printf("  dynamic_cast к самому производному: %5.1f нс\n", t_full);
}


// ============================================================ 20. цепочка вверх
namespace s20 {
struct A {
    virtual ~A() = default;
    virtual void on_tick(int depth) { std::printf("%*sA::on_tick\n", depth * 2, ""); }
};
struct B : A {};   // on_tick НЕ переопределяет
struct C : B {
    void on_tick(int depth) override {
        std::printf("%*sC::on_tick -> B::on_tick()\n", depth * 2, "");
        B::on_tick(depth + 1);          // в B нет своей версии: квалифицированный поиск находит A::on_tick
    }
};
struct D : C {
    void on_tick(int depth) override {
        std::printf("%*sD::on_tick -> C::on_tick()\n", depth * 2, "");
        C::on_tick(depth + 1);          // квалифицированный вызов: не виртуальный, без рекурсии
    }
};
}

void scenario_chain_up()
{
    title("20. Цепочка переопределений вверх: каждый уровень зовёт Base::f()");
    s20::D d;
    s20::A& a = d;
    a.on_tick(1);
}

// ============================================================ 21. цепочка в ромбе
namespace s21 {
struct Top {
    virtual ~Top() = default;
    virtual void save() { std::puts("    Top::save  (пишет общие поля)"); }
};
struct Left : virtual Top {
    void save() override { Top::save(); std::puts("    Left::save"); }
};
struct Right : virtual Top {
    void save() override { Top::save(); std::puts("    Right::save"); }
};
struct Bottom : Left, Right {
    void save() override { Left::save(); Right::save(); std::puts("    Bottom::save"); }
};

// Исправление: «своя часть» каждого класса — отдельная невиртуальная функция,
// а обход иерархии собирает только самый производный класс.
struct Top2 {
    virtual ~Top2() = default;
    virtual void save() { save_own(); }
protected:
    void save_own() { std::puts("    Top2::save_own"); }
};
struct Left2 : virtual Top2 {
    void save() override { Top2::save_own(); save_own(); }
protected:
    void save_own() { std::puts("    Left2::save_own"); }
};
struct Right2 : virtual Top2 {
    void save() override { Top2::save_own(); save_own(); }
protected:
    void save_own() { std::puts("    Right2::save_own"); }
};
struct Bottom2 : Left2, Right2 {
    void save() override {
        Top2::save_own(); Left2::save_own(); Right2::save_own();
        std::puts("    Bottom2::save_own");
    }
};
}

void scenario_chain_diamond()
{
    title("21. Цепочка в ромбе: база вызывается дважды даже при virtual-наследовании");
    std::puts("  Bottom::save():");
    s21::Bottom b;
    s21::Top& t = b;
    t.save();
    std::puts("  Bottom2::save() — каждая часть ровно один раз:");
    s21::Bottom2 b2;
    s21::Top2& t2 = b2;
    t2.save();
}

// ============================================================ 22. шаблонный метод
namespace s22 {
struct Strategy {
    virtual ~Strategy() = default;
    // Невиртуальный каркас (NVI): порядок шагов фиксирует база.
    void on_market_data(int px) {
        std::printf("  Strategy::on_market_data(%d)\n", px);
        if (should_trade(px)) send(px);          // виртуальные вызовы из кода базы
    }
private:
    virtual bool should_trade(int) { return false; }
    virtual void send(int px) { std::printf("    Strategy::send(%d)\n", px); }
};
struct Momentum : Strategy {
private:
    bool should_trade(int px) override {
        std::printf("    Momentum::should_trade(%d)\n", px);
        return px > 100;
    }
};
struct LoggedMomentum : Momentum {
private:
    void send(int px) override {
        std::printf("    LoggedMomentum::send(%d) -> ", px);
        std::fflush(stdout);
        // Strategy::send закрытая. Наследник может её ПЕРЕОПРЕДЕЛИТЬ, но не может её
        // ВЫЗВАТЬ: Strategy::send(px) здесь не скомпилируется (private within this context).
        // Если версия базы должна быть доступна наследникам как «super», её делают protected.
        std::printf("отправлено\n");
    }
};
}

void scenario_template_method()
{
    title("22. Виртуальный вызов из кода базы уходит в самый производный класс");
    s22::LoggedMomentum s;
    s.on_market_data(99);
    s.on_market_data(101);
}

// ============================================================ 23. цепочка деструкторов
namespace s23 {
struct Level1 { virtual ~Level1() { std::puts("  ~Level1"); } };
struct Level2 : Level1 { ~Level2() override { std::puts("  ~Level2"); } };
struct Level3 : Level2 { ~Level3() override { std::puts("  ~Level3"); } };
}

void scenario_dtor_chain()
{
    title("23. delete через Level1* при виртуальном деструкторе: вся цепочка снизу вверх");
    s23::Level1* p = new s23::Level3;
    delete p;
}

} // namespace

int main()
{
    scenario_single();
    scenario_tail_padding();
    scenario_order();
    scenario_hiding();
    scenario_default_args();
    scenario_access();
    scenario_ctor_virtual();
    scenario_slicing();
    scenario_nonvirtual_dtor();
    scenario_mi_adjust();
    scenario_mi_thunk();
    scenario_ambiguity();
    scenario_plain_diamond();
    scenario_virtual_diamond();
    scenario_downcast();
    scenario_member_pointer();
    scenario_covariant();
    scenario_empty();
    scenario_cost();
    scenario_chain_up();
    scenario_chain_diamond();
    scenario_template_method();
    scenario_dtor_chain();
    std::puts("");
    return 0;
}
