// Тренажёр №4: Linux под лайвкодинг. Семь задач на системные вызовы.
//
// Правила прежние: сначала сам, вслух, потом компилировать. Норма — 10-15 минут на задачу.
// После каждой — «объясни каждую строчку»: что делает syscall, что вернёт при ошибке,
// какой ресурс надо освободить и что будет, если не освободить.
//
// Сборка:
//   g++ -std=c++20 -Wall -Wextra -O2 -o linux_drills linux_drills.cxx -lgtest -lgtest_main -pthread && ./linux_drills
//   g++ -std=c++20 -g -fsanitize=address,undefined -o ld_asan linux_drills.cxx -lgtest -lgtest_main -pthread && ./ld_asan
//
// Одну задачу за раз:
//   ./linux_drills --gtest_filter=Linux.MmapCountLines*
//
// У сетевых и сигнальных ожиданий есть дедлайн — сломанный сервер даёт красный тест,
// а не зависание. Задачи с fork — исключение: если ребёнок повис, повиснет и тест.
// Скелеты компилируются и возвращают заглушки — все тесты красные.

#include <gtest/gtest.h>

#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <signal.h>
#include <sys/epoll.h>
#include <sys/eventfd.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#include <atomic>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <fstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

// =====================================================================================
// Вспомогательное для тестов
// =====================================================================================
namespace
{

// Сколько дескрипторов открыто у процесса. Разница до/после — самый честный детектор утечки fd.
int open_fd_count()
{
    int  n = 0;
    DIR* d = opendir("/proc/self/fd");
    if (!d) return -1;
    while (dirent* e = readdir(d))
        if (e->d_name[0] != '.') ++n;
    closedir(d);
    return n - 1;   // сам opendir держит один fd
}

std::string temp_file_with(const std::string& content)
{
    char name[] = "/tmp/linux_drills_XXXXXX";
    int  fd     = mkstemp(name);
    if (fd < 0) throw std::runtime_error("mkstemp");
    const char* p    = content.data();
    std::size_t left = content.size();
    while (left)
    {
        ssize_t w = write(fd, p, left);
        if (w < 0) throw std::runtime_error("write");
        p += w;
        left -= static_cast<std::size_t>(w);
    }
    close(fd);
    return name;
}

// Клиент с таймаутом на чтение: сломанный сервер даёт EAGAIN, а не вечное ожидание.
int connect_client(uint16_t port, int recv_timeout_ms)
{
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return -1;
    timeval tv{recv_timeout_ms / 1000, (recv_timeout_ms % 1000) * 1000};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof tv);
    sockaddr_in addr{};
    addr.sin_family      = AF_INET;
    addr.sin_port        = htons(port);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (connect(fd, reinterpret_cast<sockaddr*>(&addr), sizeof addr) < 0)
    {
        close(fd);
        return -1;
    }
    return fd;
}

bool send_all(int fd, const std::string& s)
{
    std::size_t off = 0;
    while (off < s.size())
    {
        ssize_t w = send(fd, s.data() + off, s.size() - off, MSG_NOSIGNAL);
        if (w <= 0) return false;
        off += static_cast<std::size_t>(w);
    }
    return true;
}

bool recv_exact(int fd, std::string& out, std::size_t n)
{
    out.resize(n);
    std::size_t off = 0;
    while (off < n)
    {
        ssize_t r = recv(fd, out.data() + off, n - off, 0);
        if (r <= 0) return false;
        off += static_cast<std::size_t>(r);
    }
    return true;
}

}   // namespace

// =====================================================================================
// 1. Посчитать строки в файле через mmap
// =====================================================================================
// Вслух: что делает mmap в момент вызова (ничего, кроме VMA); откуда берутся страницы;
// почему MAP_FAILED, а не nullptr; почему пустой файл — особый случай (mmap длины 0 —
// EINVAL); зачем MAP_PRIVATE + PROT_READ; кто закрывает fd и когда можно (сразу после
// mmap); что будет, если файл усекут под отображением (SIGBUS); чем это отличается
// от read в цикле и когда read лучше. Стретч: madvise(MADV_SEQUENTIAL) и что он меняет.
std::size_t count_lines_mmap(const std::string& path)
{
    auto fd = open(path.c_str(), O_RDONLY);

    if(!fd)
    {
        close(fd);
        throw std::runtime_error("Invalid file");
    }
    
    struct stat finfo;
    fstat(fd, &finfo);

    if(!finfo.st_size)
    {
        close(fd);
        throw std::runtime_error("Invalid file size");
    }

    auto mapping = mmap(nullptr, finfo.st_size, PROT_READ, MAP_PRIVATE, fd, 0);

    auto lines = 0;

    for(auto it = static_cast<const char*>(mapping), ite = it + finfo.st_size; it < ite; )
    {
        auto result = static_cast<const char*>(memchr(it, '\n', ite - it));

        if(result == nullptr)
        {
            break;
        }

        it = result + 1;

        ++lines;
    }

    munmap(mapping, finfo.st_size);
    close(fd);
    // TODO: open → fstat → (size == 0 → 0) → mmap → memchr/подсчёт '\n' → munmap → close.
    //       Ошибки — исключение std::runtime_error с strerror(errno).
    return lines;
}

TEST(Linux, MmapCountLinesSmall)
{
    const std::string path = temp_file_with("a\nbb\nccc\n");
    EXPECT_EQ(count_lines_mmap(path), 3u);
    unlink(path.c_str());
}

TEST(Linux, MmapCountLinesNoTrailingNewline)
{
    const std::string path = temp_file_with("a\nb");   // считаем символы '\n', а не «строки»
    EXPECT_EQ(count_lines_mmap(path), 1u);
    unlink(path.c_str());
}

TEST(Linux, MmapCountLinesEmptyFile)
{
    const std::string path = temp_file_with("");
    EXPECT_EQ(count_lines_mmap(path), 0u) << "mmap длины 0 — EINVAL; пустой файл надо обработать до mmap";
    unlink(path.c_str());
}

TEST(Linux, MmapCountLinesLargeFile)
{
    std::string content;
    content.reserve(3 << 20);
    std::size_t lines = 0;
    while (content.size() < (3u << 20))
    {
        content += "0123456789abcdef";
        if (content.size() % 7 == 0) { content += '\n'; ++lines; }
    }
    const std::string path = temp_file_with(content);
    EXPECT_EQ(count_lines_mmap(path), lines) << "несколько сотен страниц, границы страниц внутри строк";
    unlink(path.c_str());
}

TEST(Linux, MmapCountLinesDoesNotLeakFd)
{
    const std::string path = temp_file_with("x\n");
    ASSERT_EQ(count_lines_mmap(path), 1u);
    const int before = open_fd_count();
    for (int i = 0; i < 50; ++i) ASSERT_EQ(count_lines_mmap(path), 1u);
    EXPECT_EQ(open_fd_count(), before) << "fd не закрыт после mmap (закрывать можно сразу после mmap)";
    unlink(path.c_str());
}

TEST(Linux, MmapCountLinesMissingFileThrows)
{
    EXPECT_THROW((void)count_lines_mmap("/nonexistent/definitely/not/here"), std::runtime_error);
}

// =====================================================================================
// 2. fork + pipe: отправить число ребёнку, получить ответ, похоронить ребёнка
// =====================================================================================
// Вслух: что копирует fork (таблицу страниц, CoW; fd-таблицу — дескрипторы общие);
// почему нужны ДВА pipe и почему в каждом процессе закрывают ненужные концы (иначе
// read не увидит EOF); зомби и waitpid; почему в ребёнке _exit, а не exit (atexit
// и буферы stdio сработают дважды); что будет с буферизованным stdout при fork;
// что делает SIGPIPE при записи в трубу без читателя.
int pipe_round_trip(int /*value*/)
{
    // TODO: pipe ×2 → fork → ребёнок: read(value) → write(value + 1) → _exit(0);
    //       родитель: write(value) → read(reply) → waitpid → вернуть reply.
    return -1;
}

TEST(Linux, PipeRoundTripValue)
{
    EXPECT_EQ(pipe_round_trip(41), 42);
}

TEST(Linux, PipeRoundTripLeavesNoZombie)
{
    ASSERT_EQ(pipe_round_trip(1), 2);
    int   st = 0;
    pid_t r  = waitpid(-1, &st, WNOHANG);
    EXPECT_TRUE(r == -1 && errno == ECHILD) << "остался неубранный ребёнок (зомби): waitpid пропущен";
}

TEST(Linux, PipeRoundTripDoesNotLeakFd)
{
    ASSERT_EQ(pipe_round_trip(0), 1);
    const int before = open_fd_count();
    for (int i = 0; i < 30; ++i) ASSERT_EQ(pipe_round_trip(i), i + 1);
    EXPECT_EQ(open_fd_count(), before) << "концы pipe не закрыты в родителе";
}

// =====================================================================================
// 3. Echo-сервер на epoll
// =====================================================================================
// Вслух: socket → bind(127.0.0.1:0) → listen → epoll_create1 → цикл epoll_wait;
// accept4 с SOCK_NONBLOCK; почему все сокеты неблокирующие; level-triggered против
// edge-triggered и что обязан делать код при ET (читать до EAGAIN); частичная запись
// и EAGAIN на send — куда девать хвост; как разбудить epoll_wait для остановки
// (eventfd или pipe в том же epoll — не «закрыть fd из другого потока»); SO_REUSEADDR;
// TCP_NODELAY и зачем; почему select здесь хуже; что такое C10K.
class EchoServer
{
public:
    EchoServer() {}
    ~EchoServer() { stop(); }
    EchoServer(const EchoServer&)            = delete;
    EchoServer& operator=(const EchoServer&) = delete;

    uint16_t port() const { return 0; }   // TODO: getsockname после bind на порт 0
    void     start() {}                   // TODO: поток с циклом epoll_wait
    void     stop() {}                    // TODO: разбудить цикл, join, закрыть всё; повторный stop безопасен

private:
    // TODO: listen_fd_, epoll_fd_, wake_fd_ (eventfd), std::thread, состояние клиентов
    //       (незаписанный хвост на каждого).
};

TEST(Linux, EpollEchoSingleClient)
{
    EchoServer srv;
    srv.start();
    ASSERT_NE(srv.port(), 0) << "сервер не слушает";

    int fd = connect_client(srv.port(), 2000);
    ASSERT_GE(fd, 0) << "connect: " << strerror(errno);

    ASSERT_TRUE(send_all(fd, "hello"));
    std::string reply;
    EXPECT_TRUE(recv_exact(fd, reply, 5)) << "эхо не пришло за 2 с";
    EXPECT_EQ(reply, "hello");
    close(fd);
}

TEST(Linux, EpollEchoManyClientsInterleaved)
{
    EchoServer srv;
    srv.start();
    ASSERT_NE(srv.port(), 0);

    constexpr int kClients = 8, kRounds = 100;
    std::vector<int> fds;
    for (int c = 0; c < kClients; ++c)
    {
        int fd = connect_client(srv.port(), 2000);
        ASSERT_GE(fd, 0);
        fds.push_back(fd);
    }
    for (int r = 0; r < kRounds; ++r)
        for (int c = 0; c < kClients; ++c)
        {
            const std::string msg = "c" + std::to_string(c) + "r" + std::to_string(r) + ";";
            ASSERT_TRUE(send_all(fds[static_cast<std::size_t>(c)], msg));
            std::string reply;
            ASSERT_TRUE(recv_exact(fds[static_cast<std::size_t>(c)], reply, msg.size())) << "клиент " << c;
            EXPECT_EQ(reply, msg);
        }
    for (int fd : fds) close(fd);
}

TEST(Linux, EpollEchoLargeMessageSurvivesPartialWrites)
{
    EchoServer srv;
    srv.start();
    ASSERT_NE(srv.port(), 0);

    int fd = connect_client(srv.port(), 5000);
    ASSERT_GE(fd, 0);

    std::string big(4u << 20, 'x');   // 4 МБ — больше любого сокетного буфера
    for (std::size_t i = 0; i < big.size(); i += 4096) big[i] = static_cast<char>('a' + (i / 4096) % 26);

    std::string reply;
    std::thread reader([&] { recv_exact(fd, reply, big.size()); });
    ASSERT_TRUE(send_all(fd, big));
    reader.join();
    EXPECT_EQ(reply.size(), big.size()) << "сервер потерял хвост при EAGAIN на send";
    EXPECT_EQ(reply, big);
    close(fd);
}

TEST(Linux, EpollEchoClientDisconnectDoesNotKillServer)
{
    EchoServer srv;
    srv.start();
    ASSERT_NE(srv.port(), 0);

    int a = connect_client(srv.port(), 2000);
    ASSERT_GE(a, 0);
    close(a);   // сервер получит read == 0 (EOF) — должен закрыть свой конец и жить дальше
    std::this_thread::sleep_for(std::chrono::milliseconds(50));

    int b = connect_client(srv.port(), 2000);
    ASSERT_GE(b, 0) << "сервер умер после отключения клиента";
    ASSERT_TRUE(send_all(b, "still alive"));
    std::string reply;
    EXPECT_TRUE(recv_exact(b, reply, 11));
    EXPECT_EQ(reply, "still alive");
    close(b);
}

TEST(Linux, EpollEchoStopReturnsPromptlyAndFreesFds)
{
    const int before = open_fd_count();
    {
        EchoServer srv;
        srv.start();
        ASSERT_NE(srv.port(), 0);
        int fd = connect_client(srv.port(), 2000);
        ASSERT_GE(fd, 0);

        const auto t0 = std::chrono::steady_clock::now();
        srv.stop();
        const auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - t0).count();
        EXPECT_LT(ms, 1000) << "stop() ждал таймаут epoll_wait вместо явного пробуждения";
        close(fd);
    }
    EXPECT_EQ(open_fd_count(), before) << "после остановки остались открытые дескрипторы";
}

// =====================================================================================
// 4. Общий счётчик между процессами через анонимный MAP_SHARED
// =====================================================================================
// Вслух: чем MAP_SHARED|MAP_ANONYMOUS отличается от MAP_PRIVATE после fork (CoW);
// почему std::atomic работает между процессами (lock-free тип, одна физическая
// страница) и когда НЕ работает (не lock-free → внутренняя блокировка в адресном
// пространстве одного процесса); чем это отличается от shm_open + mmap (имя, время
// жизни); что нужно мьютексу, чтобы жить в общей памяти (PTHREAD_PROCESS_SHARED,
// robust); почему в сегменте нельзя хранить указатели.
long long shared_counter_across_forks(int /*processes*/, int /*increments_each*/)
{
    // TODO: mmap(MAP_SHARED | MAP_ANONYMOUS) под std::atomic<long long> → placement new →
    //       fork × processes → каждый ребёнок fetch_add × increments_each → _exit →
    //       родитель waitpid всех → результат → munmap.
    return -1;
}

TEST(Linux, SharedCounterExact)
{
    constexpr int kProcs = 4, kIncr = 100'000;
    EXPECT_EQ(shared_counter_across_forks(kProcs, kIncr), 1LL * kProcs * kIncr)
        << "инкременты потерялись: либо MAP_PRIVATE (у каждого своя копия), либо не атомик";
}

TEST(Linux, SharedCounterRepeatableAndNoZombies)
{
    for (int i = 0; i < 5; ++i) ASSERT_EQ(shared_counter_across_forks(3, 10'000), 30'000LL);
    int   st = 0;
    pid_t r  = waitpid(-1, &st, WNOHANG);
    EXPECT_TRUE(r == -1 && errno == ECHILD) << "дети не собраны";
}

// =====================================================================================
// 5. Монотонные часы без системного вызова
// =====================================================================================
// Вслух: CLOCK_REALTIME против CLOCK_MONOTONIC (NTP-скачки, suspend) и почему таймауты
// меряют монотонными; vDSO — почему clock_gettime не syscall и что будет, если
// clocksource не tsc; rdtsc: когда можно и что такое invariant TSC; разрешение
// nanosleep и почему «спать 1 мс» — это 1.05-1.1 мс; чем steady_clock отличается
// от system_clock в libstdc++ (ничем, кроме CLOCK_*).
std::int64_t monotonic_now_ns()
{
    return 0;   // TODO: clock_gettime(CLOCK_MONOTONIC) → секунды * 1e9 + наносекунды
}

TEST(Linux, MonotonicClockNeverGoesBack)
{
    std::int64_t prev = monotonic_now_ns();
    ASSERT_GT(prev, 0) << "нули — заглушка";
    for (int i = 0; i < 1'000'000; ++i)
    {
        const std::int64_t now = monotonic_now_ns();
        ASSERT_GE(now, prev);
        prev = now;
    }
}

TEST(Linux, MonotonicClockIsCheapViaVdso)
{
    constexpr int kN = 2'000'000;
    const auto    t0 = std::chrono::steady_clock::now();
    std::int64_t  sink = 0;
    for (int i = 0; i < kN; ++i) sink += monotonic_now_ns();
    const double ns = std::chrono::duration<double, std::nano>(std::chrono::steady_clock::now() - t0).count() / kN;
    EXPECT_LT(ns, 40.0) << "похоже на настоящий syscall, а не vDSO (" << ns
                         << " нс; на этой машине vDSO ~13 нс, syscall ~80 нс)";
    EXPECT_NE(sink, 0);
}

TEST(Linux, MonotonicClockAgreesWithSleep)
{
    const std::int64_t a = monotonic_now_ns();
    std::this_thread::sleep_for(std::chrono::milliseconds(20));
    const std::int64_t b = monotonic_now_ns();
    EXPECT_GE(b - a, 20'000'000) << "часы идут медленнее реального времени — единицы перепутаны?";
    EXPECT_LT(b - a, 200'000'000) << "часы идут быстрее — секунды умножены не на то";
}

// =====================================================================================
// 6. Сигнал → флаг → self-pipe: как правильно ждать сигнал
// =====================================================================================
// Вслух: что можно делать в обработчике (только async-signal-safe: write — да, printf,
// malloc, mutex — нет); volatile sig_atomic_t против std::atomic; self-pipe trick и
// зачем он (превращает сигнал в fd, который можно poll'ить вместе с сокетами);
// signalfd как альтернатива; SA_RESTART и EINTR — что происходит с read/accept при
// приходе сигнала; sigaction против signal(); маска сигналов в потоках (pthread_sigmask)
// и в какой поток попадает kill(pid).
void install_sigusr1_handler()
{
    // TODO: pipe (O_NONBLOCK | O_CLOEXEC) → sigaction(SIGUSR1) с обработчиком,
    //       который делает write(pipe[1], "x", 1) и больше ничего.
}

bool wait_for_sigusr1(int /*timeout_ms*/)
{
    // TODO: poll на pipe[0] с таймаутом → если POLLIN: вычитать всё, вернуть true.
    return false;
}

// SIGUSR1 без обработчика убивает процесс — вместе с gtest. Поэтому перед kill проверяем,
// что обработчик стоит; иначе тест красный, а не мёртвый бинарник.
bool sigusr1_handler_installed()
{
    struct sigaction sa{};
    if (sigaction(SIGUSR1, nullptr, &sa) != 0) return false;
    return sa.sa_handler != SIG_DFL && sa.sa_handler != SIG_IGN;
}

TEST(Linux, SignalFromSelfIsSeen)
{
    install_sigusr1_handler();
    ASSERT_TRUE(sigusr1_handler_installed()) << "обработчик не установлен — kill убил бы процесс";
    ASSERT_EQ(kill(getpid(), SIGUSR1), 0);
    EXPECT_TRUE(wait_for_sigusr1(1000)) << "сигнал не дошёл до pipe за 1 с";
}

TEST(Linux, NoSignalMeansTimeout)
{
    install_sigusr1_handler();
    ASSERT_TRUE(sigusr1_handler_installed());
    (void)wait_for_sigusr1(50);   // вычистить возможный хвост от предыдущего теста
    const auto t0 = std::chrono::steady_clock::now();
    EXPECT_FALSE(wait_for_sigusr1(100));
    const auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - t0).count();
    EXPECT_GE(ms, 90) << "таймаут не соблюдён";
}

TEST(Linux, SignalFromAnotherThreadIsSeen)
{
    install_sigusr1_handler();
    ASSERT_TRUE(sigusr1_handler_installed());
    (void)wait_for_sigusr1(50);
    const pthread_t main_thread = pthread_self();
    std::thread     t([&] {
        std::this_thread::sleep_for(std::chrono::milliseconds(30));
        pthread_kill(main_thread, SIGUSR1);
    });
    EXPECT_TRUE(wait_for_sigusr1(1000));
    t.join();
}

// =====================================================================================
// 7. Прочитать RSS процесса из /proc
// =====================================================================================
// Вслух: VmRSS против VmSize (VSZ) и почему VSZ бесполезен; RssAnon/RssFile/RssShmem;
// /proc/self/status против /proc/self/statm против smaps_rollup; почему RSS не растёт
// сразу после malloc (страницы приходят по первому касанию) и падает не сразу после
// free (trim threshold, см. 16-allocators); как посмотреть то же снаружи (ps, top,
// pidstat, /proc/<pid>/smaps).
std::size_t rss_kib_from_proc()
{
    return 0;   // TODO: /proc/self/status → строка "VmRSS:" → число в КиБ
}

TEST(Linux, RssIsPositive)
{
    EXPECT_GT(rss_kib_from_proc(), 1024u) << "у живого процесса с gtest RSS заведомо больше 1 МиБ";
}

TEST(Linux, RssGrowsAfterTouchingMemory)
{
    const std::size_t before = rss_kib_from_proc();
    constexpr std::size_t kBytes = 64u << 20;
    auto* p = static_cast<volatile char*>(std::malloc(kBytes));
    ASSERT_NE(p, nullptr);
    for (std::size_t off = 0; off < kBytes; off += 4096) p[off] = 1;   // первое касание — page fault, страница в RSS
    const std::size_t after = rss_kib_from_proc();
    std::free(const_cast<char*>(p));
    EXPECT_GE(after - before, 60u * 1024) << "RSS не вырос на ~64 МиБ: парсится не то поле";
}
