// Рабочий пример: чем гарантии отличаются на практике.
// Разбор — в doc/01-general-topics/13-exception-safety-guarantees.md
//
// Сборка:
//   g++ -std=c++20 -Wall -Wextra -O2 -o es_demo exception_safety_demo.cxx && ./es_demo
//   g++ -std=c++20 -g -fsanitize=address,undefined -o es_asan exception_safety_demo.cxx && ./es_asan

#include <cstdio>
#include <exception>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace {

// --- 1. Порядок разрушения при исключении из конструктора ----------------------
struct Field
{
    const char* name;
    explicit Field(const char* n) : name(n) { std::printf("      + поле %s\n", name); }
    ~Field()                                { std::printf("      - поле %s\n", name); }
};

struct Base
{
    Base()  { std::printf("      + база\n"); }
    ~Base() { std::printf("      - база\n"); }
};

struct ThrowsInBody : Base
{
    Field a{"a"};
    Field b{"b"};

    ThrowsInBody() { throw std::runtime_error("из тела конструктора"); }
    ~ThrowsInBody() { std::printf("      - ThrowsInBody (НЕ должно печататься)\n"); }
};

struct Bomb
{
    Bomb() { throw std::runtime_error("из конструктора поля"); }
};

struct ThrowsInField
{
    Field a{"a"};
    Bomb  boom;
    Field c{"c"};      // до него дело не дойдёт
};

void demo_construction()
{
    std::printf("    исключение из ТЕЛА конструктора:\n");
    try { ThrowsInBody t; } catch (const std::exception& e) { std::printf("      поймали: %s\n", e.what()); }

    std::printf("    исключение из конструктора ПОЛЯ:\n");
    try { ThrowsInField t; } catch (const std::exception& e) { std::printf("      поймали: %s\n", e.what()); }
}

// --- 2. vector::push_back: strong guarantee ------------------------------------
struct CopyThrows
{
    static inline int live       = 0;
    static inline int copies     = 0;
    static inline int throw_at   = -1;   // -1 — не бросать

    int v;

    explicit CopyThrows(int x) : v(x) { ++live; }

    CopyThrows(const CopyThrows& o) : v(o.v)
    {
        if (throw_at >= 0 && ++copies >= throw_at)
            throw std::runtime_error("копирование не удалось");
        ++live;
    }

    // Намеренно НЕ noexcept: значит move_if_noexcept выберет копирование.
    CopyThrows(CopyThrows&& o) : v(o.v) { ++live; }

    ~CopyThrows() { --live; }
};

void demo_strong()
{
    std::vector<CopyThrows> v;
    v.reserve(4);
    for (int i = 0; i < 4; ++i)
        v.emplace_back(i);

    const auto*       data_before = v.data();
    const std::size_t size_before = v.size();
    const std::size_t cap_before  = v.capacity();
    const int         live_before = CopyThrows::live;

    CopyThrows::copies   = 0;
    CopyThrows::throw_at = 3;            // упадём на третьем копировании из четырёх

    try
    {
        v.push_back(CopyThrows{99});     // capacity исчерпана -> реаллокация
        std::printf("      реаллокация прошла (не ожидалось)\n");
    }
    catch (const std::exception& e)
    {
        std::printf("      поймали: %s\n", e.what());
    }

    CopyThrows::throw_at = -1;

    std::printf("      size:     %zu -> %zu\n", size_before, v.size());
    std::printf("      capacity: %zu -> %zu\n", cap_before, v.capacity());
    std::printf("      буфер переехал? %s\n", data_before == v.data() ? "нет" : "да");
    std::printf("      живых объектов: %d -> %d\n", live_before, CopyThrows::live);

    bool intact = (v.size() == size_before);
    for (std::size_t i = 0; intact && i < v.size(); ++i)
        intact = (v[i].v == static_cast<int>(i));
    std::printf("      значения на месте? %s  <- это и есть strong guarantee\n",
                intact ? "да" : "нет");
}

// --- 3. Move-only с бросающим перемещением: гарантия падает до basic -----------
struct MoveThrows
{
    static inline int live     = 0;
    static inline int moves    = 0;
    static inline int throw_at = -1;

    int v;

    explicit MoveThrows(int x) : v(x) { ++live; }

    MoveThrows(const MoveThrows&)            = delete;   // копировать нельзя
    MoveThrows& operator=(const MoveThrows&) = delete;

    MoveThrows(MoveThrows&& o) : v(std::exchange(o.v, -1))   // и move может бросить
    {
        if (throw_at >= 0 && ++moves >= throw_at)
            throw std::runtime_error("перемещение не удалось");
        ++live;
    }

    ~MoveThrows() { --live; }
};

void demo_basic()
{
    std::vector<MoveThrows> v;
    v.reserve(4);
    for (int i = 0; i < 4; ++i)
        v.emplace_back(i);

    const std::size_t size_before = v.size();
    const int         live_before = MoveThrows::live;

    MoveThrows::moves    = 0;
    MoveThrows::throw_at = 3;

    try
    {
        v.emplace_back(99);
    }
    catch (const std::exception& e)
    {
        std::printf("      поймали: %s\n", e.what());
    }

    MoveThrows::throw_at = -1;

    std::printf("      size: %zu -> %zu, живых объектов: %d -> %d\n",
                size_before, v.size(), live_before, MoveThrows::live);

    std::printf("      значения: ");
    for (const auto& e : v)
        std::printf("%d ", e.v);
    std::printf("\n      -1 — объект, из которого уже переместили: откатить это нечем\n");
    std::printf("      вектор валиден и не течёт, но содержимое испорчено  <- basic\n");
}

// --- 4. Свой класс: copy-and-swap ----------------------------------------------
class Buffer
{
public:
    explicit Buffer(std::size_t n) : data_(new int[n]), size_(n) {}

    Buffer(const Buffer& o) : data_(new int[o.size_]), size_(o.size_)
    {
        for (std::size_t i = 0; i < size_; ++i)
            data_[i] = o.data_[i];
    }

    friend void swap(Buffer& a, Buffer& b) noexcept   // swap ОБЯЗАН быть noexcept
    {
        std::swap(a.data_, b.data_);
        std::swap(a.size_, b.size_);
    }

    // Аргумент по значению: копию делает вызывающая сторона.
    // Если копирование бросит — *this ещё не тронут, состояние прежнее.
    Buffer& operator=(Buffer o) noexcept
    {
        swap(*this, o);
        return *this;
    }

    ~Buffer() { delete[] data_; }

    std::size_t size() const noexcept { return size_; }

private:
    int*        data_ = nullptr;
    std::size_t size_ = 0;
};

// --- 5. Откат через scope guard -------------------------------------------------
// Когда «сделать всё бросающее заранее» не получается, откат оформляют RAII-объектом.
template <class F>
class ScopeGuard
{
public:
    explicit ScopeGuard(F f) : f_(std::move(f)) {}
    ~ScopeGuard() { if (active_) f_(); }

    void dismiss() noexcept { active_ = false; }

    ScopeGuard(const ScopeGuard&)            = delete;
    ScopeGuard& operator=(const ScopeGuard&) = delete;

private:
    F    f_;
    bool active_ = true;
};

void demo_scope_guard()
{
    std::vector<std::string> primary;
    std::vector<std::string> mirror;

    auto commit_two = [&](std::string a, std::string b, bool fail)
    {
        primary.push_back(std::move(a));
        ScopeGuard rollback([&] {
            primary.pop_back();                       // pop_back не бросает
            std::printf("      откат: primary вернулся к %zu элементам\n", primary.size());
        });

        if (fail)
            throw std::runtime_error("вторая половина не удалась");

        mirror.push_back(std::move(b));
        rollback.dismiss();                           // всё прошло — откат не нужен
    };

    commit_two("ok-1", "ok-2", false);
    std::printf("      успешный вызов: primary=%zu, mirror=%zu\n", primary.size(), mirror.size());

    try { commit_two("bad-1", "bad-2", true); }
    catch (const std::exception& e) { std::printf("      поймали: %s\n", e.what()); }

    std::printf("      после сбоя:     primary=%zu, mirror=%zu  <- инвариант сохранён\n",
                primary.size(), mirror.size());
}

}  // namespace

int main()
{
    std::printf("1. что разрушается, если конструктор бросил\n");
    demo_construction();

    std::printf("2. vector::push_back — strong guarantee\n");
    demo_strong();

    std::printf("3. move-only с бросающим move — basic guarantee\n");
    demo_basic();

    std::printf("4. copy-and-swap\n");
    {
        Buffer a(10), b(20);
        a = b;
        std::printf("      после присваивания size=%zu\n", a.size());
    }

    std::printf("5. откат через scope guard\n");
    demo_scope_guard();

    return 0;
}
