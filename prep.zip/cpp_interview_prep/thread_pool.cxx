// Тренажёр №3: пул потоков. Одна задача, много тестов.
//
// Вынесено из drills_mt.cxx (задача 7), потому что пул — это не «сниппет на 10 минут»,
// а полноценная вещь, которую на интервью просят написать целиком и потом
// разбирают по строчкам.
//
// Правила прежние:
//   1. Не подглядывать в doc/ и не гуглить, пока не написал свой вариант.
//   2. Проговаривать КАЖДУЮ строчку вслух.
//   3. Первый заход — 35 минут под таймер. Потом разбор. Потом СТЕРЕТЬ и написать заново.
//   4. Зелёные тесты НЕ означают корректность: гонка может не выстрелить сто раз подряд.
//      Обязательно TSan и --gtest_repeat.
//
// Сборка:
//   g++ -std=c++20 -Wall -Wextra -O2 -o thread_pool thread_pool.cxx -lgtest -lgtest_main -pthread && ./thread_pool
//
// Потом обязательно:
//   g++ -std=c++20 -g -fsanitize=thread  -o tp_tsan thread_pool.cxx -lgtest -lgtest_main -pthread && ./tp_tsan
//   g++ -std=c++20 -g -fsanitize=address,undefined -o tp_asan thread_pool.cxx -lgtest -lgtest_main -pthread && ./tp_asan
//   ./thread_pool --gtest_repeat=100 --gtest_break_on_failure
//
// Одну задачу за раз:
//   ./thread_pool --gtest_filter=ThreadPool.EveryWorkerGetsWork
//
// Второй заход (2026-09-17): submit сразу шаблонный, тесты на void/move-only — основные.
// Первая версия лежит в thread_pool_v1.cxx.
//
// Тесты написаны так, чтобы при сломанном пуле ПАДАТЬ, а не висеть: везде, где
// приходится ждать чужой прогресс, стоит дедлайн.

#include <gtest/gtest.h>

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstddef>
#include <ctime>
#include <functional>
#include <future>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <thread>
#include <type_traits>
#include <queue>
#include <unordered_set>
#include <vector>

// =====================================================================================
// Контракт, который тесты проверяют
// =====================================================================================
//   * ThreadPool(n) поднимает ровно n рабочих потоков ОДИН раз, в конструкторе.
//   * submit кладёт задачу в очередь и сразу возвращает future; вызывающий не блокируется.
//   * Задачи из очереди разбираются в порядке FIFO.
//   * Исключение из задачи не убивает воркер, а приезжает к вызывающему через future.
//   * Деструктор дожидается уже принятых задач, потом гасит потоки и join'ит их.
//   * Простаивающий пул не жжёт CPU (condition_variable, а не spin).
//
// Вслух перед тем, как писать:
//   — почему очередь хранит std::function<void()>, а не std::function<int()>;
//   — зачем packaged_task, а не promise руками (кто выставит исключение?);
//   — что обязан сделать деструктор и почему join нельзя пропустить;
//   — что произойдёт, если задача бросит, а мы завернули её в голый promise;
//   — почему std::async не заменяет пул;
//   — где здесь висит риск дедлока, если задача сама зовёт submit и get.
// =====================================================================================

class ThreadPool
{
public:
    explicit ThreadPool(unsigned threads) {
        workers_.reserve(threads);
        for(int i = 0; i < threads; ++i)
        {
            workers_.emplace_back([this]{ work(); });
        }
    }

    ~ThreadPool() {
        {
            std::lock_guard<std::mutex> lk(m_);
            stopping_ = true;
            cv_.notify_all();
        }

        for(auto& t: workers_)
        {
            t.join();
        }
    }

    ThreadPool(const ThreadPool&)            = delete;
    ThreadPool& operator=(const ThreadPool&) = delete;
    ThreadPool(ThreadPool&&)                 = delete;
    ThreadPool& operator=(ThreadPool&&)      = delete;

    // Второй заход, 2026-09-17. Первая версия сохранена в thread_pool_v1.cxx — не подглядывать.
    // Пишем сразу шаблонный submit: любой вызываемый объект, любые аргументы, future<R> включая void.
    // Пункты из вчерашнего ревью, которые должны быть закрыты в этой версии:
    //   1. submit после остановки — не пустой future;
    //   2. worker() в private;
    //   3. конструктор exception-safe (бросок std::thread на середине);
    //   4. ThreadPool(0) — осознанное решение;
    //   5. std::move из очереди, а не копия;
    //   6. notify и get_future вне мьютекса;
    //   7. лямбда с захватом по move вместо bind_front;
    //   8. ни одного warning'а на -Wall -Wextra.

    void work()
    {
        for(;;)
        {
            std::function<void()> task;
            {
                std::unique_lock<std::mutex> lk(m_);

                cv_.wait(lk, [this](){
                    return !tasks_.empty() || stopping_;
                });

                if(stopping_ && tasks_.empty())
                {
                    break;
                }

                task = tasks_.front();
                tasks_.pop();
            }
            task();
        }
    }

    template <typename F, class... Args> auto
    submit(F&& f, Args&&... args) -> std::future<std::invoke_result_t<F,Args...>>
    {
        std::lock_guard<std::mutex> lk(m_);

        if(stopping_)
        {
            // return {}; // or throw

            throw std::runtime_error("Submit call for closed thread pool");
        }

        using RetType = std::invoke_result_t<F,Args...>;

        auto task = std::make_shared<std::packaged_task<RetType()>>(
                                                                  std::bind_front(std::forward<F>(f), 
                                                                  std::forward<Args>(args)...));

        tasks_.emplace([task](){ (*task)(); });
        cv_.notify_one();

        return task->get_future();
    }

private:
    std::mutex m_;
    std::condition_variable cv_;
    std::vector<std::thread> workers_;
    std::queue<std::function<void()>> tasks_;
    bool stopping_ = false;
};

// =====================================================================================
// Вспомогательное для тестов: ждать future с дедлайном, чтобы падать, а не висеть.
// =====================================================================================
namespace
{

using Clock = std::chrono::steady_clock;

template <class T>
bool ready_within(std::future<T>& f, std::chrono::milliseconds budget)
{
    return f.wait_for(budget) == std::future_status::ready;
}

std::size_t cpu_millis_used()
{
    return static_cast<std::size_t>(1000.0 * static_cast<double>(std::clock()) / CLOCKS_PER_SEC);
}

}   // namespace

// =====================================================================================
// 1. Базовая корректность
// =====================================================================================

TEST(ThreadPool, ReturnsCorrectValues)
{
    constexpr int kTasks = 200;

    std::vector<std::future<int>> results;
    results.reserve(kTasks);

    {
        ThreadPool pool(4);
        for (int i = 0; i < kTasks; ++i) results.push_back(pool.submit([i] { return i * i; }));
    }   // деструктор обязан дождаться уже принятых задач

    long long sum = 0, expected = 0;
    for (auto& f : results) sum += f.get();
    for (int i = 0; i < kTasks; ++i) expected += 1LL * i * i;

    EXPECT_EQ(sum, expected);
}

TEST(ThreadPool, EachFutureGetsItsOwnResult)
{
    constexpr int kTasks = 500;

    ThreadPool                    pool(4);
    std::vector<std::future<int>> results;
    results.reserve(kTasks);

    for (int i = 0; i < kTasks; ++i) results.push_back(pool.submit([i] { return i; }));

    for (int i = 0; i < kTasks; ++i)
    {
        ASSERT_TRUE(ready_within(results[i], std::chrono::seconds(5))) << "задача " << i << " не доехала";
        EXPECT_EQ(results[i].get(), i) << "futures перепутаны между задачами";
    }
}

TEST(ThreadPool, NoTaskRunsTwice)
{
    constexpr int kTasks = 1000;

    std::vector<std::atomic<int>> runs(kTasks);
    for (auto& r : runs) r.store(0, std::memory_order_relaxed);

    {
        ThreadPool pool(4);
        for (int i = 0; i < kTasks; ++i)
            pool.submit([&runs, i] {
                runs[i].fetch_add(1, std::memory_order_relaxed);
                return 0;
            });
    }

    for (int i = 0; i < kTasks; ++i)
        EXPECT_EQ(runs[i].load(std::memory_order_relaxed), 1)
            << "задача " << i << " выполнена " << runs[i].load() << " раз(а)";
}

TEST(ThreadPool, ManyTasksOnSmallPool)
{
    constexpr int kTasks = 20000;

    std::atomic<long long> sum{0};
    {
        ThreadPool pool(2);
        for (int i = 0; i < kTasks; ++i)
            pool.submit([&sum, i] {
                sum.fetch_add(i, std::memory_order_relaxed);
                return 0;
            });
    }

    EXPECT_EQ(sum.load(), 1LL * kTasks * (kTasks - 1) / 2);
}

// =====================================================================================
// 2. Что потоки действительно есть и их ровно столько, сколько просили
// =====================================================================================

TEST(ThreadPool, TasksRunOnWorkerThreads)
{
    const std::thread::id main_id = std::this_thread::get_id();

    ThreadPool pool(2);
    auto       f = pool.submit([main_id] { return std::this_thread::get_id() == main_id ? 0 : 1; });

    ASSERT_TRUE(ready_within(f, std::chrono::seconds(5)));
    EXPECT_EQ(f.get(), 1) << "задача не выполнилась на чужом потоке: либо это вызов прямо в submit, "
                             "либо задача вообще не запускалась";
}

TEST(ThreadPool, SpawnsExactlyRequestedThreadCount)
{
    constexpr unsigned kThreads = 3;
    constexpr int      kTasks   = 2000;

    std::mutex                          m;
    std::unordered_set<std::thread::id> seen;

    {
        ThreadPool pool(kThreads);
        for (int i = 0; i < kTasks; ++i)
            pool.submit([&] {
                std::lock_guard lock(m);
                seen.insert(std::this_thread::get_id());
                return 0;
            });
    }

    EXPECT_LE(seen.size(), kThreads) << "потоков больше, чем просили: поток на задачу вместо пула?";
    EXPECT_GE(seen.size(), 1u);
}

TEST(ThreadPool, EveryWorkerGetsWork)
{
    // Рандеву: каждая из kThreads задач приходит и ждёт остальных. Если пул поднял
    // меньше потоков, чем обещал, — дедлайн истечёт и тест упадёт, а не повиснет.
    constexpr unsigned kThreads = 4;

    std::mutex              m;
    std::condition_variable cv;
    unsigned                arrived = 0;

    ThreadPool                    pool(kThreads);
    std::vector<std::future<int>> fs;

    for (unsigned t = 0; t < kThreads; ++t)
        fs.push_back(pool.submit([&] {
            std::unique_lock lock(m);
            ++arrived;
            cv.notify_all();
            const bool all = cv.wait_for(lock, std::chrono::seconds(3), [&] { return arrived == kThreads; });
            return all ? 1 : 0;
        }));

    int together = 0;
    for (auto& f : fs)
    {
        ASSERT_TRUE(ready_within(f, std::chrono::seconds(5))) << "воркеров меньше, чем заявлено";
        together += f.get();
    }

    EXPECT_EQ(together, static_cast<int>(kThreads)) << "не все воркеры работали одновременно";
}

TEST(ThreadPool, TasksRunConcurrently)
{
    constexpr auto kSleep = std::chrono::milliseconds(150);

    std::atomic<int> ran{0};

    const auto start = Clock::now();
    {
        ThreadPool pool(4);
        for (int i = 0; i < 4; ++i)
            pool.submit([kSleep, &ran] {
                std::this_thread::sleep_for(kSleep);
                ran.fetch_add(1, std::memory_order_relaxed);
                return 0;
            });
    }
    const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now() - start);

    ASSERT_EQ(ran.load(), 4) << "задачи не выполнились вовсе — мерить нечего";
    EXPECT_GE(elapsed.count(), kSleep.count()) << "четыре спящие задачи уложились в " << elapsed.count()
                                               << " мс — sleep не выполнялся";
    EXPECT_LT(elapsed.count(), 4 * kSleep.count()) << "четыре задачи по " << kSleep.count()
                                                   << " мс заняли " << elapsed.count()
                                                   << " мс — похоже на последовательное выполнение";
}

// =====================================================================================
// 3. Порядок, исключения, живучесть воркера
// =====================================================================================

TEST(ThreadPool, SingleThreadPoolKeepsFifoOrder)
{
    constexpr int kTasks = 100;

    std::mutex       m;
    std::vector<int> order;

    {
        ThreadPool pool(1);
        for (int i = 0; i < kTasks; ++i)
            pool.submit([&, i] {
                std::lock_guard lock(m);
                order.push_back(i);
                return 0;
            });
    }

    ASSERT_EQ(order.size(), static_cast<std::size_t>(kTasks));
    for (int i = 0; i < kTasks; ++i)
        ASSERT_EQ(order[static_cast<std::size_t>(i)], i) << "очередь не FIFO (LIFO? стек вместо deque?)";
}

TEST(ThreadPool, ExceptionTravelsThroughFuture)
{
    ThreadPool pool(2);
    auto       f = pool.submit([]() -> int { throw std::runtime_error("boom"); });

    ASSERT_TRUE(ready_within(f, std::chrono::seconds(5))) << "исключение проглочено, future не готов";
    EXPECT_THROW(
        {
            try
            {
                (void)f.get();
            }
            catch (const std::runtime_error& e)
            {
                EXPECT_STREQ(e.what(), "boom");
                throw;
            }
        },
        std::runtime_error);
}

TEST(ThreadPool, WorkerSurvivesThrowingTask)
{
    ThreadPool pool(1);   // ровно один воркер: если он умрёт, следующая задача не выполнится

    auto bad = pool.submit([]() -> int { throw std::runtime_error("boom"); });
    ASSERT_TRUE(ready_within(bad, std::chrono::seconds(5)));
    EXPECT_ANY_THROW((void)bad.get());

    auto good = pool.submit([] { return 42; });
    ASSERT_TRUE(ready_within(good, std::chrono::seconds(5))) << "воркер умер вместе с исключением";
    EXPECT_EQ(good.get(), 42);
}

TEST(ThreadPool, ManyThrowingTasksDoNotKillPool)
{
    constexpr int kTasks = 200;

    ThreadPool                    pool(4);
    std::vector<std::future<int>> fs;
    fs.reserve(kTasks);

    for (int i = 0; i < kTasks; ++i)
        fs.push_back(pool.submit([i]() -> int {
            if (i % 2 == 0) throw std::runtime_error("odd one out");
            return i;
        }));

    int survived = 0;
    for (int i = 0; i < kTasks; ++i)
    {
        ASSERT_TRUE(ready_within(fs[static_cast<std::size_t>(i)], std::chrono::seconds(5)));
        if (i % 2 == 0)
            EXPECT_ANY_THROW((void)fs[static_cast<std::size_t>(i)].get());
        else
        {
            EXPECT_EQ(fs[static_cast<std::size_t>(i)].get(), i);
            ++survived;
        }
    }
    EXPECT_EQ(survived, kTasks / 2);
}

// =====================================================================================
// 4. Жизненный цикл: деструктор, пустой пул, простой
// =====================================================================================

TEST(ThreadPool, DestructorDrainsAcceptedTasks)
{
    constexpr int kTasks = 300;

    std::atomic<int> done{0};
    {
        ThreadPool pool(4);
        for (int i = 0; i < kTasks; ++i)
            pool.submit([&done] {
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
                done.fetch_add(1, std::memory_order_relaxed);
                return 0;
            });
    }   // выход из скоупа — деструктор

    EXPECT_EQ(done.load(), kTasks) << "деструктор выбросил задачи из очереди вместо того, чтобы их доделать";
}

TEST(ThreadPool, EmptyPoolConstructsAndDestructs)
{
    for (int i = 0; i < 20; ++i)
    {
        ThreadPool pool(4);
        (void)pool;
    }   // если конструктор/деструктор ловят дедлок или пропускают join — тест повиснет или упадёт под TSan
    SUCCEED();
}

TEST(ThreadPool, ZeroSizedPoolDoesNotHang)
{
    // Договорённость: сколько потоков поднимать, если попросили 0? Твой ответ должен быть
    // осознанным — либо поднимать минимум один, либо задокументировать, что submit тогда
    // запрещён. Тест требует, чтобы конструктор и деструктор просто отработали.
    ThreadPool pool(0);
    (void)pool;
    SUCCEED();
}

TEST(ThreadPool, IdlePoolDoesNotBurnCpu)
{
    const std::size_t before = cpu_millis_used();
    {
        ThreadPool pool(4);
        std::this_thread::sleep_for(std::chrono::milliseconds(300));
    }
    const std::size_t spent = cpu_millis_used() - before;

    EXPECT_LT(spent, 60u) << "простой пул сжёг " << spent
                          << " мс CPU за 300 мс — воркеры крутятся в цикле вместо cv.wait";
}

// =====================================================================================
// 5. Давление со стороны вызывающих
// =====================================================================================

TEST(ThreadPool, ConcurrentSubmitFromManyThreads)
{
    constexpr int kProducers = 8;
    constexpr int kPerThread = 500;

    std::atomic<long long> sum{0};
    {
        ThreadPool               pool(4);
        std::vector<std::thread> producers;

        for (int p = 0; p < kProducers; ++p)
            producers.emplace_back([&pool, &sum] {
                for (int i = 0; i < kPerThread; ++i)
                    pool.submit([&sum] {
                        sum.fetch_add(1, std::memory_order_relaxed);
                        return 0;
                    });
            });

        for (auto& t : producers) t.join();
    }

    EXPECT_EQ(sum.load(), 1LL * kProducers * kPerThread) << "часть submit потерялась в гонке на очереди";
}

TEST(ThreadPool, SubmitFromInsideTask)
{
    // Классическая ловушка: задача сама кладёт задачу и ждёт её результат.
    // На пуле из 2 потоков это должно работать. Вслух: почему на пуле из 1 потока
    // такой код повиснет и что с этим делают в реальных пулах (work stealing,
    // запуск задачи прямо в ждущем потоке, запрет на вложенный get).
    ThreadPool pool(2);

    auto outer = pool.submit([&pool] {
        auto inner = pool.submit([] { return 21; });
        if (inner.wait_for(std::chrono::seconds(3)) != std::future_status::ready) return -1;
        return inner.get() * 2;
    });

    ASSERT_TRUE(ready_within(outer, std::chrono::seconds(5))) << "вложенный submit заклинил пул";
    EXPECT_EQ(outer.get(), 42);
}

TEST(ThreadPool, SubmitReturnsWithoutWaiting)
{
    // submit обязан быть быстрым: он кладёт в очередь и уходит, а не ждёт выполнения.
    ThreadPool pool(1);

    auto       blocker = pool.submit([] {
        std::this_thread::sleep_for(std::chrono::milliseconds(300));
        return 0;
    });

    const auto start = Clock::now();
    auto       quick = pool.submit([] { return 7; });
    const auto spent = std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now() - start);

    EXPECT_LT(spent.count(), 100) << "submit ждал освобождения воркера (" << spent.count() << " мс)";

    ASSERT_TRUE(ready_within(quick, std::chrono::seconds(5)));
    EXPECT_EQ(quick.get(), 7);
    (void)blocker.get();
}

// =====================================================================================
// 6. Шаблонный submit: void, move-only результат, move-only вызываемый объект
// =====================================================================================
TEST(ThreadPool, GenericSubmitHandlesVoid)
{
    std::atomic<bool> ran{false};

    ThreadPool pool(2);
    auto       f = pool.submit([&ran] { ran.store(true, std::memory_order_relaxed); });

    static_assert(std::is_same_v<decltype(f), std::future<void>>, "submit должен вернуть future<void>");
    ASSERT_TRUE(ready_within(f, std::chrono::seconds(5)));
    f.get();
    EXPECT_TRUE(ran.load());
}

TEST(ThreadPool, GenericSubmitHandlesMoveOnlyResult)
{
    ThreadPool pool(2);
    auto       f = pool.submit([] { return std::make_unique<int>(99); });

    ASSERT_TRUE(ready_within(f, std::chrono::seconds(5)));
    auto p = f.get();
    ASSERT_NE(p, nullptr);
    EXPECT_EQ(*p, 99);
}

TEST(ThreadPool, GenericSubmitHandlesMoveOnlyCallableAndArgs)
{
    // Вслух: почему std::function<void()> здесь уже не годится и чем её заменяют
    // (тип-стёртая обёртка с move-only вызовом или std::move_only_function из C++23).
    ThreadPool pool(2);

    auto captured = std::make_unique<int>(5);
    auto f        = pool.submit([captured = std::move(captured)](int mult) { return *captured * mult; }, 8);

    ASSERT_TRUE(ready_within(f, std::chrono::seconds(5)));
    EXPECT_EQ(f.get(), 40);
}

