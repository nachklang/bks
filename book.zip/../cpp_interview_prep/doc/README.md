# C++ Interview Prep — учебник

Материалы для подготовки к техническому интервью на позицию Senior C++ Developer
(ориентир — интервью в WorldQuant).

## С чего начать

[System design interview preparation (English)](04-system-design/README.md)
— подробное руководство для system design интервью: требования, оценки нагрузки,
API, хранение, consistency, транзакции, масштабирование, надёжность и безопасность;
диаграммы, вопросы с ответами, план подготовки и чеклист перед интервью.

[Design Google Drive (English)](04-system-design/01-design-google-drive.md)
— полный разбор файлового хранилища и синхронизации: resumable uploads, версии,
offline-конфликты, change feeds, sharing, revocation, quota, garbage collection,
multi-region recovery; архитектурные и sequence-диаграммы, сценарии сбоев и упражнения.

[mmap: a complete practical guide (English)](01-general-topics/23-mmap-complete-guide.md)
— подробное руководство от устройства памяти до практики C/C++, с вопросами и упражнениями.

[Memory ordering and memory barriers (English)](01-general-topics/24-memory-order-and-barriers-complete-guide.md)
— подробный разбор модели памяти C++, атомиков и барьеров, с доказательствами,
11 полными программами, 60 вопросами и 12 упражнениями.

[Memory pages (English)](01-general-topics/25-memory-pages-complete-guide.md)
— виртуальные страницы, физическая память, page tables, TLB, faults, swap и huge pages;
4 программы C++20, 40 вопросов и 8 упражнений.

**[PLAN-round-2.md](PLAN-round-2.md) — текущий план подготовки ко второму раунду**
(что в какой день, приоритеты, что известно про стиль команды).

## Структура

- [`01-general-topics/`](01-general-topics/README.md) — общие темы: язык, память, STL,
  concurrency, шаблоны, производительность, quant-специфика. Файлы создаются по ходу
  вопросов в разговоре; в README лежит план-оглавление того, что стоит закрыть.
- [`02-interview-questions/`](02-interview-questions/README.md) — конкретные вопросы
  формата «дан код — что не так / разбери». 11 основных вопросов (первый — реальный
  слитый код с интервью) плюс 2 дополнительных.

- [`03-orderbook/`](03-orderbook/) — предметная область: [ТЗ на часовую задачу
  с order book](03-orderbook/01-interview-task-spec.md) и [как работает настоящий
  биржевой стакан](03-orderbook/02-how-real-orderbook-works.md).

- [`04-system-design/`](04-system-design/README.md) — подготовка к system design
  интервью уровня Senior и глубже: [основное руководство](04-system-design/README.md)
  и [подробный дизайн Google Drive](04-system-design/01-design-google-drive.md).

- [`01-general-topics/15-vtable-layout.md`](01-general-topics/15-vtable-layout.md) —
  раскладка vtable, thunk'и при множественном наследовании, виртуальные базы
  (спутник — `../vtable_demo.cxx`).
- [`01-general-topics/16-allocators.md`](01-general-topics/16-allocators.md) — аллокаторы:
  цена malloc и page fault, счёт аллокаций контейнеров, `allocator_traits` и POCMA,
  arena-аллокатор, `std::pmr`, замена `operator new`, glibc изнутри, low-latency практика
  (спутник — `../allocator_demo.cxx`).
- [`01-general-topics/17-linux-for-cpp.md`](01-general-topics/17-linux-for-cpp.md) — Linux
  для C++: процессы и сигналы, память и page fault, epoll/io_uring, сеть и multicast,
  планировщик и affinity, время через vDSO, IPC, инструменты; пять цепочек «что происходит,
  когда» и 30 вопросов с ответами (тренажёр — `../linux_drills.cxx`).
- [`01-general-topics/18-std-string-internals.md`](01-general-topics/18-std-string-internals.md) —
  `std::string` изнутри: раскладка 32 байт и SSO на 15, что стоит аллокации, рост ×2,
  инвалидация при move, COW старого ABI, чек-лист «string против vector»
  (спутник — `../string_demo.cxx`).
- [`01-general-topics/19-virtual-call-disassembly.md`](01-general-topics/19-virtual-call-disassembly.md) —
  виртуальный вызов в машинном коде: vtable из `-S`, `mov rax,[rdi]; call [rax+8]`,
  девиртуализация, два деструктора, tail padding (спутник — `../virtual_call_asm.cxx`).
- [`01-general-topics/20-file-io-read-stdio-iostream-mmap.md`](01-general-topics/20-file-io-read-stdio-iostream-mmap.md) —
  чтение файлов четырьмя способами: `read`, `FILE*`, `ifstream`, `mmap`; определения всех
  понятий, схемы слоёв и копий, буферы и замеры, запись и долговечность, `SIGBUS`, `O_DIRECT`
  (спутник — `../file_io_demo.cxx`).
- [`01-general-topics/21-inheritance-and-multiple-inheritance.md`](01-general-topics/21-inheritance-and-multiple-inheritance.md) —
  наследование и МН с определением каждого понятия и объяснением каждого правила: раскладка,
  сдвиг указателя, `vptr` и thunk, ромб и виртуальные базы, касты, 8 задач «что напечатается»
  (спутник — `../inheritance_demo.cxx`).
- [`01-general-topics/22-memory-order-and-fences.md`](01-general-topics/22-memory-order-and-fences.md) —
  `std::memory_order` и барьеры с определением каждого понятия и объяснением каждого правила:
  модель C++ по шагам, шесть порядков, x86 TSO и машинный код, litmus-тесты на живых потоках,
  CAS, паттерны (seqlock, SPSC, refcount), TSan, замеры цен
  (спутник — `../memory_order_demo.cxx`).

- [`reference/`](reference/README.md) — справочные **корректные** реализации того,
  что в других разделах даётся как задача. Сейчас там разобранный по косточкам
  `shared_ptr` (парная задача — `../shared_ptr_fix/`), [шпаргалка по DCLP, ABA
  и reclamation](reference/lockfree-cheatsheet.md) и [личный чеклист
  ошибок](reference/my-mistakes.md) — читать перед интервью.

## Формат вопроса во втором разделе

Файлы 02–13 рассчитаны на самостоятельное решение: разбор спрятан под спойлер.

```
## Вопрос                     — постановка + код с намеренно заложенными багами
<details>Разбор</details>     — открываешь ПОСЛЕ того, как ответил сам
## На что смотрит интервьюер
## Чеклист для устного ответа
```

Багованные блоки помечены `// Пример намеренно сломан.`; в секции «Вопрос» подсказок нет.
Файл 01 (слитый код с интервью) — референсный, там разбор идёт сразу, без спойлера.

Структура вопросов по слоям: A — язык и STL (02–06), B — конкурентность (07–10),
C — quant/performance (11); 12–13 — дополнительные.

## Что известно о самом интервью

Из наблюдений за реальным кандидатом (см. [вопрос 01](02-interview-questions/01-leaked-interview-code-vector-remove-and-set-capitalize.md)):
вопросы **практические и на идиомы STL**, задаются в формате «напиши код прямо сейчас»,
и после кода обязательно идёт **«объясни, как это работает»**. Интервьюер целенаправленно
проверяет, понимаешь ли ты каждую написанную строчку, а не воспроизводишь ли заученный
ответ. Отсюда главная стратегия подготовки:

> Уметь объяснить **каждую строчку** своего решения и **сам** называть его слабые места.

Практические следствия:
- Уточняй условия до кода (какой контейнер, важен ли порядок, возможны ли дубликаты,
  один поток или несколько).
- Начинай с простого корректного решения, потом оптимизируй вслух — это выглядит как
  работа инженера, а не как вставка готового ответа.
- Всегда называй сложность и инвалидацию итераторов.
- Проговаривай trade-off'ы low-latency: аллокации, кэш, атомики, ветвления.

## Практика кода

Тренировочные сниппеты живут в `../ds_snippets.cxx` (gtest). Сниппеты из разборов
удобно копировать туда и прогонять — особенно те, что демонстрируют UB и разницу
между debug и `-O2`.

Полезные флаги для проверки примеров:

```
g++ -std=c++20 -Wall -Wextra -O2 -fsanitize=address,undefined ...
g++ -std=c++20 -Wall -Wextra -O2 -fsanitize=thread ...
```
