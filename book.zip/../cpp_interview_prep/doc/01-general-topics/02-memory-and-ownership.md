# Память и владение

Зачем это на интервью: владение — единственная тема, где C++ действительно отличается от других языков, поэтому её проверяют всегда. Формат обычно такой: «напиши свой unique_ptr», «что лежит в shared_ptr и сколько он стоит», «почему make_shared может быть плохой идеей», «как убрать аллокации из hot path». В quant-контексте почти сразу переходят к аллокаторам, arena/pool и выравниванию под кэш-линию — это уже про latency, а не про безопасность.

---

## 1. Три вида хранилища

| | Стек | Куча | Static/global |
|---|---|---|---|
| Выделение | вычитание из `rsp`, 1 инструкция | `malloc`: ~20–100 нс (быстрый путь tcache/thread cache) | компоновщик, 0 в рантайме |
| Освобождение | восстановление `rsp` | `free`, сопоставимо | конец программы |
| Размер | ограничен (обычно 8 МБ, `ulimit -s`) | ограничен RAM | фиксирован в бинаре |
| Локальность | отличная (верх стека всегда в L1) | зависит от фрагментации | хорошая |
| Потокобезопасность | у каждого потока свой | требует синхронизации внутри аллокатора | требует ручной |

Вывод для hot path: аллокация в куче стоит не столько инструкций, сколько непредсказуемости — glibc malloc обычно 20–50 нс, но при исчерпании thread cache уходит в arena под локом, а при росте — в `mmap`/`brk`, то есть syscall и потенциально сотни микросекунд. Именно хвост распределения (p99.9) убивает торговую систему, а не среднее.

### `operator new` vs `new`-выражение vs placement new

```cpp
// 1) new-выражение: аллокация + конструирование
T* p = new T(args);

// 2) operator new: только сырая память (можно перегружать глобально и на класс)
void* raw = ::operator new(sizeof(T), std::align_val_t{alignof(T)});

// 3) placement new: только конструирование в готовой памяти
T* q = new (raw) T(args);
q->~T();                        // деструктор вызывается ВРУЧНУЮ
::operator delete(raw, std::align_val_t{alignof(T)});
```
Aligned `operator new` с `std::align_val_t` появился в C++17; до него `new` не гарантировал выравнивание больше `__STDCPP_DEFAULT_NEW_ALIGNMENT__` (обычно 16), и `alignas(64)` типы могли быть выделены криво.

**Где placement new реально нужен:** пулы и арены, `std::optional`/`std::variant`/`small_vector` внутри, in-place десериализация market data, `std::vector` (реализован через `allocator::construct`).

C++17 добавил `std::launder`, C++20 — `std::construct_at`/`std::destroy_at` (constexpr-совместимые обёртки). Ловушка со `std::launder`: после placement new в память, где раньше жил объект с const-полями или ссылками, старый указатель формально нельзя переиспользовать — нужен `std::launder` или значение, возвращённое placement new.

---

## 2. `unique_ptr`

**Определение вслух.** Move-only владелец одного объекта, у которого `sizeof` равен размеру указателя, если deleter — пустой тип; вызывает deleter в деструкторе; накладных расходов относительно ручного `new`/`delete` нет.

```cpp
auto p = std::make_unique<Order>(id, px);          // C++14
auto arr = std::make_unique<double[]>(1024);       // спец. для массивов, delete[]
```

**Custom deleter и sizeof — обязательный вопрос:**

```cpp
// 1) Тип-функтор без состояния: EBO, sizeof == 8
struct FileCloser { void operator()(std::FILE* f) const noexcept { std::fclose(f); } };
std::unique_ptr<std::FILE, FileCloser> f1{std::fopen("a", "r")};
static_assert(sizeof(f1) == sizeof(void*));

// 2) Указатель на функцию: sizeof == 16 (указатель на объект + указатель на функцию)
std::unique_ptr<std::FILE, decltype(&std::fclose)> f2{std::fopen("a","r"), &std::fclose};
static_assert(sizeof(f2) == 2 * sizeof(void*));

// 3) Лямбда без захвата: тоже пустой тип, sizeof == 8
auto del = [](std::FILE* f){ std::fclose(f); };
std::unique_ptr<std::FILE, decltype(del)> f3{std::fopen("a","r"), del};
```
Почему: deleter хранится **по значению** в `unique_ptr`; для пустого класса срабатывает empty base optimization (в реализациях — через `std::tuple`/compressed pair). Лямбда с захватом или `std::function` раздувают объект и убивают инлайнинг deleter'а.

**Pimpl и неполный тип — классическая ловушка.**
```cpp
// header
class Engine {
    struct Impl;
    std::unique_ptr<Impl> impl_;
public:
    Engine();
    ~Engine();          // ОБЯЗАТЕЛЬНО объявить здесь и определить в .cpp
};
```
Если не объявить деструктор, компилятор сгенерирует его в точке использования, где `Impl` неполный, и `default_delete` не сможет вызвать деструктор — ошибка компиляции («invalid application of sizeof to incomplete type»). То же касается move-операций.

**`release()` vs `reset()`.** `release()` отдаёт владение и возвращает сырой указатель (после него удалять должны вы), `reset()` удаляет текущий и берёт новый. `get()` не меняет владения.

**Как выглядит свой unique_ptr (частая задача на доске):**
```cpp
template <class T>
class UniquePtr {
    T* p_ = nullptr;
public:
    UniquePtr() noexcept = default;
    explicit UniquePtr(T* p) noexcept : p_(p) {}
    UniquePtr(UniquePtr&& o) noexcept : p_(std::exchange(o.p_, nullptr)) {}
    UniquePtr& operator=(UniquePtr&& o) noexcept {
        if (this != &o) { delete p_; p_ = std::exchange(o.p_, nullptr); }
        return *this;
    }
    UniquePtr(const UniquePtr&) = delete;
    UniquePtr& operator=(const UniquePtr&) = delete;
    ~UniquePtr() { delete p_; }

    T& operator*()  const noexcept { return *p_; }
    T* operator->() const noexcept { return p_; }
    T* get()        const noexcept { return p_; }
    explicit operator bool() const noexcept { return p_ != nullptr; }
    T* release() noexcept { return std::exchange(p_, nullptr); }
    void reset(T* p = nullptr) noexcept { delete std::exchange(p_, p); }
};
```
Что здесь обязательно проговорить: move-операции `noexcept`, self-assignment проверен, `operator bool` explicit (иначе `p1 == p2` будет сравнивать bool'ы), деструктор не бросает.

---

## 3. `shared_ptr`

**Устройство.** `shared_ptr` — это ДВА указателя (16 байт): на объект и на control block. Control block содержит: strong count, weak count, deleter, allocator и (при make_shared) сам объект.

```
shared_ptr:  [ptr to T][ptr to control block]
control block: [strong][weak][deleter][allocator]( [T object] при make_shared )
```

**`make_shared` vs `shared_ptr<T>(new T)` — таблица:**

| | `make_shared<T>(...)` | `shared_ptr<T>(new T)` |
|---|---|---|
| Аллокаций | 1 (объект и control block вместе) | 2 |
| Локальность | объект рядом со счётчиком — хорошо | два разных места |
| Освобождение памяти объекта | только когда умрёт последний **weak_ptr** | сразу при обнулении strong count |
| Custom deleter | невозможен | возможен |
| Exception safety | безопасно | до C++17 возможна утечка в `f(shared_ptr<T>(new T), g())` |
| `new` с приватным конструктором | не работает (make_shared не friend) | работает |
| Использует ли `operator new` класса | нет, использует глобальный | да |

Практический вывод: `make_shared` по умолчанию, но если объект большой, а weak_ptr на него живут долго (кэши, observer'ы), то `make_shared` держит весь блок памяти в живых ради двух счётчиков — тогда лучше два раздельных аллока.

**Цена atomic refcount.** Копирование `shared_ptr` — это `lock xadd` на strong count: 20–40 тактов без контенции и 100–500+ при конкуренции нескольких ядер за одну кэш-линию. Плюс проверка weak count и ветвление при разрушении. Отсюда правило hot path: **передавайте `const shared_ptr<T>&` или сырой `T*`/`T&`, а не `shared_ptr<T>` по значению**, если не передаёте владение. Часто спрашивают: «сколько стоит скопировать shared_ptr в цикле на 4 потоках?» — правильный ответ содержит слова «контенция за кэш-линию control block».

Тонкость: атомарен **счётчик**, а не сам объект `shared_ptr`. Копировать один `shared_ptr` из разных потоков безопасно, а одновременно `reset` в одном и читать в другом — гонка. С C++20 есть `std::atomic<std::shared_ptr<T>>`.

**`weak_ptr` и `lock()`.**
```cpp
std::weak_ptr<Session> w = s;
if (auto sp = w.lock()) {     // атомарно: если strong != 0, инкремент и вернуть shared_ptr
    sp->send(msg);
}
```
`weak_ptr` не продлевает жизнь объекта, но продлевает жизнь **control block**. `expired()` без `lock()` бесполезен в многопоточном коде (TOCTOU: между проверкой и использованием объект умрёт).

**Циклические ссылки.** Два объекта, ссылающиеся друг на друга через `shared_ptr`, никогда не обнулят счётчики — утечка, которую не поймает ни один компилятор. Лечение: одно направление делать `weak_ptr` (обычно «ребёнок → родитель», «наблюдатель → наблюдаемое»).

```cpp
struct Node {
    std::vector<std::shared_ptr<Node>> children;
    std::weak_ptr<Node> parent;      // не shared_ptr!
};
```

**`enable_shared_from_this`.**
```cpp
class Session : public std::enable_shared_from_this<Session> {
public:
    void start() {
        auto self = shared_from_this();      // продлевает жизнь на время async-операции
        async_read([self](auto&&...){ self->on_data(); });
    }
};
```
Как работает: базовый класс хранит `weak_ptr<Session>`; конструктор `shared_ptr` обнаруживает наследование (через SFINAE) и инициализирует этот weak_ptr. Отсюда ловушки:
- **`shared_from_this()` в конструкторе — исключение `bad_weak_ptr`**: weak_ptr ещё не инициализирован, потому что shared_ptr ещё не создан.
- **Объект должен быть создан через `shared_ptr`**: на объекте на стеке или под `unique_ptr` `shared_from_this()` бросит.
С C++17 есть `weak_from_this()`, который не бросает.

**Aliasing constructor.**
```cpp
struct Book { std::vector<Level> levels; };
std::shared_ptr<Book> book = std::make_shared<Book>();
std::shared_ptr<Level> lvl(book, &book->levels[0]);   // владеет Book, указывает на Level
```
Хранит владение одним control block, а указывает на другой адрес. Применение: раздать указатель на подобъект, не разрушая владение целым; или сделать «нулевой» shared_ptr для передачи не-владеющего указателя в API, требующее shared_ptr (`shared_ptr<T>(shared_ptr<void>{}, ptr)`).

**Type erasure у deleter'а.** `unique_ptr<T, D>` хранит тип deleter'а в своём типе (поэтому deleter влияет на `sizeof` и на совместимость типов). `shared_ptr<T>` тип deleter'а стирает — он живёт в control block за виртуальным вызовом. Плата: `shared_ptr` всегда 16 байт независимо от deleter'а, но разрушение — косвенный вызов; зато `shared_ptr<Base>` может владеть `Derived` без виртуального деструктора, потому что deleter запомнил настоящий тип:

```cpp
struct Base { };            // НЕТ виртуального деструктора
struct Derived : Base { ~Derived() { /* всё равно вызовется */ } };
std::shared_ptr<Base> p = std::make_shared<Derived>();   // корректно
std::unique_ptr<Base> q = std::make_unique<Derived>();   // UB!
```
Это редкий и любимый вопрос: shared_ptr тут «спасает», unique_ptr — нет.

---

## 4. Аллокаторы и PMR

**Классический `std::allocator<T>`** — часть типа контейнера: `vector<int>` и `vector<int, MyAlloc>` — разные типы, несовместимы в интерфейсах. Аллокатор в контейнере хранится по значению; stateless-аллокатор благодаря EBO ничего не занимает.

**PMR (C++17)** решает проблему «аллокатор в типе»: `std::pmr::vector<int>` — это `std::vector<int, std::pmr::polymorphic_allocator<int>>`, и все pmr-контейнеры имеют один тип независимо от стратегии выделения; стратегия задаётся указателем на `memory_resource` в рантайме, через виртуальные вызовы `do_allocate`/`do_deallocate`.

```cpp
#include <memory_resource>
#include <vector>

void hot_path() {
    std::byte buffer[64 * 1024];                                   // на стеке
    std::pmr::monotonic_buffer_resource pool{buffer, sizeof buffer};
    std::pmr::vector<int> v{&pool};
    v.reserve(1000);
    // Все аллокации — просто сдвиг указателя внутри buffer. Ни одного malloc.
}   // deallocate — no-op; вся память "освобождается" разрушением ресурса
```

Ресурсы, которые надо знать:
- **`monotonic_buffer_resource`** — bump-аллокатор: выделение = сдвиг указателя (~1–2 нс), освобождение — no-op, вся память возвращается разом. Идеален для «обработать один пакет market data и сбросить арену».
- **`unsynchronized_pool_resource`** — пул фиксированных блоков разных размеров, без синхронизации (один поток). Подходит, когда объекты разного размера создаются и удаляются вперемешку.
- **`synchronized_pool_resource`** — то же с мьютексом (по умолчанию используется, если явно не указать).
- **`new_delete_resource()`** — обёртка над глобальным new/delete, дефолт.
- **`null_memory_resource()`** — бросает `bad_alloc` на любую аллокацию; отличный трюк для тестов «докажи, что в hot path нет аллокаций»: подставьте его как upstream к monotonic-ресурсу с фиксированным буфером, и любой выход за буфер немедленно упадёт.

**Цена PMR.** Виртуальный вызов на аллокацию (~2–5 нс сверху) вместо инлайненного `operator new`. Но monotonic вместо malloc экономит 20–50 нс — чистый выигрыш. Плюс `pmr::vector` тащит указатель на ресурс (+8 байт) и правило propagate_on_container_move_assignment == false: **move-присваивание pmr-контейнеров с разными ресурсами копирует элементы, а не перемещает**. Это неочевидная ловушка производительности.

**Ключевая идиома low-latency: pre-allocation + arena.** Все объекты, нужные в hot path, создаются на старте; в рантайме — только переиспользование. Object pool с freelist:

```cpp
template <class T, std::size_t N>
class Pool {
    alignas(T) std::byte storage_[N * sizeof(T)];
    T* free_ = nullptr;                       // freelist через сами объекты
public:
    Pool() {
        for (std::size_t i = 0; i < N; ++i) {
            auto* slot = reinterpret_cast<T*>(storage_) + i;
            *reinterpret_cast<T**>(slot) = free_;   // храним next прямо в слоте
            free_ = slot;
        }
    }
    template <class... A>
    T* acquire(A&&... a) {
        if (!free_) return nullptr;
        T* slot = free_;
        free_ = *reinterpret_cast<T**>(slot);
        return std::construct_at(slot, std::forward<A>(a)...);   // C++20
    }
    void release(T* p) noexcept {
        std::destroy_at(p);
        *reinterpret_cast<T**>(p) = free_;
        free_ = p;
    }
};
```
Что здесь проговорить: аллокация и освобождение — O(1) без ветвлений и без syscall; freelist хранится в самих слотах, поэтому нулевой оверхед по памяти; требование `sizeof(T) >= sizeof(T*)`; строгий aliasing формально требует аккуратности (в проде — `std::launder` или union-хранилище).

---

## 5. Выравнивание, padding, `alignas`

**Определение вслух.** Выравнивание — требование, чтобы адрес объекта делился на `alignof(T)`. Компилятор вставляет padding между полями и в конец структуры, чтобы каждое поле было выровнено и чтобы массив структур сохранял выравнивание.

```cpp
struct Bad  { char a; double b; char c; };   // sizeof == 24: 1 + 7pad + 8 + 1 + 7pad
struct Good { double b; char a; char c; };   // sizeof == 16: 8 + 1 + 1 + 6pad
static_assert(alignof(Bad) == 8);
```
Правило: сортируйте поля по убыванию размера. На больших массивах структур это прямая экономия кэша: 24 → 16 байт значит, что в кэш-линию 64 байта влезает 4 объекта вместо 2.

**Ловушка с padding:** `memcmp` двух логически равных структур может вернуть неравенство из-за мусора в padding; по этой же причине `std::atomic<T>::compare_exchange` может не срабатывать для структур с дырами (сравнение побайтовое). Решение: убрать дыры или сравнивать по полям (`= default` для `operator==` в C++20 сравнивает по полям, а не побайтово — это правильно).

**`std::hardware_destructive_interference_size` / `constructive`.** Первая — минимальное расстояние между объектами, чтобы избежать false sharing (обычно 64, иногда 128); вторая — максимальный размер, при котором объекты стоит держать вместе для true sharing. В GCC они помечены предупреждением об ABI-нестабильности (`-Winterference-size`), поэтому многие проекты пишут просто `constexpr std::size_t kCacheLine = 64;`.

```cpp
struct alignas(64) Counter { std::atomic<std::uint64_t> v; };  // своя кэш-линия каждому
```

**`alignas` и аллокация.** До C++17 `new Counter` мог вернуть память с выравниванием 16 — UB при использовании. C++17 добавил aligned `operator new`. Для проверки: `alignof(std::max_align_t)` обычно 16.

---

## 6. SSO и SBO

**SSO (Small String Optimization).** `std::string` хранит короткие строки прямо в объекте, без аллокации. libstdc++: `sizeof(std::string) == 32`, влезает до 15 символов + терминатор. libc++: `sizeof == 24`, до 22 символов. MSVC: 32 байта, до 15.

Практика: строки-тикеры («AAPL», «ESZ4») никогда не аллоцируют — это главная причина, почему `std::string` в trading-коде не так страшен, как кажется. Но: SSO делает move для коротких строк равным копированию (см. moved-from state), и `std::string` всё равно на 24–32 байта раздувает структуры.

**SBO в `std::function`.** `std::function` хранит небольшие вызываемые объекты внутри себя (libstdc++: 16 байт — как раз указатель на объект + указатель на метод; libc++: 24 байта). Лямбда с захватом трёх `shared_ptr` не влезет и уйдёт в кучу.

**Почему `std::function` плоха в hot path:**
1. Возможная аллокация при захвате большого состояния.
2. Вызов — всегда косвенный (виртуальный по сути), инлайнинг невозможен: ~2–5 нс на вызов вместо нуля.
3. Type erasure убивает информацию для оптимизатора.

Альтернативы: шаблонный параметр (`template <class F> void for_each(F&& f)` — инлайнится), `function_ref`/`std::function_ref` (C++26; не владеет, 16 байт, но и не продлевает жизнь), `inplace_function` из сторонних библиотек с настраиваемым размером буфера, или простой указатель на функцию + `void* ctx`.

```cpp
// Плохо в hot path:
void process(std::function<void(const Tick&)> cb);
// Хорошо:
template <class F> void process(F&& cb);              // инлайнится
// Или, если нужен рантайм-полиморфизм без владения:
void process(void (*cb)(void*, const Tick&), void* ctx);
```

---

## Частые вопросы по теме

**В: Что делает `new` пошагово?**
О: Вызывает `operator new(size)` для сырой памяти, затем конструирует объект. Если конструктор бросает, память освобождается парным `operator delete`. `delete` — деструктор, затем `operator delete`.

**В: Чему равен `sizeof(unique_ptr)`?**
О: Размеру указателя, если deleter — пустой тип (EBO): дефолтный, функтор без состояния, лямбда без захвата. Указатель на функцию или лямбда с захватом добавляют своё состояние: 16 байт и больше.

**В: Почему в pimpl нужно объявлять деструктор в заголовке и определять в .cpp?**
О: Неявный деструктор был бы сгенерирован там, где `Impl` неполный, и `default_delete` не смог бы вызвать его деструктор. Объявление переносит генерацию в .cpp, где тип полный.

**В: Из чего состоит `shared_ptr` и сколько он весит?**
О: 16 байт: указатель на объект и указатель на control block. Control block хранит strong count, weak count, deleter и аллокатор (при make_shared — ещё и сам объект).

**В: `make_shared` или `shared_ptr(new T)`?**
О: `make_shared` — одна аллокация вместо двух и лучшая локальность, но объект нельзя освободить, пока жив хотя бы один `weak_ptr`, и нельзя задать custom deleter. Для больших объектов с долгоживущими weak_ptr берите раздельную форму.

**В: Потокобезопасен ли `shared_ptr`?**
О: Атомарен счётчик, а не объект. Копировать один и тот же `shared_ptr` из разных потоков можно; одновременно писать в него (`reset`) и читать — гонка. С C++20 есть `std::atomic<std::shared_ptr<T>>`.

**В: Сколько стоит копирование `shared_ptr`?**
О: Атомарный инкремент — 20–40 тактов без контенции, до сотен при конкуренции нескольких ядер за кэш-линию control block. Поэтому в hot path передают по `const&` или сырым указателем.

**В: Что такое aliasing constructor?**
О: Конструктор `shared_ptr(other, ptr)`: владение берётся от `other`, а хранимый указатель — произвольный `ptr`. Позволяет отдать указатель на подобъект, сохранив владение целым, или сделать не-владеющий shared_ptr.

**В: Почему `shared_from_this()` в конструкторе бросает?**
О: `enable_shared_from_this` хранит `weak_ptr`, который инициализируется конструктором `shared_ptr` — то есть уже после того, как конструктор объекта отработал. Внутри конструктора он пуст, `lock()` даёт `bad_weak_ptr`.

**В: Как ломать циклические ссылки?**
О: Одно из направлений делать `weak_ptr` — обычно обратную ссылку (ребёнок на родителя, наблюдатель на субъект). `shared_ptr` не имеет сборщика циклов.

**В: Почему `shared_ptr<Base>` работает без виртуального деструктора, а `unique_ptr<Base>` — нет?**
О: `shared_ptr` стирает тип deleter'а в control block, и deleter помнит настоящий тип `Derived`. У `unique_ptr` deleter — часть типа, и `default_delete<Base>` вызовет `delete` на `Base*`, что при невиртуальном деструкторе UB.

**В: Что такое PMR и зачем?**
О: Полиморфные аллокаторы (C++17): стратегия выделения задаётся указателем на `memory_resource` в рантайме, а не типом. Все `pmr::vector<int>` одного типа. Позволяет подставить арену/пул в hot path без переписывания сигнатур.

**В: Что даёт `monotonic_buffer_resource`?**
О: Bump-аллокацию: выделение — сдвиг указателя (~1–2 нс), освобождение — no-op, память возвращается разом при разрушении ресурса. Идеально для «выделили под обработку пакета, сбросили».

**В: Как доказать, что в hot path нет аллокаций?**
О: Подставить `std::pmr::null_memory_resource()` как upstream (любая аллокация бросит), или перегрузить глобальный `operator new` с ассертом, или в тесте считать вызовы malloc через LD_PRELOAD/hook.

**В: Что такое false sharing и при чём тут alignas?**
О: Две независимые переменные в одной 64-байтной кэш-линии; протокол когерентности гоняет линию между ядрами. `alignas(std::hardware_destructive_interference_size)` разводит их по разным линиям.

**В: Что такое SSO и как оно влияет на move?**
О: Короткая строка хранится в теле объекта (libstdc++ до 15 символов при sizeof 32). Move такой строки — фактически копия, и moved-from строка может остаться непустой.

**В: Почему `std::function` не место в hot path?**
О: Косвенный вызов без инлайнинга (~2–5 нс), возможная аллокация при захвате больше SBO-буфера (16–24 байта), потеря информации для оптимизатора. Замена — шаблонный параметр или function_ref.

---

## Что сказать, если не знаешь

1. **Рассуждайте от вопроса «кто и когда освобождает».** Любой вопрос про владение сводим вслух к трём: кто владеет ресурсом, сколько владельцев может быть одновременно, и что произойдёт, если владелец умрёт раньше пользователя. Один владелец → `unique_ptr`; несколько с неизвестным порядком смерти → `shared_ptr`; пользователь не владеет и обязан быть короче по времени жизни → сырой указатель или ссылка.

2. **Оценивайте стоимость в терминах «аллокация / атомик / промах кэша».** Если не помните точных чисел, скажите структуру ответа: «Здесь одна аллокация — десятки наносекунд, один атомарный инкремент — десятки тактов, и один вероятный промах кэша — около сотни наносекунд. Доминирует промах». Это правильный порядок мышления, и он важнее точных цифр.

3. **Про незнакомый API признавайтесь и предлагайте эквивалент.** «Точный интерфейс `polymorphic_allocator` я не помню наизусть, но идея PMR — вынести стратегию из типа в рантайм-указатель; я бы то же самое собрал вручную через свой arena-аллокатор с интерфейсом allocate/deallocate и передавал его ссылкой». Демонстрация идеи важнее заученной сигнатуры.

---

## Ключевые тезисы

- `new` = `operator new` + конструктор; placement new конструирует в готовой памяти, деструктор тогда зовётся вручную.
- Стек: 1 инструкция; куча: 20–100 нс в среднем, но с длинным хвостом при уходе в syscall — именно хвост убивает latency.
- `unique_ptr` бесплатен, если deleter — пустой тип; указатель на функцию удваивает размер.
- Pimpl требует объявить деструктор (и move-операции) в заголовке, определить в .cpp — иначе неполный тип.
- `shared_ptr` = 16 байт + control block; копирование = атомарный RMW, дорого не само по себе, а из-за контенции за кэш-линию.
- `make_shared` — одна аллокация и лучшая локальность, но задерживает освобождение памяти до смерти последнего `weak_ptr` и не поддерживает custom deleter.
- Атомарен счётчик, а не сам `shared_ptr`; для конкурентной записи в указатель нужен `std::atomic<std::shared_ptr<T>>` (C++20).
- `weak_ptr::lock()` — единственный корректный способ проверить и получить объект атомарно; `expired()` подвержен TOCTOU.
- Циклы `shared_ptr` — утечка; разрывать `weak_ptr` в обратном направлении.
- `shared_ptr` стирает тип deleter'а, поэтому корректно удаляет `Derived` через `Base*` без виртуального деструктора; `unique_ptr` — нет.
- PMR (C++17) выносит стратегию аллокации из типа в рантайм; `monotonic_buffer_resource` даёт bump-аллокацию за 1–2 нс, `null_memory_resource` — способ доказать отсутствие аллокаций.
- Порядок полей по убыванию размера убирает padding: 24 → 16 байт значит вдвое больше объектов в кэш-линии.
- Padding-байты ломают побайтовые сравнения (`memcmp`, CAS у `atomic<T>`); `operator==` через `= default` сравнивает по полям и безопасен.
- `alignas(64)`/`hardware_destructive_interference_size` — лекарство от false sharing; C++17 добавил aligned `operator new`.
- SSO прячет 15–22 символа в самом объекте `std::string`; `std::function` прячет 16–24 байта состояния, всё остальное уходит в кучу.
