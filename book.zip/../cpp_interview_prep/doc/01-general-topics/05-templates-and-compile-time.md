# Шаблоны и compile-time

Зачем это на интервью: шаблоны — это способ проверить, понимаете ли вы, как компилятор разбирает и подставляет код, а не только как им пользоваться. Типичные заходы: «напиши perfect forwarding обёртку и объясни каждый `&&`», «зачем здесь `typename`», «как бы ты ограничил этот шаблон до арифметических типов — и как это делалось до концептов». В low-latency контексте продолжение всегда одно: «а что это делает со временем компиляции и размером бинаря».

---

## 1. Two-phase lookup и dependent names

**Определение вслух.** Компилятор разбирает шаблон дважды. Первая фаза — при чтении определения шаблона: проверяется синтаксис и разрешаются все имена, **не зависящие** от параметров шаблона. Вторая фаза — при инстанцировании: разрешаются **зависимые** имена, причём для функций дополнительно работает ADL в точке инстанцирования.

```cpp
template <class T>
struct Wrapper {
    // typename нужен: компилятор не знает, T::value_type — это тип или статический член
    typename T::value_type first();

    void call(T& t) {
        // template нужен: иначе '<' парсится как оператор "меньше"
        t.template get<0>();
    }
};
```

**Правило.** Если имя зависит от параметра шаблона и обозначает тип — нужен `typename`. Если зависит и обозначает шаблон — нужен `template`. Это требование парсера: он обязан решить, тип это или значение, до того как узнает, чем окажется `T`.

C++20 смягчил правило: `typename` теперь не нужен там, где по контексту возможен только тип (тип возврата, тип параметра, после `->`, в `static_cast` и т.п.).

**Ловушка — имена из зависимого базового класса не видны.**
```cpp
// Пример намеренно сломан.
template <class T> struct Base { int value; };
template <class T> struct Derived : Base<T> {
    int get() { return value; }   // ошибка: value не ищется в зависимой базе
};
```
Причина: на первой фазе компилятор не знает, чем окажется `Base<T>` (может быть специализация без `value`), поэтому не заглядывает туда. Исправление — сделать имя зависимым:
```cpp
template <class T> struct Derived : Base<T> {
    int get() { return this->value; }         // вариант 1
    // using Base<T>::value;                  // вариант 2
    // int get() { return Base<T>::value; }   // вариант 3
};
```

---

## 2. Специализация и overload resolution

**Полная специализация** — конкретный набор аргументов. **Частичная** — сужение (только для классов и переменных; функции частично специализировать нельзя, вместо этого перегружают).

```cpp
template <class T>            struct Traits          { static constexpr bool ptr = false; };
template <class T>            struct Traits<T*>      { static constexpr bool ptr = true; };  // частичная
template <>                   struct Traits<void*>   { static constexpr bool ptr = false; }; // полная
```

**Ловушка — «специализация» функции ведёт себя не так, как ожидают.**
```cpp
// Пример намеренно сломан: специализация никогда не выбирается.
template <class T> void f(T);        // #1
template <class T> void f(T*);       // #2 — перегрузка
template <>        void f<int*>(int*); // специализация #1, а не #2!
int* p; f(p);   // выбирается #2, специализация #1 не при чём
```
Правило (Sutter, «Why Not Specialize Function Templates?»): специализируйте только классы, для функций используйте перегрузку. Порядок: сначала overload resolution выбирает *базовый шаблон*, потом ищется его специализация.

**ADL (argument-dependent lookup).** При неквалифицированном вызове функции к области поиска добавляются пространства имён, ассоциированные с типами аргументов.

```cpp
namespace ns { struct S{}; void swap(S&, S&); }
template <class T> void algo(T& a, T& b) {
    using std::swap;   // "две ступени": делаем std::swap видимым
    swap(a, b);        // ADL найдёт ns::swap для ns::S, иначе возьмётся std::swap
}
```
Это идиома **two-step swap** — обязательный ответ на вопрос «как правильно вызывать swap в generic-коде». Писать `std::swap(a, b)` неправильно: ADL отключается, и пользовательский быстрый swap не найдётся.

C++20 добавил CPO (customization point objects) — `std::ranges::swap`, `std::ranges::begin`: они делают two-step внутри себя, поэтому в новом коде достаточно `std::ranges::swap(a, b)`.

**Ловушка ADL:** непреднамеренный захват. `operator<<` для вашего типа, объявленный внутри `namespace`, найдётся автоматически — это плюс. Но и `using namespace std;` в сочетании с обобщёнными именами (`std::begin`, `std::data`) даёт неожиданные разрешения.

---

## 3. Variadic templates, fold expressions, perfect forwarding

**Reference collapsing** — правило, без которого не работает ничего из forwarding: `& &` → `&`, `& &&` → `&`, `&& &` → `&`, `&& &&` → `&&`. Мнемоника: «lvalue-ссылка заразна».

**Forwarding reference** (Мейерс называл universal reference) — это `T&&`, где `T` — **выводимый** параметр шаблона этой функции. Не forwarding reference: `std::vector<T>&&`, `const T&&`, `T&&` в методе класса, у которого `T` — параметр класса, а не метода.

```cpp
template <class T> void f(T&& x);        // forwarding reference
template <class T> void g(std::vector<T>&& v);   // обычная rvalue-ссылка
template <class T> struct C { void h(T&& x); };  // обычная rvalue-ссылка (T уже фиксирован)
```

Как выводится: если передан lvalue типа `U`, то `T = U&`, и `T&&` = `U& &&` = `U&`. Если rvalue — `T = U`, и `T&&` = `U&&`. Именно поэтому `std::forward<T>` восстанавливает категорию:

```cpp
template <class T>
constexpr T&& forward(std::remove_reference_t<T>& t) noexcept {
    return static_cast<T&&>(t);   // если T == U&, то U& && == U& (lvalue); если T == U, то U&&
}
```

**Perfect forwarding factory:**
```cpp
template <class T, class... Args>
std::unique_ptr<T> make(Args&&... args) {
    return std::unique_ptr<T>(new T(std::forward<Args>(args)...));
}
```
Что здесь проговорить: `Args&&...` — пакет forwarding references; `std::forward<Args>(args)...` разворачивается в `forward<A1>(a1), forward<A2>(a2), ...`; без `forward` все аргументы стали бы lvalue (у них есть имена) и move-семантика потерялась бы.

**Чего perfect forwarding не умеет** (частый уточняющий вопрос):
- braced-init-list: `make<std::vector<int>>({1,2,3})` не выводится (нет типа у `{...}`);
- `0`/`NULL` как null pointer — выведется `int`;
- перегруженные функции и имена шаблонов без указания типа;
- битовые поля;
- статические константные члены без определения (до C++17 — ODR-use через ссылку).

**Ловушка — forwarding-конструктор съедает копирование.**
```cpp
// Пример намеренно сломан.
class Person {
    std::string name_;
public:
    template <class T> explicit Person(T&& n) : name_(std::forward<T>(n)) {}
    Person(const Person&) = default;
};
Person p{"bob"};
Person q{p};       // p — НЕ const lvalue -> шаблон подходит точнее, чем copy-ctor -> ошибка компиляции
```
Исправление — ограничить шаблон:
```cpp
template <class T>
    requires (!std::same_as<std::remove_cvref_t<T>, Person>)   // C++20
explicit Person(T&& n) : name_(std::forward<T>(n)) {}
```
До C++20 — `std::enable_if_t<!std::is_base_of_v<Person, std::decay_t<T>>, int> = 0`.

**Fold expressions (C++17).** Четыре формы: унарный правый `(pack op ...)`, унарный левый `(... op pack)`, бинарный правый `(pack op ... op init)`, бинарный левый `(init op ... op pack)`.

```cpp
template <class... Ts> auto sum(Ts... xs)      { return (xs + ...); }        // унарный правый
template <class... Ts> bool all(Ts... xs)      { return (xs && ...); }       // пустой пакет -> true
template <class... Ts> void print(Ts&&... xs)  { ((std::cout << xs << ' '), ...); }  // через запятую
template <class... Ts> auto sum0(Ts... xs)     { return (0 + ... + xs); }    // бинарный левый, безопасен для пустого
```
Пустой пакет допустим только для `&&` (true), `||` (false) и `,` (void). Для остальных операторов нужна бинарная форма с init.

До C++17 то же писали через рекурсию шаблонов — это в разы дороже по времени компиляции (каждая инстанциация — новая сущность).

---

## 4. Эволюция ограничений: SFINAE → enable_if → if constexpr → concepts

**SFINAE** (Substitution Failure Is Not An Error) — если подстановка аргументов шаблона в сигнатуру даёт некорректный тип, кандидат просто выбрасывается из overload set, а не вызывает ошибку компиляции. Работает только для «непосредственного контекста» сигнатуры; ошибка в теле функции — это уже hard error.

```cpp
// C++11: detection через enable_if
template <class T, std::enable_if_t<std::is_integral_v<T>, int> = 0>
void process(T x) { /* целые */ }

template <class T, std::enable_if_t<std::is_floating_point_v<T>, int> = 0>
void process(T x) { /* вещественные */ }
```

```cpp
// C++11 detection idiom: есть ли у T метод serialize()?
template <class T, class = void>
struct has_serialize : std::false_type {};

template <class T>
struct has_serialize<T, std::void_t<decltype(std::declval<T&>().serialize())>>
    : std::true_type {};
```
`std::void_t` (C++17, но тривиально пишется руками) — трюк: если выражение внутри `decltype` некорректно, частичная специализация отпадает по SFINAE и остаётся `false_type`.

**`if constexpr` (C++17)** — компилируется только выбранная ветвь; отброшенная не инстанцируется (но всё равно должна быть синтаксически корректна и не зависеть только от не-шаблонных ошибок).

```cpp
template <class T>
void process(T x) {
    if constexpr (std::is_integral_v<T>) {
        // ...
    } else if constexpr (std::is_floating_point_v<T>) {
        // ...
    } else {
        static_assert(sizeof(T) == 0, "unsupported type");  // трюк: зависимое условие
    }
}
```
Обратите внимание на `sizeof(T) == 0` вместо просто `false`: `static_assert(false)` сработал бы при первом же чтении шаблона, до инстанцирования (в C++23 это исправлено — P2593).

Чем `if constexpr` лучше tag dispatch и enable_if: одна функция вместо трёх, читаемо, быстрее компилируется. Чем хуже: не участвует в overload resolution, поэтому не годится, когда варианты живут в разных заголовках/библиотеках.

**Concepts (C++20)** — именованные, композируемые ограничения с внятными сообщениями об ошибках и участием в частичном упорядочивании перегрузок.

```cpp
template <class T>
concept Numeric = std::is_arithmetic_v<T>;

template <class T>
concept PriceLike = requires(T t) {
    { t.price() } -> std::convertible_to<double>;
    { t.qty() }   -> std::integral;
    typename T::id_type;
    requires sizeof(T) <= 64;          // вложенное требование
};

template <PriceLike T> double notional(const T& t) { return t.price() * t.qty(); }
// эквивалентные записи:
// template <class T> requires PriceLike<T> double notional(const T&);
// double notional(const PriceLike auto& t);
```

**Главное преимущество концептов над enable_if** (это то, что хотят услышать): концепты **упорядочены по включению**. Если один концепт подразумевает (subsumes) другой, компилятор выберет более специфичную перегрузку без всяких tag-трюков:

```cpp
template <std::integral T>        void f(T);   // выбирается для int
template <std::regular T>         void f(T);   // менее ограниченный
```
С `enable_if` пришлось бы вручную делать условия взаимоисключающими, иначе — ambiguous call.

**Таблица эволюции:**

| Механизм | Версия | Плюсы | Минусы |
|---|---|---|---|
| Перегрузка + SFINAE вручную | C++98 | работает везде | нечитаемо, ужасные ошибки |
| `enable_if` | C++11 | стандартно, участвует в overload resolution | шумно, взаимоисключающие условия вручную |
| Tag dispatch | C++98 | простое и предсказуемое разрешение | лишние типы-теги, много функций |
| `if constexpr` | C++17 | одна функция, читаемо, быстро компилируется | не участвует в перегрузке |
| Concepts | C++20 | читаемо, ошибки понятные, subsumption | требует C++20 |

---

## 5. CRTP, type erasure, tag dispatch, policy-based design

**CRTP (Curiously Recurring Template Pattern)** — статический полиморфизм: базовый класс шаблонизирован производным.

```cpp
template <class Derived>
struct Strategy {
    void on_tick(const Tick& t) {
        static_cast<Derived*>(this)->handle(t);   // разрешается на этапе компиляции, инлайнится
    }
};
struct Momentum : Strategy<Momentum> {
    void handle(const Tick& t) { /* ... */ }
};
```
Плюсы: нет vtable (объект меньше на 8 байт), вызов инлайнится, оптимизатор видит всё. Минусы: нет общего базового типа (нельзя `vector<Strategy*>`), код дублируется на каждый Derived, ошибки многословны. Применение в trading: обработчики сообщений, где тип известен на этапе компиляции.

**Type erasure** — обратное: спрятать конкретный тип за единым интерфейсом без наследования от общей базы.

```cpp
class AnyHandler {
    struct Concept {
        virtual ~Concept() = default;
        virtual void on(const Tick&) = 0;
    };
    template <class T>
    struct Model final : Concept {
        T impl;
        explicit Model(T t) : impl(std::move(t)) {}
        void on(const Tick& t) override { impl.on(t); }
    };
    std::unique_ptr<Concept> p_;
public:
    template <class T>
    AnyHandler(T x) : p_(std::make_unique<Model<T>>(std::move(x))) {}
    void on(const Tick& t) { p_->on(t); }
};
```
Так устроены `std::function`, `std::any`, `shared_ptr`'s deleter. Цена — аллокация (если нет SBO) и виртуальный вызов.

**Tag dispatch** — выбор перегрузки по типу-тегу; классика — итераторные категории:
```cpp
template <class It>
void advance_impl(It& it, int n, std::random_access_iterator_tag) { it += n; }
template <class It>
void advance_impl(It& it, int n, std::forward_iterator_tag) { while (n--) ++it; }

template <class It>
void my_advance(It& it, int n) {
    advance_impl(it, n, typename std::iterator_traits<It>::iterator_category{});
}
```
В C++20 то же самое пишется концептами и читается лучше.

**Policy-based design** — поведение задаётся параметрами-политиками; классика — `std::vector<T, Allocator>`, `std::basic_string<Char, Traits, Alloc>`.

```cpp
struct NoLock  { void lock() noexcept {} void unlock() noexcept {} };
struct RealLock { std::mutex m; void lock() { m.lock(); } void unlock() { m.unlock(); } };

template <class T, class LockPolicy = NoLock>
class Queue {
    [[no_unique_address]] LockPolicy lock_;   // C++20: пустая политика не занимает места
    std::vector<T> data_;
public:
    void push(T v) { lock_.lock(); data_.push_back(std::move(v)); lock_.unlock(); }
};
```
`[[no_unique_address]]` (C++20) — способ получить EBO для членов, а не только для баз. Без него пустая политика занимала бы минимум 1 байт плюс padding.

---

## 6. `constexpr` и compile-time вычисления

**Что можно в constexpr-функции по версиям:**

| Версия | Возможности |
|---|---|
| C++11 | одна `return`-инструкция, рекурсия |
| C++14 | циклы, локальные переменные, `if`, множественные return |
| C++17 | `if constexpr`, лямбды constexpr, `constexpr` статические члены inline |
| C++20 | `new`/`delete` (память должна освобождаться в том же вычислении), `virtual`, try/catch (без throw), `std::vector`/`std::string` (транзиентно), `constinit`, `consteval`, `is_constant_evaluated()` |
| C++23 | `static constexpr` в constexpr-функциях, `goto`, нелитеральные переменные в невыполняемых ветвях |

**Compile-time таблица — типовая задача в quant-коде:**
```cpp
#include <array>
#include <cstdint>

// Степени десятки для fixed-point арифметики
consteval auto make_pow10() {
    std::array<std::int64_t, 19> a{};
    a[0] = 1;
    for (std::size_t i = 1; i < a.size(); ++i) a[i] = a[i-1] * 10;
    return a;
}
inline constexpr auto kPow10 = make_pow10();   // лежит в .rodata, ноль работы в рантайме

static_assert(kPow10[9] == 1'000'000'000LL);
```
Что здесь проговорить: `consteval` гарантирует вычисление на этапе компиляции; `inline constexpr` на уровне namespace даёт одну копию на программу (C++17) без ODR-нарушений; таблица попадает в read-only секцию, никакой инициализации в рантайме, никакого static init order fiasco.

**`std::is_constant_evaluated()` (C++20)** — различить контекст:
```cpp
constexpr double fast_sqrt(double x) {
    if (std::is_constant_evaluated())
        return slow_but_constexpr_sqrt(x);       // compile-time
    else
        return std::sqrt(x);                     // рантайм, интринсик
}
```
Ловушка: это **функция**, а не `if constexpr` — писать `if constexpr (std::is_constant_evaluated())` бессмысленно (условие всегда true при вычислении в constexpr-контексте компилятором). C++23 добавил `if consteval`, который делает намерение явным и безопасным.

---

## 7. Влияние на время компиляции и размер бинаря

**Почему шаблоны дорого компилируются.** Каждая уникальная комбинация аргументов — отдельная инстанциация: свой AST, свой набор символов, свои оптимизации. Рекурсивные шаблоны с глубиной N дают N инстанциаций; `std::tuple` из 20 типов может породить сотни. Компилятор хранит все инстанциации в памяти.

Практические техники сокращения:
1. **Выносить не зависящий от типа код в не-шаблонные функции** (классика: `vector<T*>` для всех T реализуется через `vector<void*>` внутри — так делали в оригинальном STL).
2. **`extern template`** — запретить инстанцирование в этой TU, сделать один раз в отдельной:
```cpp
// header.h
extern template class std::vector<MyType>;   // "не инстанцируй здесь"
// impl.cpp
template class std::vector<MyType>;          // явная инстанциация, один раз
```
Экономит и время компиляции, и размер объектных файлов.
3. **Type erasure на границе** — публичный API не шаблонный, шаблоны внутри.
4. **`if constexpr` вместо рекурсии и tag dispatch** — меньше сущностей.
5. **Fold expressions вместо рекурсивных variadic** — линейно вместо N инстанциаций.
6. **Precompiled headers, unity builds, ccache, C++20 modules.**

**Code bloat.** Каждая инстанциация — свой машинный код. `std::sort` с разными компараторами (в том числе разными лямбдами!) — разные функции. Это раздувает I-cache, что в hot path контрпродуктивно: 1 МБ кода не влезет в 32 КБ L1i. Линковщик схлопывает идентичные функции (`--icf=all` в lld/gold, `-ffunction-sections -Wl,--gc-sections` убирает мёртвые), но одинаковый исходник с разными типами даёт разный код и не схлопнется.

**Практический баланс для low-latency.** Шаблоны в hot path — хорошо (инлайнинг, отсутствие косвенных вызовов), шаблоны в API и в холодном коде — плохо (время сборки, I-cache). Типичное решение: шаблонное ядро + не-шаблонная оболочка.

---

## Частые вопросы по теме

**В: Зачем нужен `typename` перед зависимым именем?**
О: Парсер должен решить, тип это или значение, ещё до подстановки `T`. По умолчанию он считает зависимое имя значением, поэтому для типа нужен явный `typename` (в C++20 не требуется там, где возможен только тип).

**В: Почему `value` из шаблонного базового класса не виден в производном?**
О: На первой фазе компилятор не заглядывает в зависимую базу — она может оказаться специализацией без этого имени. Нужно `this->value`, `Base<T>::value` или `using`.

**В: Что такое forwarding reference и чем отличается от rvalue-ссылки?**
О: `T&&`, где `T` — выводимый параметр этой же функции. Благодаря reference collapsing он связывается и с lvalue (`T = U&`), и с rvalue. `std::vector<T>&&` или `T&&` в методе класса — обычные rvalue-ссылки.

**В: Что делает `std::forward`?**
О: Условный `static_cast<T&&>`: если `T` вывелся как `U&`, collapse даёт lvalue-ссылку; если как `U` — rvalue-ссылку. Так восстанавливается исходная категория аргумента.

**В: Чего perfect forwarding не может передать?**
О: braced-init-list (нет типа), `0`/`NULL` как nullptr, имена перегруженных функций и шаблонов, битовые поля.

**В: Почему шаблонный конструктор ломает копирование?**
О: Для неконстантного lvalue шаблон даёт точное совпадение `Person&`, а copy-конструктор требует добавления const — шаблон выигрывает. Нужно ограничить его через `requires` или `enable_if`.

**В: Что такое SFINAE и где он не работает?**
О: Ошибка подстановки в сигнатуру исключает кандидата из overload set вместо ошибки компиляции. Работает только в непосредственном контексте сигнатуры; ошибка в теле функции — hard error.

**В: Чем концепты лучше `enable_if`?**
О: Читаемость и внятные диагностики, но главное — subsumption: концепты частично упорядочены по включению, поэтому более специфичная перегрузка выбирается автоматически, без ручного разведения условий.

**В: Когда `if constexpr` не заменяет перегрузку?**
О: Когда варианты должны участвовать в overload resolution (например, живут в разных заголовках или добавляются пользователем), и когда нужно частичное упорядочивание. `if constexpr` — это выбор внутри одной функции.

**В: Что такое CRTP и в чём цена?**
О: Статический полиморфизм через базу, шаблонизированную производным. Нет vtable и вызов инлайнится; цена — нет общего базового типа для контейнеров и код дублируется на каждый Derived.

**В: Как работает type erasure?**
О: Внутренний абстрактный `Concept` и шаблонный `Model<T>`, хранящий конкретный объект; наружу торчит не-шаблонный интерфейс. Так устроены `std::function` и `std::any`; цена — виртуальный вызов и возможная аллокация.

**В: Как правильно вызывать `swap` в generic-коде?**
О: `using std::swap; swap(a, b);` — ADL найдёт пользовательский swap, иначе возьмётся стандартный. Квалифицированный `std::swap(a,b)` отключает ADL. В C++20 то же делает `std::ranges::swap`.

**В: Что даёт `[[no_unique_address]]`?**
О: Позволяет пустому члену класса не занимать места (аналог EBO для членов). Практично для политик, аллокаторов и компараторов.

**В: Что такое `extern template`?**
О: Подавляет неявное инстанцирование в этой TU; явная инстанциация делается один раз в отдельном .cpp. Сокращает время компиляции и размер объектных файлов.

**В: Почему шаблоны раздувают бинарь и почему это плохо в hot path?**
О: Каждая уникальная комбинация аргументов — отдельный код; лямбды-компараторы дают разные инстанциации. Раздутый код не помещается в L1i (32 КБ), и горячий цикл начинает промахиваться по инструкциям.

**В: Что нового даёт `consteval`?**
О: Функция обязана вычисляться на этапе компиляции — попытка вызвать её с рантайм-аргументом это ошибка компиляции. Гарантия, которой у `constexpr` нет.

---

## Что сказать, если не знаешь

1. **Рассуждайте как парсер.** «Компилятор читает это определение до того, как узнал, чем будет `T`. Что он может здесь решить сейчас, а что только при инстанцировании?» Из этого выводятся и `typename`, и two-phase lookup, и почему зависимая база невидима, и почему `static_assert(false)` в шаблоне срабатывает сразу.

2. **Стройте ответ по лестнице эволюции.** Даже если не помните точный синтаксис концептов, скажите: «Задача — ограничить шаблон. Исторически это делали перегрузкой с SFINAE, потом `enable_if`, потом `if constexpr` внутри одной функции, сейчас — концепты. Здесь я бы взял концепт, потому что нужна перегрузка с упорядочиванием». Это показывает понимание, а не заученный синтаксис.

3. **Признавайте цену и предлагайте измерить.** «Я бы написал это на шаблонах ради инлайнинга, но проверил бы `nm --size-sort` на размер символов и время сборки. Если инстанциаций много и код раздувается, вынес бы общую часть в не-шаблонную функцию или закрыл бы type erasure на границе модуля».

---

## Ключевые тезисы

- Two-phase lookup: независимые имена разрешаются при чтении шаблона, зависимые — при инстанцировании (плюс ADL в точке инстанцирования).
- `typename` для зависимых типов, `template` для зависимых шаблонов — требование парсера; в C++20 `typename` часто не нужен.
- Имена из зависимого базового класса невидимы: `this->x`, `Base<T>::x` или `using`.
- Функции не специализируют частично — их перегружают; полная специализация функции подчиняется уже выбранному базовому шаблону.
- Two-step swap (`using std::swap; swap(a,b);`) — единственный правильный вызов в generic-коде; C++20 даёт CPO `std::ranges::swap`.
- Reference collapsing («lvalue заразна») — фундамент forwarding reference; `T&&` — forwarding только когда `T` выводится в этой же функции.
- `std::forward` — условный каст, восстанавливающий категорию; без него всё, у чего есть имя, становится lvalue.
- Шаблонный конструктор с forwarding reference «съедает» копирование неконстантных lvalue — ограничивайте его.
- Fold expressions (C++17) заменяют рекурсивные variadic и компилируются линейно; пустой пакет допустим только для `&&`, `||`, `,`.
- Эволюция ограничений: SFINAE → `enable_if` → tag dispatch → `if constexpr` (C++17) → concepts (C++20); главный плюс концептов — subsumption.
- `if constexpr` не инстанцирует отброшенную ветвь, но не участвует в overload resolution; `static_assert` в else-ветви требует зависимого условия (до C++23).
- CRTP — полиморфизм без vtable и с инлайнингом, ценой отсутствия общей базы; type erasure — обратный компромисс.
- `[[no_unique_address]]` (C++20) даёт EBO для членов — важно для policy-based дизайна.
- `consteval` гарантирует compile-time; `constinit` гарантирует статическую инициализацию; `inline constexpr` в заголовке даёт одну копию таблицы в `.rodata`.
- Шаблоны раздувают время сборки и I-cache: `extern template`, вынос типо-независимого кода, type erasure на границе API — стандартные противовесы.
