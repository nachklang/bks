# Раздел 1. Общие темы

Здесь лежат «теоретические» материалы: то, что спрашивают в формате «расскажи про…»,
«в чём разница между…», «что произойдёт, если…». Файлы создаются по мере того, как
ты задаёшь вопросы в разговоре — заглушек тут нет, есть план того, что имеет смысл
закрыть до интервью.

Порядок в плане — примерно по убыванию вероятности, что тему тронут на интервью
уровня Senior C++ в WorldQuant (quant research / trading infrastructure).

## Документы

Порядок чтения — по убыванию вероятности, что тему тронут на интервью.
Приоритет 1 — читать обязательно, 3 — если останется время.

Подробное руководство на английском: [mmap: a complete practical guide](23-mmap-complete-guide.md)
— устройство памяти с нуля, API, примеры C/C++, shared memory, сохранность данных,
производительность, 48 вопросов с ответами и 8 упражнений.

[Memory ordering and memory barriers: a detailed C++ interview guide](24-memory-order-and-barriers-complete-guide.md)
— подробные определения, доказательства happens-before, все memory orders, CAS,
fences, x86/Arm, время жизни объектов, 11 полных программ C++20, 60 вопросов и 12 упражнений.

[Memory pages: from virtual addresses to physical RAM](25-memory-pages-complete-guide.md)
— страницы и физические фреймы, таблицы страниц, TLB, page faults, COW, reclaim,
swap, huge pages и NUMA; 4 программы C++20, 40 вопросов и 8 упражнений.

| # | Документ | План | Строк | Приоритет |
|---|---|---|---|---|
| 04 | [Многопоточность и модель памяти](04-concurrency-and-memory-model.md) | 1.4 | 528 | 1 |
| 03 | [STL: контейнеры, алгоритмы, идиомы](03-stl-containers-algorithms-idioms.md) | 1.3 | 377 | 1 |
| 01 | [Ядро языка и объектная модель](01-language-core-and-object-model.md) | 1.1 | 462 | 1 |
| 02 | [Память и владение](02-memory-and-ownership.md) | 1.2 | 383 | 1 |
| 12 | [`weak_ptr`: наблюдение за чужим временем жизни](12-weak-ptr.md) | 1.12 | 513 | 1 |
| 13 | [Гарантии безопасности исключений](13-exception-safety-guarantees.md) | 1.13 | 410 | 1 |
| 14 | [`condition_variable` и как работает `wait`](14-condition-variable.md) | 1.14 | 488 | 1 |
| 15 | [Раскладка vtable](15-vtable-layout.md) | 1.15 | 245 | 1 |
| 16 | [Аллокаторы: от `mmap` до `std::pmr`](16-allocators.md) | 1.16 | 455 | 1 |
| 17 | [Linux для C++-разработчика](17-linux-for-cpp.md) | 1.17 | 351 | 1 |
| 18 | [`std::string` изнутри](18-std-string-internals.md) | 1.18 | 174 | 1 |
| 19 | [Виртуальный вызов в машинном коде](19-virtual-call-disassembly.md) | 1.19 | 135 | 1 |
| 20 | [Чтение файлов: `read`, `FILE*`, `ifstream`, `mmap`](20-file-io-read-stdio-iostream-mmap.md) | 1.20 | 1214 | 1 |
| 21 | [Наследование и множественное наследование](21-inheritance-and-multiple-inheritance.md) | 1.21 | 2120 | 1 |
| 22 | [memory_order и барьеры памяти](22-memory-order-and-fences.md) | 1.22 | 3271 | 1 |
| 06 | [Производительность и low-latency](06-performance-and-low-latency.md) | 1.6 | 334 | 2 |
| 05 | [Шаблоны и compile-time](05-templates-and-compile-time.md) | 1.5 | 455 | 2 |
| 07 | [Исключения и обработка ошибок](07-exceptions-and-error-handling.md) | 1.7 | 330 | 2 |
| 09 | [Quant- и trading-специфика](09-quant-and-trading-specifics.md) | 1.9 | 385 | 2 |
| 11 | [mmap и отображение файлов в память](11-mmap-and-memory-mapped-files.md) | 1.11 | 622 | 2 |
| 10 | [Алгоритмы и задачи «на бумажке»](10-algorithms-and-whiteboard-tasks.md) | 1.10 | 466 | 3 |
| 08 | [Сборка, ABI, инструменты](08-build-abi-and-tooling.md) | 1.8 | 281 | 3 |

Структура каждого документа: «зачем это на интервью» → разбор по пунктам плана
(определение, минимальный пример, ловушка, таблица) → «Частые вопросы по теме»
с эталонными ответами → «Что сказать, если не знаешь» → «Ключевые тезисы».

Смежные материалы: разборы кода — в [разделе 02](../02-interview-questions/README.md),
предметная область order book — в [разделе 03](../03-orderbook/).

## План тем (детальное оглавление)

### 1.1. [Ядро языка и объектная модель](01-language-core-and-object-model.md)
- Время жизни объектов, storage duration, order of initialization (в т.ч. static init order fiasco).
- Value categories: lvalue / xvalue / prvalue, guaranteed copy elision (C++17), RVO/NRVO.
- Move semantics: правила генерации специальных функций, rule of 0/3/5, `noexcept`,
  moved-from state, self-move, `std::move` vs `std::forward`.
- `const`, `constexpr`, `consteval`, `constinit`; const-correctness и logical vs bitwise const.
- Ссылки, reference binding, dangling: возврат ссылки на локальный объект,
  продление жизни временного через `const&` и через rvalue-ссылку (и где оно НЕ работает).
- Инициализация: `{}` vs `()`, narrowing, `initializer_list`-ловушки (`vector<int>{10, 0}`).
- UB-классика: signed overflow, strict aliasing, out-of-range, use-after-free, data race,
  чтение неинициализированного, нарушение порядка вычисления (до/после C++17).

### 1.2. [Память и владение](02-memory-and-ownership.md)
- Стек vs куча vs static; что реально делает `new` (operator new + конструктор), placement new.
- `unique_ptr` (в т.ч. custom deleter и его влияние на sizeof), `shared_ptr`
  (control block, `make_shared` vs `new`, atomic refcount и его цена), `weak_ptr`,
  `enable_shared_from_this`, циклические ссылки.
- Aliasing constructor у `shared_ptr`, тип-стирание deleter'а.
- Аллокаторы: `std::allocator`, PMR (`std::pmr::monotonic_buffer_resource`,
  `unsynchronized_pool_resource`) — очень «в тему» для low-latency.
- Выравнивание, padding, `alignas`, `alignof`, `std::hardware_destructive_interference_size`.
- Small buffer optimization (SSO в `std::string`, SBO в `std::function`).

### 1.3. [STL: контейнеры, алгоритмы, идиомы](03-stl-containers-algorithms-idioms.md)
- Гарантии сложности и инвалидация итераторов по каждому контейнеру (табличка наизусть).
- `vector`: рост capacity, `reserve`, `shrink_to_fit`, почему `push_back` амортизированно O(1),
  почему `noexcept` move важен для реаллокации.
- `deque`, `list`, `forward_list` — когда вообще нужны.
- `map`/`set` (RB-tree) vs `unordered_map`/`unordered_set` (bucket + chaining):
  память, локальность, стоимость хеширования, `reserve`/`max_load_factor`,
  почему `unordered_map` в hot path часто хуже плоской структуры.
- Node handles (`extract`/`insert`/`merge`), C++17.
- Erase-remove idiom, `std::erase`/`std::erase_if` (C++20), `remove_if` для разных контейнеров.
- Алгоритмы: `sort`/`stable_sort`/`nth_element`/`partial_sort`, `lower_bound`/`equal_range`,
  `partition`, `unique`, `accumulate`/`reduce`/`transform_reduce`.
- Ranges (C++20): views, лень, dangling-ловушки, `views::filter` и его non-const `begin()`.
- `string_view` и `span`: где висячие ссылки появляются мгновенно.

### 1.4. [Многопоточность и модель памяти](04-concurrency-and-memory-model.md)
- `std::thread`/`jthread`, join/detach, ownership потока.
- `mutex`, `unique_lock`/`lock_guard`/`scoped_lock`, `shared_mutex`, `recursive_mutex`
  (и почему он обычно признак проблемы в дизайне).
- `condition_variable`: predicate-форма wait, spurious wakeup, lost wakeup, notify под локом или нет.
- C++ memory model: sequenced-before / happens-before / synchronizes-with,
  `memory_order_relaxed/acquire/release/acq_rel/seq_cst`, release-acquire пары, fences.
- Atomics: `compare_exchange_weak` vs `strong`, ABA, `is_lock_free`, `atomic<T>` для структур.
- Lock-free: SPSC/MPMC очереди, false sharing, backoff, progress guarantees
  (wait-free / lock-free / obstruction-free).
- `std::atomic_thread_fence`, `std::memory_order_consume` (и почему его не используют).
- Thread-local storage, стоимость `thread_local`.
- Deadlock: 4 условия, lock ordering, `std::lock`/`scoped_lock`, hierarchical mutex.
- `std::call_once`, magic statics (thread-safe function-local statics с C++11).
- `std::future`/`promise`/`packaged_task`/`async` и почему `std::async` редко используют в проде.
- Coroutines (C++20) — хотя бы на уровне «что такое awaitable и зачем в IO».

### 1.5. [Шаблоны и compile-time](05-templates-and-compile-time.md)
- Two-phase lookup, dependent names, `typename`/`template` disambiguators.
- Специализация (полная/частичная), overload resolution, ADL.
- Variadic templates, fold expressions, perfect forwarding, reference collapsing.
- SFINAE → `enable_if` → `if constexpr` → concepts (C++20): эволюция и когда что.
- CRTP, type erasure, tag dispatch, policy-based design.
- `constexpr`/`consteval` вычисления, compile-time таблицы.
- Влияние шаблонов на время компиляции и размер бинаря (code bloat, extern template).

### 1.6. [Производительность и low-latency](06-performance-and-low-latency.md)
- Модель стоимости: кэш-линия, L1/L2/L3/RAM латентности, TLB, prefetch.
- Data-oriented design: AoS vs SoA, cache-friendly layout, избежание указательных прыжков.
- Branch prediction, `[[likely]]`/`[[unlikely]]`, branchless-код, cmov.
- Инлайн, LTO, PGO; что мешает оптимизатору (aliasing, virtual calls, exceptions).
- Виртуальные вызовы и devirtualization, `final`.
- Аллокации в hot path: почему их нет; pre-allocation, object pools, arena.
- Измерения: `rdtsc`/`steady_clock`, микробенчмарки (Google Benchmark), profiler (perf),
  почему бенчмарк врёт (dead code elimination, разогрев, частота, NUMA).
- Kernel bypass, busy-wait vs sleep, affinity, isolcpus, huge pages — на уровне терминов.

### 1.7. [Исключения, ошибки, гарантии](07-exceptions-and-error-handling.md)
- Гарантии: nothrow / strong / basic / none; RAII; copy-and-swap.
- Стоимость исключений (zero-cost на happy path, дорогой throw), `noexcept` и terminate.
- Исключение из деструктора, из конструктора, из потока.
- Альтернативы: коды ошибок, `std::expected` (C++23), `std::optional`, error handling
  в low-latency коде (часто исключения запрещены в hot path).

### 1.8. [Сборка, ABI, инструменты](08-build-abi-and-tooling.md)
- Единицы трансляции, ODR, inline/`inline` переменные, internal linkage.
- Статические/динамические библиотеки, symbol visibility, ABI-стабильность.
- Санитайзеры: ASan, UBSan, TSan — что ловят и чего не ловят.
- `-O2` vs `-O3`, `-march=native`, `-ffast-math` (и почему это опасно в quant).

### 1.9. [Прикладное для quant / trading](09-quant-and-trading-specifics.md)
- Представление цен и объёмов: почему не `double` для цены, fixed-point, тики.
- Floating point: IEEE-754, сравнение, накопление ошибки, Kahan, denormals и latency.
- Структуры данных для order book, time series, rolling window statistics.
- Сериализация/парсинг market data, endianness, packed структуры.
- Детерминизм и воспроизводимость расчётов.

### 1.10. [Алгоритмы и задачи «на бумажке»](10-algorithms-and-whiteboard-tasks.md)
- Сложности классики, но с уклоном в практику: top-K, sliding window, LRU-кэш,
  merge k sorted, интервалы, префиксные суммы, monotonic stack/queue.
- Многопоточные задачки: producer-consumer, bounded buffer, rate limiter.

### 1.11. [mmap и отображение файлов в память](11-mmap-and-memory-mapped-files.md)
- Фундамент: виртуальное адресное пространство, страницы, таблица страниц, TLB, page cache, VMA и `/proc/PID/maps`.
- Что `mmap` делает на самом деле: demand paging, page fault по шагам, минорные и мажорные фолты,
  fault-around, VSZ против RSS.
- Где `mmap` работает без вашего ведома: `malloc` блоков больше 128 КБ, загрузка бинаря и `.so`, стеки потоков.
- Параметры: `prot`, `MAP_PRIVATE`/`MAP_SHARED`/`MAP_ANONYMOUS`/`MAP_POPULATE`/`MAP_FIXED_NOREPLACE`,
  huge pages, ограничения (`length != 0`, выравнивание offset, `vm.max_map_count`).
- Copy-on-write: чем `MAP_PRIVATE` отличается от `MAP_SHARED` при записи.
- Плюсы и минусы развёрнуто, с измерением: последовательный проход против случайного доступа.
- Запись через отображение: `ftruncate` до `mmap`, `msync` против `fsync`, `SIGBUS` при усечении файла.
- Разделяемая память между процессами (`shm_open`, анонимная после `fork`), почему `std::mutex`
  там не годится и почему внутри сегмента хранят смещения, а не указатели — мостик к seqlock и SPSC ring.
- `madvise`, прогрев страниц, huge pages, `mlock`, давление на TLB.
- Время жизни объектов в отображении: `reinterpret_cast` как формальный UB и `std::start_lifetime_as` (C++23).
- Переносимость (Windows, boost::interprocess, mio) и инструменты: `smaps`, `pmap`, `perf stat`, `getrusage`.
- Рабочий пример с замерами: [`../../mmap_demo.cxx`](../../mmap_demo.cxx).

### 1.12. [`weak_ptr`: наблюдение за чужим временем жизни](12-weak-ptr.md)
- Что это и зачем: сравнение сырого указателя, `shared_ptr` и `weak_ptr` по владению,
  продлению жизни и знанию о смерти объекта.
- Две задачи: разрыв циклов и наблюдение за чужим временем жизни (кэш, подписчики, отложенные задачи).
- Механика двух счётчиков: `strong` на нуле убивает объект, `weak` — control block;
  приём «группа strong держит одну weak» и зачем он нужен.
- Почему `make_shared` вреден при большом объекте и долгоживущих `weak_ptr`.
- `lock()` и CAS-цикл; почему нет `operator*`/`get()`; почему `expired()` — это TOCTOU.
- Паттерны с кодом: разрыв цикла, кэш с обязательным `purge()`, самоотписывающийся
  подписчик, отмена отложенной задачи, `enable_shared_from_this`/`weak_from_this`,
  `owner_before` и `std::owner_less`.
- Цена: замер `lock()` против копии `shared_ptr` и против сырой ссылки.
- Многопоточность: что атомарно, что нет, memory orders.
- Когда `weak_ptr` НЕ нужен.
- Рабочий пример с замерами: [`../../weak_ptr_demo.cxx`](../../weak_ptr_demo.cxx);
  полная реализация — [`../reference/shared_ptr.hxx`](../reference/shared_ptr.hxx).

### 1.13. [Гарантии безопасности исключений](13-exception-safety-guarantees.md)
- Четыре уровня с точными формулировками; гарантия как свойство операции, а не класса.
- Методика: выписать точки броска → состояние в каждой → слабейшее и есть гарантия.
- RAII: что разрушается при исключении из конструктора, почему два сырых ресурса в одном
  конструкторе — утечка, function-try-block и почему он бесполезен.
- Три идиомы strong: «всё бросающее заранее, потом фиксация», copy-and-swap, scope guard.
- Таблица гарантий по операциям STL (`vector`, `map`/`set`, `unordered_*`, `sort`, `swap`).
- Почему move обязан быть `noexcept` — это тот же вопрос, вид сбоку; `move_if_noexcept`.
- Какую гарантию давать в своём коде и почему «strong везде» — антипаттерн.
- Гарантии и многопоточность: откат до выхода из-под лока, исключение через границу потока.
- Тестирование инъекцией отказов; актуальность гарантий при `-fno-exceptions`.
- Рабочий пример: [`../../exception_safety_demo.cxx`](../../exception_safety_demo.cxx).

### 1.14. [`condition_variable` и как работает `wait`](14-condition-variable.md)
- Что такое CV: очередь ожидания без памяти; обязательная тройка мьютекс + состояние + CV.
- **`wait` по шагам**: атомарная постановка в очередь и освобождение мьютекса, сон,
  повторный захват мьютекса при пробуждении; что `wait` не делает.
- Predicate-форма как буквальный `while (!pred()) wait(lk);`; две независимые причины цикла.
- Потерянное пробуждение: детерминированное воспроизведение и почему цикл от него не спасает.
- Spurious wakeup: реальные источники и почему это осознанный размен.
- Под капотом: futex, быстрый путь без системного вызова, группы ожидающих в glibc 2.25+,
  исчезнувший wait morphing.
- Видимость памяти обеспечивает мьютекс, а не `notify`.
- `notify_one` против `notify_all`: условия корректности, эффект стада и что показал замер.
- `notify` под локом или вне; когда вариант «вне» опасен.
- `wait_for`/`wait_until`: две перегрузки, пере-взведение таймаута, `steady_clock`
  против `system_clock`.
- Прерываемое ожидание со `stop_token` (C++20); `condition_variable_any` и его цена.
- Уничтожение CV с ожидающими; корректный порядок завершения потока.
- Альтернативы: `latch`, `barrier`, `counting_semaphore`, `atomic::wait`, спин в hot path.
- Рабочий пример с замерами: [`../../condvar_demo.cxx`](../../condvar_demo.cxx).

### 1.15. [Раскладка vtable](15-vtable-layout.md)
- Одна таблица на класс в `.rodata`, vptr в объекте; смещение слота известно
  на этапе компиляции, содержимое — нет.
- Что лежит в таблице: offset-to-top и typeinfo по отрицательным индексам, два слота
  деструктора (complete и deleting), слоты в порядке объявления → почему добавление
  виртуальной функции в середину ломает ABI.
- Множественное наследование: N vptr, `static_cast` сдвигает на +16, `reinterpret_cast` —
  нет; thunk'и `_ZThn16_` в чужой части таблицы; чем живёт `dynamic_cast`.
- Виртуальная база: vbase offset в таблице, construction vtables и VTT, запрет
  `static_cast` вниз из виртуальной базы.
- vptr переписывается на каждом уровне конструктора; `__cxa_pure_virtual`.
- Цена и девиртуализация: `final`, по значению, CRTP, `variant`, сортировка по типу.
- Все числа сняты `-fdump-lang-class` на GCC 15.2; рабочий пример:
  [`../../vtable_demo.cxx`](../../vtable_demo.cxx).

### 1.16. [Аллокаторы: от `mmap` до `std::pmr`](16-allocators.md)
- Пять уровней: контейнер → `Alloc` → `operator new` → `malloc` → ОС; три смысла слова «аллокатор».
- Цена: 3 нс на tcache, ~1 мкс на page fault, ~5 мкс на `mmap`; порог mmap динамический.
- Сколько аллокаций делают контейнеры: `vector` ×2 → 21 на миллион, узловые — по одной
  на элемент, SSO/SBO, `make_shared` против `shared_ptr(new)`.
- Минимальный аллокатор C++11+, rebind, stateful-аллокаторы, POCCA/POCMA/POCS,
  `is_always_equal`; move с неравными аллокаторами — O(n). Arena-аллокатор: ×5 на `list`.
- `std::pmr`: `memory_resource`, `polymorphic_allocator`, готовые ресурсы и цепочки
  upstream; цена виртуального вызова измерена.
- `operator new`: глобальная замена семейством (включая `align_val_t`), классовый free list,
  placement/nothrow/new_handler/destroying delete; GCC 15 `-fassume-sane-operators-new-delete`.
- glibc изнутри: чанк, tcache, bins, арены, top chunk и trim, фрагментация; jemalloc/mimalloc.
- Low-latency практика, 15 вопросов с ответами, 4 упражнения.
- Рабочий пример: [`../../allocator_demo.cxx`](../../allocator_demo.cxx).

### 1.17. [Linux для C++-разработчика](17-linux-for-cpp.md)
- Как отвечать: цепочка user → kernel → откуда данные → цена → чем посмотреть.
- Процессы и потоки: `fork`/`clone`/`exec`, CoW, зомби, `_exit`, сигналы и async-signal-safe.
- Память: VMA, page fault (~950 нс здесь), overcommit и OOM, RSS/PSS, page cache, huge pages, NUMA.
- I/O: fd и описания, короткое чтение, `select`/`poll`/`epoll` (LT/ET), `io_uring`, `SIGPIPE`.
- Сеть для market data: `TCP_NODELAY`, multicast и gap recovery, путь пакета, kernel bypass.
- Планировщик: EEVDF/`SCHED_FIFO`, affinity и `isolcpus`, контекст-свитч, спин против CV, futex.
- Время: vDSO 13 нс против syscall 79 нс (измерено), `rdtsc`, timer slack.
- IPC от pipe до shm ring; ELF, PLT/GOT, interposition, core dump, `perf`/`strace`/`/proc`.
- Пять цепочек «что происходит, когда», 30 вопросов с ответами.
- Тренажёр: [`../../linux_drills.cxx`](../../linux_drills.cxx) — 7 задач, 24 теста.

### 1.18. [`std::string` изнутри](18-std-string-internals.md)
- `sizeof` 32 / SSO 15 (libstdc++) против 24 / 22 (libc++); `vector<char>` — 24 и без SSO.
- Раскладка: `_M_p`, длина, union{буфер 16 | capacity}; признак «короткая» — сравнение указателя.
- Move короткой строки копирует байты и инвалидирует `data()`; длинной — крадёт буфер.
- Таблица аллокаций по операциям (измерено), рост `15 → 30 → 60 …`, что не отдаёт память.
- Старый COW-ABI: `sizeof` 8, refcount в заголовке, почему C++11 его запретил, `__cxx11`.
- Чек-лист «string против vector», 9 ловушек, 10 вопросов с ответами.
- Рабочий пример: [`../../string_demo.cxx`](../../string_demo.cxx).

### 1.19. [Виртуальный вызов в машинном коде](19-virtual-call-disassembly.md)
- Vtable `Derived` из `-S`: offset-to-top, typeinfo, `Derived::foo`, унаследованный `Base::bar`, D2/D0.
- `call_through_base`: `mov rax,[rdi]; call [rax]; … call [rax+8]` — и почему vptr перечитывается.
- Девиртуализация при известном типе даже с `-fno-inline`; vptr записывается в конструкторе.
- `sizeof(Derived) == sizeof(Base) == 16`: `y` в хвостовом padding базы.
- Vtable `Base` не эмитится: нет ключевой функции и ни одного объекта `Base`.
- Цена: BTB, кэш-промахи, потеря инлайнинга; 8 вопросов с ответами.
- Рабочий пример: [`../../virtual_call_asm.cxx`](../../virtual_call_asm.cxx).

### 1.20. [Чтение файлов: `read`, `FILE*`, `ifstream`, `mmap`](20-file-io-read-stdio-iostream-mmap.md)
- Словарь с точными определениями: fd, открытое описание, page cache, VMA, фолты, буферы, `fsync`.
- Все слои на одной схеме; каждый путь по шагам со своей схемой; сколько раз копируются байты.
- Буферы измерены: `FILE*` 4096 (= `st_blksize`), `filebuf` 8192 с чтением по 8191; большие запросы мимо буфера.
- 14 способов на 64 МБ: крупные куски все 11–13 мс, `ifstream::get` 174 мс, `istreambuf_iterator` 20 мс.
- Холодный кэш: `read` 26 мс против `mmap` 42 мс; `MAP_POPULATE` показывает 0 мажорных фолтов, но медленнее всех.
- Запись и падения: что теряется при `_exit` (проверено), кто чью запись видит, `SIGBUS`, `O_DIRECT` и выравнивание.
- Сводная таблица по 18 осям, как выбрать, 16 ловушек, 17 вопросов с ответами.
- Рабочий пример: [`../../file_io_demo.cxx`](../../file_io_demo.cxx).

### 1.21. [Наследование и множественное наследование](21-inheritance-and-multiple-inheritance.md)
- Словарь из 60 с лишним определений: подобъект, статический и динамический тип, первичная база, thunk, VTT, доминирование.
- Одиночное: база в начале и почему; хвостовой padding не-POD базы (8 против 12 байт); порядок конструирования и почему.
- Поиск имён и сокрытие, аргументы по умолчанию и доступ по статическому типу, вызов в конструкторе, срезка, виртуальный деструктор.
- МН: первичной становится полиморфная база, сдвиг +12, `reinterpret_cast` и каст в стиле C к неполному типу без сдвига, `nullptr`, сравнение указателей.
- Два `vptr`, thunk, offset-to-top, `dynamic_cast<void*>`; неоднозначность; ромб без `virtual` и с ним (дамп раскладки, vbase offset, кто строит базу, VTT).
- Касты сводной таблицей с проверенными ошибками компиляции, цена `dynamic_cast`, указатели на члены 16 байт, ковариантность, EBO.
- Цепочки вызовов по иерархии: `Base::f()`, три вида бесконечной рекурсии (GCC молчит без `final`), двойной вызов в ромбе, шаблонный метод, цепочка деструкторов.
- 18 ловушек, 8 задач «что напечатается», 22 вопроса с ответами.
- Рабочий пример: [`../../inheritance_demo.cxx`](../../inheritance_demo.cxx).

### 1.22. [`memory_order` и барьеры памяти](22-memory-order-and-fences.md)
- Словарь: гонка, modification order, synchronizes-with, happens-before (simply/strongly из C++20), release sequence, S; store buffer, MESI, TSO.
- Компилятор переставляет сам: GCC 15 `-O2` удалил цикл на обычном `bool`, выбросил запись через relaxed-store, relaxed-читатель вернул старые данные в 100 из 100.
- Шесть порядков по одному: гарантии, применение, x86-код (`mov`/`xchg`/`lock`, `fence(seq_cst)` = `lock orq $0,(%rsp)`), ARM64 и POWER по таблицам (не проверено).
- Litmus-тесты на живых потоках: SB `0 0` в 4–18 % с relaxed/acq-rel и 0 с seq_cst; MP, LB, IRIW, 2+2W, WRC, CoRR — 0 на x86 и почему это не делает relaxed корректным.
- Барьеры: три правила синхронизации, место барьера, `atomic_signal_fence`, компиляторный барьер; NT-записи и `sfence`; `pause` ускоряет пинг-понг вдвое (92 против 170 нс).
- CAS: weak/strong, failure-порядки (GCC молчит, ловит `_GLIBCXX_ASSERTIONS`), `x = x + 1` не RMW, padding в C++20; паттерны: TTAS, refcount, DCLP, seqlock, SPSC, Петерсон.
- Цены: `mov` 0.1 нс, `lock`/`xchg` 3.9 нс, `mfence` 8.0 нс, круг между ядрами 69–92 нс; TSan ловит relaxed вместо release, но не понимает барьеры; 30 вопросов, 12 задач.
- Рабочий пример: [`../../memory_order_demo.cxx`](../../memory_order_demo.cxx).
