# Memory arenas, pools, allocators, and C++ memory resources

This guide explains how applications organize memory *within* the regions supplied
by the operating system. It covers memory arenas, bump allocation, pools, slabs,
free lists, stack allocators, general-purpose heaps, and C++ `std::pmr`.

The central design question is: **which allocations have related lifetimes, and
who can safely decide that their storage is reusable?** An allocator's speed
matters only after its ownership, alignment, and lifetime rules are correct.

**Baseline:** C++20, with Linux examples used when discussing the operating-system
layer. The complete programs use standard C++20 facilities. Standard-library
guarantees are distinguished from implementation choices in malloc, jemalloc,
and TCMalloc. References were checked on 2026-09-26.

Related guides explain [memory pages](25-memory-pages-complete-guide.md),
[mmap](23-mmap-complete-guide.md), and
[memory ordering](24-memory-order-and-barriers-complete-guide.md). This document
builds on them but defines its own allocation terminology.

## Contents

1. [The layers of allocation](#1-the-layers-of-allocation)
2. [What arena means and related vocabulary](#2-what-arena-means-and-related-vocabulary)
3. [Storage, objects, ownership, and lifetime](#3-storage-objects-ownership-and-lifetime)
4. [Comparing allocation strategies](#4-comparing-allocation-strategies)
5. [How a bump arena works](#5-how-a-bump-arena-works)
6. [Complete C++ example: a fixed bump arena](#6-complete-c-example-a-fixed-bump-arena)
7. [Destruction and exception safety](#7-destruction-and-exception-safety)
8. [Growing arenas and memory budgets](#8-growing-arenas-and-memory-budgets)
9. [Checkpoints, stack allocators, and scratch storage](#9-checkpoints-stack-allocators-and-scratch-storage)
10. [Fixed-size pools and a complete typed pool](#10-fixed-size-pools-and-a-complete-typed-pool)
11. [Slabs, size classes, free lists, and buddy allocation](#11-slabs-size-classes-free-lists-and-buddy-allocation)
12. [C++ allocators and std::pmr](#12-c-allocators-and-stdpmr)
13. [Complete C++ example: a bounded PMR arena](#13-complete-c-example-a-bounded-pmr-arena)
14. [Pool resources and layered resource designs](#14-pool-resources-and-layered-resource-designs)
15. [Nested allocations and allocator propagation](#15-nested-allocations-and-allocator-propagation)
16. [Measuring requests, retention, and upstream allocation](#16-measuring-requests-retention-and-upstream-allocation)
17. [Resource lifetime and escaping data](#17-resource-lifetime-and-escaping-data)
18. [Concurrency, thread-local arenas, and remote frees](#18-concurrency-thread-local-arenas-and-remote-frees)
19. [How allocators interact with pages and the OS](#19-how-allocators-interact-with-pages-and-the-os)
20. [Performance and debugging](#20-performance-and-debugging)
21. [Choosing a strategy for real workloads](#21-choosing-a-strategy-for-real-workloads)
22. [Forty interview questions with answers](#22-forty-interview-questions-with-answers)
23. [Exercises with worked answers](#23-exercises-with-worked-answers)
24. [Design checklist and primary references](#24-design-checklist-and-primary-references)

## 1. The layers of allocation

### 1.1 One request can involve several allocators

Consider `std::vector<Record>::push_back`. If the vector needs more capacity,
it requests element storage from its allocator. That request may eventually
reach a general-purpose allocator, which occasionally obtains more virtual
address space from the operating system. Physical pages can be materialized
later when the program accesses the storage.

```text
Application: objects and data structures
                  |
Container allocator / PMR adapter
                  |
Arena, pool, or general-purpose allocation policy
                  |
Upstream storage: caller buffer, new/delete, malloc, mappings, ...
                  |
Operating system: virtual mappings and physical-page management
```

This is a conceptual decomposition, not a universal fixed call chain. C++ does
not require every `operator new` implementation to call malloc, nor every malloc
request to call mmap.

### 1.2 Allocation policy versus storage source

An arena's buffer could come from:

- A local byte array with automatic storage duration.
- A dynamically allocated byte buffer.
- One or more virtual-memory mappings.
- An upstream memory resource, which may itself be another arena or pool.

The source does not determine the arena's lifetime policy. A bump arena backed
by mmap is still a bump arena. A small arena inside a local array is not
magically the same thing as the machine's call stack.

### 1.3 Why write specialized allocation code?

A general-purpose allocator must support many sizes and independent lifetimes.
An application often knows more: all parser nodes die together, all orders have
one size, or temporary work is discarded in reverse order. An allocation strategy
can exploit that information to simplify bookkeeping, reduce contention, improve
locality, or enforce a memory budget.

The tradeoff is a stronger contract. Code that violates that contract can create
dangling references, retain excessive memory, or reuse storage prematurely.

## 2. What arena means and related vocabulary

### 2.1 Application arena: one storage domain with a lifetime policy

A **memory arena** is a region or collection of regions managed together for
allocations. In application code, the term commonly means that allocations
can be discarded together when a request, frame, phase, or computation ends.

An arena is often implemented as a bump allocator, but the words are not exact
synonyms. “Arena” describes a storage-management domain; “bump allocation”
describes a particular way of carving allocations from its current space.

Some arena libraries track object destructors; others manage only raw bytes.
Some are fixed-capacity; others grow. Always ask for the arena's actual contract.

### 2.2 Allocator-internal arena: a different common meaning

A malloc implementation may call an independent collection of heap-management
state an **arena**. Multiple internal arenas can reduce contention among threads
while still supporting ordinary individual `free` operations.

This is different from an application's “reset all request allocations at once”
arena. You should not expect to reset a malloc arena whenever one request ends.
The Linux [malloc manual](https://man7.org/linux/man-pages/man3/malloc.3.html)
and [jemalloc manual](https://jemalloc.net/jemalloc.3.html) describe their respective
implementation behavior and interfaces.

### 2.3 A vocabulary map

| Term | Meaning |
|---|---|
| Allocator | Component that provides and reclaims storage under a contract. |
| Heap | Informal name for dynamically managed storage; not necessarily one contiguous region. |
| Arena / region | Storage managed as a domain, often with shared lifetime. |
| Bump allocator | Advances a cursor through available space to allocate. |
| Monotonic allocator | Does not make individual deallocations available for reuse before a bulk-release boundary. |
| Pool | Supplies reusable allocations from a managed collection; often for one size or a set of size classes. |
| Slab | A larger backing unit divided into slots, often for similar-sized objects. |
| Free list | Metadata linking available blocks or slots. |
| Size class | A category of allocation sizes served by a common block size. |
| Chunk | A larger storage block acquired by an allocator; terminology varies by implementation. |
| Upstream resource | Storage provider used when the current resource needs backing. |
| Scratch memory | Temporary storage for a limited computation or phase. |
| Checkpoint / marker | Saved allocator position used for a later rewind under a strict lifetime rule. |
| High-water mark | Maximum observed usage or retained capacity for a defined metric. |

The term **pool** is especially broad: a raw block pool, a typed object pool,
and `std::pmr::unsynchronized_pool_resource` do not have identical interfaces
or object-lifetime behavior.

### 2.4 Fragmentation and retention

**Internal fragmentation** is unused space inside an allocated unit, including
rounding a 25-byte request to a 32-byte slot. **External fragmentation** is free
space split into pieces unsuitable for a larger request.

**Retention** means keeping backing storage available for later reuse rather
than returning it upstream immediately. It can be intentional. **Lifetime
fragmentation** describes short-lived allocations retained because they share
a region with longer-lived data or because bulk release has not yet occurred.

An arena can reduce allocator bookkeeping while increasing retention. “No
individual free” removes some free-list fragmentation but does not imply zero
waste, zero padding, or minimal resident memory.

## 3. Storage, objects, ownership, and lifetime

### 3.1 Allocation and construction are separate operations

**Storage** is the memory in which an object can exist. **Construction** initializes
an object of a particular type in suitable storage. **Destruction** performs the
type's cleanup. **Deallocation** releases storage under its allocator's rules.

```text
obtain storage -> construct object -> use object -> destroy object -> reclaim storage
```

The steps can be combined by a high-level interface, but they are conceptually
different. A `new T(args...)` expression normally obtains storage and constructs T.
The allocation function `::operator new` by itself does not run T's constructor.

### 3.2 Placement construction

**Placement new** constructs an object at supplied storage using an appropriate
placement form; it does not acquire that backing region. C++20 `std::construct_at`
provides a standard helper for constructing at a suitable address.

`std::destroy_at` destroys a live object but does not generally return its storage
to an allocator. A pointer cast does not substitute for construction of an
arbitrary nontrivial object. See the C++20
[lifetime rules](https://timsong-cpp.github.io/cppwp/n4861/basic.life) and
[placement allocation functions](https://timsong-cpp.github.io/cppwp/n4861/new.delete.placement).

### 3.3 Ownership versus references

An **owner** is responsible for an object's lifetime or storage. A **borrowed
reference** provides access without extending that lifetime. Raw pointers,
`std::span`, and `std::string_view` commonly act as borrowed views.

An arena can own backing bytes while another object owns destruction duties.
For example, a PMR vector destroys its elements, while a monotonic resource
retains the storage until a later release.

If the arena resets, its old allocations must no longer be used. A pointer
remaining numerically unchanged does not prove that the old object still exists.
The same address may now hold an unrelated new object.

### 3.4 RAII still matters

**RAII**, resource acquisition is initialization, ties cleanup to a C++ object's
lifetime. Arena-based designs still need it for files, locks, sockets, strings,
and other resources with cleanup obligations.

Skipping a destructor may leak resources even if the arena's raw bytes are
eventually reclaimed. Arena reset is a storage operation unless its documented
contract explicitly includes object destruction.

### 3.5 Member declaration order can encode dependencies

Members are constructed in declaration order and destroyed in reverse declaration
order. If a class owns a buffer, a resource using that buffer, and a container
using that resource, the dependency order should be:

```text
declare buffer first
declare resource second
declare container third

destruction: container -> resource -> buffer
```

Moving such a wrapper can be dangerous if a resource refers to the wrapper's
own buffer address. Do not default move operations without checking whether
the internal pointers remain valid.

## 4. Comparing allocation strategies

| Strategy | Allocation shape | Reclamation shape | Good fit | Main tradeoff |
|---|---|---|---|---|
| General-purpose allocator | Many sizes | Arbitrary individual frees | General application objects | More complex metadata and slow paths. |
| Fixed bump arena | Variable sizes within a buffer | Whole reset | Bounded request/frame work | Capacity exhaustion and retained dead allocations. |
| Growing monotonic arena | Variable sizes across chunks | Whole release | Parsing or batch processing | Growth and high-water retention. |
| Stack allocator | Nested allocations | Reverse order / checkpoint rewind | Nested scratch work | Lifetime order must be respected. |
| Fixed-size pool | One slot size | Individual slot return | Frequently recycled nodes | Waste for mismatched types; fixed capacity if bounded. |
| Segregated pools | Several size classes | Individual block return | Mixed small objects | Size-class rounding and partially used slabs. |
| Buddy allocator | Power-of-two blocks | Coalescing buddies | Page/block management | Rounding waste and granularity. |
| Compacting design | Movable managed objects | Move survivors, reclaim gaps | Handle-based systems | Pointer stability and relocation complexity. |

**LIFO**, last in, first out, is the order a stack allocator can exploit.
**FIFO**, first in, first out, can support some ring-buffer or queue storage
designs. Neither order is guaranteed for arbitrary application allocations.

Choose by lifetime distribution and access pattern, not by the claim that one
allocator is “the fastest.” A fixed pool suitable for orders may be a poor
choice for variable-sized response strings.

## 5. How a bump arena works

### 5.1 The cursor

A simple arena owns a byte range and a cursor indicating the next available
position. To allocate N bytes aligned to A:

1. Find the first suitably aligned address at or after the cursor.
2. Check that padding plus N bytes fits.
3. Return the aligned address and advance the cursor past the allocation.

```text
buffer start                                            buffer end
| object 1 | padding | object 2 | unused space.....................|
                               ^ next cursor
```

There is no per-allocation search for a free block. The fast path can use a
small bounded amount of arithmetic. Object constructors and backing growth
remain additional work.

### 5.2 Alignment is a correctness requirement

**Alignment** requires an address to be an appropriate multiple for a type.
`alignof(T)` gives the type's requirement. `alignas` requests alignment for a
declared object. Some types are **over-aligned**, requiring more than the ordinary
fundamental alignment.

An arena must align the actual candidate address, not merely round its byte
count. If the buffer base is misaligned, aligning only an offset can still
produce an invalid pointer.

`std::align` adjusts a candidate pointer within available storage while accounting
for alignment padding. On failure it returns null. On success it reduces the
available-space argument by the padding, not by the requested object's size.
See [C++20 alignment helpers](https://timsong-cpp.github.io/cppwp/n4861/ptr.align).

### 5.3 What reset means

In a fixed arena, reset can set the cursor back to the beginning. That can be
constant-time storage bookkeeping, but it neither zeroes bytes nor automatically
destroys every nontrivial object.

If reset destroys N objects, releases multiple upstream chunks, poisons memory
for debugging, or clears all bytes, its total cost is no longer just one cursor
assignment. State which operation your complexity claim describes.

### 5.4 Three important policies

- **Zero-size allocation:** reject it, normalize it, or follow a specified resource
  contract. Do not leave its effect on cursor progress accidental.
- **Exhaustion:** throw, return failure, grow, or invoke a documented fallback.
- **Thread access:** confine the arena to one owner, synchronize it, or implement
  a more specialized reservation protocol.

These are application decisions, not properties inferred from the word arena.

## 6. Complete C++ example: a fixed bump arena

Save as `bump_arena.cpp`. This arena manages raw storage only, has no upstream
fallback, and is not thread-safe. A zero-byte request consumes one byte.

```cpp
#include <array>
#include <cassert>
#include <cstddef>
#include <cstdint>
#include <iostream>
#include <memory>
#include <new>
#include <stdexcept>

class BumpArena {
    alignas(std::max_align_t) std::array<std::byte, 1024> storage_;
    std::size_t used_ = 0;
public:
    BumpArena() = default;
    BumpArena(const BumpArena&) = delete;
    BumpArena& operator=(const BumpArena&) = delete;
    BumpArena(BumpArena&&) = delete;
    BumpArena& operator=(BumpArena&&) = delete;

    void* allocate(std::size_t bytes, std::size_t alignment) {
        if (alignment == 0 || (alignment & (alignment - 1)) != 0)
            throw std::invalid_argument("alignment must be a power of two");
        if (bytes == 0) bytes = 1;
        void* candidate = storage_.data() + used_;
        std::size_t space = storage_.size() - used_;
        void* result = std::align(alignment, bytes, candidate, space);
        if (!result) throw std::bad_alloc();
        used_ = storage_.size() - space + bytes;
        return result;
    }

    std::size_t used_bytes() const noexcept { return used_; }
    void reset() noexcept { used_ = 0; } // Requires no remaining live users.
};

struct alignas(64) Record {
    int value;
    explicit Record(int n) : value(n) {}
};

int main() {
    BumpArena arena;
    (void)arena.allocate(3, 1); // Force alignment padding for the next request.
    void* memory = arena.allocate(sizeof(Record), alignof(Record));
    Record* record = std::construct_at(static_cast<Record*>(memory), 42);
    assert(record->value == 42);
    assert(reinterpret_cast<std::uintptr_t>(record) % alignof(Record) == 0);

    const auto before = arena.used_bytes();
    bool failed = false;
    try { (void)arena.allocate(2048, alignof(std::max_align_t)); }
    catch (const std::bad_alloc&) { failed = true; }
    assert(failed && arena.used_bytes() == before);

    std::destroy_at(record);
    arena.reset();
    assert(arena.used_bytes() == 0);
    std::cout << "alignment, exhaustion, and reset passed\n";
}
```

Build each complete program separately, for example:

```sh
g++ -std=c++20 -O2 -Wall -Wextra -Wpedantic bump_arena.cpp -o bump_arena
./bump_arena
```

The code uses `std::align` so a suitably aligned position can be found inside
the available buffer even for the demonstrated 64-byte-aligned type. Padding
consumes capacity. The allocator updates its cursor only after allocation
succeeds, preserving its state on capacity failure.

This is not a complete standard-container allocator: it has no allocator-traits
interface, typed construction policy, or PMR virtual interface. Its purpose
is to show the central storage algorithm and its contract.

## 7. Destruction and exception safety

### 7.1 Two common arena models

A **raw-storage arena** only provides bytes. Its users track object destruction.
A **destructor-tracking arena** also records cleanup actions, often in a list
that can be run in reverse construction order during teardown.

Destructor tracking adds work and metadata, and ordering matters if one object's
destructor depends on another. Neither model is automatically superior; the
important point is making the obligations explicit.

### 7.2 Construction can fail after allocation

A constructor can throw. Then storage has been reserved but no complete object
was constructed. An arena can retain those consumed bytes until reset while
preserving logical exception safety; that is retention, not necessarily a leak
outside the arena's ownership.

A checkpoint can recover the space only if no intervening valid allocations
must survive. Constructors can call other code that allocates from the same
arena, so a blind cursor rollback can invalidate more than the failed object's
own storage.

### 7.3 Strong exception guarantee is not a promise of zero retained bytes

The **strong exception guarantee** means a failed operation leaves the specified
observable state unchanged. A container operation can satisfy that guarantee
while a monotonic backing resource retains memory from an unsuccessful attempt.

For a hard memory budget, track failure-path allocation as well as successful
payload size. Repeated rejected work can exhaust a phase arena even if the
container repeatedly rolls back its logical contents.

### 7.4 Complete example: PMR construction with RAII destruction

Save as `pmr_object_lifetime.cpp`:

```cpp
#include <array>
#include <cassert>
#include <cstddef>
#include <iostream>
#include <memory>
#include <memory_resource>
#include <stdexcept>

struct Tracked {
    inline static int live = 0;
    int value;
    explicit Tracked(int n) : value(n) {
        if (n < 0) throw std::invalid_argument("negative value");
        ++live;
    }
    ~Tracked() noexcept { --live; }
};

struct ResourceDeleter {
    std::pmr::memory_resource* resource;
    void operator()(Tracked* p) const noexcept {
        std::pmr::polymorphic_allocator<> allocator(resource);
        allocator.delete_object(p);
    }
};

int main() {
    alignas(std::max_align_t) std::array<std::byte, 1024> buffer;
    std::pmr::monotonic_buffer_resource arena(
        buffer.data(), buffer.size(), std::pmr::null_memory_resource());
    std::pmr::polymorphic_allocator<> allocator(&arena);
    {
        std::unique_ptr<Tracked, ResourceDeleter> owner(
            allocator.new_object<Tracked>(7), ResourceDeleter{&arena});
        assert(Tracked::live == 1 && owner->value == 7);
        bool rejected = false;
        try { (void)allocator.new_object<Tracked>(-1); }
        catch (const std::invalid_argument&) { rejected = true; }
        assert(rejected && Tracked::live == 1);
    }
    assert(Tracked::live == 0);
    arena.release();
    std::cout << "construction failure and RAII destruction passed\n";
}
```

C++20 `new_object` combines resource allocation with uses-allocator construction
and returns storage through the allocator on construction failure. A monotonic
resource's individual deallocation is still a no-op, so those bytes may remain
consumed until release. `delete_object` destroys the object and deallocates its
storage through the correct resource. See
[polymorphic_allocator members](https://timsong-cpp.github.io/cppwp/n4861/mem.poly.allocator.mem).

The custom deleter is necessary: the ordinary `unique_ptr<T>` deleter would
use a normal delete expression, which is not the matching release protocol
for this resource allocation. The resource must outlive the owning pointer.

## 8. Growing arenas and memory budgets

### 8.1 Add chunks without moving old objects

A growing arena acquires another backing chunk when its current chunk cannot
satisfy a request. Previously returned pointers normally remain stable because
the old chunks remain in place. Growing one backing `std::vector<std::byte>`
and allowing it to reallocate would not have that property.

Geometric growth, such as increasing requested chunk sizes by some factor,
can reduce upstream calls. The exact growth factor of a standard monotonic
resource is implementation-defined; do not budget as though every implementation
always doubles its buffers.

An unusually large request may receive a dedicated chunk so it does not waste
the current small-object chunk. That is a policy choice, not an automatic property
of every arena.

### 8.2 Budget for more than live payload

An arena's consumption can include:

- Current live objects.
- Dead objects whose storage cannot yet be reused.
- Alignment padding.
- Old container backing arrays retained after growth.
- Unused tails of chunks.
- Allocator metadata and cleanup records.
- Failed-construction allocations retained until reset.

If a vector uses capacities 8, 16, 32, and 64, a monotonic resource can retain
all four arrays until release, even though the vector uses only the final one.
The total here is 120 element slots, before padding and resource chunk effects.
Those capacities are illustrative, not a standard-mandated vector growth sequence.

Use `reserve` when a credible bound is known. Repeatedly reserving one more
element than the current size can force inefficient growth and increase retention.

### 8.3 Exhaustion policies must be observable

A fixed arena with a heap fallback is not a hard allocation bound. A resource
with a null upstream fails when its local budget cannot satisfy a request.
Choose whether the caller should reject the request, retry with a different
budget, or route to a deliberately slower path.

Also budget the number of arenas and concurrent requests. A modest per-request
limit multiplied by many active requests can dominate process memory.

## 9. Checkpoints, stack allocators, and scratch storage

### 9.1 Save a position, then rewind

A stack-style allocator can save a cursor marker before nested temporary work,
then rewind to it after the work finishes. Allocations before the marker survive;
allocations after it become invalid.

```text
| persistent within phase | temporary A | temporary B | unused |
                         ^ marker

after destroying A/B and rewinding:
| persistent within phase | reusable space.....................|
```

Markers should belong to a particular arena and generation. A numeric offset
alone does not prove that a marker from an earlier reset is still valid.

### 9.2 Rewind does not undo arbitrary program state

An object before the marker may have stored a pointer to an object after it.
Rewind makes that pointer dangle. A destructor may need to undo external resources
or registrations; a cursor change does not do so.

A useful scope guard can ensure rewind on exit, but only after required object
destruction and provided nothing from the scratch scope escapes. Exception safety
includes these relationships, not just restoring the cursor.

### 9.3 Stack, double-ended, and frame allocators

A **stack allocator** enforces reverse-order release. A **double-ended arena**
can allocate from both ends for two categories of temporary work, checking that
the cursors never overlap. A **frame allocator** resets at a frame boundary in
a renderer, simulation, or batch pipeline.

If asynchronous work can outlive a frame, multiple buffers and explicit completion
tracking may be needed. Cycling through two arenas is safe only when the old
users of an arena have actually finished; “two frames should be enough” is not
a lifetime proof.

## 10. Fixed-size pools and a complete typed pool

### 10.1 Reuse individual slots

A fixed-size pool divides storage into slots appropriate for one type or block
size. Allocation removes a slot from a free list; deallocation returns it.
This supports independent object lifetimes without waiting for a whole arena reset.

An **intrusive free list** stores its links inside currently unused slots.
This saves separate metadata but requires correct alignment and lifetime transitions
between a link object and a payload object. Side metadata is often easier to audit.

### 10.2 Handles and stale-slot detection

A **handle** can identify a slot by index and generation. Each reuse changes the
generation, allowing an API to reject a handle for the slot's previous occupant.
A raw pointer cannot provide that identity check on its own.

The following pool uses `std::optional<T>` for typed storage and a side free list.
This avoids a union/raw-storage lifetime tutorial inside the pool example.
It is single-threaded; all returned references remain subject to its lifetime rules.

Save as `typed_pool.cpp`:

```cpp
#include <array>
#include <cassert>
#include <cstddef>
#include <iostream>
#include <limits>
#include <new>
#include <optional>
#include <stdexcept>
#include <type_traits>
#include <utility>

template<class T, std::size_t N>
class Pool {
    static_assert(N > 0 && std::is_nothrow_destructible_v<T>);
    struct Slot {
        std::optional<T> value;
        std::size_t next = N;
        std::size_t generation = 0;
    };
    std::array<Slot, N> slots_{};
    std::size_t free_ = 0;
public:
    struct Handle {
        const Pool* owner;
        std::size_t index;
        std::size_t generation;
    };
    Pool() {
        for (std::size_t i = 0; i < N; ++i) slots_[i].next = i + 1;
    }
    Pool(const Pool&) = delete;
    Pool& operator=(const Pool&) = delete;
    Pool(Pool&&) = delete;
    Pool& operator=(Pool&&) = delete;

    template<class... Args>
    Handle create(Args&&... args) {
        if (free_ == N) throw std::bad_alloc();
        const auto index = free_;
        auto& slot = slots_[index];
        slot.value.emplace(std::forward<Args>(args)...);
        free_ = slot.next; // Commit only after successful construction.
        return {this, index, slot.generation};
    }

    T& get(Handle h) {
        if (h.owner != this || h.index >= N ||
            !slots_[h.index].value || slots_[h.index].generation != h.generation)
            throw std::invalid_argument("invalid or stale pool handle");
        return *slots_[h.index].value;
    }

    void destroy(Handle h) {
        (void)get(h); // Validate before changing anything.
        auto& slot = slots_[h.index];
        slot.value.reset();
        if (slot.generation == std::numeric_limits<std::size_t>::max())
            return; // Retire instead of wrapping and reviving an old handle.
        ++slot.generation;
        slot.next = free_;
        free_ = h.index;
    }
};

struct Item {
    inline static int live = 0;
    int value;
    explicit Item(int n) : value(n) {
        if (n < 0) throw std::invalid_argument("negative item");
        ++live;
    }
    ~Item() noexcept { --live; }
};

int main() {
    {
        Pool<Item, 2> pool;
        auto a = pool.create(10);
        auto b = pool.create(20);
        bool full = false;
        try { (void)pool.create(30); } catch (const std::bad_alloc&) { full = true; }
        assert(full);
        pool.destroy(a);
        auto c = pool.create(30);
        assert(c.index == a.index && pool.get(c).value == 30);
        bool stale = false;
        try { (void)pool.get(a); } catch (const std::invalid_argument&) { stale = true; }
        assert(stale);
        pool.destroy(b);
        bool rejected = false;
        try { (void)pool.create(-1); }
        catch (const std::invalid_argument&) { rejected = true; }
        assert(rejected);
        auto d = pool.create(40);
        assert(pool.get(d).value == 40 && Item::live == 2);
    }
    assert(Item::live == 0);
    std::cout << "pool exhaustion, reuse, stale handles, and cleanup passed\n";
}
```

Free-list operations are constant-time apart from T's constructor/destructor.
Pool destruction visits its slots and destroys any remaining live optionals.
Objects with interdependent destruction requirements need an explicit teardown
order rather than assuming array destruction is the right semantic order.

A handle does not own the pool. It must not outlive it, and owner-address reuse
after pool destruction is outside this example's contract. References returned
by `get` are not tracked: destroying that slot while retaining a reference still
creates a dangling reference. The generation check occurs only when the API
validates a handle.

## 11. Slabs, size classes, free lists, and buddy allocation

### 11.1 Slabs and partial occupancy

A slab contains multiple slots. One possible design tracks empty, partially used,
and full slabs. Returning a slot makes it reusable, but returning the slab to
its upstream provider may require every slot in that slab to be free.

One long-lived object per slab can therefore retain much more backing than its
payload size suggests. This is one reason grouping objects by expected lifetime
can matter as much as grouping them by size.

### 11.2 Segregated size classes

A general small-object allocator can offer classes such as 16, 32, 48, and 64
bytes, with different real implementations choosing different sequences.
A request goes to a fitting class, paying rounding overhead in exchange for
fast slot management.

For example, a 33-byte object in a 48-byte slot leaves 15 bytes of internal
waste before considering other metadata. Over-alignment can alter the chosen
class or force a different path.

### 11.3 Variable-size free lists and coalescing

A variable-size allocator tracks blocks of differing lengths. **Splitting**
divides a larger free block to satisfy a smaller request. **Coalescing** combines
adjacent free blocks to make larger requests possible.

First-fit, best-fit, bins, trees, and boundary metadata are possible strategies,
with different search and fragmentation tradeoffs. A free list can be constant-time
for fixed slots without being constant-time for every variable-size policy.

### 11.4 Buddy allocation is another level of granularity

Buddy allocation splits and combines aligned power-of-two blocks. It is useful
in page and block management, but rounding every small application object up
to a power of two is not automatically a good workload fit.

Kernel physical-page allocation, user-space allocator slabs, and application
typed pools can coexist. Use the term that identifies the layer you are discussing.

## 12. C++ allocators and std::pmr

### 12.1 The standard allocator interface

A container allocator describes how to allocate storage for elements and how
the container interacts with allocation-related operations. `std::allocator_traits`
provides a uniform interface and defaults for supported operations.

An allocator must meet its requirements: size/alignment, allocation/deallocation
compatibility, supported value types, equality, and relevant propagation behavior.
A function returning arbitrary bytes is not automatically a valid allocator for
`std::vector`. See
[C++20 allocator requirements](https://timsong-cpp.github.io/cppwp/n4861/allocator.requirements).

### 12.2 PMR separates the container's type from the resource policy

**PMR** means polymorphic memory resource. The useful pieces are:

- `std::pmr::memory_resource`: a runtime interface for allocating/deallocating
  byte counts with alignment and checking resource equality.
- `std::pmr::polymorphic_allocator<T>`: an allocator adapter that delegates to
  a memory resource.
- `std::pmr::vector<T>` and similar aliases: standard containers using that adapter.

Two PMR vectors can have the same C++ type while using different resources.
**Runtime polymorphism** means the concrete allocation behavior can be selected
through an interface at runtime rather than changing the container's template type.

### 12.3 Standard resource choices

| Resource | Behavior |
|---|---|
| `new_delete_resource()` | Uses matching new/delete allocation facilities for storage. |
| `null_memory_resource()` | Allocation throws `std::bad_alloc`; useful as a bounded resource's upstream. |
| `monotonic_buffer_resource` | Fast grouped allocation; individual deallocate calls have no effect. |
| `unsynchronized_pool_resource` | Size-based reusable pools without synchronization for concurrent access. |
| `synchronized_pool_resource` | Pool resource whose interface supports concurrent access. |
| Default resource | Resource selected when a polymorphic allocator is default-constructed. |

Resources usually do not own arbitrary T objects placed in their storage, and
containers generally do not own their resource. Those two facts explain many
lifetime mistakes. See the [C++20 resource interfaces](https://timsong-cpp.github.io/cppwp/n4861/mem.res).

### 12.4 Resource equality means deallocation compatibility

Equal resources promise the relevant cross-deallocation compatibility. Equality
is not merely “same resource class” or “same upstream pointer.” Two independent
monotonic arenas are distinct allocation domains.

When a custom resource intercepts allocation for accounting, equal upstreams
do not automatically make two wrappers equal: cross-deallocation might violate
the wrappers' bookkeeping. Section 16 uses identity equality for this reason.

## 13. Complete C++ example: a bounded PMR arena

Save as `bounded_pmr.cpp`. Both vector storage and the nested PMR strings use
the chosen arena. The null upstream makes its capacity failure explicit.

```cpp
#include <array>
#include <cassert>
#include <cstddef>
#include <iostream>
#include <memory_resource>
#include <new>
#include <string>
#include <vector>

int main() {
    alignas(std::max_align_t) std::array<std::byte, 4096> buffer;
    std::pmr::monotonic_buffer_resource arena(
        buffer.data(), buffer.size(), std::pmr::null_memory_resource());
    {
        std::pmr::vector<std::pmr::string> names(&arena);
        names.reserve(4);
        names.emplace_back(80, 'a');
        names.emplace_back(120, 'b');
        assert(names[0].size() == 80 && names[1].size() == 120);
        for (const auto& name : names)
            assert(name.get_allocator().resource() == &arena);

        bool exhausted = false;
        try { (void)arena.allocate(buffer.size() * 2, alignof(std::max_align_t)); }
        catch (const std::bad_alloc&) { exhausted = true; }
        assert(exhausted);
    } // Containers and strings are destroyed before release.
    arena.release();
    std::cout << "bounded nested PMR allocation passed\n";
}
```

The declared buffer is local to main, but the resource could instead refer to
stable storage owned elsewhere. Its backing lifetime must remain long enough.

If no null upstream were supplied, exhausting the initial buffer could request
additional upstream storage. An initial buffer is therefore not automatically
a hard cap. This cap also covers only allocations routed through this resource;
I/O, exception objects, libraries, and unrelated allocations are separate.

`release` returns upstream chunks and resets the monotonic resource for reuse
under its specified behavior; it does not destroy live container elements for
you. The caller-supplied initial buffer remains owned by the caller. See
[monotonic resource behavior](https://timsong-cpp.github.io/cppwp/n4861/mem.res.monotonic.buffer)
and the [clarified release wording](https://eel.is/c++draft/mem.res.monotonic.buffer.mem).

## 14. Pool resources and layered resource designs

### 14.1 Standard pools are not one fixed-size object pool

PMR pool resources manage pools for different request sizes. Requests exceeding
the relevant pool limit can go directly upstream. `pool_options` influences
parameters such as pooling limits and blocks per chunk; it is not a universal
exact layout specification.

Their deallocation can make blocks reusable, unlike a monotonic resource's
no-op individual deallocation. A pool can retain chunks after all container
elements are erased. `release` returns the resource's backing under its contract,
but the caller must first finish all uses of affected allocations.
See [C++20 pool resources](https://timsong-cpp.github.io/cppwp/n4861/mem.res.pool).

### 14.2 The resource graph controls retention

```text
request vectors -> monotonic arena -> reusable pool -> new/delete resource
```

At request end, the arena returns its chunks to the pool. The pool can reuse
them for future requests without immediately releasing them further upstream.
This can reduce allocation churn while retaining a high-water amount of memory.

Reverse the order:

```text
short-lived nodes -> reusable pool -> monotonic arena -> new/delete resource
```

The pool can recycle nodes internally, but returning a pool chunk to the
monotonic upstream does not individually reclaim it there. Repeatedly destroying
and rebuilding such pools within one long-lived monotonic arena can accumulate
retained storage until that outer arena releases.

Neither layering is automatically wrong. The graph must match the lifetime
boundary and retention budget. Release/destroy consumers before the resources
they depend on, then proceed upstream.

## 15. Nested allocations and allocator propagation

### 15.1 An outer PMR container does not redirect every nested allocation

`std::pmr::vector<std::string>` uses its resource for the vector's element array.
The ordinary strings still have their ordinary allocator for character storage.

`std::pmr::vector<std::pmr::string>` allows allocator-aware construction to pass
the resource to the nested strings. Merely putting `std::pmr::string` as a member
of a custom `Record` does not automatically make Record allocator-aware.

**Uses-allocator construction** is the library protocol for supplying an allocator
to a type that advertises compatible allocator-aware constructors. A custom
type must implement that protocol or explicitly accept and forward a resource.
See [C++20 uses-allocator construction](https://timsong-cpp.github.io/cppwp/n4861/allocator.uses.construction).

### 15.2 Copying, moving, and swapping can change the allocation story

For ordinary PMR containers:

- Copy construction without an explicit allocator selects a default-constructed
  polymorphic allocator, using the default resource selected at that time.
- Copy assignment retains the destination resource.
- Move construction without an explicit allocator carries the source allocator.
- Move assignment retains the destination resource; unequal resources can require
  moving elements into newly allocated destination storage.
- Swapping containers with unequal, non-propagating allocators violates the
  relevant container precondition; it is not a supported slow fallback.

These are important reasons to pass a destination resource deliberately across
lifetime boundaries. A move does not turn a borrowed resource into an owned one.
See [container allocator rules](https://timsong-cpp.github.io/cppwp/n4861/container.requirements.general)
and [polymorphic allocator copy selection](https://timsong-cpp.github.io/cppwp/n4861/mem.poly.allocator.mem).

### 15.3 Complete program: verify resource selection

Save as `pmr_propagation.cpp`:

```cpp
#include <cassert>
#include <iostream>
#include <memory_resource>
#include <string>
#include <utility>
#include <vector>

int main() {
    std::pmr::monotonic_buffer_resource source_resource;
    std::pmr::monotonic_buffer_resource destination_resource;
    auto* default_resource = std::pmr::get_default_resource();
    std::pmr::vector<std::pmr::string> source(&source_resource);
    source.emplace_back(100, 'x');
    assert(source[0].get_allocator().resource() == &source_resource);

    auto default_copy = source;
    assert(default_copy.get_allocator().resource() == default_resource);
    assert(default_copy[0].get_allocator().resource() == default_resource);

    std::pmr::vector<std::pmr::string> explicit_copy(source, &destination_resource);
    assert(explicit_copy[0].get_allocator().resource() == &destination_resource);

    std::pmr::vector<std::pmr::string> assigned(&destination_resource);
    assigned = std::move(source);
    assert(assigned.get_allocator().resource() == &destination_resource);
    assert(assigned[0].get_allocator().resource() == &destination_resource);
    assert(assigned[0].size() == 100);
    // Do not assert that source is empty: its moved-from state is valid but unspecified.
    // Do not swap containers whose non-propagating resources compare unequal.
    std::cout << "nested allocation and propagation checks passed\n";
}
```

The program does not change the global default resource; that avoids hidden
effects on unrelated allocations. Both explicit resources outlive every container
using them because of declaration order.

## 16. Measuring requests, retention, and upstream allocation

### 16.1 What exactly are you counting?

An allocation request is not necessarily an operating-system allocation. A vector
may request 400 bytes from a monotonic resource; that resource may obtain a larger
chunk from its upstream resource; the general-purpose allocator may satisfy that
chunk from pages it already owns. These are three different accounting events.

**Outstanding requested bytes** are bytes allocated through an interface and not
yet deallocated through that interface. **Peak outstanding bytes**, or a high-water
mark, are the maximum of that quantity over time. Neither is automatically RSS
(resident set size: the process's currently resident physical memory accounting).

Place a counter above an arena to observe client requests. Place it below the
arena to observe the chunks the arena retains. Compare both to discover overhead
from padding, growth, and storage retained after client deallocation. The counter
below tracks its own interface only; allocator metadata and rounding below that
interface are outside its measurements.

### 16.2 Complete C++ example: counting upstream storage

Save as `counting_resource.cpp`:

```cpp
#include <cassert>
#include <cstddef>
#include <iostream>
#include <limits>
#include <memory_resource>
#include <new>
#include <vector>

class CountingResource final : public std::pmr::memory_resource {
    std::pmr::memory_resource* upstream_;
    std::size_t current_ = 0;
    std::size_t peak_ = 0;
    std::size_t calls_ = 0;

    void* do_allocate(std::size_t bytes, std::size_t alignment) override {
        constexpr auto max = std::numeric_limits<std::size_t>::max();
        if (bytes > max - current_ || calls_ == max) throw std::bad_alloc();
        void* p = upstream_->allocate(bytes, alignment); // May throw.
        current_ += bytes; // Commit statistics only after success.
        if (current_ > peak_) peak_ = current_;
        ++calls_;
        return p;
    }
    void do_deallocate(void* p, std::size_t bytes,
                       std::size_t alignment) override {
        assert(bytes <= current_);
        upstream_->deallocate(p, bytes, alignment);
        current_ -= bytes;
    }
    bool do_is_equal(const std::pmr::memory_resource& other) const noexcept override {
        return this == &other;
    }
public:
    explicit CountingResource(std::pmr::memory_resource* upstream =
                              std::pmr::new_delete_resource())
        : upstream_(upstream) {}
    std::size_t current() const noexcept { return current_; }
    std::size_t peak() const noexcept { return peak_; }
    std::size_t calls() const noexcept { return calls_; }
};

int main() {
    CountingResource upstream;
    {
        std::pmr::monotonic_buffer_resource arena(&upstream);
        {
            std::pmr::vector<int> values(&arena);
            values.resize(100, 7);
            assert(values.back() == 7);
        }
        // The vector deallocated its array; the arena still retains its chunks.
        assert(upstream.current() > 0);
        std::cout << "retained after vector destruction: " << upstream.current()
                  << " bytes; peak: " << upstream.peak()
                  << "; upstream calls: " << upstream.calls() << '\n';
    }
    assert(upstream.current() == 0);
    {
        std::pmr::unsynchronized_pool_resource pool(&upstream);
        for (int iteration = 0; iteration < 10; ++iteration) {
            std::pmr::vector<int> values(&pool);
            values.resize(32, iteration);
            assert(values[0] == iteration);
        }
        // Exact chunk sizes and reuse decisions are implementation-dependent.
    }
    assert(upstream.current() == 0);
    std::cout << "all upstream storage returned\n";
}
```

Compile every complete program in this guide with, for example:

```bash
g++ -std=c++20 -O2 -Wall -Wextra -Wpedantic counting_resource.cpp -o counting_resource
./counting_resource
```

This counter is intentionally single-threaded. Its upstream must be non-null and
outlive it. Identity-based equality prevents deallocations from bypassing the
counter that recorded the allocation. An aggregate byte assertion cannot detect
every invalid free: matching pointer, size, and alignment are still caller
obligations. A diagnostic allocator could maintain a pointer-to-request table,
but must avoid recursively allocating that table through itself.

## 17. Resource lifetime and escaping data

### 17.1 Containers borrow their resources

A PMR container stores an allocator referring to a resource. It does not normally
own that resource. Returning a container backed by a local resource creates a
lifetime bug, even if return-value optimization eliminates a container move:

```cpp
// WRONG: illustrative fragment, do not execute.
std::pmr::vector<int> make_values() {
    std::pmr::monotonic_buffer_resource local;
    std::pmr::vector<int> result(&local);
    result.push_back(42);
    return result; // local dies; result still refers to local and its storage.
}
```

Valid designs include accepting a caller-owned resource, copying the result into
a longer-lived destination resource, or returning an owning aggregate that keeps
the backing storage, resource, and objects alive together. In that aggregate,
declare backing storage first, then resource, then containers; destruction runs
in reverse declaration order. Moving such an aggregate needs deliberate design:
pointers to its embedded resource or buffer must not silently keep pointing into
the old object. Deleting moves is often the clearest initial design.

### 17.2 Clear is not release

`vector.clear()` destroys elements but retains capacity. A later `push_back` can
write into that array without requesting a new allocation. Therefore this is
invalid as a general reset protocol:

```cpp
// WRONG: the vector still retains its allocation.
values.clear();
arena.release();
values.push_back(42);
```

Destroy the container before releasing its resource. The same issue applies to
retained hash-table buckets and other internal allocations. `shrink_to_fit()` is
a non-binding request and is not a lifetime protocol. In a monotonic arena,
allocating a smaller array can retain both the old array and the replacement
until bulk release.

### 17.3 An escaping view is still an escaping dependency

A `span`, `string_view`, iterator, reference, or raw pointer does not own the
storage it exposes. A lambda capturing one by value copies the view, not its
contents. Posting that lambda to an asynchronous worker can extend its use past
the request arena's reset. Either finish the work before reset, transfer an owner
of the whole arena, or copy the required data into an independently owned region.

Shared ownership of the resource alone is insufficient if its external backing
buffer dies first. Follow the complete dependency chain.

## 18. Concurrency, thread-local arenas, and remote frees

### 18.1 Allocation safety and object safety are separate

`unsynchronized_pool_resource` is not a resource for concurrent unsynchronized
access. `synchronized_pool_resource` coordinates its resource operations, but does
not make a vector using it safe for concurrent mutation. A resource protects
allocation metadata; a container has its own size, capacity, and element state.
The standard specifies these resource distinctions in
[memory resource pools](https://timsong-cpp.github.io/cppwp/n4861/mem.res.pool).

The custom bump arena and counting resource here are also single-threaded. Giving
each thread a separate arena can avoid shared allocation metadata. However, an
arena may be transferred between threads if all prior use has finished and the
handoff is synchronized. “Unsynchronized” does not mean permanently tied to the
thread that constructed it; it means the resource supplies no required mutual
exclusion for concurrent access.

### 18.2 Why an atomic cursor is not a complete concurrent arena

An atomic reservation algorithm can potentially allocate disjoint byte ranges.
It must still handle alignment, overflow, exhaustion, and growth correctly.
After reservation, construction may not have finished. Publishing a pointer to
another thread needs synchronization that makes the initialized object visible.

Reset is harder: every outstanding reader must have stopped using every affected
object. An atomic store of zero to the cursor does not establish that fact. This
is a **reclamation** problem: deciding when previously published memory can be
reused safely. Epochs, reference counts, and explicit task joins solve different
forms of that problem; the right choice depends on ownership and progress needs.
See the [memory-ordering guide](24-memory-order-and-barriers-complete-guide.md).

### 18.3 Remote frees and retained memory

A remote free occurs when one thread frees storage allocated by another. An
allocator may handle it with a shared structure, a transfer queue, or another
implementation-specific mechanism. A per-thread free list alone is not a complete
answer if ownership crosses threads.

Thread-local caches also multiply retention. If 64 threads each retain 8 MiB,
the total is 512 MiB before considering live application objects elsewhere.
Per-thread peaks need not occur simultaneously, but independent caches can retain
their separate historical peaks. Thread exit, draining policies, and idle-worker
behavior matter as much as allocation latency.

[TCMalloc's design](https://google.github.io/tcmalloc/design.html) describes its
front-, middle-, and back-end allocation organization, including per-CPU and
per-thread modes. [jemalloc's manual](https://jemalloc.net/jemalloc.3.html)
documents its arenas and thread caches. These are examples of implementation
policy, not requirements imposed on C++ `new`.

## 19. How allocators interact with pages and the OS

### 19.1 Reusable bytes are not necessarily returned physical pages

There are several progressively stronger events:

1. An object's lifetime ends.
2. Its block becomes reusable by an allocator.
3. A resource returns a chunk to its upstream allocator.
4. That upstream allocator releases or discards backing pages.
5. The process's resident or mapped memory accounting changes.

One event does not imply all the following events. A monotonic resource's
individual deallocation usually stops before step 2 for that individual block;
bulk release advances to returning its upstream chunks. The upstream may retain
them for future allocations. `free` and `delete` are not promises of an immediate
RSS decrease. Linux's [malloc documentation](https://man7.org/linux/man-pages/man3/malloc.3.html)
describes an implementation that obtains memory using mechanisms including the
heap and anonymous mappings.

### 19.2 Reservation, residency, and first touch

Reserving a large virtual region does not mean every page is resident. The first
write to a previously untouched anonymous page may require a page fault and
physical backing. Consequently, a bump allocation can execute a few arithmetic
operations while the following object initialization incurs substantial latency.

Prefaulting means accessing or otherwise populating pages in advance. It can move
some first-touch costs earlier, but does not by itself guarantee permanent
residency, NUMA placement, or bounded runtime latency. NUMA describes systems in
which accessing memory near one CPU can cost differently from accessing memory
attached to another. The thread that initializes an arena can influence placement
under a first-touch policy; the later consumer may run elsewhere.

### 19.3 Page granularity constrains reclamation

An allocator can place many small blocks within a page. It cannot simply discard
that whole page while one live allocation still needs its contents. Grouping
similar lifetimes can produce completely unused pages or chunks sooner. Mixing
one long-lived object into every otherwise short-lived chunk can prevent useful
reclamation despite very low live-byte utilization.

Huge pages increase translation coverage, but a huge allocation granularity can
complicate fine-grained reclamation. There is no universal rule that an arena
should use huge pages. Measure translation pressure, residency, fragmentation,
and workload access patterns together. See [memory pages](25-memory-pages-complete-guide.md).

### 19.4 Can an arena live inside shared memory?

Yes, but shared backing does not make an ordinary C++ arena an IPC allocator.
Processes may map the same bytes at different virtual addresses. Raw pointers,
vtable pointers, PMR resource pointers, and process-private mutex state are not a
portable shared representation.

A shared arena usually needs offsets relative to the mapping, a defined binary
layout, process-shared synchronization, agreed initialization, and a reclamation
protocol spanning all participants. Immutable snapshots are simpler than a
mutable multi-process heap. The [shared-memory examples](27-shared-memory-cpp-examples.md)
demonstrate offsets, ownership handoffs, and process-shared synchronization.

## 20. Performance and debugging

### 20.1 Measure a complete workload

A useful benchmark includes construction, use, destruction, reset, and refill.
An allocate-only loop can hide expensive destructors, retained memory, page
faults, and cache misses. Measure representative sizes and lifetime patterns.

Record throughput (work completed per unit of time), latency distributions
(including slow percentiles), peak retained bytes, upstream call counts, page
faults, and relevant cache behavior. A percentile is a position in the distribution:
p99 means 99% of observed operations were at or below that latency, not that the
remaining 1% have any bounded maximum.

Control compiler optimization and verify actual results so unused work is not
eliminated. Compare against the ordinary allocator; a specialized allocator adds
complexity and can lose if its lifetime assumptions do not fit the workload.

### 20.2 Why sanitizers can miss use-after-reset

After an arena cursor reset, the backing byte array may still be a valid allocated
region. An old pointer can remain within its bounds while referring to storage
that has been logically retired or reused. AddressSanitizer does not automatically
know your arena's logical lifetime boundaries.

Debug techniques include generation-tagged handles, explicit allocation records,
filling retired regions with a recognizable byte pattern, guard pages around
large allocations, and integration with a sanitizer's custom-allocator APIs.
A pattern fill is evidence when observed, not a correctness mechanism; reading
a destroyed object can already violate C++ lifetime rules. Do not overwrite live
nontrivial objects as a substitute for destruction.

### 20.3 Questions to ask when memory grows

- Are live allocations growing, or only retained chunks?
- Did a single large request permanently increase a reusable arena's capacity?
- Does vector growth leave old arrays retained until the next reset?
- Are there thread-local caches for workers that have become idle?
- Does a nested ordinary string allocate outside the measured resource?
- Is an asynchronous task keeping a whole arena alive for one small result?
- Are RSS changes caused by touching previously reserved pages?

These diagnoses require different fixes. Replacing one allocator with another
without identifying the retained ownership path can merely shift the symptom.

## 21. Choosing a strategy for real workloads

| Workload | Plausible choice | Essential constraint |
|---|---|---|
| Parse one request into a temporary syntax tree | Request arena | All users finish before reset |
| Keep selected parse results for hours | Separate long-lived resource | Copy or transfer the required ownership |
| Repeatedly insert and cancel fixed-size order nodes | Typed pool or size-class pool | Individual reuse, stale-handle protection |
| Build a vector of unknown final size | Ordinary allocator or reserve-aware arena | Account for retained growth arrays |
| Per-frame temporary rendering commands | Rotating frame arenas | GPU/worker completion before reuse |
| Recursive temporary calculations | Checkpoint or stack allocator | Nested last-in-first-out lifetimes |
| Arbitrary independent object lifetimes | General-purpose allocator | Measure before specializing |
| Share a read-only dataset with processes | Immutable mapped snapshot | Stable layout, validated offsets |

For asynchronous request processing, the lifetime unit is the completed request
graph, not the lexical scope of the function that initially receives it. For
rendering, “frame finished” must include consumers still processing that frame.
For order books, an arena per trading day can retain every canceled order unless
there is another reuse mechanism; a pool often matches that churn better.

For strict memory budgets, consider the entire graph: arena chunks, nested
allocations, queue capacity, bookkeeping, stacks, and external libraries. A
bounded arena is only one bounded component. For hard real-time requirements,
preallocation alone does not prove a worst-case execution-time bound.

## 22. Forty interview questions with answers

1. **What is a memory arena?** A region or collection of regions managed together,
   commonly with bulk reclamation at a shared lifetime boundary. State which
   meaning you use, because malloc implementations use the term differently.
2. **Is an arena a special type of RAM?** No. It is an allocation and lifetime
   policy over storage that may come from an array, heap allocation, or mapping.
3. **How does a bump allocator allocate?** Align a cursor, verify the remaining
   space without arithmetic overflow, return the aligned address, and advance.
4. **Why can it be fast?** Its common path has little metadata and no search for
   arbitrary free blocks. Page faults and construction remain separate costs.
5. **Does reset call destructors?** Not inherently. The arena or its owner needs an
   explicit destruction policy for objects requiring cleanup.
6. **Can an arena contain strings?** Yes, but string object storage and character
   storage are separate. Use allocator-aware strings when both should use it.
7. **What is alignment?** A constraint on an object's address, usually expressed
   as a required power-of-two byte boundary for the supported alignment.
8. **Why does alignment waste space?** The next suitable address can lie after
   the cursor, leaving padding that cannot serve that allocation.
9. **What happens on exhaustion?** Follow the documented policy: throw, return
   failure through another interface, or obtain another chunk. Never overrun.
10. **Can a growing arena move its old buffer?** Only if its contract allows
    invalidating or relocating all references. Pointer-stable arenas add chunks.
11. **What is internal fragmentation?** Allocated storage exceeds useful payload,
    for example because of size-class rounding or alignment.
12. **What is external fragmentation?** Free space exists but is split into
    pieces that cannot satisfy a requested contiguous allocation.
13. **Does bulk allocation eliminate waste?** No. Padding, unused chunk tails,
    and storage retained after logical death remain possible.
14. **How does a fixed-size pool work?** It obtains slots of a known size and
    recycles free slots, often through a free list.
15. **What is a free list?** Metadata describing reusable blocks. It can use links
    inside free blocks, separate tables, or indexes.
16. **What is a slab?** A backing region organized into slots, often for one size
    class. Exact slab policy depends on the implementation.
17. **What is a buddy allocator?** An allocator that splits and coalesces blocks
    in related size classes, commonly powers of two, using paired buddy blocks.
18. **How is a stack allocator different from an arena?** It supports restoring
    nested allocation positions under a last-in-first-out discipline.
19. **Is checkpoint rollback a transaction?** Only for state it actually restores.
    External side effects and surviving references require separate handling.
20. **What does PMR stand for?** Polymorphic memory resource: runtime selection
    of allocation behavior behind a common resource interface.
21. **Does memory_resource know object types?** No. Its allocation interface
    receives byte counts and alignment, not destructors or element semantics.
22. **What does polymorphic_allocator do?** It adapts a resource for typed
    allocation and allocator-aware construction of objects and containers.
23. **What is an upstream resource?** The resource asked for backing storage when
    a resource cannot satisfy a request from its own available storage.
24. **How do I enforce no upstream fallback?** Supply `null_memory_resource()`
    as upstream and handle allocation failure when the supplied buffer is full.
25. **Does this prohibit every heap allocation?** No. Only requests routed through
    that resource chain are bounded; unrelated objects may allocate elsewhere.
26. **What does monotonic deallocate do?** It does not reclaim that individual
    allocation. Its storage is recovered through bulk release or destruction.
27. **Does release destroy objects?** No. Destroy users and required objects first.
28. **Can I clear a vector and release its arena?** Clearing retains its array.
    Destroy the vector before release; do not reuse its stale capacity.
29. **Does pmr::vector<std::string> route string buffers to PMR?** No. The inner
    ordinary string uses its own allocator. Use `pmr::string` where appropriate.
30. **Where does an ordinary PMR copy constructor allocate?** Through the selected
    copy allocator, normally the default resource for `polymorphic_allocator`.
    Supply an explicit destination allocator when that distinction matters.
31. **Does move assignment always steal a PMR buffer?** No. Unequal non-propagating
    allocators can require element-wise transfer into destination storage.
32. **Can unequal PMR vectors always be swapped?** No. Non-propagating unequal
    allocators violate the allocator-aware container swap requirement.
33. **Does a synchronized resource make containers thread-safe?** No. Container
    mutation still needs its own synchronization and ownership rules.
34. **Can another thread use my unsynchronized resource?** Yes after an exclusive,
    synchronized handoff; not through uncoordinated concurrent access.
35. **What is a remote free?** A deallocation by a different thread from the one
    that allocated. The allocator must route or synchronize it appropriately.
36. **Why might RSS stay high after release?** Upstream allocators may retain
    chunks, and OS accounting concerns pages rather than logical objects.
37. **Why can an arena slow down access?** Poor placement can increase cache or
    NUMA misses; large retention can increase memory pressure and page faults.
38. **Why use generation-tagged handles?** They can detect a reference to a slot
    that has since been freed and reused, provided wraparound and owner lifetime
    are handled. They do not automatically protect previously obtained pointers.
39. **Can PMR pointers be stored in shared-memory data?** They are process-local
    addresses. Use an IPC-aware representation and allocation protocol instead.
40. **What is your first design question?** Which objects share a lifetime, and
    what concrete event proves that all their users have finished?

## 23. Exercises with worked answers

### Exercise 1: Account for alignment

An aligned region begins at address `0x1000`. Allocate 3 bytes with alignment 1,
then 8 bytes with alignment 8. Where does the second allocation begin, and how
many bytes have been consumed?

**Answer:** The cursor first becomes `0x1003`. The second allocation begins at
`0x1008` after 5 padding bytes and ends at `0x1010`. Total consumption is 16 bytes:
11 payload bytes plus 5 padding bytes.

### Exercise 2: Account for vector growth

A vector uses a monotonic resource and successively requests capacity for 4, 8,
and 16 elements of 8 bytes each. Ignore padding and resource chunk overhead.
How much array storage has been requested, and how much is current capacity?

**Answer:** Requested arrays total `(4 + 8 + 16) * 8 = 224` bytes. Current capacity
is 128 bytes. The old 96 bytes remain retained until the resource releases them.
An initial `reserve(16)` can avoid those intermediate requests for this scenario.

### Exercise 3: Fix an escaping result

A parser returns a `pmr::vector<Node>` using a local monotonic resource.

**Answer:** Accept a resource from the caller whose lifetime covers the result,
or copy into the caller's destination resource. An owning result object is also
possible, but its resource, backing buffer, and containers need stable lifetimes
and carefully defined move behavior. Moving only the vector does not fix it.

### Exercise 4: Find the hidden allocation

An allocation counter reports vector storage but misses long string buffers in
`pmr::vector<std::string>`.

**Answer:** The inner type is not a PMR string. Change it to `pmr::string` and use
allocator-aware construction through the outer container. Check allocator
propagation for copies and moves rather than assuming every nested object is
automatically redirected by physical placement inside the vector.

### Exercise 5: Design exception-safe construction

An arena allocates storage, then a constructor throws. What must be restored?

**Answer:** The failed complete object has no destructor to call; already
constructed subobjects are unwound by C++. The allocation interface must follow
its own cleanup contract. An arena may retain the bytes until reset. Rewinding
is safe only if no later allocation or escaped reference depends on that region.
A destructor registry must record only successfully constructed objects and must
handle failure to register without leaking required cleanup.

### Exercise 6: Protect handles

A pool uses only an integer slot index as a handle. An old handle accesses a new
object after reuse of the slot. How can you detect this?

**Answer:** Include a generation counter and pool identity; verify them against
the slot before access. Handle generation overflow explicitly, for example by
retiring that slot before wraparound. A handle still cannot outlive the pool.
Concurrent access additionally needs a lifetime/reclamation protocol.

### Exercise 7: Explain a memory spike

A service has 48 worker arenas. One rare request makes each retain 16 MiB.
Normal live data later falls to 100 KiB per worker, but retained storage remains.

**Answer:** The arenas can collectively retain 768 MiB despite much smaller live
data. Consider a retained-capacity limit, returning exceptional large chunks at
request completion, draining idle workers, or separating large allocations.
Measure latency consequences before choosing a release policy.

### Exercise 8: Choose a lifetime boundary

A request launches three asynchronous jobs. The handler returns before two jobs
finish, and they reference request-arena strings. Where should reset occur?

**Answer:** After the final dependent job completes, not at handler return.
Use a request owner that survives all jobs or copy each job's required data into
storage with a suitable independent lifetime. Synchronize completion before reuse.

## 24. Design checklist and primary references

Before implementing an allocator, write down:

- the lifetime boundary, ownership graph, and conditions for reuse;
- supported sizes and alignments, overflow checks, and failure behavior;
- destructor and exception-safety obligations;
- maximum retained capacity and upstream fallback policy;
- pointer stability, handle validation, and resource propagation rules;
- concurrency, publication, shutdown, and reclamation protocols;
- measurement points and the baseline used to justify specialization.

The following sources define interfaces or document implementations directly:

| Source | Use it to check |
|---|---|
| [C++20 draft: memory resources](https://timsong-cpp.github.io/cppwp/n4861/mem.res) | Resource interface and PMR organization |
| [Polymorphic allocator members](https://timsong-cpp.github.io/cppwp/n4861/mem.poly.allocator.mem) | Construction, new/delete object helpers, copy allocator selection |
| [Monotonic buffer resource](https://timsong-cpp.github.io/cppwp/n4861/mem.res.monotonic.buffer) | Bulk-lifetime allocation policy |
| [Current draft: monotonic resource members](https://eel.is/c++draft/mem.res.monotonic.buffer.mem) | Clarified release and initial-state behavior |
| [Pool resources](https://timsong-cpp.github.io/cppwp/n4861/mem.res.pool) | Synchronized and unsynchronized pool behavior |
| [Object lifetime](https://timsong-cpp.github.io/cppwp/n4861/basic.life) | Storage versus object lifetime |
| [Alignment helper](https://timsong-cpp.github.io/cppwp/n4861/ptr.align) | `std::align` pointer and space updates |
| [Allocator-aware containers](https://timsong-cpp.github.io/cppwp/n4861/container.requirements.general) | Copy, move, swap, and allocator requirements |
| [Linux malloc](https://man7.org/linux/man-pages/man3/malloc.3.html) | A concrete general-purpose allocation interface |
| [jemalloc manual](https://jemalloc.net/jemalloc.3.html) | Arenas, caches, controls, and statistics |
| [TCMalloc design](https://google.github.io/tcmalloc/design.html) | Allocation layers and cache organization |

The draft links are public working-draft text, not a claim that every newer
clarification appeared verbatim in the original C++20 publication. Exact growth
factors, chunk sizes, and allocator performance remain implementation-dependent.
