# mmap: a complete practical guide for C and C++

This guide explains memory mapping from first principles, then develops the API,
correct usage, failure modes, performance tradeoffs, and interview questions.
It is intended to be read without prior knowledge of operating system memory management.

**Scope:** ordinary Linux processes with virtual memory, regular files, and C/C++.
The core mapping interfaces are POSIX interfaces; Linux-specific extensions are labeled.
POSIX is the family of standards defining common Unix operating system interfaces.
Hardware, filesystem, and kernel details can change the implementation and performance.
No finite guide covers every device driver or operating system extension; this one
covers the concepts and decisions needed for application and interview work.

**Examples:** the complete programs target Linux, C11 or C++20. Other code blocks
are explicitly identified as fragments or pseudocode. Examples assume cooperating
processes do not modify or truncate the input file unless a section says otherwise.
Technical references were checked on 2026-09-26.

Suggested reading order: sections 1–9 establish the basics; sections 10–15 cover
correctness; sections 16–22 cover performance and advanced usage. Section 23 is
the interview question bank, and section 24 contains exercises with answers.

## Contents

1. [What mmap is and when to use it](#1-what-mmap-is-and-when-to-use-it)
2. [Memory organization from first principles](#2-memory-organization-from-first-principles)
3. [What happens when you access mapped memory](#3-what-happens-when-you-access-mapped-memory)
4. [The API and every basic argument](#4-the-api-and-every-basic-argument)
5. [Mapping types and copy-on-write](#5-mapping-types-and-copy-on-write)
6. [The complete resource lifecycle](#6-the-complete-resource-lifecycle)
7. [Complete C example: read a file](#7-complete-c-example-read-a-file)
8. [Complete C++ example: own a mapping with RAII](#8-complete-c-example-own-a-mapping-with-raii)
9. [Mapping a slice at an arbitrary offset](#9-mapping-a-slice-at-an-arbitrary-offset)
10. [Writing a file and reserving storage](#10-writing-a-file-and-reserving-storage)
11. [Visibility, synchronization, and durability](#11-visibility-synchronization-and-durability)
12. [File changes, truncation, and signals](#12-file-changes-truncation-and-signals)
13. [Anonymous mappings and allocators](#13-anonymous-mappings-and-allocators)
14. [Shared memory between processes](#14-shared-memory-between-processes)
15. [C++ objects, binary formats, and pointer safety](#15-c-objects-binary-formats-and-pointer-safety)
16. [mmap versus read, pread, and other I/O](#16-mmap-versus-read-pread-and-other-io)
17. [Prefaulting, advice, locking, and latency](#17-prefaulting-advice-locking-and-latency)
18. [Huge pages, NUMA, and translation costs](#18-huge-pages-numa-and-translation-costs)
19. [Protection, fixed addresses, and advanced mappings](#19-protection-fixed-addresses-and-advanced-mappings)
20. [Errors and debugging](#20-errors-and-debugging)
21. [Measuring mmap correctly](#21-measuring-mmap-correctly)
22. [Portability and unusual backing objects](#22-portability-and-unusual-backing-objects)
23. [Interview questions and model answers](#23-interview-questions-and-model-answers)
24. [Exercises with expected reasoning](#24-exercises-with-expected-reasoning)
25. [Implementation checklist and short interview answer](#25-implementation-checklist-and-short-interview-answer)
26. [Further reading](#26-further-reading)

## 1. What mmap is and when to use it

**`mmap` creates an association between a range of virtual addresses in a process
and a backing object, or anonymous memory.** A backing object is the source or
destination of the bytes: commonly a file, a shared-memory object, or a device.
The association is called a **mapping**.

For example, suppose a file contains the bytes `ABCDE`. After mapping it for
reading, an address returned by the operating system can be treated as the start
of a byte range. Reading byte 2 obtains `C` without calling `read()` for that byte.
The mapping is not a C string: it has a length and need not contain a zero terminator.

`mmap` does not itself parse a file, create an index, validate records, synchronize
threads, or provide transactions. A **transaction** is a group of changes with
defined commit and recovery behavior, often including all-or-nothing effects.

Typical uses include:

- Repeated random access to immutable files, such as an index or historical dataset.
- Sharing a byte region between cooperating processes.
- Reserving large regions for an allocator or memory arena.
- Loading executable code and shared libraries.
- Accessing memory exposed by a device driver with a documented mapping interface.

A file that may be truncated unexpectedly, a small one-pass input, or an application
requiring explicit I/O error handling may be easier to handle with `read`/`pread`.
The performance decision depends on the workload; section 16 develops the comparison.

## 2. Memory organization from first principles

### 2.1 Processes, threads, user space, and the kernel

A **process** is a running program together with resources managed by the operating
system: an address space, open files, credentials, and at least one execution thread.
A **thread** is an execution sequence within a process. Threads in one process
normally share the same address space.

The **kernel** is the privileged part of the operating system. It manages hardware,
memory isolation, files, and scheduling. Application instructions normally execute
in **user space**, with restricted privileges.

A **system call** is a controlled request from user space into the kernel. `mmap`,
`read`, and `munmap` are examples. A system call changes privilege level; it does
not necessarily cause a **context switch**, which is a change in the running thread.
A thread waiting for file data may be put to sleep so another thread can run.

### 2.2 Virtual addresses and physical memory

A **virtual address** is an address in a process's address space, such as the
value held in a pointer. A **physical address** identifies a location in the
machine's physical memory system. **RAM** is the main volatile memory: its
contents are normally lost when power is removed.

Two processes can use the same virtual address for unrelated physical memory.
Conversely, different virtual addresses can refer to the same physical memory.
That second possibility is what makes shared mappings useful.

**Virtual contiguity does not imply physical contiguity.** A 16 MiB mapping can
look like one continuous byte range to the application while its physical pages
are scattered throughout RAM. MiB means 2^20 bytes; GiB means 2^30 bytes.

### 2.3 Pages, page frames, and page tables

A **page** is a unit of virtual-memory management. A **page frame** is a corresponding
unit of physical memory. Ordinary pages are often 4096 bytes on Linux/x86-64,
but applications should query the size with `sysconf(_SC_PAGESIZE)`.

A **page table** is a kernel-managed structure describing address translations
and access permissions. A **page-table entry**, or PTE, describes a translation
at the relevant level, or records that further handling is required.
Modern page tables are generally hierarchical so unused address ranges do not
need a complete flat table.

For an illustrative page size of 4096:

```text
virtual address = virtual page number * 4096 + offset within page
physical address = physical frame number * 4096 + the same offset
```

The **MMU**, or memory management unit, is the processor hardware involved in
translation and protection. A **TLB**, or translation lookaside buffer, caches
recent translations. A TLB miss can be resolved by a hardware page-table walk;
it does not necessarily cause a page fault or enter the kernel.

The kernel's [memory-management overview](https://docs.kernel.org/admin-guide/mm/concepts.html)
explains these translation mechanisms.

### 2.4 CPU caches and the page cache are different things

A **CPU cache** holds recently used instructions or data close to a processor core.
Common levels are L1, L2, and L3. A **cache line** is the hardware transfer and
coherence unit, often 64 bytes on common machines; it is much smaller than a page.

The **page cache** is an operating system cache of file contents in RAM.
For ordinary buffered files, both `read()` and file mappings use it:

```text
Storage device
      |
      v
File data in the kernel's page cache
      |                         |
      | read: copy bytes        | mmap: establish a mapping
      v                         v
Application-owned buffer      Application virtual addresses
      |                         |
      +---- CPU loads/stores ---+
```

A **cache hit** means requested information is already in a particular cache.
Always specify which cache. A file can be in the page cache while its contents
are absent from CPU caches and its translations are absent from the TLB.

### 2.5 VMA, heap, stack, and executable mappings

A **virtual memory area**, or VMA, is a Linux kernel description of an address
interval with compatible properties, such as permissions and backing file.
A VMA describes what is allowed in a region; page tables describe individual
translations. Creating a VMA does not mean all its pages are already resident.

A process address space typically contains:

| Region | Purpose |
|---|---|
| Executable code | Machine instructions for the program. |
| Read-only data | Constants and similar data. |
| Writable globals | Global and static objects. |
| Heap and allocator arenas | Storage managed by `malloc`, `new`, and allocators. |
| Thread stacks | Function call state and automatic objects. |
| Shared libraries | Code and data loaded from library files. |
| Explicit mappings | Files, shared memory, and anonymous regions requested by the application. |

There is no universal fixed diagram of their addresses. **ASLR**, address space
layout randomization, varies placement to make address prediction harder.
`malloc` can acquire memory through mechanisms such as `brk` and `mmap`, depending
on its implementation; “heap memory” does not imply one contiguous kernel region.

### 2.6 Resident memory, dirty pages, reclaim, swap, and overcommit

**Resident** pages are currently present in RAM. **VSZ**, virtual size, measures
mapped virtual address space. **RSS**, resident set size, measures resident pages
attributed to a process, including shared pages. **PSS**, proportional set size,
divides shared-page accounting among the processes mapping those pages. Summing
RSS values can count the same physical memory multiple times. Linux exposes these
details in [`/proc/PID/smaps`](https://man7.org/linux/man-pages/man5/proc_pid_smaps.5.html).

A **dirty page** has been modified and needs appropriate handling before its
physical storage can be reused. **Writeback** transfers modified file data toward
its backing storage. **Reclaim** frees physical memory for another use: a clean
file page can often be dropped and read again later.

**Swap** is backing storage for memory such as private anonymous pages. It is
different from writing modified shared file pages back to their file. A private
modified file page becomes anonymous copy-on-write data and may need swap.

**Overcommit** means the operating system can accept memory commitments that exceed
immediately available backing resources. A successful allocation need not imply
every later page access can be satisfied. Under memory pressure, processes can
stall, allocations can fail, or an **OOM** (out-of-memory) policy can terminate a
process. Container memory limits can matter even when the host has spare RAM.

## 3. What happens when you access mapped memory

### 3.1 Mapping setup and demand paging

For a normal lazy file mapping, `mmap` primarily establishes the virtual-memory
relationship. It generally does not eagerly read the entire file. It still uses
kernel metadata and can incur nontrivial work; flags, existing mappings, security
checks, and backing-object implementations affect the cost.

**Demand paging** means the operating system provides pages when access requires
them. Consider the first load from a mapped file:

1. The CPU tries to translate the virtual address and check permissions.
2. If the access cannot proceed, it raises a **page fault**, a synchronous processor
   exception. “Synchronous” here means caused by the current instruction.
3. The kernel finds the region and checks whether the access is valid.
4. If valid, it obtains the required page. The page may already be cached, or
   storage I/O may be necessary.
5. The kernel installs or updates the translation. On successful resolution,
   execution resumes and the instruction can complete.
6. If the access cannot be satisfied, the process may receive a signal instead.

A **signal** is an operating system notification delivered to a process or thread.
Some signal defaults terminate the process. Fault signals are discussed in section 12.

### 3.2 Minor and major faults

A **minor fault** is resolved without the I/O classified as necessary for a major
fault; examples include installing a translation for an already cached file page
or allocating a private copy. A **major fault** involves obtaining data through
I/O. A minor fault can still be expensive, particularly if allocation or contention
is involved. See the counter definitions in [`getrusage(2)`](https://man7.org/linux/man-pages/man2/getrusage.2.html).

Fault count is not equal to page count or storage-request count. **Readahead**
fetches data likely to be used soon. **Fault-around** can establish translations
for neighboring cached pages. The amount of either is an implementation decision,
not a fixed mmap guarantee.

### 3.3 What does “zero-copy” actually mean?

For ordinary file mappings, application loads can access page-cache data without
an additional copy from a kernel buffer into an application buffer. That is the
copy typically avoided compared with buffered `read`.

Data still travels from storage to memory and through CPU caches. Parsing may
copy fields. Private writes can copy pages. Translation structures consume RAM.
“Zero-copy” therefore describes a particular avoided copy, not the absence of
data movement or operating system work.

## 4. The API and every basic argument

Declarations, shown in conventional C notation:

```c
#include <sys/mman.h>

void *mmap(void *addr, size_t length, int prot, int flags,
           int fd, off_t offset);
int munmap(void *addr, size_t length);
```

| Argument | Meaning and normal choice |
|---|---|
| `addr` | Address preference. Use `NULL` in C or `nullptr` in C++ so the kernel chooses. Without a fixed-address flag, a non-null address is only a hint. |
| `length` | Requested byte count. Must be positive. Track the logical data length separately from page coverage. |
| `prot` | Access permissions: combine `PROT_READ`, `PROT_WRITE`, and possibly `PROT_EXEC`, or use `PROT_NONE`. |
| `flags` | Sharing behavior and optional features. Normally choose exactly one of `MAP_PRIVATE` and `MAP_SHARED`. |
| `fd` | File descriptor for the backing object. For anonymous mappings, use `-1`. |
| `offset` | File position corresponding to the first mapped byte; nonnegative and aligned to the required page size. For anonymous mappings, use zero. |

`size_t` is the unsigned integer type used for in-memory sizes. `off_t` is a file
offset type and is normally signed. Validate values before conversion: a negative
size converted to an unsigned type can become an enormous positive number.

A **file descriptor** is a process-local integer naming an open kernel resource.
An **open file description** holds state such as file position and open flags.
The `offset` passed to `mmap` is independent of that current file position:
mapping does not seek the descriptor or advance its read position.

On failure, compare the result with **`MAP_FAILED`**, not with null. Inspect
`errno` only after a call reports failure. `errno` is the thread-local error code
used by many C/POSIX interfaces.

For ordinary mappings the address and file offset follow page alignment rules,
but length need not be a page multiple. The OS manages the covering pages.
Never use that rounding as permission to read beyond the logical file/data size.
Explicit huge-page mappings have stricter alignment requirements.

The precise interface contract and Linux extensions are documented in
[`mmap(2)`](https://man7.org/linux/man-pages/man2/mmap.2.html).

### 4.1 Permissions and file open modes

| Desired mapping | Typical file open mode |
|---|---|
| Read-only file mapping | `O_RDONLY` |
| Private readable/writable file mapping | `O_RDONLY` is sufficient for the normal COW case |
| Shared readable/writable file mapping | `O_RDWR` |

`O_WRONLY` is not sufficient for a normal writable file mapping. Request
`PROT_READ | PROT_WRITE` when the program needs both. Some architectures make
write permission imply read permission, but portable code should not depend on it.

`PROT_EXEC` permits executing instructions. It is unnecessary for data files.
`PROT_NONE` reserves an inaccessible region useful for guard pages or staged arenas.

### 4.2 A map of the optional flags

The following flags are Linux-specific or have Linux-specific behavior. Use the
later sections to understand their limitations before adding them to a call.

| Flag | Purpose | Read next |
|---|---|---|
| `MAP_ANONYMOUS` | Obtain zero-filled memory without an ordinary file. | Section 13 |
| `MAP_POPULATE` | Request population during mapping. | Section 17 |
| `MAP_LOCKED` | Request locked pages, with weaker setup guarantees than checked `mlock`. | Section 17 |
| `MAP_HUGETLB` | Request explicit huge pages. | Section 18 |
| `MAP_FIXED` | Force an address and replace overlapping mappings. | Section 19 |
| `MAP_FIXED_NOREPLACE` | Request an address without replacing an overlapping mapping. | Section 19 |
| `MAP_SHARED_VALIDATE` | Shared mapping type that rejects unsupported flag bits; used instead of the ordinary shared/private choice. | Section 19 |
| `MAP_SYNC` | Specialized synchronization semantics for supported DAX mappings. | Section 19 |
| `MAP_NORESERVE` | Avoid the usual swap-space reservation for eligible mappings, subject to overcommit policy. | Below |

`MAP_NORESERVE` does not guarantee later allocations will succeed. Linux's strict
overcommit mode ignores it. **Commit accounting** estimates the backing resources
promised to mappings; it is different from counting pages already resident in RAM.
See [Linux overcommit accounting](https://docs.kernel.org/mm/overcommit-accounting.html).

Some flags seen in older examples are not useful general tuning switches.
`MAP_STACK` is currently a no-op on Linux; `MAP_GROWSDOWN` is a specialized stack
mechanism, not a way to make ordinary file mappings grow automatically. On Linux,
`MAP_NONBLOCK` combined with `MAP_POPULATE` currently disables population rather
than providing a general asynchronous prefault interface. Historical flags such
as `MAP_DENYWRITE` do not protect a mapped input from external writers.

## 5. Mapping types and copy-on-write

### 5.1 The four useful combinations

| Backing | Private | Shared |
|---|---|---|
| File | Read file bytes; private changes do not update the file. | Processes can share file data and modifications can update the file. |
| Anonymous | Fresh process-private storage, initially zero-filled. | Shared zero-filled storage, useful for processes inheriting the mapping. |

For anonymous mappings on Linux, add `MAP_ANONYMOUS`. It does not mean persistent
storage; ordinary anonymous shared memory does not survive a reboot.

### 5.2 Copy-on-write, explained with two processes

**Copy-on-write**, abbreviated COW, postpones making a private copy until a write
requires one. Suppose processes A and B privately map the same file:

```text
Before a private write:
  A virtual page ----+
                     +---- file's cached page: ABCD
  B virtual page ----+

After A writes X into the first byte:
  A virtual page -------- private anonymous page: XBCD
  B virtual page -------- file's cached page: ABCD
```

The write can fault even though the VMA permits writes: the hardware entry may
initially be write-protected so the kernel can implement COW. Copying happens at
page-related granularity, not merely at the one changed byte.

Private does not mean “all physical pages are unique from the start.” It also
does not mean “snapshot of the file.” External file modifications are not covered
by a stable-snapshot guarantee for `MAP_PRIVATE`. Use immutable files or an explicit
snapshot/copy protocol when readers require one consistent version.

### 5.3 Threads, fork, and exec

All threads in a process can access the same mapping. `MAP_PRIVATE` does not
isolate one thread's writes from another thread in that process.

`fork()` creates a child process. Ordinary mappings are inherited at the same
virtual addresses; private memory diverges through COW, while shared mappings
remain shared. Linux advice such as `MADV_DONTFORK` can alter inheritance.
`exec` replaces a process's program image and removes its previous mappings.

Calling `mmap` twice with anonymous shared flags creates two independent objects;
the flags alone do not discover another process's anonymous mapping.

## 6. The complete resource lifecycle

For reading an ordinary file:

1. `open` the file and check the result.
2. `fstat` that descriptor to get its size and type.
3. Handle an empty file separately.
4. Validate that its size is representable and reasonable for your application.
5. Call `mmap` and check against `MAP_FAILED`.
6. Read only valid bytes while the mapping remains alive.
7. Call `munmap` with the original mapping base and correct length.
8. Close the descriptor when it is no longer needed.

`fstat(fd, ...)` examines the opened object, unlike a separate `stat(path, ...)`
that may examine a different object if the pathname changes. It still does not
prevent that opened file from being truncated afterward.

The descriptor may be closed after a successful mapping; the mapping retains a
reference to its backing object. Keeping the descriptor is useful for later
`fsync`, resizing, or metadata checks. Closing a descriptor and unmapping an
address range release different resources.

`munmap` does not run C++ destructors and is not a durable commit operation.
It invalidates pointers into the unmapped range. Arrange ownership so no thread
continues using them. If the address is reused later, a stale pointer can corrupt
unrelated data instead of reliably producing a fault.

## 7. Complete C example: read a file

Save this complete program as `mmap_read.c`. It computes a simple byte sum,
modulo 2^64, so embedded zero bytes and arbitrary binary input work. This is a
demonstration checksum, not a cryptographic integrity check.

```c
#define _POSIX_C_SOURCE 200809L
#define _FILE_OFFSET_BITS 64
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "usage: %s FILE\n", argv[0]);
        return 2;
    }
    int fd = open(argv[1], O_RDONLY | O_CLOEXEC);
    if (fd == -1) { perror("open"); return 1; }

    struct stat st;
    if (fstat(fd, &st) == -1) {
        perror("fstat"); close(fd); return 1;
    }
    if (!S_ISREG(st.st_mode) || st.st_size < 0 ||
        (uintmax_t)st.st_size > (uintmax_t)SIZE_MAX ||
        (uintmax_t)st.st_size > (uintmax_t)PTRDIFF_MAX) {
        fprintf(stderr, "input must be a regular file of a supported size\n");
        close(fd); return 1;
    }

    size_t n = (size_t)st.st_size;
    if (n == 0) {
        if (close(fd) == -1) { perror("close"); return 1; }
        puts("bytes=0 sum=0");
        return 0;
    }
    void *base = mmap(NULL, n, PROT_READ, MAP_PRIVATE, fd, 0);
    if (base == MAP_FAILED) {
        perror("mmap"); close(fd); return 1;
    }
    if (close(fd) == -1) {
        perror("close"); munmap(base, n); return 1;
    }

    const unsigned char *bytes = base;
    uint64_t sum = 0;
    for (size_t i = 0; i < n; ++i) sum += bytes[i];
    if (munmap(base, n) == -1) { perror("munmap"); return 1; }
    printf("bytes=%zu sum=%" PRIu64 "\n", n, sum);
    return 0;
}
```

```sh
cc -std=c11 -O2 -Wall -Wextra -Wpedantic mmap_read.c -o mmap_read
./mmap_read your-file.bin
```

`O_CLOEXEC` closes the descriptor if the process successfully executes another
program. `S_ISREG` checks that this is a regular file. `PTRDIFF_MAX` is a
conservative maximum used here to avoid giant objects that exceed ordinary
pointer-difference and implementation assumptions. Larger files can be processed
in windows, as in section 9. `_FILE_OFFSET_BITS=64` selects large-file interfaces
on relevant 32-bit Linux C library configurations.

The program cannot protect itself against an external truncation simply by checking
the initial size. Its explicit input contract is that the file remains stable.

## 8. Complete C++ example: own a mapping with RAII

**RAII**, resource acquisition is initialization, binds a resource to a C++ object's
lifetime. Its destructor releases the resource during normal return and exception
unwinding. This reduces cleanup mistakes.

The following complete C++20 program uses a noncopyable, nonmovable owner to keep
ownership simple. A **view** such as `std::span` describes a range without owning it.
The view returned here becomes invalid when the owner is destroyed.

Save as `mmap_read.cpp`:

```cpp
#define _FILE_OFFSET_BITS 64
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <cerrno>
#include <cstddef>
#include <cstdint>
#include <iostream>
#include <limits>
#include <span>
#include <stdexcept>
#include <system_error>

class MappedFile {
    struct Fd {
        int value;
        explicit Fd(int n) : value(n) {}
        Fd(const Fd&) = delete;
        Fd& operator=(const Fd&) = delete;
        ~Fd() noexcept { if (value != -1) (void)::close(value); }
    };
    void* base_ = MAP_FAILED;
    std::size_t size_ = 0;

    [[noreturn]] static void fail(const char* operation) {
        const int error = errno;
        throw std::system_error(error, std::generic_category(), operation);
    }

public:
    explicit MappedFile(const char* path) {
        Fd fd{::open(path, O_RDONLY | O_CLOEXEC)};
        if (fd.value == -1) fail("open");
        struct stat st{};
        if (::fstat(fd.value, &st) == -1) fail("fstat");
        if (!S_ISREG(st.st_mode) || st.st_size < 0)
            throw std::runtime_error("expected a regular file");

        const auto n = static_cast<std::uintmax_t>(st.st_size);
        if (n > std::numeric_limits<std::size_t>::max() ||
            n > static_cast<std::uintmax_t>(
                    std::numeric_limits<std::ptrdiff_t>::max()))
            throw std::length_error("file too large; use mapped windows");
        size_ = static_cast<std::size_t>(n);
        if (size_ == 0) return;
        base_ = ::mmap(nullptr, size_, PROT_READ, MAP_PRIVATE, fd.value, 0);
        if (base_ == MAP_FAILED) fail("mmap");
    }

    MappedFile(const MappedFile&) = delete;
    MappedFile& operator=(const MappedFile&) = delete;
    MappedFile(MappedFile&&) = delete;
    MappedFile& operator=(MappedFile&&) = delete;

    ~MappedFile() noexcept {
        if (base_ != MAP_FAILED) (void)::munmap(base_, size_);
    }

    std::span<const std::byte> bytes() const noexcept {
        if (size_ == 0) return {};
        return {static_cast<const std::byte*>(base_), size_};
    }
};

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: " << argv[0] << " FILE\n";
        return 2;
    }
    try {
        MappedFile file{argv[1]};
        std::uint64_t sum = 0;
        for (std::byte b : file.bytes()) sum += std::to_integer<unsigned int>(b);
        std::cout << "bytes=" << file.bytes().size() << " sum=" << sum << '\n';
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n';
        return 1;
    }
}
```

```sh
g++ -std=c++20 -O2 -Wall -Wextra -Wpedantic mmap_read.cpp -o mmap_read_cpp
./mmap_read_cpp your-file.bin
```

The destructor cannot throw and ignores cleanup errors in this teaching owner.
An application that needs observable cleanup failures can provide a separate
explicit close operation while retaining a nonthrowing destructor.
Persistence errors belong in an explicit flush/commit operation, not a destructor.

This wrapper owns a Linux mapping; it does not establish an ISO C++ portability
claim for arbitrary mapped objects. Section 15 discusses the language boundary.

## 9. Mapping a slice at an arbitrary offset

Suppose the desired file range starts at byte `start` and contains `count` bytes.
`start` may not meet the alignment requirement for the `mmap` offset.

Let `P` be the page size. Compute:

```text
aligned_offset = start - start % P
delta          = start - aligned_offset
mapping_length = delta + count
data_pointer   = mapping_base + delta
```

For `P = 4096`, `start = 5000`, and `count = 1000`, the mapping starts at file
offset 4096, has requested length 1904, and the desired data begins 904 bytes
into it. Unmap the original base with length 1904, not the shifted data pointer.

Before doing this arithmetic:

- Require a nonnegative offset and a positive count, or handle an empty view.
- Check `start <= file_size` and `count <= file_size - start`.
- Check that the aligned offset fits `off_t`.
- Check `delta <= SIZE_MAX - count` before adding.
- Apply the same pointer-range limits and resource budgets as for a whole file.

These subtraction-based bounds checks avoid an overflowing `start + count`.
**Integer overflow** means an arithmetic result is not representable in its type.
Unsigned arithmetic wraps; signed overflow in C/C++ generally has undefined behavior.

**Windowed mapping** means mapping and processing bounded sections of a large
file. Keep records that cross window boundaries in mind: use a small carry buffer,
overlap windows safely, or choose boundaries using the file format. Every remap
can invalidate views and add kernel/translation overhead.

## 10. Writing a file and reserving storage

### 10.1 Mapping does not grow the file

Before writing a mapped output file, establish an adequate file length with
`ftruncate` or an appropriate allocation operation. Mapping a longer range does
not extend the underlying file. `O_APPEND` also does not turn mapped stores into
append operations: each store targets its mapped byte position.

`ftruncate(fd, length)` changes the logical file size. Extending a file normally
makes the new range read as zero, but does not necessarily allocate physical disk
blocks. A **sparse file** contains logical ranges with no allocated data blocks;
reading such a hole normally returns zeros.
See [`ftruncate(2)`](https://man7.org/linux/man-pages/man2/ftruncate.2.html).

`posix_fallocate(fd, offset, length)` reserves file storage so later writes in the
range do not fail specifically because of insufficient disk space. It can extend
the file. It returns an error number directly, rather than reporting all errors
through `errno`. Filesystem support and C library fallback behavior matter;
perform setup before concurrent writers begin. Reservation does not prevent
hardware failure or provide a transaction.
See [`posix_fallocate(3)`](https://man7.org/linux/man-pages/man3/posix_fallocate.3.html).

### 10.2 Complete C example: create and update a mapped file

Save as `mmap_write.c`. This example creates a new file with exclusive creation
so a typo does not truncate an existing file. It writes six bytes and explicitly
checks synchronization. For clarity, failure can leave the newly created file
behind; this is not a crash-safe publication protocol.

```c
#define _POSIX_C_SOURCE 200809L
#define _FILE_OFFSET_BITS 64
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "usage: %s NEW_FILE\n", argv[0]);
        return 2;
    }
    const char message[] = "hello\n";
    const size_t n = sizeof message - 1;
    int fd = open(argv[1], O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC, 0600);
    if (fd == -1) { perror("open"); return 1; }
    if (ftruncate(fd, (off_t)n) == -1) {
        perror("ftruncate"); close(fd); return 1;
    }
    void *base = mmap(NULL, n, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (base == MAP_FAILED) {
        perror("mmap"); close(fd); return 1;
    }
    memcpy(base, message, n);

    int result = 0;
    if (msync(base, n, MS_SYNC) == -1) { perror("msync"); result = 1; }
    if (fsync(fd) == -1) { perror("fsync"); result = 1; }
    if (munmap(base, n) == -1) { perror("munmap"); result = 1; }
    if (close(fd) == -1) { perror("close"); result = 1; }
    return result;
}
```

```sh
cc -std=c11 -O2 -Wall -Wextra -Wpedantic mmap_write.c -o mmap_write
./mmap_write new-output.bin
```

`0600` requests read/write permission for the owner only, subject to the creation
mask. `O_EXCL` combined with `O_CREAT` fails if the name already exists.
The example uses both mapping synchronization and file synchronization to make
their roles visible. This is not a claim that every application requires both.
Durably publishing a newly created filename also involves its containing directory.

## 11. Visibility, synchronization, and durability

These are separate requirements. Answering one does not answer the others.

| Requirement | Question it answers | Typical mechanisms |
|---|---|---|
| Sharing/visibility | Can another participant access the same modified bytes? | Shared mappings and the platform's coherent memory system. |
| Ordering and synchronization | When may the reader consume a complete update? | Mutexes, semaphores, or a valid atomic publication protocol. |
| Durability | What data survives a crash or power loss after success is reported? | Checked synchronization plus filesystem/storage guarantees. |
| Crash consistency | Is the surviving data a valid old or new state? | Logging, versioning, checksums, and recovery protocols. |

### 11.1 Does another process need msync to see a write?

For ordinary shared mappings of the same local file or shared-memory object,
`msync` is not a message-publication primitive. Processes can share the modified
memory without a disk flush. They still need a valid synchronization protocol.

**Cache coherence** is the hardware mechanism that coordinates cached copies
of a memory location across processors. **Memory ordering** concerns the allowed
observations of operations on different locations. Coherence does not by itself
make a record of several fields appear as one indivisible update.

A **data race**, in the C++ threading model, includes conflicting unsynchronized
accesses to one memory location where at least one is a write and the accesses
are not both atomic. Such a race produces undefined behavior. **Undefined behavior**
means the language imposes no requirements on the program's result.
The mapping mechanism does not remove these rules. See the
[C++ data-race rules](https://eel.is/c++draft/intro.races).

### 11.2 What does msync do?

`msync(address, length, MS_SYNC)` requests synchronization of modified mapped
file data and waits for completion under the interface's guarantees. Check its
return value. Its address must satisfy page alignment, so a pointer into the
middle of a mapped record may need to be rounded down and the length expanded.

`MS_ASYNC` is not a durability boundary. On Linux it has effectively been a no-op
since Linux 2.6.19 because the kernel already tracks and schedules dirty data.
`MS_INVALIDATE` is not a CPU-cache flush instruction or a replacement for locks.
`msync` cannot make a `MAP_PRIVATE` modification become a file modification.
See [`msync(2)`](https://man7.org/linux/man-pages/man2/msync.2.html).

Do not infer that data remains unwritten until `msync`: background writeback can
persist some changes earlier. Conversely, `munmap`, process exit, and `close`
are not checked durable-commit boundaries.

### 11.3 fsync, fdatasync, and directory persistence

`fsync(fd)` synchronizes modified file data and relevant metadata to the storage
device according to the filesystem and device contract. `fdatasync` can omit
metadata that is not needed to retrieve the data correctly; file-size changes
are still relevant. On Linux, synchronizing a regular file also addresses its
dirty mapped data; a separate `msync` is not universally required before `fsync`.

A **directory entry** associates a name with a file. Making file contents durable
does not automatically make a newly created or renamed directory entry durable.
On Linux filesystems supporting the usual protocol, synchronize the containing
directory when durable name publication is required. The `fsync` documentation
explicitly distinguishes file and directory synchronization.
See [`fsync(2)`](https://man7.org/linux/man-pages/man2/fsync.2.html).

### 11.4 Why flushing is not a transaction

Imagine an account record containing `balance` and `version`. A writer updates
both and calls `msync`. A crash can occur after one write reaches storage but
before the other does. Even a single large record may suffer a **torn write**:
only part of its intended new bytes survives.

A CPU-atomic store is not automatically power-fail atomic on storage. A mutex
can coordinate running processes but disappears as a useful protection when the
machine loses power.

For an immutable-file publication design, a common sequence is:

1. Create a distinct temporary file in the target directory/filesystem.
2. Give it the final size and write a complete validated version.
3. Synchronize the file and check every relevant error.
4. Rename it over the target name, within the same filesystem.
5. Synchronize the directory as required for durable publication.

An atomic rename changes the name association without exposing an intermediate
missing destination in the normal replacement case. Existing mappings retain
the previous object; new opens obtain the new object. This supports readers of
immutable generations, but readers must reopen/remap to see a new generation.
See [`rename(2)`](https://man7.org/linux/man-pages/man2/rename.2.html).

In-place databases need more: for example, **write-ahead logging** records recovery
information durably before committing dependent data, while a **copy-on-write
storage design** writes new versions elsewhere and carefully publishes a new root.
That storage design is distinct from the kernel's `MAP_PRIVATE` page mechanism.
Specify the actual filesystem, storage stack, and failure model before claiming
crash safety. This example sequence does not establish guarantees for every
network filesystem or storage device.

## 12. File changes, truncation, and signals

### 12.1 End-of-file has two different boundaries

The logical file length and page boundary are not necessarily equal. With a
5000-byte file and 4096-byte pages:

```text
page 0: file bytes    0 .. 4095
page 1: file bytes 4096 .. 4999 | beyond-EOF tail 5000 .. 8191
page 2: entirely beyond EOF
```

For ordinary file mappings, the unused part of the final partial page is initially
zero-filled and modifications there do not extend the file or get written as file
contents. Linux has documented page-cache caveats for this tail, so never use it
as reliable application scratch storage. Enforce the logical bounds.

If the mapped range includes a page entirely beyond the object's end, accessing
that page can deliver `SIGBUS`. Access past the mapping itself can instead touch
an unrelated mapping or fault; neither outcome is valid application behavior.

### 12.2 SIGSEGV versus SIGBUS

| Signal | Typical mmap-related cause |
|---|---|
| `SIGSEGV` | Address not mapped, use after unmapping, or violating permissions such as writing to a read-only page. |
| `SIGBUS` | Address belongs to a mapping, but its backing cannot satisfy the access; accessing a page beyond a truncated file is a classic case. |

These are typical causes, not exhaustive classifications for every architecture.
Signals can arise during an ordinary load or store, long after `mmap` succeeded.
C++ `try`/`catch` does not normally turn these signals into standard exceptions.

### 12.3 Why fstat followed by mmap is not enough

A writer can truncate a file after the reader checks its size. The mapping can
still exist while pages no longer have valid file backing. Even a second size
check immediately before reading leaves a **TOCTOU** race: time of check differs
from time of use.

Practical designs include immutable files, cooperative locking, versioned file
replacement, or Linux sealed memory files where appropriate. **Advisory locking**
only works when every relevant participant respects the protocol; it does not
prevent an uncooperative process from changing the file.

Installing a general `SIGBUS` handler is not a simple recovery design. Signal
handlers have restricted safe operations, and resuming the faulting instruction
can fault again. Complex C++ cleanup and arbitrary exception unwinding are not
safe default strategies in a signal handler. See
[`signal-safety(7)`](https://man7.org/linux/man-pages/man7/signal-safety.7.html).

### 12.4 What if the file grows, is removed, or is replaced?

- **Growth:** an existing mapping does not automatically acquire a larger virtual
  range. Establish a new mapping or resize one using supported facilities, and
  coordinate readers. Do not rely on subtle behavior in an old beyond-EOF range.
- **Unlink:** removing a name does not invalidate an existing mapping of the
  object. The object can stay alive through open descriptors and mappings.
- **Replacement by rename:** existing mappings refer to the original object,
  not whichever file currently happens to have that pathname.
- **In-place edits:** shared readers can observe modifications, but coherent
  records still require synchronization. Private mappings are not snapshots.

Linux `mremap` can resize or move a mapping. If moving is allowed, every absolute
pointer into the old range must be treated as invalid after a move. Resizing a
file mapping does not replace the separate need to establish the file's size.
See [`mremap(2)`](https://man7.org/linux/man-pages/man2/mremap.2.html).

## 13. Anonymous mappings and allocators

An **anonymous mapping** supplies memory without an ordinary file as its backing
object. Its initial bytes are zero. Actual private physical pages can be allocated
on demand; a read may initially be served by a shared zero page.

This Linux C fragment allocates an arena. An **arena** is one larger region from
which an application allocates smaller pieces:

```c
/* Fragment: include sys/mman.h; check/report errors in the surrounding code. */
size_t arena_size = 16u * 1024u * 1024u;
void *arena = mmap(NULL, arena_size, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
if (arena == MAP_FAILED) {
    /* Handle failure; do not use arena. */
} else {
    /* Use storage within bounds; construct objects if required. */
    if (munmap(arena, arena_size) == -1) {
        /* Report failure. */
    }
}
```

On glibc, strict language/feature settings may require a feature-test macro such
as `_DEFAULT_SOURCE` before headers to expose `MAP_ANONYMOUS`.

Why not use this for every small allocation? Mapping calls operate at page scale,
consume kernel metadata, and can incur synchronization and translation costs.
A general allocator amortizes these costs by serving many small allocations from
larger regions. **Internal fragmentation** is unused space within allocated units;
**external fragmentation** is free space split into inconvenient separated pieces.

Releasing a C++ object and releasing its storage are different operations:
destroy the object correctly, then return storage to its owner. `free` must not
release a raw mmap allocation, and `munmap` must not release a normal `malloc`
allocation merely because that allocator may internally use mappings.

## 14. Shared memory between processes

**IPC**, interprocess communication, means exchanging information between processes.
Shared memory is an IPC mechanism, but it supplies storage, not a complete protocol.

### 14.1 How processes obtain the same backing object

| Mechanism | How the other process finds the memory |
|---|---|
| Regular file plus `MAP_SHARED` | Opens the same file object and maps a compatible range. |
| POSIX `shm_open` | Opens a named shared-memory object, then maps its descriptor. |
| Linux `memfd_create` | Receives or inherits a descriptor for the same anonymous file. |
| Shared anonymous mapping before `fork` | Inherits the already established mapping. |

A POSIX shared-memory creator uses `shm_open` with exclusive creation, sets size
with `ftruncate`, and maps with `MAP_SHARED`. Opening a name and initializing its
contents are separate events: another process must not consume an object that
is only partially initialized. Use an external rendezvous or a documented
initialization protocol. `shm_unlink` removes the name; existing references can
keep the object alive. See [`shm_open(3)`](https://man7.org/linux/man-pages/man3/shm_open.3.html).

Linux `memfd_create` makes a RAM-backed file-like object without a normal filesystem
pathname. **Seals** are restrictions applied to such an object: for example,
preventing shrinkage can eliminate a cooperating reader's truncation hazard.
Write seals and preexisting writable mappings have additional constraints, so
select and apply seals before publishing the object. This is useful for immutable
data transfer, not reboot persistence. See
[`memfd_create(2)`](https://man7.org/linux/man-pages/man2/memfd_create.2.html).

### 14.2 Shared bytes need a publication protocol

Suppose a message contains a payload and a `ready` flag. Writing the payload,
then an ordinary integer flag, does not establish a portable concurrent protocol.
Neither `volatile` nor `msync` fixes that.

**Atomic operations** operate indivisibly according to their specified memory
model. A **release** operation can publish earlier writes; an **acquire** operation
that observes the matching publication can order subsequent reads. A **happens-before**
relationship is the ordering relationship that makes these visibility guarantees
usable in the C++ threading model.

Conceptual pseudocode for a *single-use* publication, assuming a platform-supported
shared atomic mechanism whose objects are properly initialized:

```text
writer:   initialize payload
          store_release(ready, true)

reader:   wait until load_acquire(ready) observes true
          consume payload
```

This alone is not a reusable queue. The writer must not overwrite the payload
while the reader uses it. Reuse requires acknowledgment, sequence numbers, or
ownership transfer, plus a strategy for full/empty states and process failure.

ISO C++ does not supply a general interprocess guarantee for arbitrary `std::atomic`
implementations in mapped storage. A non-lock-free implementation can depend on
locks that are local to a process. Even a lock-free result is only one prerequisite;
confirm platform/compiler support, alignment, object lifetime, and address independence.
**Lock-free** means the algorithm provides system-wide progress without relying
on a blocking lock; it does not mean every participant has bounded latency.

### 14.3 Process-shared mutexes and owner death

A POSIX alternative is a `pthread_mutex_t` located in the shared region and
initialized with `PTHREAD_PROCESS_SHARED` attributes. All participants must use
compatible implementations and avoid racing with initialization/destruction.
The default process-private mutex attributes are insufficient. See
[`pthread_mutexattr_setpshared(3)`](https://man7.org/linux/man-pages/man3/pthread_mutexattr_setpshared.3.html).

A **robust mutex** can report that its previous owner died, through `EOWNERDEAD`.
The new owner must repair protected state and declare it consistent using the
appropriate API, or deliberately leave it unrecoverable. The mutex detects the
event; it does not reconstruct a half-written message. See
[`pthread_mutexattr_setrobust(3)`](https://man7.org/linux/man-pages/man3/pthread_mutexattr_setrobust.3.html).

### 14.4 Store offsets, not process-local pointers

Process A may map a shared object at `0x10000000`; process B may map it at
`0x70000000`. A pointer written by A normally cannot be used by B.

Store a byte offset relative to the mapping base and reconstruct a local pointer:

```text
local address = this process's mapping base + validated stored offset
```

Check that the offset and required object length fit within the region before
addition. Define a representation for “no object,” such as a reserved offset.
Offsets also survive remapping at a different address, but do not solve lifetime,
concurrent reclamation, format compatibility, or corruption by themselves.

## 15. C++ objects, binary formats, and pointer safety

### 15.1 Mapped bytes are not automatically arbitrary C++ objects

An object needs suitable storage, alignment, a valid lifetime, and a valid
representation. `reinterpret_cast<Record*>(base)` changes the pointer type; it
does not validate the file or make every possible byte pattern a usable `Record`.

**Alignment** means an address satisfies the type's divisibility requirement.
The mapping base is page aligned, but `base + 3` may not meet an integer's or
record's alignment requirement.

**Object lifetime** is the period during which a C++ object exists according to
the language rules. `mmap` is outside ISO C++; the implementation's interaction
with the object model matters. For writable anonymous storage, explicitly
construct nontrivial objects and destroy them before unmapping. Placement `new`
constructs an object at an existing suitably aligned address; it does not allocate
the backing region. See the [C++ lifetime rules](https://eel.is/c++draft/basic.life).

For read-only file formats, decoding bytes into ordinary local values is often
the clearest approach. C++23's explicit lifetime facilities can help in narrowly
specified cases but do not fix incompatible layouts, invalid representations,
endianness, or arbitrary nontrivial serialized objects.

### 15.2 What makes dumping a struct fragile?

| Issue | Explanation |
|---|---|
| Padding | A compiler can insert unused bytes between members or at the end of a structure. |
| Endianness | The order in which a multibyte integer's bytes are stored. |
| ABI | The application binary interface: machine-level conventions including layout and calling rules. |
| Width | Types such as `long` and pointers can differ in size between platforms. |
| Representation | Not every arbitrary bit pattern is valid for every C++ type. |
| Embedded pointers | Their targets belong to a particular address space and lifetime. |
| Versioning | A later program may assign a different meaning or layout to the same bytes. |

**Serialization** converts program values into a defined external byte format;
**deserialization** validates and reconstructs values from that format.
Memory mapping is an access technique, not a serialization format.

`std::string`, `std::vector`, virtual-function objects, and ordinary pointer-linked
containers are not portable persistent file representations. A vector's elements
usually live in a separate allocation, so mapping or dumping its control object
does not capture those elements.

### 15.3 Example: explicitly decode a little-endian integer

This C++20 helper fragment requires `<cstddef>`, `<cstdint>`, `<span>`, and
`<stdexcept>`. It avoids unaligned typed loads and host byte-order assumptions.

```cpp
std::uint32_t read_u32_le(std::span<const std::byte> input, std::size_t offset) {
    if (offset > input.size() || input.size() - offset < 4)
        throw std::out_of_range("truncated 32-bit field");
    std::uint32_t value = 0;
    for (unsigned int i = 0; i < 4; ++i)
        value |= std::to_integer<std::uint32_t>(input[offset + i]) << (8u * i);
    return value;
}
```

Copying with `memcpy` into an existing trivially copyable local object can avoid
an alignment/type-access problem, but only use it when the file's representation
is actually valid for that type. **Trivially copyable** is a C++ property allowing
certain object-byte copying operations; it does not mean “portable file format.”

For a robust file format, define a header with identification bytes, a version,
sizes, byte order, and explicit bounds for all ranges. Validate lengths before
multiplication: for records of size `R`, prefer checking `count <= remaining / R`
when `R > 0`. A mapped pointer does not make untrusted file content safe.

### 15.4 Views, strings, and vectorized reads

A `std::string_view` or `std::span` into a mapping is non-owning. It must not
outlive the owner, survive a moving remap, or escape into work that runs after
unmapping. Copying a view does not extend the mapping's lifetime.

Do not call `strlen` on arbitrary mapped file data: it searches for a zero byte
without knowing the mapping's end. A parser using SIMD, single instruction
multiple data, may load several bytes at once. It must still handle the final
bytes without an out-of-range load; apparent padding up to a page boundary is
not a general format or language guarantee.

## 16. mmap versus read, pread, and other I/O

**I/O** means input/output: transferring information to or from files, devices,
or communication endpoints. `read` copies bytes into a supplied buffer and
advances an open file description's position. `pread` reads at an explicit file
offset without modifying that position. Both can return fewer bytes than requested;
callers must handle short reads and errors.

| Dimension | File mapping | Buffered `read` / `pread` |
|---|---|---|
| Access interface | Loads and stores through addresses. | Explicit operations on buffers. |
| Error location | Setup can fail; later access can fault or signal. | Most transfer errors are returned at I/O calls. |
| Extra data copy | Usually avoids the page-cache-to-user-buffer copy. | Usually copies from page cache to the supplied buffer. |
| Page tables | Translations needed for the accessed mapped range. | A reusable buffer can keep translation footprint smaller. |
| Access pattern | Convenient random access and repeated scans. | Convenient streaming and controlled batching. |
| Resource control | OS handles demand paging and reclaim; advice can influence it. | Application chooses buffer sizes and request timing more explicitly. |
| File changes | Mapping lifetime does not protect file size or records. | Short reads/errors are often easier to handle, but consistency still needs a protocol. |
| Working data | Can parse directly from stable file bytes. | Application owns the copied bytes until it changes them. |
| Persistence | Requires explicit policy for shared stores. | Requires explicit policy for writes and synchronization. |

### 16.1 Why can mmap be faster?

It can avoid copying large amounts of file data and allow many processes to read
the same cached pages. Random access can use normal address calculations.
Repeated scans of a resident mapping avoid repeated explicit read operations.
An index with stable offsets and long-lived readers is a good candidate to benchmark.

### 16.2 Why can mmap be slower?

First access can incur many faults, page-table allocation, and kernel contention.
Mapping and unmapping many tiny regions adds overhead. A large address footprint
can increase TLB pressure. Blocking storage faults occur inside the access path,
so the application has less direct control over request scheduling.

A large sequential `read` into a reusable buffer can amortize system-call costs
over many bytes and benefit from efficient readahead. Copying is a real cost,
but it is not necessarily the dominant cost of the workload.

### 16.3 How do malloc, stdio, streams, and asynchronous I/O relate?

- `malloc` allocates storage; it does not read file contents. It is often used
  to obtain the buffer passed to `read`.
- `FILE*` functions such as `fread` add C library buffering and stream state.
- `std::ifstream` adds C++ stream facilities and buffering. Performance depends
  heavily on how it is used, especially per-character versus bulk operations.
- Asynchronous I/O interfaces let an application submit work and handle completion
  later. They can provide explicit control of concurrency and queue depth, the
  number of outstanding requests. They are a different scheduling model from
  blocking on an unexpected page fault.

`O_DIRECT` requests a form of I/O intended to reduce ordinary page-cache involvement,
subject to filesystem/device restrictions and alignment rules. It is not a switch
that makes an ordinary file mapping bypass the page cache. Mixing overlapping
direct I/O and mapped access needs documented coherency rules and coordination.
See the direct-I/O discussion in [`open(2)`](https://man7.org/linux/man-pages/man2/open.2.html).

## 17. Prefaulting, advice, locking, and latency

**Latency** is the time to complete one operation. **Throughput** is work completed
per unit time. **Tail latency** concerns the slow end of the distribution, such
as the 99th percentile, rather than just the average.

### 17.1 Prefaulting is preparation, not permanent residency

**Prefaulting** triggers page preparation before the latency-sensitive operation.
On Linux, `MAP_POPULATE` asks for page-table population and file readahead during
mapping. Mapping success does not prove complete population succeeded.

Touching pages yourself can also populate them, but a read touch of anonymous
memory may only map a shared zero page. Preparing later private writes can require
write faults and COW allocations. Do not write-touch a read-only mapping, change
file data accidentally, or touch outside the logical range.

After population, pages can still be reclaimed unless stronger measures apply.
CPU caches and TLB entries can be evicted even while pages remain resident.

### 17.2 What madvise can and cannot promise

`madvise` tells Linux how a mapped address range will be used. Ordinary hints are
not guaranteed schedules. Some advice values actually change memory contents or
semantics, so the API is not uniformly harmless.

| Advice | Intended use or significant effect |
|---|---|
| `MADV_NORMAL` | Normal access policy. |
| `MADV_SEQUENTIAL` | Expect a forward scan. |
| `MADV_RANDOM` | Expect nonsequential access. |
| `MADV_WILLNEED` | Ask the kernel to prepare data likely to be used soon. |
| `MADV_DONTNEED` | Discard eligible contents/translations; private anonymous pages can subsequently read as zeros. |
| `MADV_FREE` | Mark eligible private anonymous pages reclaimable; contents may disappear after reclamation. |
| `MADV_HUGEPAGE` | Prefer transparent huge pages where supported. |
| `MADV_NOHUGEPAGE` | Exclude eligible ranges from transparent huge-page use. |
| `MADV_DONTFORK` | Exclude the range from a child created by `fork`. |
| `MADV_DONTDUMP` | Exclude the range from ordinary core dumps. |

Linux `MADV_POPULATE_READ` and `MADV_POPULATE_WRITE` provide explicit population
operations on existing mappings and can report errors; partial progress is possible.
Availability depends on the running kernel. These still do not permanently lock
the pages. Consult [`madvise(2)`](https://man7.org/linux/man-pages/man2/madvise.2.html)
for each advice value's precise constraints.

`posix_fadvise` provides advice through a file descriptor rather than a virtual
address range. Advice through either interface is not an interprocess synchronization
protocol and should be validated with measurements. Its return convention is an
error number directly, unlike `madvise`'s `-1` plus `errno`. See
[`posix_fadvise(2)`](https://man7.org/linux/man-pages/man2/posix_fadvise.2.html).

### 17.3 mlock, MAP_LOCKED, and real-time expectations

`mlock` keeps covered pages resident while the lock remains in effect, subject to
successful acquisition and applicable limits. `RLIMIT_MEMLOCK` is the process
resource limit controlling how much memory can be locked without additional
privileges. `mlock2` with `MLOCK_ONFAULT` changes when pages are brought in, so it
is not equivalent to eagerly making every page resident.

Linux `MAP_LOCKED` has weaker population/error behavior than explicitly checking
`mlock` after mapping. Fork/COW, changing mappings, and invalidating backing files
still need attention. Locking also does not guarantee CPU-cache or TLB residency,
eliminate scheduling interruptions, or reserve device bandwidth. See
[`mlock(2)`](https://man7.org/linux/man-pages/man2/mlock.2.html).

A latency preparation plan should define the working set, fault it appropriately,
check locking where justified, prepare stacks and other allocations, and measure
under realistic memory pressure. A **working set** is the subset of memory an
application actively uses during a relevant interval.

## 18. Huge pages, NUMA, and translation costs

### 18.1 Why larger pages can help

A **huge page** covers more memory per translation than the ordinary base page.
For an illustrative x86-64 configuration, a 2 MiB page covers the same byte count
as 512 base pages of 4 KiB. This can reduce translation-table memory and increase
the amount of memory covered by a limited number of TLB entries, called **TLB reach**.

Illustrative arithmetic: 1 GiB / 4 KiB = 262,144 base pages. With 8-byte leaf
entries, leaf PTEs alone occupy 2 MiB. Higher-level tables and other metadata
add costs. This is an architecture-specific example, not a universal accounting
formula or a promise about the cost of an untouched mapping.

### 18.2 Explicit huge pages versus transparent huge pages

**HugeTLB** is Linux's explicit huge-page facility, commonly used through
`MAP_HUGETLB` or hugetlbfs. It involves configured availability, permissions,
and huge-page alignment rules. Ordinary base-page rounding assumptions are
insufficient, particularly for unmapping. See
[HugeTLB documentation](https://docs.kernel.org/admin-guide/mm/hugetlbpage.html).

**THP**, transparent huge pages, allows the kernel to use larger pages for eligible
ranges according to policy and support. `MADV_HUGEPAGE` is a preference, not
proof that the range is currently using huge pages. Eligibility and available
sizes depend on mapping type, kernel, and configuration. See
[transparent huge-page documentation](https://docs.kernel.org/admin-guide/mm/transhuge.html).

Costs can include wasted memory for sparse use, memory compaction, and latency
when large pages are allocated, split, or collapsed. **Compaction** rearranges
physical memory to form larger contiguous free regions. Measure the tradeoff;
huge pages are not automatically beneficial to every file mapping.

### 18.3 NUMA and first-touch placement

**NUMA**, non-uniform memory access, describes machines with memory attached to
different processor nodes. A core can access local memory faster than memory on
another node. **First-touch placement** commonly means the thread that first
materializes a new anonymous page influences where that page is allocated,
subject to the operating system's memory policy.

An initialization thread on one node can inadvertently place all pages far from
the eventual worker threads. Existing page-cache pages can already have a placement
before a reader maps them, so “my first mmap access makes the page local” is not
a reliable rule for files.

**CPU affinity** constrains which CPUs a thread can run on. Affinity and memory
placement policy can improve locality when chosen together, but require workload
measurement and an understanding of the machine topology.

### 18.4 TLB shootdowns and false sharing

A **TLB shootdown** invalidates stale translations on CPUs that might use them
after mapping or protection changes. This can involve **IPIs**, interprocessor
interrupts: notifications from one CPU to another. Frequent `munmap`/`mprotect`
in a heavily threaded process can therefore affect other cores.

**False sharing** happens when independent variables share a hardware cache line
and different cores repeatedly modify them. The line moves between caches even
though the variables are logically independent. Shared-memory queues should
consider cache-line layout as well as page layout. Padding can help, but its
size and effect should be measured on the target hardware.

## 19. Protection, fixed addresses, and advanced mappings

### 19.1 Guard pages and mprotect

A **guard page** is deliberately inaccessible memory placed next to a usable
region, so some out-of-bounds accesses trigger a fault. `mprotect` changes access
permissions on page-aligned regions. It does not add fine-grained C++ bounds
checking: an overflow that stays within an accessible page is not caught.
See [`mprotect(2)`](https://man7.org/linux/man-pages/man2/mprotect.2.html).

An allocator can reserve a large `PROT_NONE` range and progressively enable
access to portions it owns. Address-space reservation alone does not guarantee
that future physical allocation will succeed.

### 19.2 Why MAP_FIXED is dangerous

`MAP_FIXED` requests a specific address and can discard overlapping mappings.
Choosing an apparently unused address after inspecting `/proc/PID/maps` is racy:
another thread or library can allocate there before the mapping call.

Linux `MAP_FIXED_NOREPLACE` fails rather than replacing an existing overlapping
mapping. On older kernels that do not recognize this flag, verify the returned
address because the request can fall back to hint-like behavior.

One legitimate specialized use of `MAP_FIXED` is replacing a region that the
application already reserved and exclusively controls. It still requires correct
ownership and synchronization with every potential user of that range.

### 19.3 Can the same bytes appear twice in one address space?

Yes. Mapping the same file-backed region twice creates aliases. A specialized
ring-buffer design maps the same backing region at adjacent virtual addresses,
so a wraparound byte range can appear contiguous.

This requires careful address reservation, alignment, synchronization, and cleanup.
Two independent private mappings do not provide shared writable aliases after COW.
The technique does not solve queue ownership or publication ordering.

### 19.4 JIT code and executable permissions

A **JIT**, just-in-time compiler, generates machine instructions at runtime.
A common policy is **W^X**, writable XOR executable: memory should not be both
writable and executable at the same time. A code generator can fill writable
storage, then establish executable permissions under platform policy.

Instruction-cache maintenance may be needed on some architectures before generated
code can run correctly. Changing page permissions alone is not a portable complete
JIT protocol. Data-only applications normally have no reason to request execution.

### 19.5 Persistent memory and MAP_SYNC

**DAX**, direct access, is a filesystem/device facility that can expose suitable
persistent memory without the ordinary page-cache data path. It is not what an
ordinary mapping of an SSD file normally does.

Linux `MAP_SYNC`, used with `MAP_SHARED_VALIDATE` on supported DAX files, supports
specialized persistence workflows. It does not make arbitrary CPU stores into
complete durable transactions; cache-flush instructions, ordering, and recovery
protocols still matter. Ordinary file-mapping recipes must not be transferred to
device or persistent-memory mappings without checking their contracts.

## 20. Errors and debugging

### 20.1 Common setup errors

| Error | Typical reasons to investigate |
|---|---|
| `EINVAL` | Zero length, bad alignment, or an invalid combination of flags. |
| `EACCES` | Requested protections incompatible with file access or permissions. |
| `EBADF` | Invalid file descriptor for a file mapping. |
| `ENODEV` | Backing object or filesystem does not support this mapping. |
| `ENOMEM` | Address-space exhaustion, resource limits, mapping-count limits, or allocation failure. |
| `EEXIST` | Overlap with `MAP_FIXED_NOREPLACE`. |
| `EPERM` | A policy, seal, or privilege restriction; inspect the actual operation. |
| `EOVERFLOW` | Offset/length accounting overflow on affected platforms. |

This is a diagnostic starting point; consult the actual interface's error list.
`ENOMEM` does not uniquely mean “RAM is full.” A fragmented 32-bit address space,
container limits, or Linux `vm.max_map_count` can be the relevant constraint.
Many small mappings and protection changes can increase VMA counts; adjacent
compatible regions can sometimes be merged, so one syscall is not always one
permanent VMA.

### 20.2 Useful inspection commands

Run these with the appropriate permissions and substitute the actual PID:

```sh
getconf PAGESIZE
cat /proc/PID/maps
cat /proc/PID/smaps
pmap -x PID
strace -e trace=mmap,munmap,mprotect,madvise,msync,openat,close ./your_program
perf stat -e page-faults,minor-faults,major-faults ./your_program
```

`/proc` is Linux's virtual filesystem exposing process and kernel information.
`maps` shows address ranges, permissions, file offsets, and backing names.
`smaps` adds memory accounting. `strace` observes system calls, so an absence
of `read` calls does not prove an absence of file I/O: page faults can initiate it.
`perf` measures supported performance events; permissions or event availability
can limit its use.

`mincore` can query page residency under platform permission restrictions. The
result is a snapshot: it cannot guarantee a later access will avoid faults, and
resident backing data does not prove this process already has all translations.
See [`mincore(2)`](https://man7.org/linux/man-pages/man2/mincore.2.html).

A **core dump** records process state for debugging after certain failures.
Use a debugger to inspect the faulting instruction and address, then compare
that address with mapping boundaries, permissions, file offset, and current file
size. A backtrace ending in an innocent parser load can still indicate truncation.

Sanitizers are useful but not proofs of mmap correctness. They may not detect
every logical file bound violation inside an accessible page, and ordinary race
detectors do not automatically validate a cross-process protocol.

## 21. Measuring mmap correctly

### 21.1 Benchmark the work, not just the mapping call

Timing only `mmap` excludes most demand-paging and parsing work. A meaningful
comparison includes setup as appropriate, accesses to the required bytes,
parsing/computation, cleanup, and durability when it is part of the requirement.

Keep an observable result, such as a checksum, so the compiler cannot simply
remove unused reads. Compare the same logical computation and correctness
requirements on both paths.

### 21.2 Distinguish three warm states

1. **Cold file data:** required data is not in the relevant file cache.
2. **Warm page cache, new mapping:** data is resident but the process can still
   need faults and translations.
3. **Warm existing mapping:** data and translations have been accessed before,
   though CPU caches and TLBs can still miss.

One benchmark run can warm the next. Merely unmapping a file does not remove it
from the page cache. Do not present warm-cache results as storage performance.

### 21.3 What to record

- File size, accessed fraction, access pattern, and record size.
- Storage and filesystem, kernel version, CPU architecture, and available RAM.
- Number of threads/processes and NUMA placement where relevant.
- End-to-end time, throughput, and latency distribution.
- Minor/major faults, resident memory, page-table overhead where observable,
  CPU usage, and relevant cache/TLB events.
- Effects of memory pressure and competing activity.
- Whether flushing, file creation, or cold-cache preparation is included.

Avoid universal nanosecond claims for faults or mapping calls. Device latency,
memory contention, scheduling, kernel work, and configuration all affect them.
Changing system-wide cache state can disrupt unrelated workloads; use an isolated
benchmark environment when that experiment is necessary.

## 22. Portability and unusual backing objects

### 22.1 POSIX versus Linux versus ISO C++

`mmap`, `munmap`, `msync`, and the central file-mapping model are POSIX facilities,
not ISO C++ library facilities. Linux-specific interfaces or flags in this guide
include `mremap`, `memfd_create`, `MAP_POPULATE`, `MAP_FIXED_NOREPLACE`, and several
`madvise` options. Compile-time availability does not ensure the running kernel
supports a feature; handle documented runtime failures or fallback behavior.

BSD and macOS have related interfaces but can differ in flags, permissions,
resource accounting, and advice semantics. Windows uses file-mapping objects
and mapped-view APIs with its own granularity and lifetime rules. An application
portability layer should expose the behavior it needs instead of assuming the
same flags and error behavior exist everywhere.

On 32-bit systems, a large file can exceed available contiguous virtual space
even when storage and physical RAM are sufficient. Large-file offsets and
windowed mappings solve different parts of that problem.

### 22.2 Pipes, devices, tmpfs, and network filesystems

Ordinary pipes and sockets are streams, not regular files with a directly usable
file-mapping interface. Some kernel interfaces expose special shared rings or
device mappings, but those are separate documented protocols.

**tmpfs** is a memory-backed filesystem used for facilities such as Linux POSIX
shared memory. It may use swap and is not ordinary reboot-persistent storage.
“It has a file descriptor” does not imply “its bytes are durable on disk.”

A **device mapping** can represent device registers or special buffers.
**MMIO**, memory-mapped I/O, uses addresses to access device resources.
Ordinary cacheability, load/store, alignment, and ordering assumptions may not
apply. `volatile` has specialized uses with device interfaces, but is not a
general replacement for the required driver/platform access protocol.

**DMA**, direct memory access, lets a device transfer data to or from memory
without the CPU copying every byte. **Pinning** pages for a device has kernel and
driver requirements beyond merely keeping them resident with `mlock`; locking
does not promise a stable physical address or establish a device mapping.
See the kernel's [page-pinning documentation](https://docs.kernel.org/core-api/pin_user_pages.html).

Network filesystems can have different cache-consistency and failure behavior.
Do not infer cross-machine synchronization guarantees from coherent shared memory
within one machine. Verify the filesystem's documented mapping support and use
an application protocol suitable for remote participants.

## 23. Interview questions and model answers

These questions consolidate the guide and add design-oriented follow-ups.

### Fundamentals

**1. What is mmap in one sentence?**

It creates a virtual-address mapping to a file, another supported backing object,
or anonymous memory, allowing access through memory operations.

**2. Does mapping a 100 GiB file allocate 100 GiB of RAM immediately?**

Normally no. It reserves a corresponding virtual range and creates metadata;
physical residency and translations generally grow with access. Address-space,
metadata, resource limits, and population flags still matter.

**3. Is a mapped file guaranteed to remain in RAM?**

No. Ordinary pages can be reclaimed. A later access may fault again. Checked
memory locking provides stronger residency guarantees within its constraints.

**4. What is the difference between a TLB miss and a page fault?**

A TLB miss means a cached translation was unavailable. A valid page-table entry
can satisfy it. A page fault requires exception handling because translation
or permissions did not allow the current access to complete normally.

**5. Is a minor fault free because it does not read the disk?**

No. It still invokes fault handling and may allocate, copy, update tables,
or contend on shared kernel structures.

**6. Does mmap bypass the page cache?**

Ordinary buffered file mappings use it. Specialized device or DAX mappings have
different contracts.

**7. Does virtual memory mean swap?**

No. Virtual memory is address translation, isolation, sharing, and related
management. Swap is one possible backing mechanism for some memory.

**8. Does zero-copy mean no data movement?**

No. It usually means avoiding the additional copy from the file page cache to
an application read buffer. Storage transfers, CPU cache movement, and COW remain.

### API and ownership

**9. Why is checking the return value against nullptr wrong?**

The API's failure sentinel is `MAP_FAILED`. A null comparison tests the wrong
condition regardless of whether normal platform policies avoid mapping address zero.

**10. Why must the file offset be aligned, but the length need not be?**

The offset establishes which backing page corresponds to the first virtual page.
Length describes requested bytes; the OS operates on the pages covering that range.

**11. How do you map bytes 5000 through 5999 with 4096-byte pages?**

Map from offset 4096 with requested length 1904. Access 1000 bytes beginning
904 bytes from the returned base. Unmap using the original base.

**12. Can the descriptor be closed immediately after mmap?**

Yes, after success. The mapping holds a reference to the backing object. Retain
the descriptor if later operations such as `fsync` or resizing need it.

**13. Does mmap change the file descriptor's current offset?**

No. Its explicit file offset is independent of the current read/write position.

**14. What should happen for an empty file?**

Return an empty application view or an application-specific error. Do not call
`mmap` with zero length.

**15. Can you free the pointer with free or delete[]?**

No. Release the mapping with `munmap`. Destroy any explicitly constructed objects
before releasing their backing storage.

**16. Does the OS clean up mappings on process exit?**

Yes, but that does not provide an application-visible durable commit result or
replace explicit lifetime management while the process is running.

**17. Is unmapping part of a region possible?**

Ordinary mappings can be partially unmapped under alignment rules. This can
split regions and complicate ownership. A simple RAII owner should either forbid
external partial unmapping or explicitly track it.

### Sharing and consistency

**18. Does MAP_PRIVATE mean private to one thread?**

No. Threads in the process share the mapping. The private behavior concerns
propagation to the backing file and other independently private mappings.

**19. Does MAP_PRIVATE copy the whole file at mmap time?**

Normally no. Private writes can create private page copies lazily through COW.

**20. Is MAP_PRIVATE a stable snapshot of a changing file?**

No. Require immutable input or an explicit snapshot/version protocol.

**21. Can a private writable mapping use an O_RDONLY descriptor?**

For the normal file COW case, yes: modifications remain private. A shared
writable mapping normally needs `O_RDWR`.

**22. Does MAP_SHARED remove the need for locks?**

No. It provides shared storage. Ownership, publication, concurrent reads/writes,
and lifetime still need synchronization.

**23. Can volatile bool ready synchronize shared-memory messages?**

No. `volatile` does not provide the necessary atomicity or interthread ordering.
Use a supported process-shared primitive or a documented atomic protocol.

**24. Can any std::atomic be placed in shared memory?**

Do not assume so. Verify interprocess implementation support, lock freedom where
required, correct initialization, lifetime, alignment, and representation.

**25. Why store offsets instead of pointers in shared memory?**

Participants can map the same object at different addresses. Validated offsets
allow each participant to reconstruct an address relative to its own base.

**26. What happens to mappings after fork?**

Normally they are inherited. Private mappings can diverge through COW, while
shared mappings remain shared. Some Linux advice can change inheritance.

### Files and durability

**27. Does writing beyond EOF through a mapping append data?**

No. First extend the file using a size-changing operation. Entire pages beyond
EOF can cause `SIGBUS`, and the partial-page tail is not append storage.

**28. Does ftruncate reserve enough disk space for later writes?**

Not necessarily. It establishes logical length. Use an appropriate allocation
operation when storage reservation is a requirement.

**29. Why can a successful mapping later cause SIGBUS?**

Its backing may become invalid for the access, especially after truncation, or
an underlying fault may prevent satisfying the page access.

**30. Does stat before mmap eliminate truncation races?**

No. Even `fstat` on the correct object cannot prevent a later size change.
Prevent the change through the data-sharing design.

**31. Does unlink invalidate the mapping?**

No. The mapped object can remain alive after its pathname is removed.

**32. Does replacing a path make existing mappings see the replacement file?**

No. Existing mappings retain the old object. New readers can open the new one.

**33. When do shared writes reach storage?**

They can be written in the background. Use a checked synchronization operation
when the application requires an explicit completion boundary.

**34. Is msync necessary for another process to read shared bytes?**

Not as an ordinary shared-memory publication mechanism. Correct synchronization
is necessary; a storage flush serves a different purpose.

**35. Does MS_SYNC make a multibyte record update transactional?**

No. A crash during updates or synchronization can leave partial state. Define
a transaction/recovery protocol when consistency after failure matters.

**36. Are munmap and close substitutes for fsync?**

No. Releasing resources does not provide the same checked durability boundary.

**37. Does flushing a file make a new filename durable?**

Not by itself. Directory synchronization can be required for durable creation
or rename under the target filesystem's guarantees.

### C++, performance, and design

**38. Can a mapped file be cast to an array of structs?**

Only with justified layout, alignment, lifetime, representation, and bounds
assumptions. For an external format, explicitly decoding fields is often safer.

**39. Can you persist std::vector by mapping its object?**

No general solution follows from that: its control object contains process-specific
state and references a separate allocation. Design an external format instead.

**40. Can mmap fail despite plenty of free RAM?**

Yes. Address-space limits, fragmentation, permissions, unsupported objects,
mapping-count limits, and invalid arguments are separate concerns.

**41. Is mmap always faster than read?**

No. Saved copies compete with faults, translation costs, and less explicit I/O
scheduling. Benchmark the real access pattern and cache conditions.

**42. Does MAP_POPULATE guarantee no future page faults?**

No. Population can be incomplete, pages can be reclaimed, and later writes or
mapping changes can require additional work.

**43. Does mlock guarantee a hard real-time deadline?**

No. It addresses residency, not all scheduling, translation, cache, COW, or device
latency sources. Hard deadlines require a wider system design.

**44. Can huge pages make an application slower?**

Yes. Sparse access, allocation/compaction costs, and splitting or collapsing
pages can outweigh translation benefits.

**45. Why does a second benchmark run become much faster?**

The first run may have populated file caches and other state. Separate cold
data, warm page cache, and warm mapping measurements before drawing conclusions.

**46. Would you use mmap for a file another service edits unpredictably?**

First establish an immutable-version or synchronization contract. If that is
unavailable, explicit reads generally offer a more manageable error boundary,
though they still do not create a consistent multi-read snapshot.

**47. How would you design a mapped log?**

Separate allocated capacity from committed logical length; define record framing,
publication and durability rules, checksums or validation, recovery from an
incomplete tail, and a rotation/remapping protocol. Mapping alone supplies none
of these. A live reader's publication boundary and a restart's durable boundary
may be different counters.

**48. What would you ask before choosing mmap?**

Ask about access pattern, file lifetime and mutation, size relative to address
space/RAM, error handling, concurrency, durability, latency goals, target systems,
and evidence from an equivalent benchmark.

## 24. Exercises with expected reasoning

### Exercise 1: diagnose a broken reader

Intentionally incorrect pseudocode:

```text
p = mmap(...)
if p is null: report failure
print p as a zero-terminated string
free(p)
```

Identify three independent errors: wrong failure sentinel, missing bounded string
handling, and wrong deallocation API. Also ask about empty files, size conversion,
permissions, descriptor cleanup, and concurrent truncation.

### Exercise 2: implement a mapped subrange

For file size 20,000, page size 4096, start 8190, and count 10, compute the mapping.

Expected: aligned offset 4096, delta 4094, requested length 4104. The logical
range crosses a page boundary. Test overflow and EOF bounds before calling mmap.

### Exercise 3: explain a private write

Two independent processes privately map a file containing `abc`. A changes the
first byte to `x`. Explain why A can see `xbc`, while the file and B remain `abc`
under stable-input assumptions. Account for a possible write fault and a private
page allocation. Explain why `msync` does not publish A's private bytes.

### Exercise 4: reason about a truncation race

Reader maps two pages. Writer shrinks the file to one page. Reader touches the
second page. Expected: the access can deliver `SIGBUS`; checking size earlier
does not fix the race. Propose immutable version replacement or a cooperative
lifetime protocol instead of adding a third size check.

### Exercise 5: design a shared message

Specify who initializes the region, how readers learn initialization completed,
how publication is synchronized, when the writer can reuse the payload, and what
happens if either process dies. An answer containing only `MAP_SHARED` is incomplete.

### Exercise 6: design a durable update

Two related fields must survive power failure consistently. Explain why a mutex
plus `msync` does not supply an atomic transaction. Sketch either logging and
recovery or an immutable generation with a carefully synchronized publication step.

### Exercise 7: compare mmap and pread

Benchmark a full sequential checksum and a random lookup workload. Keep the
calculation identical. Report cache state, faults, end-to-end latency, and memory
use. Explain why comparing only `mmap()` time against a completed `pread()` is unfair.

### Exercise 8: find the lifetime error

Conceptual C++ fragment using the owner from section 8:

```cpp
std::span<const std::byte> dangling_view(const char* path) {
    MappedFile file{path};
    return file.bytes(); // Invalid after file's destructor unmaps the region.
}
```

Expected: return an owner, return a copy of the needed data, or arrange an explicit
shared owner that outlives every view. A copied span alone owns nothing.

## 25. Implementation checklist and short interview answer

Before calling a mapping-based component complete, be able to explain:

- Why mapping fits the access pattern and failure model.
- Who owns the file/object and prevents unsafe truncation or mutation.
- How lengths, offsets, conversions, alignment, and empty files are handled.
- Which permissions and sharing semantics are intended.
- Which object owns the mapping and how every borrowed view remains valid.
- How concurrent access and initialization are synchronized.
- What visibility, durability, and crash consistency each operation promises.
- How delayed access failures and synchronization failures are handled.
- Which assumptions concern C++ lifetime, representation, and binary layout.
- Which measurements justify any prefaulting, locking, advice, or huge-page tuning.

A useful short interview answer:

> mmap establishes a virtual-memory mapping so a process can access file-backed
> or anonymous storage through loads and stores. Ordinary file mappings use the
> page cache and normally populate pages on demand. MAP_PRIVATE gives private
> copy-on-write changes; MAP_SHARED allows shared changes to the backing object.
> I check MAP_FAILED, validate lengths and aligned offsets, handle empty files,
> and bind the mapping to an owner. I protect readers from truncation, separate
> synchronization from persistence, and benchmark against buffered I/O because
> avoiding a copy does not make mmap universally faster.

## 26. Further reading

Use the linked primary references for exact contracts and platform details:

- [Linux mmap/munmap manual](https://man7.org/linux/man-pages/man2/mmap.2.html)
  for arguments, sharing, flags, errors, EOF, and mapping caveats.
- [Kernel memory-management concepts](https://docs.kernel.org/admin-guide/mm/concepts.html)
  for address translation, backing, reclamation, and memory pressure.
- [msync](https://man7.org/linux/man-pages/man2/msync.2.html),
  [fsync/fdatasync](https://man7.org/linux/man-pages/man2/fsync.2.html), and
  [rename](https://man7.org/linux/man-pages/man2/rename.2.html)
  for synchronization and name replacement.
- [ftruncate](https://man7.org/linux/man-pages/man2/ftruncate.2.html) and
  [posix_fallocate](https://man7.org/linux/man-pages/man3/posix_fallocate.3.html)
  for logical sizing versus allocation.
- [shm_open](https://man7.org/linux/man-pages/man3/shm_open.3.html),
  [memfd_create](https://man7.org/linux/man-pages/man2/memfd_create.2.html),
  [process-shared mutex attributes](https://man7.org/linux/man-pages/man3/pthread_mutexattr_setpshared.3.html),
  and [robust mutex attributes](https://man7.org/linux/man-pages/man3/pthread_mutexattr_setrobust.3.html)
  for shared-memory infrastructure.
- [madvise](https://man7.org/linux/man-pages/man2/madvise.2.html),
  [mlock](https://man7.org/linux/man-pages/man2/mlock.2.html),
  [mprotect](https://man7.org/linux/man-pages/man2/mprotect.2.html), and
  [mremap](https://man7.org/linux/man-pages/man2/mremap.2.html)
  for advice, residency, protection, and resizing.
- [HugeTLB](https://docs.kernel.org/admin-guide/mm/hugetlbpage.html) and
  [transparent huge pages](https://docs.kernel.org/admin-guide/mm/transhuge.html)
  for Linux large-page facilities.
- [smaps](https://man7.org/linux/man-pages/man5/proc_pid_smaps.5.html) and
  [getrusage](https://man7.org/linux/man-pages/man2/getrusage.2.html)
  for memory and fault accounting.
- [C++ object lifetime](https://eel.is/c++draft/basic.life) and
  [C++ data races](https://eel.is/c++draft/intro.races) from the working draft;
  consult the edition targeted by your program because the online draft evolves.

Related material already in this repository:

- [Memory pages: from virtual addresses to physical RAM](25-memory-pages-complete-guide.md),
  for detailed page-table arithmetic, faults, physical allocation, reclaim, and huge pages.
- [Existing mmap chapter, in Russian](11-mmap-and-memory-mapped-files.md).
- [File I/O comparison](20-file-io-read-stdio-iostream-mmap.md).
- [Memory and ownership](02-memory-and-ownership.md).
- [Allocators](16-allocators.md).
- [Memory ordering and fences](22-memory-order-and-fences.md).
- [Detailed English memory-ordering and barriers guide](24-memory-order-and-barriers-complete-guide.md),
  with C++ synchronization proofs, complete examples, and interview exercises.
- [Existing mmap demonstration source](../../mmap_demo.cxx).

The examples in this guide are independent of the historical benchmark numbers
and validation claims in those other documents.

Example validation performed for this guide: all three complete programs compiled
with warnings treated as errors. Both readers produced matching byte counts and
checksums for seven inputs, including empty, arbitrary binary, page-boundary, and
multi-page files. Missing-file, directory, and usage errors were checked. The
writer's output and refusal to overwrite an existing file were checked. The
integer decoder was compiled and checked for valid input and out-of-bounds offsets.
These checks validate the examples' basic behavior, not power-failure recovery or
the behavior of every filesystem, architecture, or kernel extension.
