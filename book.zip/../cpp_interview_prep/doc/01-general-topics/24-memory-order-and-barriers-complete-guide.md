# Memory ordering and memory barriers: a detailed C++ interview guide

This guide develops the C++ memory model from first principles. It explains the
terminology, shows how to prove synchronization, connects language rules to
hardware, and examines the mistakes interviewers commonly use to test understanding.
The goal is to explain *why* an algorithm is correct, rather than memorize that
one line should say `acquire` and another should say `release`.

**Language baseline:** C++20/23. Runnable examples use C++20. Version-sensitive
details are marked, including the C++20 release-sequence change and the C++26
change to `memory_order_consume`. The stable C++20 draft N4861 is used for formal
rules; the continuously updated working draft is not silently treated as C++20.
References were checked on 2026-09-26.

**Execution baseline:** ordinary threads in one process accessing ordinary host
memory. Device registers, persistent storage, and interprocess shared memory have
additional contracts. Examples assume objects are initialized before sharing,
remain alive during access, and threads are eventually scheduled. None of the
algorithms promises a scheduling deadline.

Teaching programs assume worker creation succeeds and worker operations complete
without exceptions. A production component also needs cancellation and failure
handling so a failed participant cannot leave another waiting indefinitely.

**Code labels:** a **complete program** can be saved and compiled independently.
A **fragment** supplies only the relevant operations. Deliberately incorrect
fragments are labeled **INCORRECT** and must not be used as executable tests of
the set of permitted C++ outcomes.

## Contents

1. [The questions memory ordering answers](#1-the-questions-memory-ordering-answers)
2. [Foundational vocabulary](#2-foundational-vocabulary)
3. [Why executions can surprise you](#3-why-executions-can-surprise-you)
4. [Data races and undefined behavior](#4-data-races-and-undefined-behavior)
5. [The formal relationships used in proofs](#5-the-formal-relationships-used-in-proofs)
6. [The atomic API and legal memory orders](#6-the-atomic-api-and-legal-memory-orders)
7. [Relaxed ordering in detail](#7-relaxed-ordering-in-detail)
8. [Release and acquire in detail](#8-release-and-acquire-in-detail)
9. [Reusing storage requires a return handoff](#9-reusing-storage-requires-a-return-handoff)
10. [Release sequences and transitive publication](#10-release-sequences-and-transitive-publication)
11. [Read-modify-write and acq_rel](#11-read-modify-write-and-acq_rel)
12. [Sequential consistency](#12-sequential-consistency)
13. [Consume and dependency ordering](#13-consume-and-dependency-ordering)
14. [Compare-exchange, step by step](#14-compare-exchange-step-by-step)
15. [Fences and their three synchronization patterns](#15-fences-and-their-three-synchronization-patterns)
16. [Compiler barriers, signal fences, and volatile](#16-compiler-barriers-signal-fences-and-volatile)
17. [Hardware ordering on x86 and Arm](#17-hardware-ordering-on-x86-and-arm)
18. [Litmus tests and permitted outcomes](#18-litmus-tests-and-permitted-outcomes)
19. [Mutexes and other library synchronization](#19-mutexes-and-other-library-synchronization)
20. [Atomic wait and notification](#20-atomic-wait-and-notification)
21. [Building and explaining a spinlock](#21-building-and-explaining-a-spinlock)
22. [A complete SPSC queue and its proof](#22-a-complete-spsc-queue-and-its-proof)
23. [Lifetime, reference counting, ABA, and reclamation](#23-lifetime-reference-counting-aba-and-reclamation)
24. [Atomic types, atomic_ref, and progress guarantees](#24-atomic-types-atomic_ref-and-progress-guarantees)
25. [Performance and measurement](#25-performance-and-measurement)
26. [Testing, tooling, and the limits of experiments](#26-testing-tooling-and-the-limits-of-experiments)
27. [Sixty interview questions with model answers](#27-sixty-interview-questions-with-model-answers)
28. [Exercises with detailed answers](#28-exercises-with-detailed-answers)
29. [A proof checklist and interview answer](#29-a-proof-checklist-and-interview-answer)
30. [Primary references and related material](#30-primary-references-and-related-material)

Read sections 1–8 first. Sections 9–18 explain the subtle ordering rules.
Sections 19–24 apply them to real components. Sections 27–29 support revision.

## 1. The questions memory ordering answers

Suppose a producer writes a message and then sets a flag. A consumer observes
the flag and reads the message. There are several different questions:

1. Can either access tear, exposing only part of a value?
2. Is concurrent access to the flag legal in C++?
3. Does seeing the flag establish that the message can be read safely?
4. Can the producer overwrite the message while the consumer reads it?
5. Can either participant stop making progress?
6. Does any of this make the message survive a power failure?

Atomicity addresses part of the first two questions. Ordering and synchronization
address the third. Ownership and lifetime protocols address the fourth. Progress
properties and scheduling address the fifth. Persistence is a separate subject.

**Memory ordering** specifies constraints on which effects of memory operations
can be observed, and in what relationships, by threads. It is not simply a demand
that processors execute every instruction in the order written in the source.

**Memory barrier** is an overloaded term. It may mean a compiler ordering
constraint, a hardware fence instruction, or a C++ synchronization operation.
Always identify the layer. A C++ fence can require no hardware instruction on a
particular architecture and still have an essential language-level effect.

## 2. Foundational vocabulary

### 2.1 Program execution and storage

**Process:** a running program and its operating-system resources, including an
address space. **Thread:** one execution sequence within a process. Threads in
the same process normally share memory but have separate execution state.

**Core:** a processor execution resource. Threads are software entities; a thread
can move between cores, and multiple software threads can take turns on one core.
Simultaneous physical execution is not required for a C++ data race.

**Object:** a region of storage with a type and lifetime under C++ rules.
**Lifetime:** the period during which the object exists and may be used subject
to its type's rules. Correct ordering cannot rescue a pointer to an object whose
lifetime has already ended.

**Memory location:** the language unit used for determining conflicting accesses.
Roughly, it is a scalar object or a maximal sequence of adjacent nonzero-width
bit-fields. Separate ordinary structure members can be separate locations while
neighboring bit-fields can share one. It is not synonymous with a cache line.

**Load:** an operation obtaining a value from memory. **Store:** an operation
modifying a value. **Evaluation:** the language's execution of an expression or
part of one, including value computations and side effects. A **side effect**
includes modifying an object; it is not merely an incidental extra consequence.

### 2.2 Atomicity and compound operations

**Atomic operation:** an indivisible operation with the guarantees of its atomic
interface. Other atomic operations on that object cannot observe a partially
completed update. This does not imply that the operation uses one machine
instruction or that it is lock-free.

**Tearing:** observing pieces of different writes as one apparent value, such as
the high half of one integer update and the low half of another. A legal atomic
load of an atomic object does not tear with respect to atomic stores to it.

**Read-modify-write**, or **RMW:** an atomic operation that obtains the old value
and stores a new value as one atomic action. Examples include `fetch_add`,
`exchange`, and a successful compare-exchange.

**Compound operation:** several operations that together implement one higher-level
action. Atomic steps do not automatically make their composition atomic:

```cpp
// Fragment: x is std::atomic<int>.
x = x + 1; // An atomic load and a separate atomic store, not one atomic increment.
```

Two threads can both read 5 and both store 6. `x.fetch_add(1)` performs an RMW
and avoids that lost update, independent of whether its memory order is relaxed.

### 2.3 Visibility, ordering, and synchronization

**Visibility** is informal shorthand for which write a read can observe. Avoid
the vague claim “the value is visible everywhere now.” A useful claim names
the write, the read, and the ordering relation connecting them.

**Synchronization:** an operation or protocol that establishes specified ordering
between participants. A mutex handoff and a release/acquire atomic handoff are
examples. Sleeping, yielding, and observing elapsed time are not C++ synchronization.

**Publication:** making initialized data available to another participant through
a protocol that orders initialization before consumption.

**Ownership:** the right to access or modify an object during some interval.
Single-writer ownership can eliminate the need for an atomic payload, provided
handoffs correctly order conflicting accesses.

**Invariant:** a property the component promises to maintain, such as “a queue
slot is written only while owned by the producer.” Ordering choices must support
an invariant; choosing memory orders without one is guesswork.

### 2.4 Ordering relations: mathematical terms

A **relation** identifies ordered pairs of events. We write `A -> B` to mean
the particular relation holds from A to B. The arrow's label matters.

A **partial order** permits some events to be incomparable. A **total order**
places every distinct pair in one order or the other. Two unrelated writes in
different threads need not have a common C++ happens-before order.

**Transitive:** if A is related to B and B to C, the relation also connects A to C.
**Cycle:** a chain leading back to its starting event. A cycle in the order required
by a proposed execution can prove that execution impossible.

### 2.5 Correctness and progress

**Data race:** a specific C++ condition involving conflicting, potentially
concurrent operations, at least one non-atomic, without the required ordering.
Section 4 gives the full practical test.

**Race condition:** a broader logical defect where a result depends incorrectly
on timing. A program can have a race condition while every shared variable is
atomic and no C++ data race exists.

**Linearizability:** a concurrent component's operations can be understood as
taking effect at single points between invocation and return, consistently with
their real-time non-overlap. A **linearization point** is that effective point
for an operation. A proof may choose a successful CAS as the point for insertion.

**Safety:** something bad never happens, such as reading a half-published record.
**Liveness:** useful progress eventually occurs under the stated assumptions.
A correct release/acquire handoff can be safe without guaranteeing when the
consumer will be scheduled.

**Blocking:** progress can depend on another thread releasing a resource.
**Lock-free:** the algorithm provides system-wide progress even though a particular
thread may repeatedly lose. **Wait-free:** every participating operation completes
within a bounded number of its own steps, under its stated computational model.
**Starvation:** one participant fails to make progress while others do.
These terms describe algorithms; they are not synonyms for a particular memory order.

### 2.6 Hardware vocabulary

**Cache:** fast storage holding recently used instructions or data. **Cache line:**
the unit transferred and managed by the coherence mechanism, commonly 64 bytes
on familiar systems but not fixed by C++.

**Cache coherence:** rules coordinating accesses to a location across cached
copies. **Memory consistency:** rules governing observations across memory
operations, potentially involving different locations. Coherence alone does not
publish a multi-field record.

**Store buffer:** hardware that can hold stores pending propagation to the
coherent memory system. **Store forwarding:** satisfying a core's own load from
an earlier buffered store to the relevant location.

**Out-of-order execution:** internally executing instructions in an order chosen
for efficiency, subject to the architecture's observable rules. **Speculation:**
performing work before knowing whether it will be needed, for example before
a branch outcome is resolved.

**ISA**, instruction set architecture: the machine-level contract implemented by
a processor. **Microarchitecture:** one implementation of that contract. Different
processors can implement the same ISA with different pipelines and performance.

## 3. Why executions can surprise you

### 3.1 The C++ abstract machine comes first

The **abstract machine** is the language's model of execution. A compiler may
transform a program if the resulting observable behavior remains permitted.
This is often called the **as-if rule**.

For example, a compiler can keep a value in a register, eliminate a redundant
load, combine work, or move independent calculations. Source-line order is not
by itself a command to emit a matching instruction sequence.

For defined multithreaded programs, transformations must respect the memory model.
For a program with a data race, there is no useful guarantee that a compiler
will preserve the programmer's intended polling or communication scheme.

### 3.2 Three orders should not be confused

```text
C++ source and abstract evaluations
            |
            | compiler chooses a legal implementation
            v
Machine instructions
            |
            | CPU executes under ISA rules
            v
Observations made by other threads
```

An unexpected outcome can arise without the compiler literally swapping two
instructions. A later load can complete while an earlier store is buffered.
Conversely, strongly ordered hardware does not repair a source-level data race.

### 3.3 Store buffering: a concrete hardware intuition

Imagine two atomic integers initially zero:

```text
Thread A                  Thread B
store x = 1               store y = 1
load y into rA            load x into rB
```

Each core can buffer its own store, then read the other location before the
other store has propagated. Both reads can obtain zero on hardware and language
models that allow this execution. The program did not require a cache to be
incoherent; each location can still have a coherent history.

Section 12 shows why fully sequentially consistent operations prohibit this
specific outcome. Section 18 distinguishes permitted abstract outcomes from
outcomes actually observed on a machine.

## 4. Data races and undefined behavior

### 4.1 How to identify a data race

Two operations conflict when one modifies a memory location, or starts/ends
relevant object lifetime, and the other accesses overlapping storage in a
conflicting way. For ordinary different-thread examples, ask:

1. Do the operations concern the same location or overlapping lifetime/storage?
2. Is at least one a write or relevant lifetime change?
3. Is at least one operation non-atomic?
4. Are they unordered by happens-before?

If these conditions apply, the execution has a data race and therefore undefined
behavior. **Undefined behavior**, or UB, means the language imposes no requirements
on that execution. “It may print either the old or new value” is then not a
complete or valid bound on outcomes.

Primary wording: [N4861 data-race rules](https://timsong-cpp.github.io/cppwp/n4861/intro.races).

### 4.2 A flag can be atomic while the program still races

**INCORRECT fragment**, initial `ready == false`, no other synchronization:

```cpp
int payload = 0;
std::atomic<bool> ready{false};

// Producer:
payload = 42;
ready.store(true, std::memory_order_relaxed);

// Consumer, on another thread:
if (ready.load(std::memory_order_relaxed)) {
    use(payload); // No happens-before edge protects this ordinary read.
}
```

The flag accesses are atomic. The conflicting payload accesses are not ordered
by relaxed flag operations. On an execution entering the consumer branch, the
program has a data race. It is not merely a program whose payload can be stale.

For a valid litmus test of stale observations, make the payload atomic too.
Then an unexpected value may be a permitted result rather than UB. This
distinction is essential when answering “what can it print?”

### 4.3 Real time, alignment, and one-core execution do not establish safety

An aligned `int` may happen to use an indivisible machine load on a particular
CPU. A plain C++ `int` still does not gain atomic synchronization semantics.

A sleep lasting longer than the other thread usually needs is not an ordering
proof. Running on one CPU does not remove the language requirement. Logging can
change timing or add synchronization and make a bug disappear without fixing it.

Two concurrent reads of the same ordinary object are fine if there is no
conflicting writer/lifetime change. Two writes to distinct ordinary structure
members can also be legal, even if they perform poorly because of false sharing.

## 5. The formal relationships used in proofs

### 5.1 Sequenced-before: ordering inside a thread

**Sequenced-before**, abbreviated **SB**, is the language's within-thread relation
between evaluations. Consecutive full-expression statements in the examples are
sequenced in order. Do not assume arbitrary function arguments are evaluated
left-to-right; expression sequencing has its own language rules.

```cpp
payload = 42; // A
ready.store(true, std::memory_order_release); // B
```

Here A is sequenced-before B. This is a semantic constraint on a valid execution,
not a claim that all resulting physical work completes in that order globally.

### 5.2 Reads-from: which write supplied this load?

**Reads-from**, abbreviated **RF**, connects a specific write with a load that
obtains its value from that write. This is not determined by numerical equality
alone. If two threads both store `true`, a load returning `true` might read from
either store, with different synchronization consequences.

When proving publication, identify the actual modifying event, not just “the
flag equals one.” A carefully restricted single-writer, single-transition flag
makes the argument easier.

### 5.3 Modification order: one history per atomic object

**Modification order**, abbreviated **MO**, is a total order of modifications to
one atomic object. Stores and successful RMW operations modify it; ordinary loads
and failed CAS operations do not.

Each atomic has its own modification order. There is no general rule that the
modification orders of several atomics form one shared global timeline.

A successful RMW reads the modification immediately preceding it in that object's
modification order. This makes `fetch_add` useful for obtaining distinct tickets:
each update is tied to the actual immediately preceding state.

### 5.4 Synchronizes-with: the cross-thread bridge

**Synchronizes-with**, abbreviated **SW**, is an explicitly defined relation between
synchronization operations. In the basic case, a release operation on atomic M
synchronizes with an acquire operation on M that reads from that release, or
from its qualifying release sequence.

Other library operations have their own SW rules, including mutex handoff,
thread completion and joining, and one-time initialization.

Merely using an acquire somewhere and a release somewhere else is insufficient.
The matching conditions are part of the rule, not optional implementation detail.

### 5.5 Happens-before: compose local order and synchronization

For examples without historical consume ordering, **happens-before**, abbreviated
**HB**, is built from sequenced-before, synchronizes-with, and their transitive
composition. If A is before a publishing release, and B is after the matching
acquire, the chain can establish A HB B.

```text
Producer                               Consumer
A: write payload
       | SB
B: release-store ready  --- SW --->  C: acquire-load ready reading B
                                           | SB
                                      D: read payload

A HB D, through A -> B -> C -> D.
```

For an ordinary payload initialized once and not subsequently changed, this
orders its write before its read and establishes the initialized value as the
one the reader uses. If another writer later modifies the payload, that later
access needs its own synchronization; publication is not permanent protection.

HB is a semantic relation, not a timestamp. Two operations can occur at different
wall-clock times and still lack the required relation.

### 5.6 Atomic coherence rules, explained individually

These rules apply even to relaxed atomics:

| Rule | If the first event happens-before the second… |
|---|---|
| Write-write coherence | Two modifications of the same atomic must occur in that order in MO. |
| Read-read coherence | A later read of the same atomic cannot go backward before the modification observed by the earlier read. |
| Read-write coherence | A read before a modification must obtain its value from an earlier modification in MO. |
| Write-read coherence | A read after a modification must observe that modification or a later one in MO. |

“Cannot go backward” concerns modification events, not numerical values. A
counter can wrap, and a flag can change from true back to false, so a later
modification can have a smaller number or repeat an earlier value.

### 5.7 Simply and strongly happens-before: why interview sources differ

C++20 distinguishes **happens-before**, **simply happens-before**, and **strongly
happens-before**. Without consume, HB and simply-HB coincide. Simply-HB is the
transitive closure of SB and SW.

Strongly-HB has a narrower role in constraining the total order of sequentially
consistent operations. In C++20 it can arise through:

- Sequenced-before.
- Synchronizes-with between two sequentially consistent atomic operations.
- A chain whose endpoints surround a simply-HB relationship with SB edges:
  `A SB B`, `B simply-HB C`, `C SB D` gives `A strongly-HB D`.
- Transitive composition of strongly-HB relationships.

An ordinary release/acquire SW edge does not, by itself, automatically become
the second bullet's strongly-HB edge. This matters in exotic programs mixing
SC and non-SC atomics. Later drafts simplify terminology around consume, so
always specify the edition when discussing the exact definitions.

### 5.8 A repeatable proof procedure

1. List every shared object and who reads/writes it.
2. Separate ordinary payload objects from atomic control objects.
3. Identify the specific write each successful control read must observe.
4. Draw SB, RF, and applicable SW edges.
5. Use transitivity to order every conflicting ordinary access.
6. Check that mutation, reuse, destruction, and error paths obey the same argument.
7. Prove the higher-level invariant and progress assumptions separately.

This procedure is more reliable than trying to visualize “flushing everything.”

## 6. The atomic API and legal memory orders

Include `<atomic>` and explicitly initialize objects:

```cpp
// Fragment.
std::atomic<int> count{0};
int a = count.load(std::memory_order_relaxed);
count.store(7, std::memory_order_release);
int old = count.exchange(9, std::memory_order_acq_rel);
int before_increment = count.fetch_add(1, std::memory_order_relaxed);
```

`load` returns a value; it does not return a reference to the atomic's storage.
`exchange` and `fetch_add` return the old value. Atomic `++count` returns the
new value and defaults to sequential consistency.

### 6.1 Order matrix for C++20/23

| Operation | relaxed | consume | acquire | release | acq_rel | seq_cst |
|---|---|---|---|---|---|---|
| `load` | Yes | Yes, historical | Yes | No | No | Yes |
| `store` | Yes | No | No | Yes | No | Yes |
| RMW success | Yes | Yes, historical | Yes | Yes | Yes | Yes |
| CAS failure | Yes | Yes, historical | Yes | No | No | Yes |
| `wait` | Yes | Yes, historical | Yes | No | No | Yes |
| `atomic_thread_fence` | No effect | Acquire-fence behavior | Acquire | Release | Both | SC fence |

The CAS row describes its load-like failure operation; section 14 discusses
success/failure pair selection and standard-version caveats. Invalid orders are
not repaired by the fact that the compiler happens to accept them.

When omitted, the order on ordinary atomic operations is `memory_order_seq_cst`.
`notify_one` and `notify_all` have no memory-order parameter.

### 6.2 There is no single simple strength ladder

Acquire and release serve different directions and different operation categories.
A release store cannot be replaced with an acquire store: that is not a legal
store order. An acquire RMW need not publish prior ordinary writes, while a
release RMW need not acquire earlier publications it reads.

Start with the operation's role, then select a legal order that supplies its proof
obligations. The detailed contracts are in
[N4861 atomic operations](https://timsong-cpp.github.io/cppwp/n4861/atomics.types.operations).

## 7. Relaxed ordering in detail

### 7.1 What relaxed guarantees

`memory_order_relaxed` gives an atomic operation and preserves the per-object
atomic coherence rules. A relaxed RMW still updates atomically. It does not
independently establish a release/acquire synchronization edge for other data.

Typical suitable uses include a statistics counter, a ticket generator that does
not itself publish payloads, or a stop flag whose only meaning is “stop polling.”
Whether relaxed is enough depends on the required relationship with other memory.

### 7.2 Complete program: a statistics counter

Save as `relaxed_counter.cpp`:

```cpp
#include <atomic>
#include <cassert>
#include <iostream>
#include <thread>
#include <vector>

int main() {
    constexpr int workers = 4;
    constexpr int increments = 25000;
    std::atomic<int> counter{0};
    std::vector<std::jthread> threads;
    for (int i = 0; i < workers; ++i) {
        threads.emplace_back([&] {
            for (int j = 0; j < increments; ++j)
                counter.fetch_add(1, std::memory_order_relaxed);
        });
    }
    for (auto& thread : threads) thread.join();
    const int result = counter.load(std::memory_order_relaxed);
    assert(result == workers * increments);
    std::cout << result << '\n';
}
```

**Proof:** each increment is an RMW, so updates are not lost. Worker completion
synchronizes with successful `join` return. All increments therefore happen-before
the final load. Atomic coherence, the absence of later updates, and the known
number of increments determine the final value. No payload publication is being
asked of the counter.

During the run, a relaxed load is not a transactionally consistent snapshot of
this counter together with unrelated statistics counters. Joining is essential
to the final-state argument; “the increments are probably finished” is not enough.

### 7.3 What relaxed does not mean

It does not mean “the compiler may invent arbitrary values,” “each core has a
private unrelated counter,” or “the atomic can tear.” It also does not promise
a particular wall-clock freshness interval for a reader.

If a stop flag accompanies an ordinary shutdown reason, a relaxed flag may be
insufficient to publish that reason. If the worker never reads extra data and
only exits its own loop, the same relaxed flag can be appropriate. Describe the
actual information transferred before choosing the order.

## 8. Release and acquire in detail

### 8.1 Release publishes; acquire receives a specific publication

A **release operation** can make prior writes available through a matching
synchronization. An **acquire operation** can ensure subsequent operations are
ordered after a publication it reads. Neither is a request to flush all CPU
caches to RAM.

A release does not wait for a reader. An acquire does not wait until it sees the
newest value. Waiting is a separate loop or blocking mechanism. Synchronization
arises only when the acquire observes the relevant release or release sequence.

### 8.2 Complete program: publish an ordinary object once

Save as `publication.cpp`:

```cpp
#include <atomic>
#include <cassert>
#include <iostream>
#include <string>
#include <thread>

struct Message {
    int id = 0;
    std::string text;
};

int main() {
    Message message;
    std::atomic<bool> ready{false};

    std::jthread producer([&] {
        message.id = 42;
        message.text = "published";
        ready.store(true, std::memory_order_release);
    });
    std::jthread consumer([&] {
        while (!ready.load(std::memory_order_acquire))
            std::this_thread::yield();
        assert(message.id == 42);
        assert(message.text == "published");
    });
    producer.join();
    consumer.join();
    std::cout << "publication passed\n";
}
```

**Proof:** initialization of both message fields is SB-before the release store.
Only that store writes true. The successful acquire load therefore reads the
publication. The field reads are SB-after the acquire. The resulting HB chain
orders initialization before consumption. The producer never mutates the message
again, and the message outlives both threads.

The message need not contain atomic fields. Even the dynamically allocated storage
owned by its string is usable because its initialization is part of the ordered
work and its lifetime remains valid.

`yield` is a scheduling hint that can reduce aggressive polling. It contributes
no synchronization edge and is not required for the proof. It also promises no
particular fairness or latency.

### 8.3 Direction matters

Think of the useful publication path as:

```text
producer work -> release -> matching acquire -> consumer work
```

Reading the payload before the acquire is not repaired by an acquire afterward.
Putting a release before initializing the payload does not publish that later
initialization. The mnemonic “release keeps prior accesses before it, acquire
keeps later accesses after it” is useful intuition, but the HB proof is the
actual justification.

### 8.4 Acquire does not freeze the payload

If the producer writes the message again immediately after setting `ready`, the
new write can race with the consumer. A publication operation is not a reader
lock and does not maintain ownership automatically. Reusable storage needs a
return path telling the producer the reader has finished.

## 9. Reusing storage requires a return handoff

### 9.1 There are two different publications

A reusable one-slot mailbox needs two ordered transfers:

1. Producer publishes “payload is ready for reading.”
2. Consumer publishes “reading is complete; storage may be overwritten.”

The second publication protects a read-before-next-write relationship. Release
semantics can order preceding reads as well as preceding writes. A fence or order
name containing “release” is not limited to flushing dirty data.

### 9.2 Complete program: a reusable one-slot mailbox

Save as `mailbox.cpp`:

```cpp
#include <atomic>
#include <cassert>
#include <iostream>
#include <thread>

int main() {
    constexpr int messages = 20000;
    int payload = 0;
    std::atomic<bool> full{false};

    std::jthread producer([&] {
        for (int value = 1; value <= messages; ++value) {
            while (full.load(std::memory_order_acquire))
                std::this_thread::yield();
            payload = value;
            full.store(true, std::memory_order_release);
        }
    });
    std::jthread consumer([&] {
        for (int expected = 1; expected <= messages; ++expected) {
            while (!full.load(std::memory_order_acquire))
                std::this_thread::yield();
            assert(payload == expected);
            full.store(false, std::memory_order_release);
        }
    });
    producer.join();
    consumer.join();
    std::cout << "mailbox passed\n";
}
```

**Forward proof:** the producer's payload write precedes its release store of
true. The consumer's acquire observes that publication before reading payload.

**Return proof:** the consumer's payload read precedes its release store of false.
The producer's acquire observes the acknowledgment before its next payload write.

Why cannot a participant repeatedly use an ancient flag value? Each participant
has also modified the same atomic in its previous iteration. Atomic coherence
prevents its subsequent load from going backward before its own preceding
modification. With one producer, one consumer, and the alternating protocol,
the next usable value corresponds to the required handoff.

The initially empty state is safe because object initialization happens before
worker accesses through thread startup. No prior consumer read exists for the
first producer write to wait for.

### 9.3 What weakening the return edge breaks

Changing only the acknowledgment store/load to relaxed removes the HB ordering
between the previous read and next write of the ordinary payload. The protocol
may look temporally correct on a machine, but the C++ proof is missing.

Adding a second producer also breaks the ownership argument: two producers can
both see the slot empty and write it. Stronger memory orders do not turn this
SPSC design into an MPSC design. **SPSC** means single producer, single consumer;
**MPSC** means multiple producers, single consumer.

## 10. Release sequences and transitive publication

### 10.1 What a release sequence is in C++20/23

A **release sequence** starts with a release modification of one atomic object
and continues through consecutive RMW modifications of that object in modification
order. A later ordinary atomic store ends that sequence. The RMWs may use relaxed
ordering and may be performed by other threads.

This is a history of modifications to one atomic, not a list of source-code
statements and not a sequence of operations that happen to contain “release.”

An acquire that reads a value written by an RMW in the sequence can synchronize
with the release heading the sequence. The definition is in
[N4861 release sequences](https://timsong-cpp.github.io/cppwp/n4861/intro.races#5).

### 10.2 Three-thread relay example

Fragment: initialize `payload = 0` and `state = 0` before starting threads.
There are no other state modifications, and the objects outlive all threads.

```cpp
// Writer:
payload = 42;
state.store(1, std::memory_order_release);

// Relay:
int expected = 1;
while (!state.compare_exchange_weak(expected, 2,
                                    std::memory_order_relaxed,
                                    std::memory_order_relaxed)) {
    expected = 1;
}

// Reader:
while (state.load(std::memory_order_acquire) != 2) {}
assert(payload == 42);
```

The successful CAS changes 1 to 2 as an RMW and immediately follows the writer's
store in MO. The reader acquiring 2 synchronizes with the writer's release of 1.
The relay does not need acquire merely to carry that original publication along.

However, the relay cannot safely read the ordinary payload using only this
relaxed CAS. Nor does its relaxed CAS publish the relay's own unrelated ordinary
writes. Preserving a release sequence and acquiring/publishing one's own work
are separate claims.

### 10.3 An ordinary store is different

Replace the relay's CAS with a relaxed load loop followed by `state.store(2,
relaxed)`. The store breaks the sequence, and the reader's acquire of 2 does
not automatically acquire the original writer's payload.

A valid alternative is for the relay to acquire 1, then release-store 2. Now
there is a transitive chain through two synchronizes-with relationships, even
though the ordinary store ended the original release sequence.

### 10.4 Version trap: same-thread stores changed in C++20

Before C++20, the release-sequence definition also included certain subsequent
ordinary stores by the thread that performed the head release. C++20 removed
that extension. For this guide's baseline, even a same-thread relaxed store
after a release store does not extend the original release sequence.

If an interview answer depends on that old rule, state the language version and
rewrite the protocol around a current, explicit proof.

## 11. Read-modify-write and acq_rel

### 11.1 What each order means for an RMW

An RMW has both a read role and a write role:

| Order | Useful role |
|---|---|
| relaxed | Atomic state transition only. |
| acquire | Receive a publication through the value read. |
| release | Publish earlier operations through the modification made. |
| acq_rel | Receive through the read and publish through the modification. |
| seq_cst | Acquire/release roles plus participation in the SC order. |

The acquire half depends on reading a qualifying publication. Merely spelling
`acq_rel` does not create a connection to every other thread.

### 11.2 Complete program: the last worker aggregates results

Save as `completion.cpp`:

```cpp
#include <array>
#include <atomic>
#include <cassert>
#include <iostream>
#include <thread>
#include <vector>

int main() {
    constexpr int workers = 4;
    std::array<int, workers> results{};
    std::atomic<int> completed{0};
    int total = 0;
    std::vector<std::jthread> threads;

    for (int i = 0; i < workers; ++i) {
        threads.emplace_back([&, i] {
            results[i] = (i + 1) * 10;
            const int old = completed.fetch_add(1, std::memory_order_acq_rel);
            if (old == workers - 1) {
                int sum = 0;
                for (int value : results) sum += value;
                total = sum;
            }
        });
    }
    for (auto& thread : threads) thread.join();
    assert(total == 100);
    std::cout << total << '\n';
}
```

Each worker writes a distinct array element, so those writes do not conflict.
Every write is sequenced-before that worker's release RMW. The last RMW acquires
the preceding chain of releases, including release sequences from earlier
workers. All result writes therefore happen-before the last worker's reads.
Exactly one worker observes old value 3, so only one writes `total`. Joining
orders that write before the main thread reads it.

An all-relaxed completion counter would still count correctly, but the worker
that sees the final count would lack the publication edges needed to read the
ordinary array elements. Joining *after* those reads would not retroactively
repair them.

## 12. Sequential consistency

### 12.1 The useful all-SC mental model

**Sequential consistency**, abbreviated **SC**, allows a race-free program using
only SC atomic operations to be reasoned about as one interleaving consistent
with each thread's sequencing. `memory_order_seq_cst` operations participate
in one total order S, subject to the standard's consistency constraints.

An SC store has release behavior. An SC load has acquire behavior. An SC RMW
has both. SC adds cross-object ordering constraints; it does not add atomicity
to ordinary variables or make a group of atomics one transaction.

### 12.2 Prove the store-buffering outcome impossible with all-SC

All atomics are initialized to zero before the threads begin:

```text
Thread A                        Thread B
A1: x.store(1, seq_cst)          B1: y.store(1, seq_cst)
A2: rA = y.load(seq_cst)         B2: rB = x.load(seq_cst)
```

Assume both reads obtain zero. Sequencing requires `A1 < A2` and `B1 < B2`
in S. Reading the initial values, with no other modifications, requires
`A2 < B1` and `B2 < A1`. Combining them gives:

```text
A1 < A2 < B1 < B2 < A1
```

A total order cannot contain that cycle. Thus `(rA, rB) == (0, 0)` is forbidden.

Using release stores and acquire loads does not give the same result. If both
loads read the initial zeros, neither reads the other thread's release, so no
cross-thread SW edge rules out the outcome.

### 12.3 What SC does not promise

- It does not make an atomic load read a wall-clock-defined “latest value.”
- It does not provide mutual exclusion for compound operations.
- It does not synchronize arbitrary ordinary accesses lacking a relevant path.
- It does not guarantee fairness, wait freedom, or persistent storage.
- It does not necessarily require a full fence instruction after every access.

Two SC stores updating `balance` and `version` remain two operations. A reader
can interleave between them and see a combination that violates a record-level
invariant. Use a lock, a suitable atomic aggregate, or a proved versioning design.

### 12.4 Mixing SC and weaker operations requires the formal rules

S orders the SC operations and SC fences. Weaker operations remain governed by
their own rules and the constraints connecting them to S; they do not all become
members of one global SC execution.

The exact C++20 rules use strongly-HB and coherence-related constraints. Avoid
the blanket statement “S respects every possible HB edge identically,” which
oversimplifies mixed-order cases. Start with all-SC if it makes the algorithm
clear, then weaken individual operations only with a replacement proof.
See [N4861 SC ordering](https://timsong-cpp.github.io/cppwp/n4861/atomics.order).

## 13. Consume and dependency ordering

### 13.1 The original idea

Historical `memory_order_consume` attempted to exploit **data dependencies**.
If a loaded pointer is used to compute the address of a subsequent load, that
subsequent access depends on the pointer value:

```cpp
// Conceptual fragment; prefer acquire in actual code.
Node* p = head.load(std::memory_order_consume);
int value = p->value; // The address depends on p.
```

The intended ordering followed dependency chains, instead of ordering all later
operations as acquire does. A load from an unrelated global variable does not
become dependent merely because it appears after the consume load.

A control dependency, such as an `if` condition, is not generally equivalent to
the required dependency chain. Compiler transformations make preserving the
historical dependency model particularly difficult.

### 13.2 What to say in a modern interview

For C++20/23, understand why consume existed, but use acquire for ordinary portable
application code. Mainstream compilers commonly implement consume with acquire
strength; GCC documents this behavior in its
[atomic builtins](https://gcc.gnu.org/onlinedocs/gcc/_005f_005fatomic-Builtins.html).

C++26's change deprecates consume and gives it acquire-equivalent meaning.
`std::kill_dependency` is also deprecated in that change. It historically broke
dependency propagation; it never meant “remove a lock” or “flush a cache.”
See [WG21 P3475R2](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2025/p3475r2.pdf)
and the [working draft compatibility wording](https://eel.is/c++draft/depr.atomics.order).

## 14. Compare-exchange, step by step

### 14.1 The operation and its two outcomes

**CAS**, compare-and-swap, is the common name for compare-exchange. C++ exposes
`compare_exchange_weak` and `compare_exchange_strong`:

```cpp
// Fragment: state is std::atomic<int>.
int expected = 0;
bool won = state.compare_exchange_strong(expected, 1,
                                         std::memory_order_acquire,
                                         std::memory_order_relaxed);
```

On success, state matched expected and is replaced with 1; the successful operation
is an RMW using the success order. On failure, the operation acts as an atomic
load using the failure order and writes the observed value into `expected`.

`expected` is an ordinary object supplied by reference. Do not share one mutable
`expected` variable among concurrent callers without separate synchronization.

### 14.2 Weak versus strong

Weak CAS may fail **spuriously**: return false even though the comparison would
otherwise match. This permits efficient use of hardware reservation mechanisms.
Strong CAS does not have that particular permitted failure, but it can still
fail because another thread changed the value.

Weak is often appropriate inside a retry loop. Strong is convenient when a
single false result should indicate an actual mismatch. Neither supplies fairness.

On some hardware CAS is implemented with **load-linked/store-conditional**, or
LL/SC: read while establishing a reservation, then attempt a store conditional
on the reservation remaining valid. Reservations can be lost for reasons beyond
the final value comparison, motivating weak CAS.

### 14.3 Complete program: update an atomic maximum

Save as `atomic_max.cpp`:

```cpp
#include <array>
#include <atomic>
#include <cassert>
#include <iostream>
#include <thread>
#include <vector>

void update_max(std::atomic<int>& maximum, int candidate) {
    int observed = maximum.load(std::memory_order_relaxed);
    while (observed < candidate &&
           !maximum.compare_exchange_weak(observed, candidate,
                                           std::memory_order_relaxed,
                                           std::memory_order_relaxed)) {
        // On failure, observed was refreshed. Recheck before retrying.
    }
}

int main() {
    std::atomic<int> maximum{0};
    constexpr std::array values{5, 91, 17, 3, 84, 100, 23, 99};
    std::vector<std::jthread> threads;
    for (int value : values)
        threads.emplace_back([&, value] { update_max(maximum, value); });
    for (auto& thread : threads) thread.join();
    assert(maximum.load(std::memory_order_relaxed) == 100);
    std::cout << maximum.load(std::memory_order_relaxed) << '\n';
}
```

Only the atomic maximum is shared by this operation; it does not publish an
associated winning record. Relaxed is enough for that narrow contract. If a
payload accompanies the maximum, keeping the pair consistent is a separate design.

For a general CAS update, recompute the desired value from the newly observed
expected value on each retry. Avoid irreversible side effects in the retry body:
it might run multiple times before one update succeeds.

### 14.4 Choosing the failure order

Failure does not store, so its order cannot be release or acq_rel. If failure
merely refreshes a number for the next retry, relaxed is often enough. If failure
returns a pointer whose published fields you then dereference, failure may need
acquire semantics, in addition to a valid lifetime/reclamation protocol.

Conventional pairs include relaxed/relaxed, acquire/relaxed, release/relaxed,
acq_rel/acquire, and seq_cst/seq_cst. These are examples, not an exhaustive table
of legal or useful combinations.

With a single order argument, C++ derives the failure order: release becomes
relaxed, acq_rel becomes acquire, and other orders remain the supplied order.

**Version and implementation caveat:** older C++11/14 rules included a restriction
against a failure order stronger than success. The C++20 draft's explicit
precondition excludes release and acq_rel on failure; it does not state that
older general strength restriction. Compiler builtins can document stricter
requirements, and implementation diagnostics can differ. Use conventional pairs
unless you have a reason and have checked both the target edition and implementation.
Compare [C++20 CAS wording](https://timsong-cpp.github.io/cppwp/n4861/atomics.types.operations#21)
with [GCC builtin requirements](https://gcc.gnu.org/onlinedocs/gcc/_005f_005fatomic-Builtins.html).

### 14.5 Comparison is not operator==

CAS compares representations under the language version's rules, not a user-defined
equality operation. C++20 uses value representation; padding bits that never
participate in it are ignored. Floating-point NaNs, signed zero, unions, and
multiple representations still make generic CAS reasoning subtle. Integer state
machines with explicit values are easier to explain and audit.

## 15. Fences and their three synchronization patterns

### 15.1 What atomic_thread_fence is

`std::atomic_thread_fence(order)` establishes ordering constraints without itself
loading or storing a named atomic object. It is declared in `<atomic>`.

A fence does not automatically find another fence and synchronize with it.
The ordinary release/acquire fence rules require a connecting atomic communication
path. Without that path, sprinkling fences around racing ordinary accesses does
not make the program valid.

A relaxed fence has no effect. An acquire fence, release fence, acq_rel fence,
and SC fence provide different constraints. In C++20 a consume fence has
acquire-fence behavior; it is not a special cheap dependency-only fence.

Primary reference: [N4861 fences](https://timsong-cpp.github.io/cppwp/n4861/atomics.fences).

### 15.2 Pattern A: release fence to acquire atomic operation

Fragment with `flag` initially zero and one publishing store:

```cpp
// Producer:
payload = 42;                                      // W
std::atomic_thread_fence(std::memory_order_release); // F
flag.store(1, std::memory_order_relaxed);             // X

// Consumer:
if (flag.load(std::memory_order_acquire) == 1) {      // Y, reads X
    assert(payload == 42);                          // R
}
```

The release fence F is sequenced-before modifying operation X. Acquire operation
Y reads X. Under the fence-atomic rule, **F synchronizes with Y**. Thus
`W SB F SW Y SB R`, which orders W before R.

X is relaxed, but it is still essential: it carries the value that connects the
threads. Moving the release fence after X destroys this particular publication
proof, because the fence must precede the communicating modification.

### 15.3 Pattern B: release atomic operation to acquire fence

```cpp
// Producer:
payload = 42;                                      // W
flag.store(1, std::memory_order_release);             // X

// Consumer:
if (flag.load(std::memory_order_relaxed) == 1) {      // Y, reads X
    std::atomic_thread_fence(std::memory_order_acquire); // F
    assert(payload == 42);                          // R
}
```

Relaxed load Y reads release X and is sequenced-before acquire fence F. Under
the atomic-fence rule, **X synchronizes with F**. The payload read is after F.

The fence must be after the load that supplies the observation, and before
the ordinary reads needing protection. An acquire fence placed before the
relaxed load does not implement this pattern.

This arrangement can be useful when several relaxed observations are made and
one acquire fence is applied only on a successful path. The successful path
must actually have the required reads-from relationship.

### 15.4 Pattern C: release fence to acquire fence

```cpp
// Producer:
payload = 42;                                      // W
std::atomic_thread_fence(std::memory_order_release); // F1
flag.store(1, std::memory_order_relaxed);             // X

// Consumer:
if (flag.load(std::memory_order_relaxed) == 1) {      // Y, reads X
    std::atomic_thread_fence(std::memory_order_acquire); // F2
    assert(payload == 42);                          // R
}
```

The path is `W SB F1 SB X RF Y SB F2 SB R`. The fence-fence rule establishes
**F1 synchronizes with F2**, making W HB R.

The full rules also account for qualifying release-sequence continuations. These
examples intentionally use a single modification so the essential path is clear.

### 15.5 Complete program checking all three patterns

Save as `fence_publication.cpp`:

```cpp
#include <atomic>
#include <cassert>
#include <iostream>
#include <thread>

// mode 0: fence -> atomic; 1: atomic -> fence; 2: fence -> fence.
void check_pattern(int mode) {
    int payload = 0;
    std::atomic<int> flag{0};
    std::jthread producer([&] {
        payload = 42;
        if (mode != 1)
            std::atomic_thread_fence(std::memory_order_release);
        flag.store(1, mode == 1 ? std::memory_order_release
                               : std::memory_order_relaxed);
    });
    std::jthread consumer([&] {
        const auto order = mode == 0 ? std::memory_order_acquire
                                      : std::memory_order_relaxed;
        while (flag.load(order) != 1) std::this_thread::yield();
        if (mode != 0)
            std::atomic_thread_fence(std::memory_order_acquire);
        assert(payload == 42);
    });
    producer.join();
    consumer.join();
}

int main() {
    for (int mode = 0; mode < 3; ++mode) check_pattern(mode);
    std::cout << "three fence patterns passed\n";
}
```

Each mode has exactly the proof given above. For normal single-flag publication,
putting release/acquire directly on the flag operations is usually easier to
review. Fence patterns are useful when their different placement or scope serves
a concrete purpose; they are not a default readability improvement.

### 15.6 Why an acq_rel fence is not an SC fence

An acq_rel fence has acquire and release semantics. An SC fence additionally
participates in S and adds SC ordering constraints.

Consider the store-buffering test with a fence between each store and load.
Using SC fences with the relevant atomic operations prohibits both reads being
zero. Replacing those fences with acq_rel fences does not generally provide that
guarantee: if both reads get initial values, there need not be an SW connection,
and there is no SC-fence order to produce the contradiction.

In particular, an acq_rel fence on x86 can compile to no hardware instruction,
whereas an SC fence needs additional ordering in this context. “Both acquire
and release” is not shorthand for every possible full-barrier property.

### 15.7 A fence does not make non-atomic flags safe

**INCORRECT fragment:**

```cpp
// flag is an ordinary bool, read/written concurrently.
payload = 42;
std::atomic_thread_fence(std::memory_order_release);
flag = true;
```

An acquire fence in the reader cannot turn the racing ordinary flag into a
valid atomic communication path. A hardware fence instruction alone also does
not change the flag's language-level type or access rules.

## 16. Compiler barriers, signal fences, and volatile

### 16.1 Compiler barrier versus hardware barrier

A **compiler barrier** restricts transformations by the compiler. A **hardware
barrier** constrains machine-level ordering according to the ISA. A correct
language-level synchronization operation must account for both layers, but it
can need no emitted fence when the hardware already supplies the necessary order.

GCC/Clang-style inline assembly is sometimes used for an implementation-specific
compiler barrier:

```cpp
// GCC-style fragment: not a portable C++ synchronization primitive.
asm volatile("" ::: "memory");
```

The memory clobber tells the compiler the assembly may access memory beyond its
explicit operands, constraining relevant optimizations. It emits no CPU fence
by itself and establishes no ISO C++ interthread synchronizes-with relation.
See [GCC extended assembly](https://gcc.gnu.org/onlinedocs/gcc/Extended-Asm.html).

Inline assembly without the right constraints can fail to constrain the compiler
even if the instruction itself has hardware ordering effects. Prefer standard
atomics for ordinary C++ thread synchronization.

### 16.2 What atomic_signal_fence means

`std::atomic_signal_fence` establishes ordering between a thread and a signal
handler executing on that same thread. Its intended effect is compiler ordering;
it does not emit the hardware fences that an equivalent thread fence might need.

A **signal handler** runs in response to a platform/language signal mechanism
and has strict restrictions on permitted operations. Signal fences do not make
arbitrary object accesses, library calls, allocation, or locking safe in a handler.
They are not a substitute for thread synchronization between CPU cores.

### 16.3 Why volatile is not an atomic or a lock

`volatile` tells the implementation that accesses have special observable
properties under its rules. It does not generally provide interthread atomicity,
modification order, or release/acquire synchronization for ordinary shared data.

**INCORRECT fragment:**

```cpp
volatile bool ready = false;
// Writing ready in one thread while another reads it is still not
// a valid ordinary C++ message-publication protocol.
```

Even if the compiler emits every polling load, a non-atomic conflicting access
still races. GCC explicitly explains that volatile accesses do not order ordinary
non-volatile accesses as a general memory barrier in its
[volatile documentation](https://gcc.gnu.org/onlinedocs/gcc/Volatiles.html).

Volatile can have roles in implementation-defined device access and limited
signal-handling patterns. Those roles do not justify using it as a concurrency
replacement for `std::atomic`.

### 16.4 std::barrier is another meaning of barrier

C++20 `std::barrier` coordinates a group of participants across phases. Threads
arrive and can wait for phase completion. It has specified synchronization effects.

`atomic_thread_fence` does not wait for other threads to arrive and does not count
participants. A hardware memory fence also does not act as a rendezvous. Saying
“put a barrier here” is incomplete unless the intended kind is clear.

## 17. Hardware ordering on x86 and Arm

### 17.1 Ordinary coherent memory is the scope of the simple examples

CPU ordering rules depend on the architecture and memory type. The familiar x86
model for ordinary write-back cacheable memory does not describe every device
mapping or non-temporal instruction. A C++ program should obtain correctness
from its language and library operations, then inspect how they are implemented.

### 17.2 x86-64 and TSO

**TSO**, total store order, is a useful model for ordinary x86 memory ordering.
It is not the same as C++ sequential consistency. Stores can be buffered while
a later load from another location proceeds, enabling the store-buffering example.

Ordinary load/load, load/store, and store/store ordering is stronger than on
many weakly ordered machines. Therefore acquire loads and release stores often
need only ordinary `mov` instructions. Their C++ semantics still restrict the
compiler, and the plain non-atomic equivalent is not interchangeable.

Common compiler mappings for scalar atomics on x86-64 are:

| C++ operation | Typical instruction family |
|---|---|
| relaxed load/store | `mov` |
| acquire load / release store | `mov` |
| SC load | Often `mov`, as part of the compiler's whole SC mapping. |
| SC store | Often memory `xchg`, or an alternative store/barrier sequence. |
| `fetch_add` returning old value | Often `lock xadd`. |
| CAS | Often `lock cmpxchg`. |
| acquire/release fence | Often no hardware instruction. |
| SC fence | `mfence` or a suitable locked instruction. |

The **lock prefix** gives specified atomic and ordering behavior for supported
instructions. It does not normally mean the CPU acquires a C++ mutex. For normal
cacheable aligned accesses, coherence ownership can provide the needed exclusion;
unusual memory layouts and types can have very different costs.

`PAUSE` is a spin-wait hint, not a C++ memory fence. It does not publish data.
`SFENCE`, `LFENCE`, and `MFENCE` have ISA-specific roles; instruction names are
not one-to-one aliases for C++ release, acquire, and seq_cst.

Authoritative hardware reference: the
[Intel software developer manuals](https://www.intel.com/content/www/us/en/developer/articles/technical/intel-sdm.html),
especially the memory-ordering material and instruction definitions.

### 17.3 Arm AArch64

On AArch64, ordinary instructions can expose weaker ordering. Dedicated load-acquire
and store-release instructions, commonly `LDAR` and `STLR`, can implement relevant
language operations. Relaxed operations can use ordinary `LDR`/`STR`.

RMW operations may use exclusive-load/store loops or atomic instructions from
the Large System Extensions, depending on target support and compiler choices.
An acquire load and release store are not necessarily synthesized as an ordinary
access plus a separate barrier instruction.

Three commonly discussed Arm barriers have distinct roles:

- **DMB**, data memory barrier: orders specified memory accesses within a selected
  domain. The domain describes which observers the barrier covers.
- **DSB**, data synchronization barrier: additionally waits for specified completion
  requirements before execution proceeds as defined by the architecture.
- **ISB**, instruction synchronization barrier: coordinates the instruction stream
  after relevant changes; it is not the standard answer for publishing a C++ payload.

Different barrier options matter. “Use a DMB” without its type, domain, and
surrounding operations is not a complete machine-level argument.

Arm's [memory-ordering explanation](https://developer.arm.com/community/arm-community-blogs/b/architectures-and-processors-blog/posts/memory-access-ordering-part-3---memory-access-ordering-in-the-arm-architecture)
and [Armv8 SC discussion](https://developer.arm.com/community/arm-community-blogs/b/tools-software-ides-blog/posts/armv8-sequential-consistency)
explain why SC mappings must be considered as a set, not instruction by instruction.
The Arm mappings here are explanatory and were not executed on Arm for this guide.

### 17.4 Why “flush the cache” is usually the wrong explanation

Synchronization can work through coherent caches without writing dirty lines
all the way to DRAM. A fence constrains ordering; a cache-maintenance instruction
has a separate architecture-specific effect. Neither automatically supplies a
filesystem commit or power-fail recovery guarantee.

**Persistence ordering**, **device ordering**, and **speculation security barriers**
solve different problems. For example, preventing a speculative side channel is
not equivalent to establishing C++ HB, and `msync` is not an acquire fence.

## 18. Litmus tests and permitted outcomes

A **litmus test** is a small concurrency program designed to isolate one ordering
property. Unless labeled otherwise, the following x and y variables are atomics
initialized before thread startup; output registers belong to their respective
threads and are inspected only after synchronization such as joining.

### 18.1 Message passing: a flag does not publish by itself

```text
Thread A                         Thread B
x.store(42, relaxed)              r1 = flag.load(relaxed)
flag.store(1, relaxed)            r2 = x.load(relaxed)
```

The outcome `r1 == 1 && r2 == 0` is allowed by the language. If the flag store
is release and the flag load is acquire, and it reads that release, the outcome
is forbidden: x's store HB x's load, which cannot read the earlier initialization.
Here x is atomic so the relaxed version is a defined weak-order test. Making x
ordinary would turn the unsynchronized payload access into a data-race problem.

### 18.2 Store buffering, abbreviated SB in litmus literature

The acronym SB can mean **store buffering** in a test name or **sequenced-before**
in a proof. Use context or spell it out to avoid ambiguity.

```text
A: x.store(1); rA = y.load();
B: y.store(1); rB = x.load();
```

With relaxed operations, both zero is allowed. With release stores and acquire
loads, both zero remains allowed. With all-SC operations, it is forbidden by
the cycle proof in section 12.

### 18.3 Load buffering

```text
A: rA = x.load(relaxed); y.store(1, relaxed);
B: rB = y.load(relaxed); x.store(1, relaxed);
```

The outcome where both reads are 1 is allowed by the relaxed C++ model for
these independent stores. All-SC forbids it through another order cycle.
The stores already contain the literal value 1; this is not the same as inventing
a value through a circular value dependency.

If the stores use release and the loads acquire, both reads taking 1 from those
stores would produce an HB cycle and is forbidden for that variant.

### 18.4 Independent reads of independent writes: IRIW

```text
Writer A: x.store(1, release)
Writer B: y.store(1, release)
Reader C: r1 = x.load(acquire); r2 = y.load(acquire)
Reader D: r3 = y.load(acquire); r4 = x.load(acquire)
```

The outcome `(r1,r2,r3,r4) == (1,0,1,0)` is permitted by C++ acquire/release
rules: there is no required common total order of the two independent publications.
Replacing all six operations with SC forbids that contradictory observation.
Some hardware/compiler mappings may be stronger and never produce the permitted
weak result. That does not change the language-level answer.

### 18.5 Read-read coherence on one object

```text
Writer: x.store(1, relaxed); x.store(2, relaxed)
Reader: a = x.load(relaxed); b = x.load(relaxed)
```

With no other modifications, `(a,b) == (2,1)` is forbidden. The two writer
stores are ordered in MO, and the second reader load cannot go backward from
the modification observed by the first. This is an example of a guarantee
that relaxed ordering retains.

### 18.6 Out-of-thin-air values

**Out-of-thin-air**, or OOTA, describes values justified only by a circular
speculation/dependency argument. It is not ordinary staleness. The standard's
treatment and research history are subtle; relaxed atomics should not be taught
as permission to invent arbitrary values.

For interview examples, distinguish a constant store that already exists in
the program from a value that could exist only if another thread had somehow
first invented it. Avoid claiming that an OOTA litmus can be resolved by the
simple all-SC interleaving method for arbitrary relaxed programs.

### 18.7 Complete store-buffering experiment

Save as `store_buffering.cpp`. It tests relaxed operations, release/acquire,
all-SC, and relaxed accesses separated by SC fences. The harness uses a C++20
phase barrier to reset state and collect results safely. Counts are observations;
only the SC variants assert the forbidden outcome never appears.

```cpp
#include <atomic>
#include <barrier>
#include <cassert>
#include <iostream>
#include <thread>

enum class Mode { relaxed, release_acquire, sequential, sc_fences };

template<Mode mode>
int experiment() {
    constexpr int rounds = 5000;
    std::atomic<int> x{0}, y{0};
    int rA = -1, rB = -1;
    int both_zero = 0;
    std::barrier phases(3);
    constexpr auto store_order = mode == Mode::sequential ? std::memory_order_seq_cst
        : mode == Mode::release_acquire ? std::memory_order_release
                                        : std::memory_order_relaxed;
    constexpr auto load_order = mode == Mode::sequential ? std::memory_order_seq_cst
        : mode == Mode::release_acquire ? std::memory_order_acquire
                                        : std::memory_order_relaxed;

    std::jthread a([&] {
        for (int i = 0; i < rounds; ++i) {
            phases.arrive_and_wait();
            x.store(1, store_order);
            if constexpr (mode == Mode::sc_fences)
                std::atomic_thread_fence(std::memory_order_seq_cst);
            rA = y.load(load_order);
            phases.arrive_and_wait();
        }
    });
    std::jthread b([&] {
        for (int i = 0; i < rounds; ++i) {
            phases.arrive_and_wait();
            y.store(1, store_order);
            if constexpr (mode == Mode::sc_fences)
                std::atomic_thread_fence(std::memory_order_seq_cst);
            rB = x.load(load_order);
            phases.arrive_and_wait();
        }
    });
    for (int i = 0; i < rounds; ++i) {
        x.store(0, std::memory_order_relaxed);
        y.store(0, std::memory_order_relaxed);
        phases.arrive_and_wait();
        phases.arrive_and_wait();
        if (rA == 0 && rB == 0) ++both_zero;
    }
    a.join();
    b.join();
    return both_zero;
}

int main() {
    const int relaxed = experiment<Mode::relaxed>();
    const int release_acquire = experiment<Mode::release_acquire>();
    const int sequential = experiment<Mode::sequential>();
    const int sc_fences = experiment<Mode::sc_fences>();
    assert(sequential == 0);
    assert(sc_fences == 0);
    std::cout << "both-zero counts: relaxed=" << relaxed
              << " release/acquire=" << release_acquire
              << " seq_cst=" << sequential << " SC-fences=" << sc_fences << '\n';
}
```

The start barrier places each reset before the round's accesses. The end barrier
places writes to the ordinary result variables before the main thread reads
them. The next start phase prevents a worker from overwriting its result before
the main thread finishes collecting it.

The barrier does not order the two workers' accesses *within* the tested region.
Nevertheless, harness overhead can influence observed frequencies. The template
selects the order at compile time; GCC may conservatively strengthen runtime-selected
orders, which would make a runtime-only selector less useful here. A zero count
in a weak variant is always an acceptable experimental
result; the test never asserts that an allowed outcome must occur.

## 19. Mutexes and other library synchronization

### 19.1 A mutex provides ordering as well as exclusion

**Mutual exclusion** means at most one participant holds the lock and enters
the protected critical section at a time. A **critical section** is the region
of work protected by that ownership.

An unlock synchronizes with a subsequent successful acquisition of the same
mutex under its specified ordering. Work before unlocking can therefore happen-before
work after the later acquisition. This is why ordinary payload fields protected
by a mutex normally do not also need atomics.

Fragment, assuming every access to the record follows the same lock discipline:

```cpp
std::mutex mutex;
Record record;

void update() {
    std::lock_guard<std::mutex> guard(mutex);
    record.a = 10;
    record.b = 20;
}

Record snapshot() {
    std::lock_guard<std::mutex> guard(mutex);
    return record;
}
```

**RAII**, resource acquisition is initialization, associates a resource with an
object's lifetime. Here the guard locks on construction and unlocks on destruction,
including exception unwinding. Manually unlocking is not needed on each return path.

Reading one field without acquiring the mutex breaks the discipline. Replacing
that field alone with an atomic can remove a race on that field but still leave
the pair's invariant inconsistent. See
[N4861 mutex requirements](https://timsong-cpp.github.io/cppwp/n4861/thread.mutex.requirements.mutex).

### 19.2 Thread startup and join

Successful thread construction provides the specified ordering to the start of
the new thread's callable. Values initialized before startup can be safely used
by the worker, subject to their lifetimes and later modifications.

Thread completion synchronizes with a successful return from `join`. Therefore
a worker can write an ordinary result object that the parent reads after joining,
provided no conflicting access occurs earlier. A relaxed atomic is not needed
for every result simply because a worker produced it.

`detach` removes the joining ownership relationship; it does not extend the
lifetime of captured references or establish completion synchronization. A local
variable captured by reference can dangle if the detached thread outlives it.
See [N4861 thread members](https://timsong-cpp.github.io/cppwp/n4861/thread.thread.member).

### 19.3 Condition variables: the predicate matters

A **condition variable** lets a thread wait until a predicate on shared state
may have become true. A **predicate** is a condition such as “the queue is not empty.”

Fragment using `<mutex>` and `<condition_variable>`:

```cpp
// Shared, initialized before use:
std::mutex mutex;
std::condition_variable cv;
bool ready = false;
int payload = 0;

// Producer:
{
    std::lock_guard<std::mutex> guard(mutex);
    payload = 42;
    ready = true;
}
cv.notify_one();

// Consumer:
std::unique_lock<std::mutex> lock(mutex);
cv.wait(lock, [&] { return ready; });
assert(payload == 42); // Still holds the mutex.
```

`wait` releases the mutex while blocking and reacquires it before returning.
The predicate overload rechecks the condition, accommodating **spurious wakeups**:
wakeups that do not imply the application condition became true.

The mutex protects the predicate and payload and supplies the publication ordering.
Notification is not a stored message that automatically protects unrelated data.
Updating an unrelated unprotected flag and calling `notify_one` is not equivalent.
See [N4861 condition variables](https://timsong-cpp.github.io/cppwp/n4861/thread.condition.condvar).

### 19.4 call_once and local static initialization

**One-time initialization** can be handled with `std::call_once` and `std::once_flag`
or thread-safe initialization of a function-local static object. These mechanisms
have defined publication behavior and exception/retry rules.

For example, returning a reference to a function-local `static const Config`
often removes the need to write a custom double-checked initialization protocol.
If the configuration will later change or be destroyed concurrently, the new
lifetime/mutation requirements still need a design.
See [N4861 call_once](https://timsong-cpp.github.io/cppwp/n4861/thread.once.callonce).

### 19.5 Futures, latches, and phase barriers

A promise/future pair communicates through a shared result state with specified
synchronization when the state becomes ready and is successfully waited for.
A **latch** is a countdown-based one-shot coordination mechanism. A **barrier**
supports repeated phases.

These are often better matches than manually polling an atomic if the desired
operation is “wait for this task/group/phase to finish.” Their guarantees arise
from their contracts, not from incidental operating-system behavior.

## 20. Atomic wait and notification

### 20.1 Separate the state change from waking a waiter

C++20 atomics provide `wait(old, order)`, `notify_one`, and `notify_all`.
`wait` examines the atomic value and can block while it equals `old`. It returns
after observing a value different from `old`; internal spurious wakeups do not
make it return as though the value had changed.

The load performed by wait uses the supplied order. Notify operations wake
eligible waiters; they do not independently publish the payload. Normally change
the state with a release store, then notify, and use acquire when the waiter
needs the associated payload.

### 20.2 Complete program: blocking one-time publication

Save as `atomic_wait.cpp`:

```cpp
#include <atomic>
#include <cassert>
#include <iostream>
#include <thread>

int main() {
    int payload = 0;
    std::atomic<bool> ready{false};

    std::jthread consumer([&] {
        ready.wait(false, std::memory_order_acquire);
        assert(payload == 42);
    });
    std::jthread producer([&] {
        payload = 42;
        ready.store(true, std::memory_order_release);
        ready.notify_one();
    });
    producer.join();
    consumer.join();
    std::cout << "atomic wait passed\n";
}
```

If the store happens before the consumer calls wait, the consumer observes a
changed value and need not block. If it is already waiting, notification allows
it to check again. Only one store changes false to true, so the acquire observation
has an unambiguous publication source.

Calling `notify_one` while leaving the value false does not make this wait return
successfully. Storing true with relaxed order and notifying does not establish
the required payload publication by itself.

### 20.3 Transient changes and the ABA problem

Wait observes values, not every transition. A value can change from A to B and
back to A between observations. The waiter can miss that transient change.
This is a form of the **ABA problem**: equal current values do not prove an
unchanged history.

Use a suitable generation counter or queue if every event must be represented.
Define counter wraparound and ownership rules. Notifications are not a count
of application messages. All waiters must finish before the atomic's lifetime
ends. See [N4861 atomic waiting](https://timsong-cpp.github.io/cppwp/n4861/atomics.wait).

## 21. Building and explaining a spinlock

### 21.1 The ownership transition

A **spinlock** waits by repeatedly examining a state instead of immediately
blocking in the operating system. To claim a lock, a thread must atomically
change it from unowned to owned. A load followed by a separate store is not enough:
two threads can both see it free.

`atomic_flag::test_and_set` is an RMW that sets true and returns the previous
value. Success means it observed false. `clear` releases ownership by storing false.

### 21.2 Complete program: test-and-test-and-set lock

Save as `spinlock.cpp`:

```cpp
#include <atomic>
#include <cassert>
#include <iostream>
#include <mutex>
#include <thread>
#include <vector>

class SpinLock {
    std::atomic_flag flag_ = ATOMIC_FLAG_INIT;
public:
    void lock() noexcept {
        while (flag_.test_and_set(std::memory_order_acquire)) {
            while (flag_.test(std::memory_order_relaxed))
                std::this_thread::yield();
        }
    }
    void unlock() noexcept {
        flag_.clear(std::memory_order_release);
    }
};

int main() {
    SpinLock lock;
    int counter = 0;
    std::vector<std::jthread> threads;
    for (int i = 0; i < 4; ++i) {
        threads.emplace_back([&] {
            for (int j = 0; j < 10000; ++j) {
                std::lock_guard<SpinLock> guard(lock);
                ++counter;
            }
        });
    }
    for (auto& thread : threads) thread.join();
    assert(counter == 40000);
    std::cout << counter << '\n';
}
```

**Exclusion proof:** among contenders, only one RMW can observe the currently
available false value before a modification makes it true. Others see true
and do not enter the critical section.

**Ordering proof:** the previous owner's ordinary accesses precede its release
clear. The next successful acquire test-and-set reads that false modification,
ordering those accesses before the new owner's critical section.

The inner relaxed tests only decide when to try claiming ownership again. They
do not authorize payload access, so they need not acquire. The final successful
RMW does acquire. Failed test-and-set attempts still write true and are RMWs;
reducing them can reduce cache-line ownership traffic.

### 21.3 Why this is not automatically better than a mutex

The lock is unfair and can starve threads. If the owner is descheduled, waiters
can consume resources while it cannot run. Blocking or lengthy work in the
critical section can make the design unsuitable. Recursive locking by the same
thread deadlocks this simple lock.

Although `atomic_flag` operations are lock-free, the spinlock algorithm is a
blocking algorithm: all waiters depend on the current owner releasing the lock.
The word “lock-free” must not be transferred from its primitive to the whole design.

## 22. A complete SPSC queue and its proof

### 22.1 State and invariant

A **ring buffer** stores elements in an array and wraps indices at the end.
This queue has one producer and one consumer. An array of N slots holds at most
N−1 elements; one slot is left unused so equal indices mean empty unambiguously.

`head` identifies the next producer slot. `tail` identifies the next consumer
slot. The producer alone advances head; the consumer alone advances tail.
The fields are atomic because the other thread reads them.

The key invariant is: an ordinary slot is written only after it is available,
and read only after its new contents have been published. The consumer publishes
completion before the producer reuses that slot.

### 22.2 Complete program

Save as `spsc_queue.cpp`:

```cpp
#include <array>
#include <atomic>
#include <cassert>
#include <cstddef>
#include <iostream>
#include <thread>

template<std::size_t N>
class SpscQueue {
    static_assert(N >= 2);
    std::array<int, N> slots_{};
    std::atomic<std::size_t> head_{0};
    std::atomic<std::size_t> tail_{0};

    static constexpr std::size_t next(std::size_t value) noexcept {
        return value + 1 == N ? 0 : value + 1;
    }
public:
    bool try_push(int value) noexcept {
        const auto head = head_.load(std::memory_order_relaxed);
        const auto following = next(head);
        if (following == tail_.load(std::memory_order_acquire)) return false;
        slots_[head] = value;
        head_.store(following, std::memory_order_release);
        return true;
    }

    bool try_pop(int& value) noexcept {
        const auto tail = tail_.load(std::memory_order_relaxed);
        if (tail == head_.load(std::memory_order_acquire)) return false;
        value = slots_[tail];
        tail_.store(next(tail), std::memory_order_release);
        return true;
    }
};

int main() {
    SpscQueue<64> queue;
    constexpr int items = 100000;
    std::jthread producer([&] {
        for (int value = 1; value <= items; ++value)
            while (!queue.try_push(value)) std::this_thread::yield();
    });
    std::jthread consumer([&] {
        for (int expected = 1; expected <= items; ++expected) {
            int value = 0;
            while (!queue.try_pop(value)) std::this_thread::yield();
            assert(value == expected);
        }
    });
    producer.join();
    consumer.join();
    int unused = 0;
    assert(!queue.try_pop(unused));
    std::cout << "SPSC queue passed\n";
}
```

### 22.3 Explain every memory order

**Producer's own head load is relaxed.** Only the producer modifies head during
concurrent operation, so this load retrieves its own progress under per-object
coherence. It is not receiving consumer payload through head.

**Producer's tail load is acquire.** When reuse depends on consumer progress,
it must acquire the consumer's release of that progress. This places the consumer's
previous slot read before the producer's next write of the reusable slot.

**Producer's head store is release.** It publishes the ordinary slot write before
a consumer uses the new head value to authorize reading the slot.

**Consumer's own tail load is relaxed.** Only the consumer modifies tail during
concurrent operation; this is its own index.

**Consumer's head load is acquire.** It receives the publication needed before
reading the ordinary slot. Reading a later head update can also cover earlier
producer slot writes that precede that later release.

**Consumer's tail store is release.** It publishes that the slot read is complete
before the producer can reuse the slot.

### 22.4 Staleness, wraparound, and limitations

A stale peer index can cause a conservative false-full or false-empty result.
Per-object coherence and the one-producer/one-consumer protocol prevent observations
from regressing to earlier modification events in a way that permits unsafe
overtaking. The spare slot prevents producer and consumer from lapping each
other without observing the necessary progress. Numeric index values repeat,
so the proof concerns the sequence of modifications, not just their integers.

Changing the design to multiple producers or consumers invalidates the single-owner
reasoning. Adding CAS only to one index does not automatically solve reservation,
publication gaps, slot lifetime, or fairness.

This example stores integers to keep construction, exceptions, and destruction
out of the proof. A generic queue for nontrivial objects must manage those lifetimes
and exception guarantees. An unbounded queue additionally needs node allocation
and reclamation. `try_push`/`try_pop` have bounded algorithmic work, but implementation
lock freedom of the index atomics and end-to-end latency are separate questions.

## 23. Lifetime, reference counting, ABA, and reclamation

### 23.1 Publishing a pointer does not keep its object alive

An acquire load of a published pointer can order initialization before subsequent
field reads. It cannot prevent another thread from deleting the object immediately
after the load. **Reclamation** means determining when removed storage can safely
be destroyed or reused.

This is why a lock-free linked structure needs two proofs: how nodes are published
and how readers are protected from reclamation. Stronger memory orders alone
cannot solve missing ownership.

### 23.2 Double-checked locking

**Double-checked locking**, DCLP, tries a cheap initialized-pointer check before
taking an initialization mutex. A correct modern design can use an acquire
fast-path load and a release publication, with construction under a mutex and
well-defined lifetime.

The second check under the initialization mutex may be relaxed when mutex
synchronization supplies the needed ordering and the protocol is proved. The
fast-path check cannot be a racing ordinary pointer access merely because the
slow path uses a mutex.

For initialization-only objects, a function-local static or `call_once` is often
simpler. Deletion, replacement, exceptions during construction, and shutdown
need explicit treatment in a custom DCLP design.

### 23.3 Reference counting and an acquire fence on final release

A **reference count** records how many owning references keep an object alive.
Incrementing an already-valid owned reference often needs only a relaxed RMW:
the thread already obtained access through a separate valid ownership path.

A common release fragment is:

```cpp
// Fragment inside an otherwise correct ownership system.
// refs is std::atomic<unsigned>, initialized to the owning-reference count.
if (refs.fetch_sub(1, std::memory_order_release) == 1) {
    std::atomic_thread_fence(std::memory_order_acquire);
    delete object;
}
```

Prior owner operations are ordered before their release decrements. The final
RMW reads the preceding modification and can receive earlier releases through
release sequences; the acquire fence provides the receiving side before destruction.
Alternatively, an acq_rel decrement acquires on every decrement, which is often
easier to explain but can do more ordering than non-final releasers need.

Assumptions are essential: all references are counted correctly, no thread
resurrects the count from zero, no underflow/overflow occurs, lifetime acquisition
is already safe, count changes use RMWs rather than intervening reset stores,
and concurrently conflicting payload operations are separately
synchronized. Reference counting does not allow several owners to race on an
ordinary mutable payload.

Reading a raw pointer, then incrementing its count, is not a general safe way
to acquire ownership: deletion may happen between the two steps.

### 23.4 ABA in compare-exchange

Suppose a thread reads pointer A and pauses. Other threads remove A, modify
the structure, and eventually make the head address A again. A CAS comparing
only the pointer can succeed even though the state relevant to its plan changed.
This is ABA.

A **tagged pointer** pairs an address with a generation or counter. It can help
detect state changes, but requires suitable atomic support and a wraparound
argument. It does not by itself guarantee that dereferencing the pointer was safe.

**Hazard pointers** publish which nodes readers may access and delay reclamation
until no relevant hazard remains. **Epoch-based reclamation** delays freeing
retired nodes until participants have passed a period in which old readers
could still hold references. Both require specific ordering protocols; simply
naming the technique is not an implementation proof.

### 23.5 Why a naive seqlock is not portable C++

A **sequence lock**, or seqlock, uses a sequence counter around updates. Readers
read a sequence, copy data, and retry if a writer intervened.

If the payload is ordinary non-atomic data and a writer can modify it during
the read, the speculative copy itself can be a C++ data race. Detecting the
collision afterward does not undo UB. Adding acquire/release fences around the
retry does not retroactively legalize the read.

Portable designs need appropriate atomic payload accesses or a different lifetime
and exclusion strategy, together with a complete consistency proof. Kernel
seqlock recipes depend on their environment's own memory model and primitives;
they cannot be copied verbatim into ISO C++ user code.

## 24. Atomic types, atomic_ref, and progress guarantees

### 24.1 std::atomic<T> does not promise one instruction

The general atomic template requires an appropriate trivially copyable type and
other type constraints. **Trivially copyable** is a C++ property supporting certain
byte-copy operations; it does not imply that an arbitrary object fits a hardware
atomic instruction.

An atomic aggregate can provide a coherent whole-object snapshot through its
atomic interface, but might use a library lock. Large sizes and alignment can
change implementation behavior. Some targets require linking a support library
such as `libatomic` for particular operations.

`is_always_lock_free` is a compile-time property of the atomic specialization.
`is_lock_free()` queries the relevant implementation behavior at runtime.
`std::atomic_flag` is the dedicated atomic type guaranteed to be lock-free.
Neither `atomic<int>` nor `atomic<Pointer>` should be declared universally
lock-free just because they are on common desktop targets.

### 24.2 Complete program: atomic_ref over existing storage

C++20 `std::atomic_ref<T>` provides atomic operations referring to an existing
T object. It does not own that object or extend its lifetime. Required alignment
can be stricter than ordinary T alignment.

Save as `atomic_ref.cpp`:

```cpp
#include <atomic>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <thread>
#include <vector>

int main() {
    using Ref = std::atomic_ref<std::uint64_t>;
    alignas(Ref::required_alignment) std::uint64_t value = 0;
    std::vector<std::jthread> threads;
    for (int i = 0; i < 4; ++i) {
        threads.emplace_back([&] {
            Ref ref(value);
            for (int j = 0; j < 25000; ++j)
                ref.fetch_add(1, std::memory_order_relaxed);
        });
    }
    for (auto& thread : threads) thread.join();
    // All worker atomic_ref objects have been destroyed before ordinary access.
    assert(value == 100000);
    std::cout << value << '\n';
}
```

While relevant atomic_ref objects exist, accesses to the referenced object must
follow the atomic_ref access requirements. Do not mix ordinary concurrent accesses
with these atomic accesses, and do not independently refer to overlapping objects
or subobjects in incompatible ways. Multiple atomic_ref objects can refer to
the same suitably aligned live object.
See [N4861 atomic_ref](https://timsong-cpp.github.io/cppwp/n4861/atomics.ref.generic).

### 24.3 Shared pointers: the handle and the pointee differ

The control block of shared ownership manages reference counting, but two threads
modifying the same ordinary `shared_ptr` handle still need synchronization.
Distinct handles sharing ownership can be used according to their library contract.

C++20 provides `std::atomic<std::shared_ptr<T>>` for atomic operations on a shared
pointer handle. A useful snapshot pattern is an atomic shared pointer to an
immutable configuration: publish a fully initialized new configuration with
release, load a snapshot with acquire, and retain the loaded owning handle while
using it. The pointee must actually remain immutable; mutable aliases can break
that contract.

Reference-count safety is not payload synchronization. An atomic shared-pointer
load keeps its owned object alive but does not make all future accesses to its
mutable fields thread-safe. The atomic specialization is not guaranteed lock-free.
See [N4861 atomic shared_ptr](https://timsong-cpp.github.io/cppwp/n4861/util.smartptr.atomic.shared).

### 24.4 Progress and fairness are separate from visibility

A CAS retry loop can starve one contender while others succeed. A spinlock can
block every waiter behind a descheduled owner. A wait operation can depend on
another thread changing state and notifying. Stronger memory orders do not
automatically fix any of these progress properties.

**Backoff** means delaying or reducing retry frequency after contention. It can
improve throughput but changes latency and fairness. **Contention** is concurrent
competition for the same resource, such as a cache line or lock.

The standard has separate forward-progress requirements and recommendations;
none should be interpreted as “an acquire load will see this store within N
nanoseconds.” See [N4861 forward progress](https://timsong-cpp.github.io/cppwp/n4861/intro.progress).

## 25. Performance and measurement

### 25.1 The memory-order spelling is only one cost

An uncontended operation on a cache line already owned by one core can be much
cheaper than the same operation under heavy contention. Costs include:

- Compiler constraints that prevent useful movement or elimination of work.
- Instruction choice and pipeline effects.
- Acquiring cache-line ownership and moving it between cores.
- CAS failures, retries, and reservation loss.
- Scheduling, blocking, wakeups, and preemption.
- NUMA distance, where memory latency depends on the processor node.

A relaxed `fetch_add` remains an RMW and can still cause substantial line
contention. An acquire load and relaxed load may emit the same instruction yet
have different permissible compiler transformations and program semantics.

### 25.2 False sharing and layout

**False sharing** occurs when independent variables occupy one cache line and
different cores repeatedly write them. The variables may be separate C++ memory
locations, so there is no data race, but the hardware transfers ownership of
the common line.

Padding or separating frequently written fields can reduce this traffic.
`std::hardware_destructive_interference_size`, where supported, describes an
implementation-provided separation size intended to help avoid it. Layout
choices can affect ABI, object size, and cache footprint; blindly padding every
field can make a program larger and slower.

For the SPSC queue, separating producer and consumer indices is a performance
experiment, not part of the proof that slot accesses are correctly synchronized.

### 25.3 Reduce sharing before weakening correctness

Sharding counters per worker, batching updates, or avoiding repeated ownership
transfers can produce larger gains than changing seq_cst to relaxed on the same
contended variable. **Sharding** means distributing state among independently
owned pieces and combining results when needed.

Batching publication can amortize synchronization cost but delays visibility and
can increase latency. Evaluate the application's actual throughput and latency
requirements, including its slowest operations rather than only an average.

### 25.4 How to benchmark honestly

Specify compiler/version/options, CPU, thread placement, number of participants,
working-set size, contention pattern, and whether the benchmark includes startup.
Inspect optimized code and retain observable results so unused work is not eliminated.

Compare algorithms doing equivalent work and meeting equivalent requirements.
Do not conclude that relaxed is universally “X nanoseconds faster” from one
single-threaded loop. Separate uncontended latency, shared throughput, and
handoff latency between cores. Printing inside the timed loop changes the workload.

If runtime memory-order arguments make the compiler choose a conservative
implementation, specialize the benchmark at compile time. Treat measurements
as properties of a configuration, not amendments to the C++ memory model.

## 26. Testing, tooling, and the limits of experiments

### 26.1 Build and run the complete examples

Each program contains its own main. Save it under its indicated filename and
compile it separately, for example:

```sh
g++ -std=c++20 -O2 -Wall -Wextra -Wpedantic -pthread publication.cpp -o publication
./publication
```

Keep assertions enabled while checking the examples. `-DNDEBUG` disables standard
`assert` checks. The examples validate results after the relevant synchronization;
they are not performance benchmarks except for the explicitly observational
litmus harness, which is still not a rigorous latency benchmark.

### 26.2 What stress testing can establish

Repeated executions can expose wrong results, missing handoffs, and some lifetime
bugs. A failure in a supposedly correct program is useful evidence to investigate.
Millions of successful executions do not prove a forbidden-by-design outcome
cannot occur on another build, CPU, or schedule.

Distinguish these statements:

| Statement | Evidence required |
|---|---|
| “This run produced this count.” | Recorded output from that run. |
| “This ISA/compiler combination normally forbids this outcome.” | Verified instruction mapping and architectural reasoning. |
| “C++ forbids this outcome.” | Language-level proof under the specified edition and assumptions. |
| “The algorithm is correct.” | Safety, ownership, lifetime, state-machine, and relevant progress arguments. |

### 26.3 ThreadSanitizer

**ThreadSanitizer**, TSan, is a dynamic tool that instruments a program to detect
many data races during observed executions. Typical usage is:

```sh
g++ -std=c++20 -O1 -g -fsanitize=thread -pthread publication.cpp -o publication_tsan
./publication_tsan
```

A report can identify accesses whose synchronization is missing. No report does
not prove an all-atomic algorithm logically correct; data-race-free algorithms
can still violate invariants. TSan has limitations around standalone fences,
custom synchronization, unsupported runtimes, and interprocess protocols. Some
GCC configurations explicitly warn that atomic fences are not supported by its
TSan instrumentation.

Do not “fix” a valid fence protocol based solely on a tool limitation, and do
not dismiss a report without a proof. See the
[Clang ThreadSanitizer documentation](https://clang.llvm.org/docs/ThreadSanitizer.html)
for supported targets and restrictions.

### 26.4 Inspecting assembly

```sh
g++ -std=c++20 -O2 -S -masm=intel publication.cpp -o publication.s
```

`-S` emits assembly; `-masm=intel` selects Intel syntax for an x86 target.
Use small standalone functions to compare one atomic operation at a time.
Check whether the result is used: `fetch_add` with an unused result may use a
different instruction from one that returns the old value.

An acquire and relaxed load both becoming `mov` does not mean the C++ operations
are interchangeable. Assembly is evidence about that compilation, not a proof
that an invalid source-level program was valid.

### 26.5 Model checking and bounded exploration

A **model checker** explores executions under a formal model rather than only
the schedules observed by one run. It can find weak-memory outcomes your hardware
does not exhibit. Check which language edition, atomic features, and algorithms
the tool models; simplified or bounded models have limits.

Bounded exploration means only a finite scope, such as a fixed number of threads
and operations, has been checked. It does not automatically prove unbounded
queue reuse, reclamation, or counter-wrap behavior. Use the tool to support a
clearly stated proof obligation, not replace all reasoning with “the tool passed.”

## 27. Sixty interview questions with model answers

### Foundations and vocabulary

**1. What problem does the C++ memory model solve?**

It defines how concurrent evaluations can interact, including which accesses
race, which operations synchronize, and what values atomic reads can observe.
This lets programmers and compilers reason about portable concurrency without
assuming one particular CPU's instruction behavior.

**2. What is the difference between atomicity and ordering?**

Atomicity makes an operation indivisible with respect to the relevant atomic
accesses. Ordering constrains relationships with other operations. Relaxed
`fetch_add` is still an atomic increment, but it does not by itself publish
unrelated ordinary data.

**3. What is a data race, and how is it different from a race condition?**

A data race involves conflicting potentially concurrent accesses, at least one
non-atomic, without the required happens-before ordering; it produces UB.
A race condition is a broader timing-dependent logical error. A check-then-act
sequence made entirely of atomic operations can have a race condition without
having a data race.

**4. Can two reads of one ordinary variable race?**

Two reads alone do not conflict in the relevant way. The difficulty arises when
there is a concurrent write or lifetime/storage change. Also check that the
object was safely initialized and is still alive.

**5. Can two independent structure members cause false sharing without a data race?**

Yes. Separate ordinary members can be separate memory locations, while residing
on one hardware cache line. Legal independent writes can still repeatedly move
that line between cores. Language correctness and hardware sharing costs use
different granularities.

**6. Does running on one CPU remove the need for atomics?**

No. C++ rules concern potentially concurrent threads and ordering, not just
simultaneous physical execution. Scheduling changes, compiler transformations,
and future deployment on different hardware also make that assumption unsuitable.

**7. Does an aligned integer load count as an atomic C++ access?**

Not merely because it uses one indivisible instruction on a target CPU. Use a
supported atomic interface, such as `std::atomic` or correctly used `atomic_ref`,
or protect ordinary storage through a synchronization protocol.

**8. What is sequenced-before?**

It is the language's ordering relation within one thread. It connects ordinary
statements in the examples but should not be replaced with a universal assumption
of left-to-right expression evaluation. It is one building block of a cross-thread
happens-before proof.

**9. What is happens-before?**

For the non-consume examples here, it is the transitive ordering built from
sequenced-before and specified synchronizes-with edges. It orders conflicting
accesses and constrains visible effects. It is not the same as an earlier
timestamp or one thread appearing to finish first during a debug run.

**10. What is modification order?**

The total order of modifications to one atomic object. Every atomic has its
own order, and loads do not themselves modify that order. Several independent
atomics do not automatically share one common order of all their operations.

### Relaxed and release/acquire

**11. What does memory_order_relaxed guarantee?**

Atomicity and the per-object coherence constraints still apply. A relaxed RMW
is a real RMW and cannot lose updates through an intervening modification inside
that operation. The missing guarantee is independent publication ordering for
unrelated ordinary data.

**12. When is a relaxed statistics counter appropriate?**

When the counter's numeric update is the requirement and its value is not used
to authorize access to separately published data. If an exact final total is
read after all workers join, the joins supply completion ordering. A live total
does not imply a consistent snapshot of other metrics.

**13. Can relaxed loads of one atomic go backward?**

Not to an earlier modification event when the later load is happens-after the
earlier one. Read-read coherence prevents that. Numerical values can decrease
if a later modification stored a smaller value or a counter wrapped.

**14. Why is an atomic ready flag insufficient with relaxed ordering?**

It protects accesses to the flag itself, but it supplies no release/acquire edge
for the ordinary payload. A consumer entering the payload-reading path can race
with initialization. Make the flag's publication relationship valid or protect
the payload another way.

**15. State the release/acquire rule precisely enough for a proof.**

A release operation on atomic M synchronizes with an acquire operation on M
that reads from the release or its qualifying release sequence. Ordinary work
before the release can then happen-before work after the acquire through SB
on the two sides.

**16. Does an acquire load always see the most recent store?**

No general wall-clock freshness guarantee follows from acquire. It constrains
the consequences of the publication actually observed. A reader might need to
wait until an appropriate value appears, and even that waiting has scheduling
and progress assumptions.

**17. Can the payload be a non-atomic std::string?**

Yes, if construction and mutation before publication happen-before consumption,
there are no subsequent conflicting modifications, and the string and its
owned storage remain alive. Making every field atomic is unnecessary when
ownership and publication are correct.

**18. What if two producers both release-store true?**

The consumer must identify which publication it received. Numerical equality
does not prove a load read the particular producer's store needed for a payload.
Moreover, multiple writers may race on the payload itself. A single boolean
usually does not provide enough ownership information for that design.

**19. Why does reusable storage need a second handoff?**

The forward handoff orders writing before reading. A return handoff orders
reading before the next overwrite. Without that second edge or equivalent
ownership protection, the producer can conflict with a reader still using
the previous contents.

**20. Can synchronization be transitive through a third thread?**

Yes. A relay can acquire one publication, then release another; a downstream
acquire can receive the original work through the HB chain. This differs from
a relaxed RMW that merely extends someone else's release sequence.

### RMW, release sequences, and CAS

**21. What makes fetch_add different from load followed by store?**

`fetch_add` reads the immediately preceding modification and installs its result
as one RMW. Another writer cannot intervene between those two roles within
the operation. Separate load/store steps can both use the same old value and
overwrite one another's updates.

**22. When does an RMW need acq_rel?**

When it both receives previously published data through its read and publishes
the current thread's earlier work through its modification. A state transition
often serves both roles, but the required relationships must be demonstrated;
using acq_rel by habit is not a proof.

**23. What is a release sequence in C++20?**

A release modification followed by consecutive RMW modifications of the same
atomic in MO. An acquire reading one of those continuation modifications can
synchronize with the head release. An ordinary store ends the sequence, even
when issued by the head-release thread.

**24. Does a relaxed RMW in a release sequence acquire the payload for its own thread?**

No. It can preserve publication for a later acquire, but its own relaxed read
does not perform an acquire. If that thread needs to use the payload, it needs
an appropriate acquiring operation or another valid synchronization path.

**25. What changed about release sequences in C++20?**

The earlier allowance for certain subsequent ordinary stores from the releasing
thread was removed. Current-baseline proofs should rely on consecutive RMWs
or explicit new acquire/release handoffs, not silently reuse the older rule.

**26. What happens to expected when compare-exchange fails?**

It is updated with the value observed by the failed operation. A retry loop
must account for that update and recompute its desired result as needed.
The expected object itself is not magically safe for concurrent mutation by
several callers.

**27. Why can weak CAS fail spuriously?**

To allow efficient implementation on mechanisms such as LL/SC, where a reservation
can be lost without the value comparison having changed. Retry when the algorithm
allows it. Strong CAS eliminates that permitted spurious failure, not contention
or the need to reason about failed comparisons.

**28. Why are release and acq_rel invalid CAS failure orders?**

A failed CAS performs a load-like observation; it makes no modifying publication
on the atomic. Failure can need acquire when the observed value identifies
published data, or relaxed when it only supplies another numeric retry candidate.

**29. Is “failure can never be stronger than success” a timeless C++ rule?**

No. State the edition: older C++11/14 wording included that restriction, while
the C++20 precondition is different. Also distinguish standard-library wording
from compiler-builtin constraints. Conventional order pairs avoid many portability
and diagnostic surprises; unusual pairs deserve explicit justification.

**30. Does successful CAS prove a pointer's history never changed?**

No. ABA can restore the same compared value after significant intervening changes.
Use a state/history and reclamation strategy appropriate to the structure.
A stronger CAS memory order cannot reveal history absent from the compared state.

### SC and fences

**31. What does seq_cst add to acquire/release?**

A shared total order of SC operations and fences, with specified consistency
constraints. This can rule out cross-object outcomes that acquire/release alone
permits. It does not group separate operations into one transaction or protect
unrelated ordinary accesses automatically.

**32. Why can store buffering produce two zeros with release/acquire?**

Both loads may read the initial values, so neither reads the opposing release.
Without those reads-from connections, there is no SW edge forcing either load
to observe the other thread's store. The order names alone do not establish
a completed handoff.

**33. Why does all-SC forbid two zeros in that test?**

Each store must precede its own later load in S. Each load returning zero must
precede the opposing store in the all-SC, single-update test. Combining those
requirements creates a cycle, impossible in a total order.

**34. Is an SC load necessarily implemented with a fence instruction?**

No. On common x86 mappings it can be an ordinary load, with other operations
carrying the necessary additional constraints. Correctness depends on the
compiler's whole mapping, not on each SC operation individually looking expensive.

**35. Does an acq_rel fence equal an SC fence?**

No. The SC fence additionally participates in S and has SC ordering constraints.
Acquire/release fence semantics alone need not rule out store-buffering outcomes
when no communicating observation provides an SW path.

**36. What connects a release fence to an acquire fence?**

A suitable atomic modification after the release fence and a read of that
modification, or its qualifying continuation, before the acquire fence. The
communicating atomic is essential. Two disconnected fences do not automatically
establish publication.

**37. Where does an acquire fence go in a relaxed-load publication pattern?**

After the load that observes the publication and before the ordinary payload
accesses requiring protection. A fence before the load does not supply that
atomic-fence proof. Always draw the sequence and reads-from edges.

**38. Can fences fix a non-atomic polling flag?**

Not by themselves. A racing ordinary flag remains a data race, and the normal
fence publication rules require a suitable atomic communication path. Use an
atomic flag or another defined synchronization mechanism.

**39. What is the difference between thread and signal fences?**

A thread fence serves interthread memory-order rules. A signal fence constrains
ordering between a thread and a signal handler executing on that same thread
and does not insert the corresponding hardware fence instructions. Signal-handler
access restrictions remain in force.

**40. Does std::barrier mean the same thing as a memory fence?**

No. A barrier coordinates participant arrivals across phases and supplies its
specified synchronization. A memory fence orders operations without making all
threads rendezvous. Clarify which meaning an interview question intends.

### Hardware, libraries, and lifetime

**41. Why can acquire and relaxed loads compile identically on x86?**

The hardware already supplies relevant load ordering for ordinary memory, while
the compiler applies different language-level constraints. Identical emitted
instructions in one function do not make the source operations interchangeable
in a larger program.

**42. Does a release store flush every cache to RAM?**

No. Synchronization concerns permitted observations and ordering, commonly using
coherent caches. Writing back all caches to DRAM is neither the definition nor
the normal required mechanism. Persistence and device access need separate analysis.

**43. Does volatile make a polling loop correct?**

It does not establish the atomicity and interthread synchronization required
for ordinary C++ shared data. Emitting repeated loads does not eliminate the
data race or publish an associated payload. Use the appropriate atomic/library
interface.

**44. What do DMB, DSB, and ISB distinguish on Arm?**

Memory-access ordering, stronger completion requirements, and instruction-stream
synchronization, respectively, with architecture-specific options and domains.
They are not interchangeable spellings for one universal barrier, and C++
acquire/release often uses dedicated load/store instructions instead.

**45. Does a mutex only prevent simultaneous execution?**

No. Its handoff also has synchronization effects ordering protected work between
owners. This permits ordinary non-atomic payload fields when every conflicting
access follows the lock discipline. Exclusion without an ordering contract would
not be the whole required C++ abstraction.

**46. Does joining allow a parent to read an ordinary worker result?**

Yes, if the worker's completion precedes successful join return, the object
remains alive, and there were no earlier conflicting accesses. Join provides
the completion synchronization; an atomic result is not always needed.

**47. Does atomic notify_one publish the payload?**

Notification wakes waiters; the state-changing operation and the waiting load's
order provide the publication argument. A release store plus an acquire wait
is a common pattern. A relaxed store plus notification does not independently
publish ordinary payload data.

**48. Can atomic wait miss a transition?**

Yes, when the value changes and returns to its old representation before the
waiter observes it. Wait is value-based, not an event-history queue. Use a
generation/event-counting protocol if every transition matters, and account
for wraparound and shutdown.

**49. Is a spinlock lock-free because its atomic_flag is lock-free?**

No. The primitive's property does not describe the algorithm. A paused lock
owner can prevent all waiters from entering. The spinlock is a blocking ownership
scheme despite implementing its waiting with lock-free atomic operations.

**50. Why can an SPSC queue's own index load be relaxed?**

Only that participant writes the index during concurrent operation. The load
tracks its own progress rather than acquiring another participant's publication.
Acquiring the peer's progress and releasing new progress provide the two handoffs
that protect ordinary slot accesses.

**51. Why is the consumer's release of tail important?**

It orders the completed slot read before the producer reuses that slot after
acquiring the updated tail. Protecting writes-before-reads alone is insufficient
for a reusable buffer; the reverse ownership transfer also matters.

**52. Does acquire protect a loaded pointer from deletion?**

No. It can receive initialization but does not grant indefinite ownership.
Reclamation protection, shared ownership, a lock, or another valid lifetime
mechanism must keep the object alive during use.

**53. Why is incrementing a reference count through an unprotected raw pointer unsafe?**

The object can be deleted before the increment accesses its count. Making that
increment atomic does not make dereferencing freed storage legal. Ownership
acquisition itself must be protected; reference counts only help once that
acquisition is valid.

**54. Why can a naive seqlock have UB despite retrying?**

A speculative ordinary payload read can race with a writer. A later sequence
check and retry cannot erase the already-occurring data race. Use a design
whose attempted reads are legal before analyzing whether they form a consistent
snapshot.

### Judgment, tooling, and performance

**55. Is atomic_ref a way to mix atomic and plain concurrent access freely?**

No. It has alignment, lifetime, and exclusive-access-through-atomic_ref requirements
while references exist. It adapts existing storage to an atomic access discipline;
it does not excuse other threads from following that discipline.

**56. Does a relaxed RMW become cheap under contention?**

Not necessarily. It still needs an atomic modification and often transfers
cache-line ownership. Sharding or batching can reduce contention more than
weakening an order on one heavily shared variable.

**57. What can a clean ThreadSanitizer run prove?**

It shows no supported race was reported on the observed executions. It does
not prove all schedules safe, an all-atomic invariant correct, or a custom fence
or interprocess protocol modeled accurately. Combine tools with a proof and
their documented limitations.

**58. If a weak-memory result never appears on your machine, is it forbidden?**

No. The CPU/compiler can be stronger than the language requires, and the test
may not explore a revealing schedule. State separately what C++ permits, what
the target mapping permits, and what an experiment actually observed.

**59. How do you choose the weakest correct order?**

First define ownership and invariants. Identify which operations publish, acquire,
or only update numeric state. Draw the required HB edges and any global-order
constraints. Weaken an operation only when every proof obligation survives,
then measure whether the added complexity buys anything.

**60. What is a strong answer when you are unsure about a lock-free algorithm?**

State the missing proof obligation precisely: publication, reclamation, ABA,
reuse, progress, or a mixed-SC rule. Offer a simpler correct design, such as a
mutex, and explain what additional evidence would justify the specialized one.
Do not replace a missing argument with “x86 usually makes it work.”

## 28. Exercises with detailed answers

### Exercise 1: atomic steps, lost compound update

Initially `std::atomic<int> x{0}`. Two threads each perform `x = x + 1` once.
After joining both, what can the final value be? Would adding seq_cst fix it?

**Answer:** 1 or 2. The default operations are already SC, but each expression
has a load and a separate store. Both threads can load 0 before either stores 1.
SC permits that interleaving. There is no data race on x, but the intended
compound increment is not atomic. Use `fetch_add(1)` or atomic increment; relaxed
is sufficient if the only contract is the final numeric count after joining.

### Exercise 2: stale value or undefined behavior?

Producer writes `payload = 7`, then relaxed-stores 1 to an atomic flag. Consumer
relaxed-loads 1 from the flag and reads payload. Analyze both cases:

1. Payload is an ordinary integer.
2. Payload is an atomic integer and the payload accesses are relaxed.

**Answer:** case 1 lacks HB for the conflicting payload accesses and has a data
race on that path. Do not limit its result to “0 or 7.” Case 2 has no data race
on the payload but may observe its older initialized value. Changing the flag's
store/load to release/acquire, with the load reading that publication, supplies
the ordering needed for either representation's intended use.

### Exercise 3: an acquire fence in the wrong place

Producer initializes ordinary payload and release-stores true. Reader does:

```cpp
// INCORRECT fragment: no other synchronization.
std::atomic_thread_fence(std::memory_order_acquire);
if (ready.load(std::memory_order_relaxed)) {
    use(payload);
}
```

**Answer:** the acquire fence precedes the communicating load, so the
atomic-fence synchronization rule does not apply. Move the acquire fence after
the load and before `use(payload)` on the successful path, or make the load
acquire and remove the standalone fence. Placing the fence after `use(payload)`
is also too late to order the ordinary read.

### Exercise 4: numerical equality is not reads-from identity

Writer A initializes payload and release-stores true to ready. Writer B independently
relaxed-stores true to ready. Consumer acquire-loads true and reads the ordinary
payload. Are the contents guaranteed initialized for that reader?

**Answer:** not from this protocol. The load can read B's unrelated relaxed
store. That store is not an RMW release-sequence continuation and supplies no
publication edge from A. B storing the same bit pattern does not transfer A's
ordering. A safe design identifies which publication the reader consumes, for
example with single ownership or a separately proved state/generation protocol.

### Exercise 5: prove or refute two-zero store buffering

Both x and y start at zero. Each thread stores 1 to its own atomic and reads
the other atomic. Analyze relaxed, release/acquire, all-SC, and relaxed with
SC fences between each thread's store and load.

**Answer:** relaxed and release/acquire permit two zeros. For all-SC, draw the
four-event cycle from section 12. For the SC-fence version, coherence and the
fence constraints would require each fence to precede the other in S if both
loads read before the opposing modifications; that contradiction forbids the
outcome. Acq_rel fences do not supply that shared SC order.

### Exercise 6: a broken CAS lock loop

The lock state uses 0 for free and 1 for held:

```cpp
// INCORRECT fragment: expected is not reset after failure.
int expected = 0;
while (!state.compare_exchange_weak(expected, 1,
                                     std::memory_order_acquire,
                                     std::memory_order_relaxed)) {
}
// Supposedly own the lock here.
```

**Answer:** failure while the lock is held sets expected to 1. The next attempt
can succeed by replacing 1 with 1, even though another owner still holds the
lock. The atomic operations themselves are valid, but the ownership invariant
is broken. Reset expected to 0 for every attempt, or use a correctly designed
exchange/atomic_flag lock. Strong CAS would not fix the missing reset.

### Exercise 7: what can a relaxed relay do?

A release-stores state 1 after initializing payload. B changes 1 to 2 using
a successful relaxed CAS. C acquire-loads 2. May C read payload? May B?

**Answer:** C may under the stated single-sequence assumptions: B's RMW continues
A's release sequence. B cannot rely on its relaxed CAS to acquire payload for
its own reads. If B also writes new ordinary metadata, C does not automatically
receive that metadata from B's relaxed CAS. Use the required acquiring and
releasing semantics for B's additional roles.

### Exercise 8: reference counting does not safely acquire from a raw pointer

Thread A loads an atomic raw pointer, then increments the pointee's atomic
reference count. Thread B removes the pointer and deletes the object when its
count reaches zero. Would seq_cst everywhere make A safe?

**Answer:** no. A's pointer load can be ordered before B's removal, while B's
deletion occurs before A's count increment. A then dereferences dead storage.
Every atomic operation can participate in a perfectly valid SC order while
the lifetime protocol remains invalid. Protect ownership acquisition with a
lock, an appropriate atomic shared owner, or a proved reclamation mechanism.

### Exercise 9: why is a relaxed tail acknowledgment insufficient?

In the SPSC queue, keep the producer's release head store and the consumer's
acquire head load. Change the consumer's tail store and producer's tail load
to relaxed. What proof is now missing?

**Answer:** the reader's completed ordinary slot access no longer happens-before
the producer's next write when the slot is reused. The forward handoff still
publishes new contents, but the reverse ownership transfer is absent. The
fact that the producer numerically sees an advanced tail is not an SW edge.

### Exercise 10: can a seqlock discard an illegal read?

A reader copies a plain structure while a writer might update it, then checks
an atomic sequence number and retries if it changed. The reader never *uses*
an inconsistent copy. Is the algorithm therefore portable C++?

**Answer:** no. The conflicting ordinary read itself can race. Undefined behavior
does not become harmless because a later branch discards the result. First
make attempted accesses legal, for example through an appropriate atomic payload
design or exclusion/lifetime mechanism; then prove the snapshot validation.

### Exercise 11: notifications versus event history

A producer stores true, notifies, and immediately stores false into a flag.
A consumer waits for the flag to differ from false. Must it observe the event?

**Answer:** no. The flag can return to false before the waiter observes true,
and wait is not an event queue. A notification is not a permanent stored permit.
If every event matters, represent it with a suitable count/queue protocol,
including acknowledgment and shutdown semantics. Merely changing both stores
to SC does not make the intermediate value unmissable.

### Exercise 12: design immutable configuration snapshots

Several readers need a consistent pair of configuration fields. One writer
occasionally replaces both. Readers should keep using a valid old snapshot
while replacement happens. Explain why two independent SC fields are insufficient,
then propose a C++20 design.

**Answer:** two SC stores still have an interval between them where a reader can
observe a mixed pair. A straightforward design publishes an immutable, fully
constructed configuration through `std::atomic<std::shared_ptr<const Config>>`.
A release store publishes the new shared owner; an acquire load obtains a
snapshot whose fields can be read together. The local owning handle keeps the
old object alive across replacements.

The writer must not modify objects after publication through retained mutable
aliases. Readers must retain the handle while using references into the object.
The design trades allocation and shared-ownership costs for simpler correctness
and is not guaranteed lock-free. A mutex-protected copy is another valid choice
when its performance meets the requirement.

## 29. A proof checklist and interview answer

### 29.1 Choose an order by role

| Role of the operation | Typical starting point | Required justification |
|---|---|---|
| Independent numeric update | relaxed RMW | No unrelated payload is published through this update. |
| Publish initialized data | release store/RMW | Initialization precedes it and reader consumes this publication. |
| Receive published data | acquire load/RMW | It reads the required release or release sequence. |
| Receive and republish | acq_rel RMW | Both directions are necessary and valid. |
| Require a cross-object SC argument | seq_cst | Show the global-order constraints the algorithm needs. |
| Poll only before a later acquiring claim | Often relaxed | No protected payload is accessed based only on the poll. |
| Successful pointer CAS followed by dereference | Often acquire or acq_rel | Publication and lifetime must both be proved. |
| Failed CAS followed by dereference of observed pointer | Often acquire failure | The failure observation receives initialization; lifetime remains separately protected. |
| Shared mutable multi-field invariant | Often a mutex | Every conflicting access follows the same lock discipline. |

This table is a starting point, not a recipe that replaces the algorithm proof.

### 29.2 Review checklist

Before calling a concurrency component correct, answer:

1. Which language edition and platform assumptions apply?
2. Which objects are ordinary, atomic, immutable, or protected by a lock?
3. Are all objects safely initialized and alive during every access?
4. Who owns each writable payload region at every stage?
5. Which modification does each successful control observation read?
6. Where are the SW edges, including any fence rules used?
7. Are all conflicting ordinary accesses ordered by HB?
8. What protects storage reuse, removal, and destruction?
9. Does every RMW/CAS order match the operation's success and failure roles?
10. Do repeated values, counter wraparound, or ABA break identity/history assumptions?
11. Is any claimed cross-object ordering actually justified by SC or another protocol?
12. Are notification, termination, exceptions, and participant failure handled?
13. What progress/fairness properties are promised, and under what scheduling assumptions?
14. What did testing verify, and what remains a language-level or architectural proof?
15. Does measurement justify the complexity compared with a simpler synchronized design?

### 29.3 A short interview answer

> Atomicity and ordering are separate. An atomic operation is indivisible, while
> its memory order determines how it can constrain other accesses. Relaxed is
> enough for some standalone counters. For publication, I put initialization
> before a release, require an acquire that reads that publication, and put
> consumption afterward; that gives a happens-before chain. Reusing storage
> needs an acknowledgment in the other direction. Sequential consistency adds
> one order for SC operations, but it does not make compound updates transactional.
> Fences need a valid connecting atomic path, and neither stronger ordering nor
> volatile repairs a missing lifetime or ownership protocol.

### 29.4 How to answer a live code-review question

Start by stating the intended invariant. Point to the exact conflicting accesses.
Draw the publishing and receiving events, and say which store the receiver must
observe. Explain reuse and destruction before discussing instruction costs.
If the code is invalid, classify the failure: data race, logical race, missing
lifetime, invalid memory-order argument, or lack of progress.

Then suggest the smallest clear correction and explain why it supplies the
missing property. Finish with platform/version caveats only where they matter
to that code. This demonstrates understanding more effectively than listing
every memory-order enumerator without connecting it to the algorithm.

## 30. Primary references and related material

### Stable C++20 wording used for the main proofs

- [N4861: data races, release sequences, and happens-before](https://timsong-cpp.github.io/cppwp/n4861/intro.races).
- [N4861: atomic ordering and consistency](https://timsong-cpp.github.io/cppwp/n4861/atomics.order).
- [N4861: atomic operation contracts and CAS](https://timsong-cpp.github.io/cppwp/n4861/atomics.types.operations).
- [N4861: fences](https://timsong-cpp.github.io/cppwp/n4861/atomics.fences).
- [N4861: atomic waiting](https://timsong-cpp.github.io/cppwp/n4861/atomics.wait).
- [N4861: atomic_ref](https://timsong-cpp.github.io/cppwp/n4861/atomics.ref.generic).
- [N4861: atomic_flag](https://timsong-cpp.github.io/cppwp/n4861/atomics.flag).
- [N4861: atomic shared_ptr](https://timsong-cpp.github.io/cppwp/n4861/util.smartptr.atomic.shared).
- [N4861: mutex synchronization](https://timsong-cpp.github.io/cppwp/n4861/thread.mutex.requirements.mutex).
- [N4861: thread construction](https://timsong-cpp.github.io/cppwp/n4861/thread.thread.constr)
  and [joining](https://timsong-cpp.github.io/cppwp/n4861/thread.thread.member).
- [N4861: condition variables](https://timsong-cpp.github.io/cppwp/n4861/thread.condition.condvar).
- [N4861: call_once](https://timsong-cpp.github.io/cppwp/n4861/thread.once.callonce).
- [N4861: phase barriers](https://timsong-cpp.github.io/cppwp/n4861/thread.barrier.class).
- [N4861: forward progress](https://timsong-cpp.github.io/cppwp/n4861/intro.progress).

These are rendered copies of the standard committee's draft text. Stable draft
links keep the edition explicit; the final published standard is the authority
for a specific edition.

### Version changes, compilers, tools, and hardware

- [WG21 P3475R2: consume deprecation and acquire-equivalent meaning](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2025/p3475r2.pdf).
- [Current working draft: consume compatibility wording](https://eel.is/c++draft/depr.atomics.order).
- [GCC atomic builtins](https://gcc.gnu.org/onlinedocs/gcc/_005f_005fatomic-Builtins.html).
- [GCC extended assembly and memory clobbers](https://gcc.gnu.org/onlinedocs/gcc/Extended-Asm.html).
- [GCC volatile semantics](https://gcc.gnu.org/onlinedocs/gcc/Volatiles.html).
- [Clang ThreadSanitizer documentation](https://clang.llvm.org/docs/ThreadSanitizer.html).
- [Intel architecture manuals](https://www.intel.com/content/www/us/en/developer/articles/technical/intel-sdm.html).
- [Arm memory-access ordering](https://developer.arm.com/community/arm-community-blogs/b/architectures-and-processors-blog/posts/memory-access-ordering-part-3---memory-access-ordering-in-the-arm-architecture).
- [Armv8 sequential consistency](https://developer.arm.com/community/arm-community-blogs/b/tools-software-ides-blog/posts/armv8-sequential-consistency).

### Existing repository material

- [mmap companion guide](23-mmap-complete-guide.md), especially visibility,
  persistence, shared memory, and ownership of mapped views.
- [Existing memory-order chapter, in Russian](22-memory-order-and-fences.md).
- [Concurrency and the memory model](04-concurrency-and-memory-model.md).
- [Condition variables](14-condition-variable.md).
- [SPSC interview problem](../02-interview-questions/09-lock-free-spsc-ring-buffer.md).
- [Atomic-flag spinlock interview problem](../02-interview-questions/10-spinlock-atomic-flag-memory-order.md).
- [Existing memory-order demonstration source](../../memory_order_demo.cxx).

### Validation of this guide's complete examples

The 11 complete programs were extracted directly from this Markdown and compiled
on x86-64 with GCC 15.2 using C++20, optimization, pthread support, and warnings
treated as errors. Each executable passed five runs with assertions enabled.
The SPSC queue additionally passed three runs each with array sizes 2 and 3,
exercising a one-element usable capacity and frequent wraparound.

The store-buffering program checks the forbidden result for all-SC and SC-fence
variants. It does not require a permitted weak-order result to appear. No Arm
execution, formal model-checker run, or TSan validation is claimed for these
checks. The per-example ordering proofs are separate from this execution evidence.
