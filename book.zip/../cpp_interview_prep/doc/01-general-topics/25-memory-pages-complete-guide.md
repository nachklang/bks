# Memory pages: from virtual addresses to physical RAM

This is a standalone guide to memory pages for C++ interview preparation. It
explains what a page is, how addresses reach RAM, why accesses fault, how Linux
allocates and reclaims memory, and what all of this means for application design.
Definitions appear before or alongside their use.

**Scope:** ordinary processes on Linux systems with virtual memory. C++ examples
target Linux and C++20. Concrete page-table calculations use an explicitly stated
x86-64 configuration; other architectures and kernel configurations can differ.
References were checked on 2026-09-26.

The [mmap guide](23-mmap-complete-guide.md) explains the mapping API in detail.
This document concentrates on the machinery underneath it. The
[memory-ordering guide](24-memory-order-and-barriers-complete-guide.md) explains
thread synchronization, which is a separate layer from page management.

## Contents

1. [What a memory page actually is](#1-what-a-memory-page-actually-is)
2. [The different units people call memory](#2-the-different-units-people-call-memory)
3. [Page arithmetic and alignment](#3-page-arithmetic-and-alignment)
4. [Virtual pages and physical frames](#4-virtual-pages-and-physical-frames)
5. [Page tables in detail](#5-page-tables-in-detail)
6. [TLBs, page walks, and shootdowns](#6-tlbs-page-walks-and-shootdowns)
7. [Page faults from start to finish](#7-page-faults-from-start-to-finish)
8. [Anonymous memory, zero pages, and overcommit](#8-anonymous-memory-zero-pages-and-overcommit)
9. [File pages, page cache, and writeback](#9-file-pages-page-cache-and-writeback)
10. [Copy-on-write and fork](#10-copy-on-write-and-fork)
11. [How Linux allocates physical pages](#11-how-linux-allocates-physical-pages)
12. [Reclaim, swapping, and memory pressure](#12-reclaim-swapping-and-memory-pressure)
13. [Huge pages and transparent huge pages](#13-huge-pages-and-transparent-huge-pages)
14. [Permissions, guard pages, and security](#14-permissions-guard-pages-and-security)
15. [NUMA, migration, locking, and pinning](#15-numa-migration-locking-and-pinning)
16. [How pages relate to C++ objects and allocators](#16-how-pages-relate-to-c-objects-and-allocators)
17. [Observing pages and memory accounting](#17-observing-pages-and-memory-accounting)
18. [C++ experiment: page geometry](#18-c-experiment-page-geometry)
19. [C++ experiment: first access and page faults](#19-c-experiment-first-access-and-page-faults)
20. [C++ experiment: private and shared pages after fork](#20-c-experiment-private-and-shared-pages-after-fork)
21. [C++ experiment: protected pages](#21-c-experiment-protected-pages)
22. [Performance decisions and common mistakes](#22-performance-decisions-and-common-mistakes)
23. [Forty interview questions with answers](#23-forty-interview-questions-with-answers)
24. [Exercises and worked answers](#24-exercises-and-worked-answers)
25. [Revision checklist and primary references](#25-revision-checklist-and-primary-references)

## 1. What a memory page actually is

A **memory page** is a fixed-size unit used in virtual-memory management.
The operating system and processor use page-sized regions to associate virtual
addresses with physical storage and enforce access permissions.

For an ordinary page size of 4096 bytes, consecutive virtual pages cover:

```text
page 0: addresses     0 through  4095
page 1: addresses  4096 through  8191
page 2: addresses  8192 through 12287
...
```

These are arithmetic ranges, not a claim that the low addresses are accessible
to a real program. Many ranges in an actual process are deliberately unmapped.

A page is not one C++ object, one allocation, or one array. A page can contain
many small objects. A large object can span many pages. The memory manager
normally does not know where the C++ object boundaries are.

Why use pages? Fixed-size units simplify translation, protection, sharing,
allocation, and movement between backing stores. Without a manageable granularity,
tracking an independent mapping and permission set for every byte would require
unreasonable metadata and hardware work.

The page size is a tradeoff. Smaller pages give finer control and less wasted
memory for sparse use, but require more translations and bookkeeping. Larger
pages reduce some of that overhead while making allocation and selective use
less flexible.

## 2. The different units people call memory

### 2.1 A vocabulary table

| Term | Meaning | Who primarily uses it? |
|---|---|---|
| Byte | Basic addressable unit of ordinary application storage on these systems. | Programs and hardware. |
| C++ object | Typed storage with a language-defined lifetime. | Compiler and application. |
| Allocation | Storage returned by an allocator, such as one `malloc` call. | Application allocator. |
| Cache line | Hardware unit of data transfer and coherence in CPU caches. | Processor caches. |
| Virtual page | Page-sized interval in a virtual address space. | MMU and operating system. |
| Physical page frame | Page-sized region of physical memory that can back a virtual page. | Kernel memory allocator. |
| Page-table entry | Metadata describing a translation or another stage of translation. | MMU and kernel. |
| VMA | Kernel description of a virtual interval and its policy/backing. | Linux virtual-memory subsystem. |
| Filesystem block | Filesystem allocation or addressing unit for file storage. | Filesystem. |
| Device sector | Logical or physical storage-device transfer/addressing unit. | Storage device and driver. |

These units sometimes have equal sizes by coincidence. Equal sizes do not make
them the same concept. A 4096-byte filesystem block and a 4096-byte virtual page
have different responsibilities.

### 2.2 CPU cache versus page cache

A **CPU cache** is hardware storage close to a processor core. It holds recently
used instructions or data, commonly in cache lines. A **core** is a processor
execution resource; an operating-system thread can move between cores.

The **page cache** is a kernel-managed cache of file contents in RAM. It is not
another level called L4 in the usual L1/L2/L3 CPU-cache hierarchy.

On an illustrative machine with 64-byte cache lines and 4096-byte pages, one
base page contains 64 cache lines. A page may be resident in RAM while none of
its contents are in a particular core's L1 cache.

### 2.3 The operating system and the application

The **kernel** is the privileged part of the operating system that manages
hardware and process isolation. **User space** is the execution environment for
ordinary applications. A **system call** requests kernel work, such as creating
a mapping with `mmap`.

A **process** owns an address space and other resources. Its **threads** normally
share that address space. Creating or protecting a mapping in one thread usually
affects the mapping available to every thread in that process.

A **virtual address space** is the set of addresses the process can potentially
use. A **mapping** associates part of it with backing storage and access rules.
**RAM** is the machine's main volatile memory: it normally loses data without power.

## 3. Page arithmetic and alignment

### 3.1 Split an address into a page number and an offset

Let P be the page size and A a nonnegative numeric address:

```text
virtual page number = A / P
offset within page  = A % P
page base address   = A - A % P
```

For `A = 0x12345` and `P = 4096 = 0x1000`:

```text
virtual page number = 0x12 = 18
offset              = 0x345 = 837
page base           = 0x12000
```

The numeric address in this calculation is an illustration. It is not a pointer
that a program is allowed to dereference.

### 3.2 Page alignment

An address is **page aligned** when its remainder modulo the page size is zero.
For power-of-two page sizes, masking can implement alignment arithmetic, but
division and remainder express the idea without hiding the assumption.

To round a byte count N upward to a page multiple, for nonnegative N:

```text
page_count   = N / P + (N % P != 0)
rounded_size = page_count * P
```

Check that the multiplication fits the integer type. The common expression
`(N + P - 1) / P` can overflow before division when N is close to the type limit.
Unsigned arithmetic wraps; signed overflow in C++ generally has undefined behavior.

### 3.3 A range can cover more pages than its length suggests

For a nonempty range starting at A with N bytes:

```text
offset = A % P
covered_pages = ceil((offset + N) / P)
```

Validate `offset + N` before adding. A zero-length range covers no pages in
this arithmetic model and should be handled separately.

With 4096-byte pages, eight bytes starting at offset 4092 span two pages.
Eight bytes beginning at offset zero span one. Thus `ceil(N/P)` is only enough
when the range starts on a page boundary.

### 3.4 Query instead of assuming

On Linux, `sysconf(_SC_PAGESIZE)` returns the ordinary system page size.
`getconf PAGESIZE` queries it from a shell. Check the result in code before
converting it to an unsigned size. See
[`sysconf(3)`](https://man7.org/linux/man-pages/man3/sysconf.3.html).

This is a **base page size** query. It does not report that every mapping uses
only that translation size; huge pages can coexist with base-page mappings.
KiB, MiB, and GiB mean powers of two: 2^10, 2^20, and 2^30 bytes, respectively.

## 4. Virtual pages and physical frames

### 4.1 Translation preserves the offset

The **MMU**, memory management unit, translates virtual addresses and checks
permissions. For an ordinary page translation, the offset within the page is
preserved while the page number is replaced with a physical frame number:

```text
Virtual address                    Physical address
+----------------+-----------+     +----------------+-----------+
| virtual page # | offset    | --> | physical frame | offset    |
+----------------+-----------+     +----------------+-----------+
```

If virtual page `0x12` maps to physical frame `0x9A`, then virtual address
`0x12345` maps to physical address `0x9A345` for 4096-byte pages.
The **PFN**, page frame number, is the frame's physical base address divided
by the relevant base page size.

### 4.2 Contiguous virtual addresses need not mean contiguous RAM

```text
Process virtual pages        Physical frames
       100 --------------------> 700
       101 -------------------->  25
       102 --------------------> 910
       103 -------------------->  26
```

To the application these pages form one continuous virtual range. Ordinary
pointer arithmetic can traverse it according to the language and allocation
contract. The frames backing it can be scattered throughout RAM.

This is why an ordinary large virtual allocation does not normally require
finding one equally large physically contiguous region. Explicit huge-page
allocations and some device requirements can change that situation.

### 4.3 Different addresses can share the same frame

Two processes can map one file page at different virtual addresses while
accessing the same physical cached data. One process can also have two virtual
aliases of the same physical storage.

Conversely, identical numeric virtual addresses in two processes normally say
nothing about whether the physical storage is shared. Address-space context
is part of translation.

Shared storage is not synchronization. Two threads or processes can still
need a locking or atomic protocol to coordinate access to the shared bytes.

### 4.4 Virtual addresses can stay stable while physical location changes

The kernel can reclaim, reload, copy, or migrate backing pages while preserving
the application's virtual addresses. A pointer is not a promise of a permanent
physical address. User-space code should not cache an inferred physical address
and assume that a later access reaches the same frame.

## 5. Page tables in detail

### 5.1 VMA versus page table

A Linux **virtual memory area**, VMA, describes an interval: its permitted
accesses, backing file or anonymous policy, and related properties. A page
table describes address translations and hardware-facing access information.

An address can be inside a valid readable VMA without currently having a
present translation. The kernel can use the VMA when a fault asks it to
materialize that translation.

One VMA can cover millions of pages. Changing protections on a subrange can
split a VMA. Compatible adjacent regions can be merged. Neither “one page per
VMA” nor “one mmap call always means one permanent VMA” is a correct model.

### 5.2 Why a hierarchy is needed

Imagine a flat page table for every possible 48-bit address using 4096-byte
pages and 8-byte entries:

```text
2^48 / 2^12 = 2^36 entries
2^36 * 8   = 2^39 bytes = 512 GiB
```

Allocating that flat table per process would be wasteful because most of the
possible address space is unused. A hierarchy allocates lower-level tables
only for needed portions of the range.

An absent entry near the top can represent a large unmapped region without
allocating all the corresponding lower tables.

### 5.3 A four-level x86-64 example

For ordinary 4 KiB pages in a conventional four-level x86-64 configuration,
the meaningful 48-bit virtual address is divided as follows:

```text
bits:      47..39     38..30     29..21     20..12       11..0
           +---------+---------+---------+---------+------------+
           | index 1 | index 2 | index 3 | index 4 | byte offset|
           +---------+---------+---------+---------+------------+
width:        9           9         9         9          12
```

Each 9-bit index selects one of 512 entries. A table with 512 entries of
8 bytes fits in a 4096-byte page. The first three entries normally identify
the next table; the final entry identifies the data frame and attributes.

The top-level table has a processor-visible root. On x86 the relevant control
register is CR3, with additional architecture-specific information. The kernel
selects the address-space context when scheduling a process.

This arithmetic describes the chosen configuration, not every 64-bit processor.
A 64-bit pointer does not imply that all 64 address bits are implemented.

### 5.4 Linux level names and folded levels

Linux expresses a generic hierarchy with levels named **PGD**, **P4D**, **PUD**,
**PMD**, and **PTE**. Architectures with fewer hardware levels can **fold** an
unused software level: it remains part of generic code structure without a
separate real table for that level.

The names expand to page global directory, page fourth-level directory, page
upper directory, page middle directory, and page-table entry. Here a directory
is a translation-structure level, not a filesystem directory.

In common x86 four-level terminology, hardware names include PML4, PDPT,
page directory, and page table. Do not assume a kernel's generic level names
always have a one-to-one correspondence with one architecture's names.
See the kernel's [page-table documentation](https://docs.kernel.org/mm/page_tables.html).

### 5.5 Canonical addresses and five-level paging

In the conventional x86 48-bit scheme, upper address bits must extend the
relevant sign bit; valid **canonical addresses** form low and high ranges.
The ordinary lower user-space range is therefore not “all 2^64 bytes.”

Five-level paging extends the supported virtual-address range on suitable
x86 hardware and kernels. Actual user allocation policy can still prefer
lower addresses for compatibility. Do not store arbitrary tags in supposedly
unused pointer bits without a platform contract. See
[Linux five-level paging](https://docs.kernel.org/arch/x86/x86_64/5level-paging.html).

### 5.6 What information can an entry carry?

Exact bit layouts are architecture-specific, but relevant concepts include:

| Information | Role |
|---|---|
| Present/valid state | Whether this translation can currently be used. |
| Frame or next-table address | Where translation continues or where data resides. |
| Read/write and privilege constraints | Which kinds of access are allowed. |
| Execute restriction | Whether the page can supply executable instructions. |
| Accessed information | Evidence that the mapping has been used. |
| Dirty information | Evidence of writes requiring appropriate handling. |
| Page size / leaf indication | Whether this level directly maps a larger region. |
| Memory attributes | How hardware should treat the mapped memory type. |

**Accessed** and **dirty** tracking can involve hardware and kernel cooperation.
Not every architecture uses the same bits or automatically updates them in
the same way. A non-present entry may encode useful software state, such as
swap-related information; non-present does not always mean “invalid forever.”

### 5.7 Page-table memory is real overhead

For a populated 1 GiB range using 4 KiB pages:

```text
1 GiB / 4 KiB = 262,144 leaf mappings
262,144 * 8 bytes = 2 MiB of leaf entries
```

Higher-level tables and other kernel metadata add to that. A huge mapping can
terminate at a higher level and avoid many leaf entries. An untouched reserved
range need not already contain all those populated tables.

Sparse access can be especially costly: touching one page in many widely
separated regions may allocate many mostly empty table pages. Translation
overhead depends on layout and population, not just the sum of useful bytes.

## 6. TLBs, page walks, and shootdowns

### 6.1 A TLB caches translations

A **TLB**, translation lookaside buffer, caches recent address translations
and relevant attributes. A TLB hit can avoid walking the page tables for the
access. CPUs can have multiple TLB levels and separate instruction/data structures.

A **page-table walk** follows the hierarchy to resolve a translation. On common
x86 systems hardware performs ordinary walks; other architectures can have
different mechanisms. Walk entries themselves may be cached, so a four-level
walk does not necessarily mean four slow uncached DRAM accesses.

```text
Memory operation
       |
       v
Translation cached in TLB? ---- yes ----> check/access using translation
       |
       no
       v
Walk page tables
       |
       +---- usable entry ----> populate translation cache, continue
       |
       +---- absent/disallowed -> page-fault handling
```

Translation and data-cache lookup can overlap in real processors. The diagram
is a conceptual dependency, not a claim about exact pipeline timing.

### 6.2 A TLB miss is not a page fault

A TLB miss can be satisfied entirely from a valid page table without entering
the kernel. A page fault occurs when the access cannot proceed normally under
the current translation/protection state and exception handling is needed.

Likewise, a CPU data-cache miss is not a page fault. The processor can fetch
the requested cache line from another cache or RAM while the virtual translation
remains perfectly valid.

### 6.3 TLB reach

**TLB reach** is the amount of address space represented by cached translations.
In a simplified example, 128 entries for 4 KiB pages cover 512 KiB. The same
entry count at 2 MiB per entry would cover 256 MiB.

Real hardware often has different entry counts and organizations for different
page sizes. The calculation demonstrates the benefit's direction, not a claim
that switching page size multiplies every machine's reach by exactly 512.

### 6.4 Context switches do not always flush every translation

A **context switch** changes the running thread or process context. Modern
architectures can tag translations by address-space identifiers, such as x86
**PCIDs**, process-context identifiers, or **ASIDs**, address-space identifiers,
on other architectures, allowing some translations to coexist.

Changing processes does not therefore universally erase the entire TLB.
Specific kernel policies, protection mechanisms, and architecture support affect
what is retained or invalidated.

### 6.5 TLB shootdowns

If a kernel changes mappings or permissions, processors must not continue using
stale translations. A **TLB shootdown** coordinates invalidation on CPUs that
may have relevant cached entries. It can involve an **IPI**, interprocessor
interrupt: one CPU notifying another.

Frequent `munmap` or `mprotect` calls in a multithreaded process can therefore
affect other cores and incur synchronization costs. See
[Linux x86 TLB documentation](https://docs.kernel.org/arch/x86/tlb.html).

A C++ acquire/release operation is not a TLB invalidation API. A memory-ordering
fence and a page-table maintenance operation solve different problems.

## 7. Page faults from start to finish

### 7.1 A fault is an exception, not automatically a bug

A **page fault** is a processor exception raised when an access needs handling
beyond its current usable translation. An **exception** here is a hardware
control transfer caused by the instruction; it is not a C++ `throw`.

Normal demand paging depends on recoverable faults. **Demand paging** supplies
backing and translations when accesses require them rather than preparing every
possible page eagerly.

### 7.2 A typical valid fault

1. A thread loads or stores through a virtual address.
2. Hardware determines that the access cannot proceed normally and enters
   the kernel's fault handler.
3. The kernel finds the relevant region and checks access policy.
4. It obtains appropriate backing: an existing cached page, a zero page,
   newly allocated memory, data read from backing storage, or a private copy.
5. It updates the mapping/translation structures with the necessary synchronization.
6. The interrupted operation resumes and can complete.

The kernel may wait for storage or other work, letting a different thread run.
The caller sees an ordinary load or store, but it can have very non-ordinary latency.

### 7.3 Minor versus major faults

A **minor fault** is resolved without the I/O that characterizes a major fault.
Examples include installing a translation for a cached file page or handling
many first-write/COW cases. A **major fault** requires fetching backing data
through I/O according to the OS's accounting.

A minor fault is not free: allocation, zeroing, copying, page-table work, and
contention can still cost time. A major-fault count is not the count of individual
storage requests or every possible blocking event. See
[`getrusage(2)`](https://man7.org/linux/man-pages/man2/getrusage.2.html).

### 7.4 Protection faults can be recoverable

A writable VMA can initially have a read-only hardware translation to implement
copy-on-write. A write then faults, and the kernel installs a writable private
page if policy permits. Thus “hardware says write-protected” does not always
mean “the application has no right to write this virtual region.”

If the VMA itself forbids writing, the kernel normally cannot resolve the
operation as a legitimate COW write.

### 7.5 Unresolvable faults and signals

Typical outcomes include:

- `SIGSEGV` for an unmapped address or an access violating permissions.
- `SIGBUS` when an address is in a mapping but its backing cannot satisfy the
  access, such as a file page entirely beyond the new end after truncation.

A **signal** is a process/thread notification mechanism. These signals usually
terminate the process by default. Ordinary C++ `try`/`catch` is not a portable
way to catch them and continue.

Fault counts are not one-to-one with base pages. Readahead, larger pages, and
**fault-around**, installing nearby cached translations, can change the relationship.

## 8. Anonymous memory, zero pages, and overcommit

### 8.1 Anonymous means no ordinary file identity

**Anonymous memory** is storage without a regular file supplying its persistent
byte contents. It backs many heap allocations, thread stacks, and explicit
anonymous mmap regions. Private modifications of file mappings can also become
anonymous COW data.

An ordinary anonymous mapping starts logically zero-filled. That does not
require immediately allocating and writing a distinct physical frame for every
virtual page in a large range.

### 8.2 Reading zeros can be cheaper than materializing writable pages

For some anonymous read faults, the kernel can map a shared read-only **zero
page**. Many virtual pages can then provide zero bytes through the same underlying
all-zero physical storage.

On a later write, each affected private page needs suitable private writable
backing. That can trigger allocation and a protection/COW fault. The exact path
depends on architecture, page size, policy, and kernel implementation.

Therefore, reading one byte per page is not necessarily sufficient preparation
for a later latency-sensitive write to every page.

### 8.3 Reservation, commitment, and residency differ

| Concept | Question it answers |
|---|---|
| Virtual address reservation | Is this address range available to this mapping? |
| Commit accounting | What potential backing obligations has the OS accepted? |
| Residency | Which backing pages are currently in RAM? |
| Translation population | Which needed page-table mappings have been established? |
| CPU-cache/TLB warmth | Which data and translations are currently cached by a processor? |

Successful mmap or malloc does not imply all five are complete. Even a resident
range can have cold CPU caches and evicted TLB entries.

### 8.4 Overcommit and delayed failure

**Overcommit** permits accepted memory commitments to exceed what could all be
backed immediately. Linux has configurable accounting policies, including a
stricter mode limiting aggregate commitments. `MAP_NORESERVE` is not a guarantee
of future success and is ignored in strict overcommit mode.

Under pressure, an access needing a new physical page can stall in reclaim,
fail through the applicable mechanism, or trigger an **OOM**, out-of-memory,
response. The **OOM killer** can terminate a process so the system or constrained
group can recover memory.

Even strict global accounting does not remove every hardware, cgroup, or
application-level failure possibility. See
[Linux overcommit accounting](https://docs.kernel.org/mm/overcommit-accounting.html).

## 9. File pages, page cache, and writeback

### 9.1 Two interfaces can reach the same cached file data

For ordinary buffered files, `read` and file-backed mmap commonly use the same
kernel page cache. `read` copies bytes into an application buffer. mmap allows
the application to access the cached backing through virtual addresses.

```text
File on storage <---- read/writeback ----> cached file data in RAM
                                                |
                          +---------------------+--------------------+
                          |                                          |
                   copied by read()                           mapped by mmap()
                          |                                          |
                   application buffer                      application addresses
```

The avoided copy is why file mapping is often described as “zero-copy.” Data
still moves between storage, RAM, and processor caches, and private modifications
can create copies. mmap does not make I/O disappear.

### 9.2 Clean and dirty pages

A **clean file page** agrees with reconstructible backing contents. It can
often be discarded and loaded again if needed. A **dirty file page** contains
modifications requiring writeback before its physical storage can be safely
reused while preserving those changes.

**Writeback** transfers modified file data toward storage. It may occur in
the background before the application calls a flush interface. Dirty data is
not necessarily safely persistent merely because it exists in RAM or a CPU cache.

`msync` and `fsync` concern synchronization with backing storage under their
contracts. They do not replace C++ locks or atomic publication. Durability and
crash consistency are covered in the mmap guide.

### 9.3 Readahead and page-cache residency

**Readahead** fetches file data that the kernel predicts will be needed soon.
One fault can cause neighboring data to be fetched, while later accesses may
still need minor faults to install translations in this process.

Another process can warm a file's page cache without establishing any translations
in your process. A warm file cache and a warm mapping are different benchmark states.

### 9.4 The final partial page of a file

If a file has 5000 bytes and pages are 4096 bytes, its data occupies one complete
page and 904 bytes of the next. The unused tail of the last partial page is
not application-owned file data. Writing there does not extend the file.

Mapping pages entirely beyond EOF, the end of file, and touching them can
produce `SIGBUS`. Truncation can create this problem after mmap succeeds.
Page rounding does not replace logical file bounds checks. See the detailed
EOF rules and Linux caveats in
[`mmap(2)`](https://man7.org/linux/man-pages/man2/mmap.2.html).

## 10. Copy-on-write and fork

### 10.1 Copy only when a private writer needs it

**Copy-on-write**, COW, allows storage to be shared until a write requires a
private version. A private file mapping can initially read file-cache data,
then obtain anonymous private backing for pages it changes.

```text
Before private write:
Process A virtual page ----+
                          +---- shared original data
Process B virtual page ----+

After A changes its copy:
Process A virtual page -------- private modified data
Process B virtual page -------- original data
```

One byte changed can cause a page-scale allocation/copy. Huge-page splitting,
exclusive ownership, and implementation decisions affect the actual amount of
work; not every COW fault must copy the same fixed size.

### 10.2 What fork initially shares

`fork()` creates a child process with a related address-space layout. Linux
uses COW for ordinary private memory so it does not eagerly duplicate every
payload page. Page-table and other metadata work still exists, and fork is
not free for very large populated address spaces.

Parent and child can have the same pointer value but later access different
physical frames after private writes. Shared mappings remain shared under their
normal contract. See [`fork(2)`](https://man7.org/linux/man-pages/man2/fork.2.html).

### 10.3 The memory cost can arrive later

A child that dirties many inherited pages can allocate substantial new physical
memory even when the original fork was inexpensive. This matters for servers
that fork a background snapshot or persistence process while the parent keeps
mutating data.

Not every increase in memory after fork is a conventional leak. Some is the
expected materialization of private copies. Sum-of-RSS accounting can also
overstate the initial physical cost of shared pages.

### 10.4 Private mapping does not mean snapshot of a changing file

`MAP_PRIVATE` describes how this mapping's writes propagate; it does not
guarantee that external changes to the original file are hidden as a coherent
snapshot. Use immutable versions or a suitable snapshot protocol for that requirement.

## 11. How Linux allocates physical pages

### 11.1 Nodes, zones, and free lists

Linux organizes physical memory according to hardware topology and allocation
constraints. A **NUMA node** groups memory with related access costs. A **zone**
represents memory with relevant addressing/usage restrictions within that organization.

Names such as `ZONE_DMA`, `ZONE_DMA32`, `ZONE_NORMAL`, and `ZONE_MOVABLE` appear
in kernel documentation. Their exact presence and boundaries depend on architecture
and configuration. Do not memorize one old 32-bit layout as a rule for all Linux.
See [Linux physical memory](https://docs.kernel.org/mm/physical_memory.html).

### 11.2 Buddy allocation

A **buddy allocator** manages free physical blocks in power-of-two numbers of
base pages. An **order-k allocation** requests 2^k physically contiguous base
pages under the allocator's rules.

For 4 KiB base pages:

```text
order 0:  1 page  =   4 KiB
order 1:  2 pages =   8 KiB
order 9: 512 pages = 2 MiB
```

An appropriately aligned free block can be split to satisfy a smaller request.
Compatible free buddy blocks can be coalesced into a larger block. Per-CPU
page caches and other mechanisms reduce common allocation overhead; this is
not a claim every user-space access directly searches one global free list.

### 11.3 Physical fragmentation

**External fragmentation** means free memory exists but is split into pieces
unsuitable for a requested contiguous allocation. Plenty of free base pages
does not guarantee a large physically contiguous block is available.

**Compaction** rearranges movable physical pages to create larger free ranges.
**Reclaim** frees memory by discarding or moving out backing that can be recovered.
Compaction and reclaim have different objectives, though an allocation path
can involve both.

**Internal fragmentation** is space wasted within allocated units, such as
using a large page for a tiny actively used portion of a region.

### 11.4 struct page, compound pages, and folios

`struct page` is a Linux kernel metadata structure used to describe physical
page-related state. It is not the page's application payload. Kernel metadata
itself consumes memory.

A **compound page** groups multiple base pages into a larger managed allocation,
with head/tail conventions in kernel bookkeeping. A **folio** is a kernel
abstraction for a power-of-two, physically contiguous group of base pages managed
as a unit; it can also consist of just one base page.

Large folios can improve file-cache or memory-management batching without
necessarily becoming one hardware huge-page translation. The allocation,
management, and translation granularities must be distinguished. Consult the
kernel's [memory-management APIs](https://docs.kernel.org/core-api/mm-api.html)
when reading implementation-specific folio code.

### 11.5 Application allocators are another layer

The kernel's page allocator serves physical-memory needs. A user-space allocator
such as malloc normally obtains larger regions and subdivides them into object
allocations. The kernel also has allocators for its own smaller objects.

“Allocation” can therefore refer to several layers. When discussing cost, identify
whether it is a small object allocation, a new virtual mapping, a base-page fault,
or a physically contiguous higher-order allocation.

## 12. Reclaim, swapping, and memory pressure

### 12.1 What can be evicted?

| Backing type | Typical reclaim strategy |
|---|---|
| Clean regular-file page | Discard cached contents and reload from the file later. |
| Dirty shared file page | Write back as required, then reclaim when eligible. |
| Private anonymous modified page | Preserve contents through swap or another applicable backing mechanism. |
| Discardable anonymous data | Discard under an explicit permitted policy, such as suitable advice. |
| Locked/pinned/ineligible memory | Not ordinarily reclaimable in the same way; depends on the constraint. |

**Swap** is backing used for memory such as anonymous pages that cannot simply
be reconstructed from an unchanged ordinary file. Swapping a private modified
file page does not mean writing its private contents back into the original file.

Swap need not mean a traditional disk partition in every configuration; compressed
memory mechanisms can participate in the backing path. The essential question
is how the page's contents remain recoverable when the current frame is reused.

### 12.2 Reclaim can run in the allocation path

**Background reclaim** attempts to keep memory available before an allocation
is in urgent need. **Direct reclaim** makes an allocating thread participate
in reclaim work or wait for it, which can create latency spikes.

**Writeback throttling** can slow writers when dirty data accumulates faster
than storage can accept it. A successful ordinary store instruction in a mapped
workload does not imply the whole workload avoids kernel-induced stalls.

### 12.3 The working set and thrashing

A **working set** is the memory actively needed during a relevant interval.
If active demand substantially exceeds available memory, the program can keep
evicting pages that it soon needs again. **Thrashing** is the resulting excessive
reclaim/reload activity with little useful progress.

A large virtual mapping is not inherently thrashing: only a small fraction
may be touched. Conversely, scattered accesses across a large working set can
perform poorly even if the code handles one record at a time.

### 12.4 Which page does Linux evict?

Reclaim policies use access history and other information to estimate usefulness.
**LRU**, least recently used, is the general idea of preferring less-recently-used
data for eviction. Real implementations approximate and refine it rather than
maintain an exact timestamp-ordered list of every load.

Linux can use **multi-generation LRU**, grouping pages into age-related generations
with additional policy. Availability and configuration matter. Do not promise
that “the oldest page is always evicted next.” See
[multi-generation LRU documentation](https://docs.kernel.org/mm/multigen_lru.html).

### 12.5 Containers and cgroups

A **cgroup**, control group, accounts for and controls resources used by a group
of processes. A process can encounter memory reclaim, throttling, or OOM within
its cgroup even if the machine has unused memory elsewhere.

Under cgroup v2, `memory.current`, `memory.high`, `memory.max`, and `memory.events`
help describe usage, thresholds, limits, and related events. Interpret them
under the deployed policy, rather than equating one number with process RSS.
See [cgroup v2 memory controls](https://docs.kernel.org/admin-guide/cgroup-v2.html).

## 13. Huge pages and transparent huge pages

### 13.1 Why larger translations help

A **huge page** uses a larger mapping granularity than the ordinary base page.
On a familiar x86 configuration, 2 MiB and 1 GiB translations coexist with
4 KiB translations when supported and used appropriately.

A 2 MiB mapping covers 512 times as many bytes as a 4 KiB mapping. A higher-level
page-table entry can directly map that range, avoiding the descent into a leaf
table for each of its constituent base pages.

Benefits can include fewer translations, fewer populated table pages, and fewer
fault-handling events. They are potential benefits, not universal speedups.

### 13.2 HugeTLB: explicit management

**HugeTLB** is Linux's explicit huge-page facility. Applications can use mechanisms
such as hugetlbfs and `MAP_HUGETLB`, subject to configured page availability,
permissions, and alignment requirements.

**hugetlbfs** is a filesystem interface for huge-page-backed objects; its name
does not imply ordinary durable file storage. HugeTLB pages have accounting and
reclaim characteristics different from normal pageable memory. Under the ordinary
HugeTLB model they are not swapped like normal anonymous pages.

An explicit huge-page mapping can fail when its required pool or allocation
conditions cannot be satisfied; it is not automatically a transparent fallback
to base pages. See [HugeTLB documentation](https://docs.kernel.org/admin-guide/mm/hugetlbpage.html).

### 13.3 Transparent huge pages

**THP**, transparent huge pages, allows the kernel to choose larger pages for
eligible ranges according to policy. `MADV_HUGEPAGE` can express a preference;
it does not prove the range currently has huge-page translations.

**Collapse** combines suitable smaller backing into a larger managed page/mapping.
**Split** divides larger units when finer-grained management is needed. Their
costs and eligibility depend on what is being split or collapsed.

Modern THP support can include **multi-size THP**, or mTHP. Some larger anonymous
allocations remain mapped through multiple base-page PTEs rather than one PMD
translation. Reducing fault/allocation work does not always reduce translation
entry count in the same way. See
[THP documentation](https://docs.kernel.org/admin-guide/mm/transhuge.html).

### 13.4 Tradeoffs to explain in an interview

Large pages can waste memory when only a small part is useful. Preparing a large
contiguous allocation can trigger compaction or larger zeroing work. Fine-grained
protection or reclamation can require splitting. NUMA placement can become
coarser. Performance can improve in throughput while developing worse tail latency.

**Tail latency** describes the slow end of the operation-time distribution,
such as the 99th percentile. A low average does not show that a latency-sensitive
thread avoids rare expensive page-management events.

## 14. Permissions, guard pages, and security

### 14.1 Permissions apply to mapped regions at page granularity

`PROT_READ`, `PROT_WRITE`, `PROT_EXEC`, and `PROT_NONE` describe access rights
for mappings. `mprotect` changes protections for a page-aligned range according
to platform rules. You cannot independently protect two adjacent small C++
objects sharing one page using ordinary page protection.

Changing permissions does not run C++ constructors/destructors or establish a
thread synchronization protocol for accesses to an object. Threads sharing the
address space must coordinate before one invalidates another's access.
See [`mprotect(2)`](https://man7.org/linux/man-pages/man2/mprotect.2.html).

### 14.2 Guard pages

A **guard page** is an inaccessible page placed beside a usable range. An access
entering it faults, helping detect some overflows or stack growth beyond a limit.

```text
inaccessible page | accessible data pages | inaccessible page
```

It does not catch an overrun that remains within an accessible page. An operation
that jumps past the guard into another accessible region can also evade it.
Bounds checks and valid C++ object accesses remain necessary.

### 14.3 Non-executable data and writable code

**NX**, no-execute, is a name commonly used for an execute restriction. A policy
such as **W^X**, writable XOR executable, avoids having memory writable and
executable at the same time where appropriate.

Code generation can require carefully changing permissions and performing
architecture-specific instruction-cache maintenance. Making data executable is
not part of ordinary allocation or mmap file parsing.

### 14.4 Isolation and zeroing

User/kernel permission distinctions and separate process translation contexts
help isolate memory. Zero-filled anonymous mappings prevent applications from
receiving arbitrary previous contents through fresh ordinary anonymous allocation.

Page protection is not the same as cryptographic confidentiality, and freeing
an object is not automatically a secure erasure guarantee for every physical
or backing copy. Match any stronger security requirement to the relevant APIs
and threat model.

## 15. NUMA, migration, locking, and pinning

### 15.1 NUMA and first-touch placement

**NUMA**, non-uniform memory access, means access cost varies with where a CPU
and memory reside in the machine topology. “Local” memory can be cheaper for
a core than memory attached to a different node.

For new anonymous pages, the thread that first materializes backing can influence
placement under the selected memory policy. This is often called **first touch**.
It is not a universal rule overriding all NUMA policies, and read-touching a zero
page does not necessarily allocate the private data locally.

If one setup thread initializes every page and workers on other nodes later use
them, placement may be poor. File-cache pages can already reside on a node before
the current process maps them. See
[NUMA memory policy](https://docs.kernel.org/admin-guide/mm/numa_memory_policy.html).

### 15.2 Page migration

**Migration** moves physical backing while keeping the process's virtual address
stable. It can support NUMA balancing, compaction, or other memory-management
requirements. Moving backing requires maintaining correct contents and translations;
it is not simply changing an integer without synchronization.
See [page migration](https://docs.kernel.org/mm/page_migration.html).

### 15.3 Prefaulting versus locking

**Prefaulting** prepares pages/translations before a critical phase. Linux
`MAP_POPULATE`, explicit touching, and some madvise operations can help, with
different guarantees and error behavior.

**Memory locking**, such as a successful `mlock`, prevents covered resident memory
from being paged out under the interface's contract. It is subject to limits
and permissions. `mlock2` with on-fault behavior defers some preparation.

Prefaulting alone does not prevent later reclaim. Locking does not ensure every
cache/TLB access is a hit, protect against truncation, or guarantee that future
fork/COW writes require no allocation. See
[`mlock(2)`](https://man7.org/linux/man-pages/man2/mlock.2.html).

### 15.4 Pinning for devices

**DMA**, direct memory access, lets a device transfer data without the CPU
copying each byte. Device access can require stable backing and a separate
device-address translation/mapping protocol.

**Pinning** holds pages under specific kernel/driver constraints needed for
such uses. It is not equivalent to ordinary mlock. Locking against paging does
not promise a fixed physical address suitable for a device. An **IOMMU** is
hardware that can translate and restrict device memory accesses, distinct from
the CPU's ordinary virtual-address translation.

Long-lived pins can hinder migration, compaction, and reclaim. See the kernel's
[page-pinning documentation](https://docs.kernel.org/core-api/pin_user_pages.html).

## 16. How pages relate to C++ objects and allocators

### 16.1 malloc and new normally allocate objects within larger regions

Many small allocations can share a page. Freeing one does not make the page
entirely unused. The allocator may keep freed memory for reuse instead of
returning it to the kernel immediately.

Large allocations may use separate mappings, depending on the allocator.
Do not treat one allocator's threshold as a universal C++ or Linux rule.
`new` additionally handles object construction; page mapping supplies storage,
not arbitrary C++ object semantics.

### 16.2 Object alignment is not page alignment

`alignof(T)` specifies the alignment needed by a type. An allocator must meet
the appropriate object-alignment contract. Page alignment is a different,
usually larger constraint.

A page-aligned base does not make every byte offset suitably aligned for T.
Likewise, `alignas(64)` does not guarantee a distinct page or a physical-address
layout. Cache-line separation and page separation solve different problems.

### 16.3 What happens when an object crosses a page boundary?

An ordinary array or object can span pages. Its virtual storage can remain
continuous while physical frames differ. Accessing it may require translations
and data from multiple pages.

A wide or vectorized load crossing a boundary can fault if one part is not
accessible. A C++ out-of-bounds access does not become valid because the next
page happens to be mapped. Conversely, a valid in-bounds access can still fault
temporarily due to demand paging.

### 16.4 Page sharing is not false sharing, though they can coexist

Two objects on one page can occupy separate cache lines and avoid cache-line
false sharing. Two threads writing separate bytes on one cache line can cause
false sharing without a data race if they are distinct language memory locations.

Putting one object per page is usually an expensive way to solve a cache-line
layout problem. It increases virtual space and potentially page-table, resident,
and TLB costs.

### 16.5 Returning unused pages

An allocator with suitable ownership knowledge can release mappings or advise
that some pages are no longer needed. Linux `MADV_DONTNEED` on suitable private
anonymous memory discards contents so later accesses can receive zeros;
`MADV_FREE` has different lazy-discard semantics.

These are not universally interchangeable hints. Do not apply them to live
objects whose contents must be preserved, or to pages partly occupied by other
live allocations. See [`madvise(2)`](https://man7.org/linux/man-pages/man2/madvise.2.html).

### 16.6 Stacks and page probing

A **stack** holds function-call state and many automatic objects. Its virtual
range can be reserved more broadly than its current resident backing. Stack
growth and guard handling depend on the operating system and thread runtime;
not every stack is an automatically growing mmap region.

A large stack allocation can cross several pages. **Stack probing** touches
intermediate pages according to a compiler/runtime strategy so growth and guard
mechanisms are encountered instead of jumping over them. A page-size-aware
protection mechanism does not mean allocating an arbitrarily large local array
is safe for the thread's stack limit.

### 16.7 Page boundaries do not define C++ atomicity

Being aligned to a page or contained inside one page does not make ordinary
C++ concurrent writes atomic. Conversely, a valid atomic operation obtains its
guarantees from the language/library contract and supported implementation,
not from a rule that every operation on a page is indivisible.

Wide accesses crossing boundaries can have additional hardware costs, but
page-level access permissions never replace synchronization or object-lifetime
rules. This distinction connects the present guide to the memory-ordering guide.

## 17. Observing pages and memory accounting

### 17.1 VSZ, RSS, PSS, and swap

| Metric | Interpretation |
|---|---|
| VSZ / virtual size | Virtual address space associated with mappings; not the amount of physical RAM exclusively owned. |
| RSS / resident set size | Resident pages attributed to the process, including shared pages. |
| PSS / proportional set size | Shared residency divided among processes sharing the relevant pages. |
| Private dirty | Modified private resident memory under the accounting rules. |
| Shared clean/dirty | Resident shared memory classified by modification state. |
| Swap | Backing accounted as swapped out under the reporting interface. |
| Page-table memory | Kernel memory used for translation structures; not application payload. |

Summing RSS across processes can count shared physical data multiple times.
PSS is useful for proportional attribution, but it still is not a complete
account of every kernel overhead or system-wide memory commitment.

### 17.2 Useful read-only commands

Substitute an actual numeric process ID for PID:

```sh
getconf PAGESIZE
cat /proc/PID/maps
cat /proc/PID/smaps
cat /proc/PID/smaps_rollup
cat /proc/PID/status
cat /proc/meminfo
cat /proc/buddyinfo
pmap -x PID
```

`/proc` exposes kernel/process information through a virtual filesystem.
`maps` shows intervals and permissions. `smaps` gives detailed per-mapping
accounting; `smaps_rollup` provides aggregate information. `buddyinfo` reports
free blocks by allocation order and zone, useful when investigating fragmentation.

`KernelPageSize`, `MMUPageSize`, `AnonHugePages`, and related fields need to be
interpreted together rather than assuming one label describes every kind of
large backing. See [`proc_pid_smaps(5)`](https://man7.org/linux/man-pages/man5/proc_pid_smaps.5.html).

### 17.3 Residency and physical-address inspection

`mincore` reports residency information for a mapped range, subject to its
platform behavior and permission restrictions. The result is a snapshot: a
page can be reclaimed afterward. It does not prove that the calling process
has a warm TLB or will avoid every kind of fault. See
[`mincore(2)`](https://man7.org/linux/man-pages/man2/mincore.2.html).

Linux `pagemap` exposes page-related information, but physical-frame information
is restricted for security reasons. It is not a universal unprivileged
virtual-to-physical address service. Even when visible, a PFN observation is
not a pin or guarantee against migration. See
[pagemap documentation](https://docs.kernel.org/admin-guide/mm/pagemap.html).

### 17.4 Fault and translation measurements

```sh
perf stat -e page-faults,minor-faults,major-faults ./your_program
```

Performance-event support and permissions vary. Hardware TLB/page-walk counters
have model-specific definitions and names. Do not reuse a raw event number from
a different processor and assume it means the same thing.

`getrusage` can provide fault counts inside a program. Many memory-accounting
values are snapshots or approximate aggregates, so avoid demanding exact
equality between every reported field and a toy model.

## 18. C++ experiment: page geometry

This complete program queries the base page size and checks arithmetic for
page coverage. It performs numeric address decomposition without dereferencing
the illustrative address.

Save as `page_geometry.cpp`:

```cpp
#include <unistd.h>
#include <cassert>
#include <cstddef>
#include <cstdint>
#include <iostream>
#include <limits>
#include <stdexcept>

std::size_t covering_pages(std::size_t offset, std::size_t length,
                           std::size_t page_size) {
    if (page_size == 0 || offset >= page_size)
        throw std::invalid_argument("invalid page size or offset");
    if (length == 0) return 0;
    if (length > std::numeric_limits<std::size_t>::max() - offset)
        throw std::overflow_error("range coverage overflow");
    const auto covered_bytes = offset + length;
    return covered_bytes / page_size + (covered_bytes % page_size != 0);
}

int main() {
    try {
        const long queried = ::sysconf(_SC_PAGESIZE);
        if (queried <= 0) throw std::runtime_error("page size query failed");
        const auto page = static_cast<std::size_t>(queried);
        constexpr std::uintptr_t address = 0x12345;
        const auto offset = static_cast<std::size_t>(address % page);
        const auto base = address - offset;

        assert(covering_pages(0, 0, page) == 0);
        assert(covering_pages(0, page, page) == 1);
        assert(covering_pages(page - 1, 2, page) == 2);
        bool rejected = false;
        try {
            (void)covering_pages(1, std::numeric_limits<std::size_t>::max(), page);
        } catch (const std::overflow_error&) {
            rejected = true;
        }
        assert(rejected);

        std::cout << "page bytes=" << page
                  << " address=" << address
                  << " base=" << base
                  << " offset=" << offset
                  << " pages covering 9000 bytes="
                  << covering_pages(offset, 9000, page) << '\n';
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n';
        return 1;
    }
}
```

Build each complete program in this document separately with the analogous command:

```sh
g++ -std=c++20 -O2 -Wall -Wextra -Wpedantic page_geometry.cpp -o page_geometry
./page_geometry
```

For a 4096-byte base page, the illustrative address has offset 837, and a
9000-byte range starting there covers three pages. The helper returns a count;
a caller converting that count back into a rounded byte size must separately
check multiplication for overflow.

## 19. C++ experiment: first access and page faults

This complete Linux program maps anonymous storage and performs three passes:
read one byte per base page, write one byte per base page, and write again.
It prints minor/major fault differences rather than asserting a fixed number.

Save as `page_faults.cpp`:

```cpp
#include <sys/mman.h>
#include <sys/resource.h>
#include <unistd.h>
#include <cerrno>
#include <cstddef>
#include <cstdint>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <system_error>

class Mapping {
    void* base_;
    std::size_t size_;
public:
    explicit Mapping(std::size_t size)
        : base_(::mmap(nullptr, size, PROT_READ | PROT_WRITE,
                       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0)), size_(size) {
        if (base_ == MAP_FAILED)
            throw std::system_error(errno, std::generic_category(), "mmap");
    }
    Mapping(const Mapping&) = delete;
    Mapping& operator=(const Mapping&) = delete;
    ~Mapping() { (void)::munmap(base_, size_); }
    void* data() const noexcept { return base_; }
};

rusage usage() {
    rusage result{};
    if (::getrusage(RUSAGE_SELF, &result) == -1)
        throw std::system_error(errno, std::generic_category(), "getrusage");
    return result;
}

void report(const char* name, const rusage& before, const rusage& after) {
    std::cout << name << ": minor=" << after.ru_minflt - before.ru_minflt
              << " major=" << after.ru_majflt - before.ru_majflt << '\n';
}

int main() {
    try {
        const long queried = ::sysconf(_SC_PAGESIZE);
        if (queried <= 0) throw std::runtime_error("page size query failed");
        const auto page = static_cast<std::size_t>(queried);
        constexpr std::size_t pages = 2048;
        if (page > std::numeric_limits<std::size_t>::max() / pages)
            throw std::overflow_error("mapping size overflow");
        const auto bytes = page * pages;
        if (bytes > static_cast<std::size_t>(
                        std::numeric_limits<std::ptrdiff_t>::max()))
            throw std::length_error("mapping exceeds example pointer limit");
        Mapping mapping(bytes);
        if (::madvise(mapping.data(), bytes, MADV_NOHUGEPAGE) == -1)
            std::cerr << "MADV_NOHUGEPAGE unavailable; counts may reflect THP\n";

        // Volatile retains the deliberate accesses in this single-threaded probe.
        auto* data = static_cast<volatile unsigned char*>(mapping.data());
        std::uint64_t checksum = 0;
        const auto a = usage();
        for (std::size_t i = 0; i < pages; ++i) checksum += data[i * page];
        const auto b = usage();
        for (std::size_t i = 0; i < pages; ++i) data[i * page] = 1;
        const auto c = usage();
        for (std::size_t i = 0; i < pages; ++i) data[i * page] = 2;
        const auto d = usage();

        if (checksum != 0) throw std::runtime_error("fresh anonymous data was not zero");
        report("first read", a, b);
        report("first write", b, c);
        report("second write", c, d);
        std::cout << "mapped bytes=" << bytes << " initial checksum=" << checksum << '\n';
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n';
        return 1;
    }
}
```

The owner uses **RAII**, resource acquisition is initialization: construction
acquires a mapping and destruction releases it. Its teaching destructor ignores
munmap errors; production code can expose an explicit checked release operation
if such errors must be reported.

The `volatile` byte accesses make the compiler preserve this probe's deliberate
loads and stores under the implementation's volatile rules. They do not provide
thread synchronization and do not make a concurrent application protocol correct.

On a typical base-page run, the first read can create zero-page translations,
the first write can materialize private pages, and the second write often adds
few faults. Counts can vary because of kernel policy, other work in the process,
memory pressure, and page-size behavior. Do not turn that pattern into exact
portable counts or fixed latency claims.

The program uses 2048 base pages: 8 MiB when pages are 4 KiB. It does not
request memory locking, change system-wide settings, or need root privileges
under a normal Linux environment.

## 20. C++ experiment: private and shared pages after fork

This complete Linux program creates one private and one shared anonymous mapping,
then changes them in a child. The parent reads after waiting for the child to
exit, so this is a lifetime/COW experiment rather than a concurrent IPC protocol.

Save as `page_cow.cpp`:

```cpp
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#include <cerrno>
#include <cstddef>
#include <iostream>
#include <stdexcept>
#include <system_error>

class Mapping {
    void* base_;
    std::size_t size_;
public:
    Mapping(std::size_t size, int sharing)
        : base_(::mmap(nullptr, size, PROT_READ | PROT_WRITE,
                       sharing | MAP_ANONYMOUS, -1, 0)), size_(size) {
        if (base_ == MAP_FAILED)
            throw std::system_error(errno, std::generic_category(), "mmap");
    }
    Mapping(const Mapping&) = delete;
    Mapping& operator=(const Mapping&) = delete;
    ~Mapping() { (void)::munmap(base_, size_); }
    unsigned char* bytes() const noexcept {
        return static_cast<unsigned char*>(base_);
    }
};

int main() {
    try {
        const long queried = ::sysconf(_SC_PAGESIZE);
        if (queried <= 0) throw std::runtime_error("page size query failed");
        const auto page = static_cast<std::size_t>(queried);
        Mapping private_map(page, MAP_PRIVATE);
        Mapping shared_map(page, MAP_SHARED);
        private_map.bytes()[0] = 12;
        shared_map.bytes()[0] = 12;

        const pid_t child = ::fork();
        if (child == -1)
            throw std::system_error(errno, std::generic_category(), "fork");
        if (child == 0) {
            private_map.bytes()[0] = 99;
            shared_map.bytes()[0] = 99;
            ::_exit(0);
        }

        int status = 0;
        pid_t waited;
        do { waited = ::waitpid(child, &status, 0); }
        while (waited == -1 && errno == EINTR);
        if (waited == -1)
            throw std::system_error(errno, std::generic_category(), "waitpid");
        if (!WIFEXITED(status) || WEXITSTATUS(status) != 0)
            throw std::runtime_error("child did not exit successfully");
        if (private_map.bytes()[0] != 12 || shared_map.bytes()[0] != 99)
            throw std::runtime_error("unexpected mapping contents");

        std::cout << "parent private=" << static_cast<int>(private_map.bytes()[0])
                  << " shared=" << static_cast<int>(shared_map.bytes()[0]) << '\n';
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n';
        return 1;
    }
}
```

Expected values are private 12 and shared 99. The child changed its private
view while the shared backing retained the child's modification for the parent.
`_exit` ends the child without running normal C++/stdio shutdown and flushing
inherited user-space output buffers.

This example starts from a single-threaded process. Forking a multithreaded C++
process adds important post-fork restrictions: a child can inherit locks whose
owners do not exist in the child. Do not extrapolate this small example into
a general multithreaded fork recipe.

## 21. C++ experiment: protected pages

This complete program reserves three inaccessible pages, enables the middle
page for read/write, writes its endpoints, then makes it read-only and reads
the values back. It deliberately performs only valid accesses.

Save as `page_protection.cpp`:

```cpp
#include <sys/mman.h>
#include <unistd.h>
#include <cerrno>
#include <cstddef>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <system_error>

int main() {
    void* base = MAP_FAILED;
    std::size_t length = 0;
    try {
        const long queried = ::sysconf(_SC_PAGESIZE);
        if (queried <= 0) throw std::runtime_error("page size query failed");
        const auto page = static_cast<std::size_t>(queried);
        if (page > static_cast<std::size_t>(
                       std::numeric_limits<std::ptrdiff_t>::max()) / 3)
            throw std::overflow_error("mapping size too large");
        length = 3 * page;
        base = ::mmap(nullptr, length, PROT_NONE,
                      MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (base == MAP_FAILED)
            throw std::system_error(errno, std::generic_category(), "mmap");
        auto* middle = static_cast<unsigned char*>(base) + page;
        if (::mprotect(middle, page, PROT_READ | PROT_WRITE) == -1)
            throw std::system_error(errno, std::generic_category(), "mprotect RW");

        auto* observed = static_cast<volatile unsigned char*>(middle);
        observed[0] = 17;
        observed[page - 1] = 29;
        if (::mprotect(middle, page, PROT_READ) == -1)
            throw std::system_error(errno, std::generic_category(), "mprotect R");
        if (observed[0] != 17 || observed[page - 1] != 29)
            throw std::runtime_error("contents changed unexpectedly");

        if (::munmap(base, length) == -1)
            throw std::system_error(errno, std::generic_category(), "munmap");
        base = MAP_FAILED;
        std::cout << "middle-page contents preserved after protection change\n";
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n';
        if (base != MAP_FAILED) (void)::munmap(base, length);
        return 1;
    }
}
```

On ordinary Linux mappings, accessing the outer pages or writing the middle
page after its read-only transition would violate protection and normally
produce `SIGSEGV`. This program does not install a signal handler or intentionally
crash to test that behavior. It demonstrates the successful protection transitions
and data retention.

Changing protection does not erase the bytes. The two guard pages also do not
give the program permission to access outside any C++ object it constructs in
the middle page. Mapping permissions and language bounds are separate checks.

## 22. Performance decisions and common mistakes

### 22.1 Define what needs to be fast

**Throughput** is work per unit time. **Latency** is the duration of one operation.
A strategy that improves large sequential scans can worsen first-access or
tail latency. Define whether startup, prefaulting, file I/O, and cleanup are
inside the measured interval.

For a latency-sensitive phase, consider its actual working set, write versus
read access, NUMA placement, page population, and reclaim constraints. Pre-touching
unneeded gigabytes can increase startup time and memory pressure without helping.

### 22.2 Diagnose the right kind of miss

| Observation | Questions to investigate |
|---|---|
| Many major faults | Is backing data cold, swapped out, or repeatedly reclaimed? |
| Many minor faults | Is this first touch, COW, repeated remapping, or translation population? |
| Few faults but slow scattered reads | Are CPU-cache misses, TLB walks, NUMA distance, or dependency chains dominant? |
| Sudden stalls while allocating | Is reclaim, compaction, zeroing, or a memory limit involved? |
| High virtual size but low RSS | Is a large range reserved but sparsely materialized? |
| High summed RSS after fork | How much physical backing is shared, and how much COW occurred? |

Page counts alone do not diagnose all memory performance. A page can already
be resident while every access in a random traversal suffers a costly data-cache
miss or a translation walk.

### 22.3 Avoid these shortcuts

- “64-bit pointers mean an application can map 2^64 bytes.”
- “Every page is always 4096 bytes.”
- “mmap immediately reads and allocates every byte.”
- “A TLB miss means a disk read.”
- “A minor fault is free.”
- “Read-touching is enough to prepare private writes.”
- “mlock means a fixed physical address.”
- “Huge backing always means one huge hardware translation.”
- “free must reduce RSS immediately.”
- “A guard page replaces bounds checking.”
- “A memory fence flushes the TLB.”
- “Pages shared between processes make ordinary concurrent writes safe.”

Each shortcut confuses two layers that the earlier sections distinguish.

## 23. Forty interview questions with answers

### Basic concepts

**1. What is a memory page?**

A unit of virtual-memory management used for mapping, protection, and related
operations. Distinguish the virtual page, its physical backing frame, and the
metadata describing that relationship. None is necessarily one C++ allocation.

**2. What is the difference between a page and a page frame?**

A virtual page is an interval in a virtual address space. A physical frame is
a physical-memory region that can back it. Several virtual pages can share
one frame, and one virtual page can have different backing over time.

**3. How do you find the page size?**

Query `sysconf(_SC_PAGESIZE)` or use `getconf PAGESIZE` on Linux. This reports
the base page size, not every supported or currently used huge-page size.
Do not hard-code 4096 as a universal platform rule.

**4. Why do operating systems use fixed-size pages?**

They provide a practical granularity for translation, protection, sharing,
allocation, and reclaim. The fixed size simplifies management but introduces
tradeoffs in fragmentation and metadata cost.

**5. Is a cache line the same thing as a page?**

No. Cache lines are hardware data-cache/coherence units, often much smaller.
Pages are virtual-memory management units. Independent variables can share
a cache line or page in different ways, with different consequences.

**6. Are page size, filesystem block size, and sector size necessarily equal?**

No. They belong to different layers and can differ. Even when their sizes
match, they retain distinct roles. A file offset's mapping alignment is not
derived simply from the storage device's sector size.

### Translation and faults

**7. How is a virtual address translated?**

Conceptually, split it into a virtual page number and an offset. Translation
selects the backing frame and checks access attributes; the offset identifies
the byte within the translated region. A TLB may cache the needed information.

**8. Why are page tables hierarchical?**

So unused address regions do not require a complete flat table of leaf entries.
An absent higher-level branch can represent a large hole, and suitable large
translations can terminate at higher levels.

**9. What is the difference between a VMA and a PTE?**

A VMA describes policy and backing for a virtual interval. A PTE is translation
metadata at the relevant level. A valid VMA can cover many pages whose
translations have not yet been populated.

**10. Does a TLB miss enter the kernel?**

Not necessarily. On common hardware, a page-table walk can resolve it without
a fault. The kernel is needed when the access requires fault handling or
other architecture-specific intervention.

**11. Does a CPU-cache miss cause a page fault?**

Not by itself. Data can be fetched from another cache or RAM using an already
valid translation. Cache residency, translation residency, and backing residency
are distinct states.

**12. Is every page fault an application error?**

No. First-touch allocation, cached-file translation setup, and COW commonly
use recoverable faults. Only faults the system cannot validly satisfy lead
to error handling such as a terminating signal.

**13. What is the difference between minor and major faults?**

Minor faults are resolved without the backing-data I/O characteristic of major
faults. Both can require kernel work, and minor faults can still allocate,
copy, zero, or contend. Counts do not directly give a fixed latency.

**14. Why might a write fault on a region that is logically writable?**

Its current hardware translation can be read-only to implement COW or another
tracking mechanism. If the VMA permits the write, the kernel can resolve the
fault by establishing suitable writable backing.

**15. What causes a TLB shootdown?**

Mapping or permission changes can invalidate translations cached by multiple
CPUs. The kernel coordinates invalidation so stale entries are not used.
This is one reason frequent mapping changes can affect other threads.

### Allocation, sharing, and backing

**16. Does a contiguous vector require physically contiguous RAM?**

Normally no. Its elements occupy contiguous virtual storage under the container's
contract, but different pages can map to scattered physical frames. Physical
contiguity is a separate requirement for specialized uses.

**17. Can two processes use the same address for different data?**

Yes. Translation depends on the address-space context. Conversely, two different
addresses can map the same shared backing. Comparing pointer numbers across
processes does not establish sharing.

**18. Does mmap of a large anonymous range allocate all its RAM immediately?**

Usually not for normal lazy mapping. It establishes a virtual range and policy,
with physical pages and translations materialized as required. Population flags,
commit policy, and backing type can change the work done at setup.

**19. Why can reading anonymous memory and then writing it cause two fault passes?**

The initial reads may establish shared zero-page translations. The first private
writes then need actual writable backing. Read-prefaulting and write-prefaulting
are therefore not always equivalent.

**20. Is MAP_PRIVATE guaranteed to copy every page immediately?**

No. COW delays private backing until needed. Some private mappings initially
share file-cache or inherited pages, and implementation details can avoid
copying when exclusive backing already exists.

**21. What happens to memory after fork?**

Ordinary private pages can initially be shared under COW while the child gets
its own process context and necessary metadata. Subsequent private writes
can materialize separate frames. Shared mappings remain shared.

**22. Why can a process's RSS rise significantly after fork?**

Mutations can create private copies of previously shared pages. Accounting can
also count shared residency in both processes. Examine proportional/private
usage and the write pattern before diagnosing a leak.

**23. Does private file mapping mean a stable snapshot?**

No. It describes the treatment of the mapping's own writes. External file
mutation needs an immutable-version, locking, or snapshot design if readers
require consistent contents.

**24. What is a dirty page?**

A modified page whose contents require appropriate preservation or discard
policy before its physical storage is reused. Dirty shared file data can need
file writeback; private anonymous data has a different backing path.

### Reclaim and large pages

**25. Why can clean file pages be cheaper to reclaim than anonymous modified pages?**

They can be reconstructed from the unchanged file and may simply be discarded.
Anonymous modified data normally needs preserved backing such as swap unless
the application or kernel has a valid discard policy.

**26. Does swap mean the entire process is copied to disk at once?**

No. Paging operates on memory units and their backing, not necessarily a
whole-process transfer. The active resident set can change while the process
continues running.

**27. What is thrashing?**

Repeatedly evicting and reloading actively needed pages so memory-management
work dominates useful execution. It commonly occurs when the working set
does not fit the resources available under the actual memory limits.

**28. Why can a large allocation fail despite many free pages?**

It may require contiguous physical pages, a particular zone/node, commit
capacity, address space, or a resource allowance that is unavailable. “Free
RAM” is not one scalar guarantee satisfying every allocation requirement.

**29. How does compaction differ from reclaim?**

Compaction rearranges movable physical pages to create larger contiguous free
ranges. Reclaim frees eligible backing resources. A workload can need one,
both, or neither, and their latency costs differ.

**30. Why do huge pages help TLB performance?**

One translation can represent a larger region, increasing reach for the relevant
translation-cache resources and reducing some page-table work. Actual gains
depend on hardware organization, mapping type, and access pattern.

**31. Why can huge pages hurt?**

They can waste memory for sparse use, require more expensive preparation,
increase compaction/zeroing costs, and complicate fine-grained protection or
reclaim. Tail latency can worsen even when average throughput improves.

**32. Does a large folio always use a single huge-page translation?**

No. A larger kernel-managed backing unit can still use multiple PTE translations.
Keep allocation size, management size, and hardware translation size distinct,
especially when discussing multi-size THP.

### Practical C++ and diagnostics

**33. Why might free not reduce RSS?**

The allocator can retain the storage, and a page may still contain other live
allocations. A freed object is not the same as an entirely releasable page
or an unmapped region.

**34. What does mlock guarantee about caches?**

It is a residency facility, not a CPU-cache or TLB residency guarantee. Those
caches can miss while pages remain in RAM. It also does not automatically
pin backing for device access.

**35. Does pinning equal locking?**

No. Device/kernel pinning and ordinary memory locking have different purposes
and constraints. A device's DMA mapping needs the appropriate driver/platform
protocol, not merely a user-space call to mlock.

**36. What does first-touch NUMA placement mean?**

Under an applicable policy, the thread materializing new backing influences
its node placement. Existing file-cache backing, zero-page reads, explicit
policies, and later migration can make a simplistic “first read chooses RAM”
story wrong.

**37. Is PSS the same as RSS?**

No. RSS counts resident shared pages for each process; PSS proportionally
attributes sharing. Summed RSS can overstate distinct physical memory used
by several processes mapping common data.

**38. Does mincore prove the next access cannot fault?**

No. It reports a residency snapshot, not permanent residency or guaranteed
usable/warm translations for every future operation. Reclaim and later
write/COW behavior can still matter.

**39. Do guard pages catch every overflow?**

No. They catch accesses entering inaccessible page regions. Overruns staying
inside an accessible page or jumping past a guard can escape that mechanism.
Language bounds and lifetime rules still apply.

**40. What would you inspect for a sudden latency spike in an allocation-heavy program?**

Look at fault counts, COW activity, memory pressure and cgroup limits, reclaim,
compaction, NUMA placement, page-size policy, and allocator behavior. Then
separate those effects from CPU-cache/TLB misses and application synchronization.
Measure the specific workload rather than assuming every stall is disk paging.

## 24. Exercises and worked answers

### Exercise 1: translate a numeric address

Page size is 4096. Virtual address is `0x12345`, and virtual page `0x12` maps
to physical frame `0x9A`. What is the physical address?

**Answer:** offset `0x345` is preserved. Frame base is `0x9A000`, so the
physical address is `0x9A345`. This is arithmetic, not a claim that such an
address can be accessed directly by user space.

### Exercise 2: count covering pages

A 9000-byte range begins at offset 3000 within a 4096-byte page. How many
pages does it cover? Why is `ceil(9000/4096)` insufficient in general?

**Answer:** coverage is `3000 + 9000 = 12000` bytes from the aligned base,
so three pages. For this particular length, rounding the length alone also
gives three by coincidence. Change the length to 6000: length-only rounding
gives two, but `(3000 + 6000)` covers three pages. Include the starting offset.

### Exercise 3: estimate leaf table memory

Map and populate 8 GiB using 4 KiB pages and 8-byte leaf entries. Ignore
higher-level tables. What is the leaf-entry cost?

**Answer:** `8 * 2^30 / 2^12 = 2,097,152` entries. At 8 bytes each, that
is 16 MiB. Real memory cost also includes higher levels and other metadata.
A reserved but untouched mapping need not already pay the fully populated cost.

### Exercise 4: distinguish three misses

Explain what can happen for a CPU-cache miss with a TLB hit, a TLB miss with
a valid PTE, and an access requiring backing data that is not resident.

**Answer:** the first can fetch data from another cache or RAM with an available
translation. The second can complete a hardware page walk without entering
the kernel. The third can fault and require backing-data retrieval, potentially
sleeping the thread. They are different events and can overlap in a larger access path.

### Exercise 5: explain two first-touch passes

A program maps anonymous memory, reads one byte per page, then writes one
byte per page. Both passes report many minor faults. Is that inconsistent?

**Answer:** no. The reads can establish shared zero-page translations, while
the writes require private physical backing. The reads did not necessarily
materialize all future writable pages. Verify the actual page-size and kernel
policy before predicting exact counts.

### Exercise 6: diagnose memory after fork

Parent and child each report 1 GiB RSS immediately after fork. Later the child
modifies much of the inherited data. Did the initial RSS sum prove 2 GiB of
distinct physical payload existed from the start?

**Answer:** no. Initial residency can be shared and counted in both RSS values.
COW writes can increase distinct physical backing later. PSS and private/shared
accounting help distinguish sharing from materialized private copies.

### Exercise 7: choose between base and huge pages

One application scans a dense large array repeatedly. Another touches one
small record in each large sparse region. Would the same huge-page policy
necessarily benefit both?

**Answer:** no. The dense array can benefit from translation reach and fewer
table entries. Sparse use can waste backing and increase allocation costs.
Measure residency, translation misses, faults, and latency distribution, not
just elapsed time for one warm run.

### Exercise 8: explain a guard-page blind spot

A 100-byte object is allocated at the beginning of an accessible 4096-byte
page, with a guard page after that page. Will writing object byte 101 reliably
cause a page fault?

**Answer:** no. It is outside the object's bounds but remains in the accessible
page. It is invalid C++ even if the hardware accepts the address. Guard pages
enforce page permissions, not every language-level object boundary.

## 25. Revision checklist and primary references

### A concise interview explanation

> A page is the unit used to manage virtual-memory mappings and permissions.
> Virtual pages are translated to physical frames through page tables, with
> translations cached in the TLB. A TLB miss can be resolved by a page walk;
> a page fault invokes handling such as demand allocation, file I/O, or COW.
> Virtual contiguity does not imply physical contiguity, and a mapped range
> need not be fully resident. Page size affects translation overhead, memory
> waste, allocation, and latency. I distinguish base pages, huge translations,
> cached file data, and application allocations before diagnosing memory behavior.

### Questions to ask while reviewing a design

- What is the base page size, and what translation sizes are actually in use?
- Is the backing anonymous, file-backed, private, shared, or device-specific?
- Which accesses first materialize physical pages and translations?
- Will a later write require COW even after read-prefaulting?
- Is the active working set compatible with host and cgroup memory limits?
- Are placement, reclaim, compaction, or translation costs on the critical path?
- Does protection change while another thread can still access the region?
- Are logical file bounds and C++ object bounds enforced independently of pages?
- Does device access need pinning and a DMA protocol rather than merely locking?
- Which claims come from observed measurements, and which follow from an API contract?

### Primary documentation

- [Kernel memory-management concepts](https://docs.kernel.org/admin-guide/mm/concepts.html).
- [Page tables](https://docs.kernel.org/mm/page_tables.html) and
  [five-level x86 paging](https://docs.kernel.org/arch/x86/x86_64/5level-paging.html).
- [x86 TLB management](https://docs.kernel.org/arch/x86/tlb.html).
- [Physical memory organization](https://docs.kernel.org/mm/physical_memory.html)
  and [memory-management APIs](https://docs.kernel.org/core-api/mm-api.html).
- [Overcommit accounting](https://docs.kernel.org/mm/overcommit-accounting.html).
- [Multi-generation LRU](https://docs.kernel.org/mm/multigen_lru.html).
- [HugeTLB](https://docs.kernel.org/admin-guide/mm/hugetlbpage.html) and
  [transparent huge pages](https://docs.kernel.org/admin-guide/mm/transhuge.html).
- [NUMA memory policy](https://docs.kernel.org/admin-guide/mm/numa_memory_policy.html),
  [page migration](https://docs.kernel.org/mm/page_migration.html), and
  [page pinning](https://docs.kernel.org/core-api/pin_user_pages.html).
- [cgroup v2](https://docs.kernel.org/admin-guide/cgroup-v2.html).
- [mmap](https://man7.org/linux/man-pages/man2/mmap.2.html),
  [mprotect](https://man7.org/linux/man-pages/man2/mprotect.2.html),
  [madvise](https://man7.org/linux/man-pages/man2/madvise.2.html), and
  [mlock](https://man7.org/linux/man-pages/man2/mlock.2.html).
- [fork](https://man7.org/linux/man-pages/man2/fork.2.html) and
  [sysconf](https://man7.org/linux/man-pages/man3/sysconf.3.html).
- [smaps accounting](https://man7.org/linux/man-pages/man5/proc_pid_smaps.5.html),
  [mincore](https://man7.org/linux/man-pages/man2/mincore.2.html),
  [getrusage](https://man7.org/linux/man-pages/man2/getrusage.2.html), and
  [pagemap](https://docs.kernel.org/admin-guide/mm/pagemap.html).

### Related repository chapters

- [mmap: a complete practical guide](23-mmap-complete-guide.md).
- [Memory ordering and memory barriers](24-memory-order-and-barriers-complete-guide.md).
- [Memory and ownership](02-memory-and-ownership.md).
- [Allocators](16-allocators.md).
- [Linux for C++](17-linux-for-cpp.md).
- [File I/O methods](20-file-io-read-stdio-iostream-mmap.md).

### Example validation

All four complete programs were extracted from this Markdown, compiled with
GCC 15.2 in C++20 mode on x86-64 with `-O2 -Wall -Wextra -Wpedantic -Werror`,
and executed successfully. The system reported a 4096-byte base page size.
Geometry checks, private/shared COW results, and successful protection changes
matched the documented expectations.

In this run the 2048-page anonymous experiment reported 2048 minor faults on
the first read, 2048 on the first write, and zero on the second write; all three
passes reported zero major faults. Those numbers describe this run, not an
interface guarantee. The examples do not validate huge-page allocation, NUMA
placement, DMA pinning, memory-pressure behavior, or intentional fault recovery.
