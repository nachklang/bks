# Design Google Drive: a detailed system design interview case study

[System design preparation guide](README.md) · [Documentation home](../README.md)

This chapter designs a **Google Drive-like file storage, sharing, and synchronization service**. It is a proposed architecture for interview reasoning, not a description of Google's private implementation. Every numerical target, schema, endpoint, state machine, chunk size, retention interval, and deployment choice below is an illustrative design decision unless explicitly identified as documented public behavior.

The core design is a transactional metadata service, immutable file revisions in object storage, durable change feeds, and clients that synchronize using explicit versions. Its difficult parts are publication across storage systems, concurrent edits, permission changes, and recovering clients without losing or exposing data. A large blob store alone does not solve those problems.

The baseline prioritizes correctness and a coherent transaction boundary. Later sections discuss scaling that boundary. Live collaborative document editing is an extension because editing structured documents is a separate conflict-resolution problem from synchronizing arbitrary binary files.

## Contents

1. [Frame the problem](#01-frame-the-problem)
2. [Requirements and product decisions](#02-requirements-and-product-decisions)
3. [Correctness invariants and guarantees](#03-correctness-invariants-and-guarantees)
4. [Capacity model](#04-capacity-model)
5. [Baseline architecture](#05-baseline-architecture)
6. [Data model and transaction boundaries](#06-data-model-and-transaction-boundaries)
7. [API contracts](#07-api-contracts)
8. [Content layout and chunking](#08-content-layout-and-chunking)
9. [Upload protocol](#09-upload-protocol)
10. [Download protocol](#10-download-protocol)
11. [Concurrent edits and version history](#11-concurrent-edits-and-version-history)
12. [Synchronization and change feeds](#12-synchronization-and-change-feeds)
13. [Client internals and offline operation](#13-client-internals-and-offline-operation)
14. [Sharing and authorization](#14-sharing-and-authorization)
15. [Folders, names, moves, and copies](#15-folders-names-moves-and-copies)
16. [Deletion, retention, and garbage collection](#16-deletion-retention-and-garbage-collection)
17. [Quota and accounting](#17-quota-and-accounting)
18. [Search, previews, and notifications](#18-search-previews-and-notifications)
19. [Partitioning and scaling](#19-partitioning-and-scaling)
20. [Multi-region operation and disaster recovery](#20-multi-region-operation-and-disaster-recovery)
21. [Security, privacy, and abuse](#21-security-privacy-and-abuse)
22. [Reliability and failure matrix](#22-reliability-and-failure-matrix)
23. [Observability and verification](#23-observability-and-verification)
24. [Cost and optimization](#24-cost-and-optimization)
25. [Extensions and changed requirements](#25-extensions-and-changed-requirements)
26. [Design decisions and alternatives](#26-design-decisions-and-alternatives)
27. [The interview presentation](#27-the-interview-presentation)
28. [Question bank with answer checkpoints](#28-question-bank-with-answer-checkpoints)
29. [Exercises and worked failure traces](#29-exercises-and-worked-failure-traces)
30. [Final review and primary references](#30-final-review-and-primary-references)

**First pass:** sections 1–7, 9–12, 14, and 27. **Second pass:** client internals, folder operations, reclamation, regional recovery, and failure exercises. **Before the interview:** reproduce the publication and sync sequences, then answer the question bank aloud.

<a id="01-frame-the-problem"></a>
## 1. Frame the problem

Start by stating the product in terms of user journeys:

> “A user can store files in folders, access them from multiple devices, share access with other people, and continue editing while temporarily offline. The service preserves complete revisions and prevents silent loss of concurrent work.”

Then ask the architectural questions:

1. Is this arbitrary file storage and synchronization, or also collaborative text editing?
2. Do we need desktop offline sync, or only browser uploads and downloads?
3. Can users share files, folders, or entire team spaces?
4. Is strict permission revocation required for future requests, and what about existing transfers?
5. Must acknowledged files survive complete region loss without data loss?
6. What are active users, stored bytes, file-size distribution, and peak traffic?
7. How do deletion, revision retention, quota, and trash work?

If answers are unavailable, proceed with the assumptions below. Do not spend the interview trying to perfectly reproduce every Drive feature.

### 1.1 What public documentation establishes

Google's public Drive API documents simple, multipart, and resumable upload modes. Its resumable protocol uses an upload session URI, status queries, and a byte-range-oriented upload procedure. These public API details do **not** reveal how Google partitions metadata or stores internal chunks. [Drive upload documentation](https://developers.google.com/workspace/drive/api/guides/manage-uploads).

Drive also documents a changes collection and notifications that signal the availability of changes. Clients retrieve the actual changes separately. We use that public behavior as motivation for a durable pull-based synchronization design, while defining our own internal protocol below. [Drive change retrieval](https://developers.google.com/workspace/drive/api/guides/manage-changes).

### 1.2 Vocabulary

A **namespace** is a personal drive or team space with its own hierarchy, policy, quota, and ordered metadata changes. A **file** has stable identity. A **revision** is one immutable content version of that file. A **manifest** describes the ordered content objects composing a revision. An **upload session** tracks a not-yet-published transfer. A **device cursor** records which committed changes the device has applied.

These distinctions prevent confusion. Renaming a file changes metadata but not its content revision. Uploading all bytes does not necessarily mean a revision has been published. Receiving a push does not mean a device has applied the associated changes.

<a id="02-requirements-and-product-decisions"></a>
## 2. Requirements and product decisions

### 2.1 Baseline scope

| Feature | Baseline contract |
|---|---|
| Upload | Large files support restart after connection failure without resending confirmed parts. |
| Download | Authorized users can stream and resume a specific immutable revision. |
| Folders | One physical parent per item within a namespace; stable object identity. |
| Sharing | Direct user and group grants on files/folders; inherited access. |
| Synchronization | Online devices discover changes promptly; offline devices reconcile later. |
| Concurrency | Stale writers receive a conflict; unmerged work is preserved. |
| Version history | Retained immutable revisions can be inspected and restored if authorized. |
| Deletion | Trash is reversible; permanent purge follows policy and may be asynchronous. |
| Search | Metadata and optionally content search, with current authorization before exposure. |
| Operations | Quotas, audit history, monitoring, integrity checks, and recovery. |

Extensions include live document collaboration, cross-namespace atomic moves, advanced enterprise policy, end-to-end encryption, and arbitrary filesystem metadata replication.

### 2.2 Explicit product choices

For this design, sibling names are unique under a namespace-defined normalized comparison; each original display name is retained. This is a **simplification**, not a claim that actual Google Drive requires unique sibling names. Collision behavior is explicit, including conflict copies and restore conflicts.

All retained revision bytes count toward the namespace's logical quota, including trashed files. Sharing does not charge each viewer. Content reuse does not silently lower customer quota unless the product deliberately adopts physical accounting. This makes accounting predictable and independent of internal deduplication.

Baseline grants confer access to the file's retained history unless a policy says otherwise. If old revisions contain sensitive data, the product may instead require revision-specific permissions. Decide this before implementing “restore version.”

Restoring a revision creates a new head revision referencing the selected content; it does not move the file's generation counter backward. That keeps synchronization and auditing monotonic.

### 2.3 Illustrative service objectives

| Operation or property | Assumed objective and boundary |
|---|---|
| Metadata reads | p95 below 200 ms for clients reasonably near a serving region. |
| Metadata mutations | p95 below 500 ms, excluding upload transfer and content scanning. |
| Online metadata propagation | 99% of eligible online devices learn of a committed change within 5 seconds under ordinary load. |
| Core API availability | 99.95% of eligible requests succeed within the defined operation deadline over 30 days. |
| Download startup | Measure authorization and first byte separately from full transfer time. |
| Durability | Successful publication survives a node or zone failure in the baseline deployment. |
| Regional disaster | Baseline asynchronous remote copy has nonzero RPO; zero regional RPO is an explicit stronger extension. |
| Revocation | New download authorizations after completed revocation use current permissions; active streams are handled separately. |

These are proposed goals, not measured Google performance or an advertised SLA. Sync freshness applies to reachable, subscribed devices; an offline phone cannot meet an online propagation objective. Quarantined content may have metadata synchronized before the content becomes downloadable.

<a id="03-correctness-invariants-and-guarantees"></a>
## 3. Correctness invariants and guarantees

Write these on the board before discussing storage products:

1. **Complete publication:** every committed revision references a complete, validated manifest and content satisfying the configured durability policy.
2. **One authoritative head:** each file has one current head selected by a conditional transaction.
3. **No silent overwrite:** changing a head requires the expected base revision or an explicit conflict-resolution action.
4. **Stable retries:** the same authorized operation key and request produce one logical mutation and a recoverable result.
5. **No authorization bypass:** metadata visibility and content delivery obey the effective policy; knowing a blob ID or hash grants no access.
6. **No missing committed changes:** each committed visible metadata mutation creates a durable change event in the same transaction.
7. **Safe reclamation:** content cannot be physically reclaimed while a retained revision or valid protected operation still references it.
8. **Quota safety:** concurrent reservations and commits cannot spend the same remaining quota twice.
9. **No deletion resurrection:** old devices cannot recreate deleted identities merely by replaying stale state.
10. **Acyclic hierarchy:** folder operations preserve the single-parent tree.

The baseline metadata store provides serializable transactions and authoritative reads with real-time freshness where these contracts require it. A merely asynchronous replica read is not used to authorize a sensitive action or decide the current head. Search and previews are derived and may lag.

### 3.1 Three different success states

```text
Bytes accepted:      parts reached storage, but publication may still fail.
Revision committed:  durable content and metadata head are atomically published.
Revision usable:     content passes required policy checks and may be downloaded.
```

The API exposes these states rather than displaying “complete” at every stage. In the baseline, a newly committed revision is quarantined until scanning completes. The user can see that it exists and is being checked. Downloading a pending or blocked head is rejected; an older allowed revision can be requested explicitly if policy permits.

This separates durability from content safety. Scanning before publication is an alternative with different latency and visibility semantics; do not accidentally mix the two models.

<a id="04-capacity-model"></a>
## 4. Capacity model

### 4.1 Workload assumptions

| Quantity | Assumption |
|---|---|
| Registered users | 100 million. |
| Daily active users | 10 million. |
| Metadata reads per active user/day | 20. |
| Content uploads per active user/day | 2. |
| Mean new uploaded content | 10 MB per upload, decimal units. |
| Content downloads per active user/day | 5. |
| Mean bytes delivered per download | 10 MB, including the chosen partial-download mix. |
| Peak multiplier | 5× average for initial planning. |
| Average logical retained bytes per registered user | 10 GB. |
| Average retained file/revision record | 1 KB of core metadata, before indexes and manifests. |
| Illustrative online devices | 5 million concurrent connections at peak. |

Metadata traffic here excludes additional protocol amplification from chunk plans, notifications, pagination, retries, and background work. Estimate these separately after choosing a protocol.

### 4.2 Derived rates

```text
metadata reads:     200 million/day ≈ 2,315/s average ≈ 11,574/s peak
upload commits:     20 million/day ≈   231/s average ≈  1,157/s peak
content ingress:   200 TB/day      ≈  2.31 GB/s      ≈ 11.57 GB/s peak
content downloads:  50 million/day ≈   579/s average ≈  2,894/s peak
content egress:    500 TB/day      ≈  5.79 GB/s      ≈ 28.94 GB/s peak
retained content: 100 million × 10 GB = 1 EB logical
```

One exabyte is 1,000 petabytes in these decimal estimates. Threefold replication would imply 3 EB before temporary uploads, manifests, indexes, backups, and operational slack. An erasure-coded policy changes this multiplier, but introduces other costs.

The retained corpus and ingestion rate are independent assumptions. At 200 TB/day, a 1 EB corpus represents roughly 5,000 days of that ingestion rate without deletion. A mature historical corpus, a different past workload, or different retention can explain the combination. Do not present both numbers as if one automatically derives from the other.

At a 10 MB mean retained revision, 1 EB corresponds to roughly 100 billion retained revisions; 1 KB each implies 100 TB of core revision metadata before indexes, replicas, ACLs, and manifests. File count may be lower because a file can retain many revisions.

### 4.3 Chunk requests and small files

Suppose large files use an illustrative 8 MiB logical chunk size. A 1 GiB file has 128 chunks. A 10 MB file spans two such chunks, but a workload's mean file size alone cannot determine its mean number of chunks: many tiny files and a few huge files have a different request distribution. Measure or assume a size histogram.

At 5 million online connections, even 10 KB of connection state consumes about 50 GB across the notification fleet, before runtime overhead and transport buffers. If every device reconnects within 60 seconds after an outage, that is about 83,333 connection establishments/s. Plan jittered reconnects and authentication capacity.

### 4.4 What the estimates imply

Content traffic should avoid the metadata application servers. Storage, bandwidth, and object count dominate long-term cost. Metadata transactions at the initial rate are manageable with a well-designed store, but a huge shared namespace or folder can create localized contention. Notification fanout and device bootstrap may have larger bursts than steady-state upload commits.

<a id="05-baseline-architecture"></a>
## 5. Baseline architecture

```mermaid
flowchart TB
    C[Web mobile and desktop clients]
    C --> E[Edge API routing and admission]
    E --> M[Metadata and upload coordinator]
    M --> D[(Transactional metadata authority)]
    M --> I[Identity verification]
    M --> P[Policy evaluation module]
    P --> D
    C --> U[Scoped upload endpoints]
    U --> B[(Immutable object storage)]
    M --> B
    C --> G[Authorized download gateway and edge cache]
    G --> P
    G --> B
    D --> O[Outbox relay]
    O --> L[Durable event log]
    L --> N[Notification service]
    N -. change hint .-> C
    L --> W[Scanning indexing and preview workers]
    W --> B
    W --> M
    W --> S[(Derived search and preview state)]
    E --> Q[Search service]
    Q --> S
    Q --> P
```

### 5.1 Responsibilities

**Edge API:** authenticate requests, apply request-size and rate limits, attach tracing context, and route namespace operations. Authorization remains resource-specific; a valid access token alone does not permit every file operation.

**Metadata and upload coordinator:** owns names, parents, revisions, upload sessions, quota, and idempotency records. It decides when content is ready to publish. For the baseline, authorization relationships are stored in the same transactional authority so permission changes and metadata changes can be ordered coherently.

**Object storage:** stores immutable content and manifests, checks integrity, replicates or erasure-codes according to policy, and supports internal range reads. It does not interpret user-visible paths as its object identity.

**Download gateway:** checks current access before serving an immutable revision and uses an edge cache for bytes. It can scale independently of metadata transactions. “Gateway” does not imply one central server; it is a fleet of regional or edge serving processes.

**Event log and workers:** deliver change processing, scanning, indexing, preview generation, and notification work. These are asynchronous consumers of committed state. Consumers must tolerate redelivery and stale work.

### 5.2 Logical versus physical deployment

The diagram shows responsibilities, not a mandate for separate microservices. Metadata, upload coordination, and policy evaluation can initially share a process and database. Split them when independent capacity, security isolation, or ownership justifies the network boundary.

Search, previews, and push do not determine whether publication committed. An outage in those systems should not roll back a durable revision. An inability to establish authorization must prevent the sensitive operation, even if content bytes are healthy.

<a id="06-data-model-and-transaction-boundaries"></a>
## 6. Data model and transaction boundaries

### 6.1 Main entities

```mermaid
erDiagram
    NAMESPACE ||--o{ FILE : contains
    NAMESPACE ||--o{ UPLOAD_SESSION : reserves
    NAMESPACE ||--o{ CHANGE_EVENT : orders
    FILE ||--o{ REVISION : retains
    FILE ||--o{ GRANT : controls
    REVISION }o--|| MANIFEST : describes
    MANIFEST ||--o{ MANIFEST_ENTRY : orders
    BLOB ||--o{ MANIFEST_ENTRY : referenced_by
    UPLOAD_SESSION ||--o{ UPLOAD_PART : tracks
    DEVICE ||--o{ SYNC_CURSOR : remembers
```

The drawing omits some fields and relationships for readability. The schema below defines the important constraints.

```text
Namespace(
  namespace_id PK, owner_or_team_id, home_region, routing_epoch,
  quota_limit_bytes, used_logical_bytes, reserved_bytes,
  next_change_seq, authz_epoch, hierarchy_generation
)

File(
  namespace_id, file_id, parent_id, kind, display_name, normalized_name,
  metadata_generation, head_revision_id, lifecycle_state,
  deletion_generation, created_at, updated_at,
  PK(namespace_id, file_id)
)

Revision(
  namespace_id, file_id, revision_id, base_revision_id, manifest_id,
  logical_size, content_digest, creator_id, created_at,
  content_state, retained, minimum_policy_version,
  PK(namespace_id, file_id, revision_id)
)

UploadSession(
  namespace_id, session_id, principal_id, target_file_id, target_parent_id,
  target_name, expected_head, declared_size, reserved_bytes,
  state, expires_at, manifest_id, request_hash, operation_key,
  committed_revision_id, fencing_generation,
  PK(namespace_id, session_id)
)

UploadPart(session_id, part_number, blob_id, byte_length, digest,
           storage_generation, verification_state,
           PK(session_id, part_number))

Manifest(manifest_id, namespace_id, total_length, manifest_digest, state)
ManifestEntry(manifest_id, ordinal, logical_offset, length, blob_id, digest)
Blob(blob_id, namespace_id, storage_key, storage_generation,
     byte_length, digest, durability_state, lifecycle_state, gc_generation)
BlobPin(blob_id, pin_owner_id, pin_kind, generation)

Grant(namespace_id, resource_id, subject_type, subject_id, role)
GroupMember(namespace_id, group_id, member_id, membership_generation)
IdempotencyRecord(namespace_id, principal_id, operation_kind, key,
                  request_hash, outcome, created_at)
ChangeEvent(namespace_id, seq, event_id, file_id, metadata_generation,
            event_kind, resulting_state_or_reference, transaction_id)
Outbox(namespace_id, event_id, payload, delivery_state)
DeviceCursor(device_id, namespace_id, membership_epoch, applied_seq)
```

The group-membership table represents the authoritative membership snapshot used by this design. External identity-provider membership changes must enter this authority through a versioned update process; silently checking a separate stale directory would weaken the authorization contract.

### 6.2 Indexes and constraints

Use a primary lookup on `(namespace_id, file_id)`. Index active children by `(namespace_id, parent_id, normalized_name, file_id)` for listings. Enforce uniqueness of active sibling names according to the chosen normalization. Index revisions by `(namespace_id, file_id, creation_order)` and changes by `(namespace_id, seq)`.

Session lookups need `(namespace_id, session_id)` and a cleanup index on state and expiration. Subject-to-resource indexes help discover shares, but are derived discovery aids unless maintained transactionally. Do not authorize solely because an eventually updated “shared with me” index contains an entry.

Bound parent depth, filename length, manifest entries per page, and batch sizes. A logical manifest for a very large file can be stored as immutable pages with a root digest rather than millions of database rows in one transaction.

### 6.3 Transaction locality

The baseline puts one namespace's mutation authority within one serializable transaction domain. A publication transaction changes the file head, inserts a revision, transfers quota reservation to usage, protects manifest reachability, records the operation result, appends a change, and adds an outbox event.

The namespace change sequence is allocated under a namespace row lock held until commit. Consequently, a later transaction cannot publish a larger sequence while a smaller committed event remains invisible. This avoids a subtle cursor bug where an ordinary sequence generator allocates 10 and 11, transaction 11 commits first, and a client advances past 10 before it commits.

The cost is namespace-level serialization for sequence allocation and quota updates. This is a deliberate baseline limitation, revisited in [scaling](#19-partitioning-and-scaling). Global serialization across all users is unnecessary.

### 6.4 Metadata version versus content version

`metadata_generation` changes for rename, move, trash, head replacement, and other visible file mutations. `revision_id` identifies immutable bytes. A rename need not invalidate a content edit based on the same head, but the upload must still recheck current permissions, existence, and destination policy at publication. A client should not confuse an old display name with an obsolete content base.

### 6.5 Why no universal global transaction?

Object storage is outside the database transaction. We first make immutable content durable and protected, then publish references atomically in metadata. Failed publication can leave reclaimable content; it must never leave visible metadata pointing to missing content. That asymmetric ordering is the central design choice.

<a id="07-api-contracts"></a>
## 7. API contracts

These are proposed APIs for this case study, not Google Drive API endpoints.

| API | Purpose and important contract |
|---|---|
| `POST /v1/namespaces/{ns}/upload-sessions` | Reserve quota and create a session; requires operation key, declared size, target, and expected head for replacement. |
| `GET /v1/upload-sessions/{id}` | Recover durable session state and confirmed parts after interruption. |
| `POST /v1/upload-sessions/{id}/part-capabilities` | Issue a bounded batch of scoped upload capabilities. |
| `PUT <part-capability>` | Transfer one part under an exact object identity and bounded length. |
| `POST /v1/upload-sessions/{id}/complete` | Seal and validate a manifest, then conditionally publish once. |
| `POST /v1/upload-sessions/{id}/abort` | Idempotently stop an unpublished session and release its reservation. |
| `GET /v1/files/{id}` | Read currently authorized metadata; return metadata generation and head. |
| `GET /v1/folders/{id}/children?page_token=...` | List authorized children with deterministic pagination. |
| `PATCH /v1/files/{id}` | Rename or update metadata with an expected metadata generation. |
| `POST /v1/files/{id}/move` | Move within a namespace with source/destination checks and hierarchy validation. |
| `POST /v1/files/{id}/download` | Authorize a specific revision and return a scoped gateway capability. |
| `GET /v1/files/{id}/revisions` | List retained history according to revision-visibility policy. |
| `POST /v1/files/{id}/restore-revision` | Create a new head from retained content with a current-head precondition. |
| `POST /v1/files/{id}/grants` | Add or alter a grant with current share-management authorization. |
| `DELETE /v1/files/{id}/grants/{grant}` | Revoke a particular grant and advance authorization state. |
| `POST /v1/files/{id}/trash` | Atomically hide the item/subtree logically and create a tombstone event. |
| `POST /v1/files/{id}/restore` | Restore if policy, parent, names, and permissions allow it. |
| `POST /v1/files/{id}/purge` | Start policy-checked permanent removal; return an operation handle if asynchronous. |
| `GET /v1/namespaces/{ns}/changes?cursor=...` | Return authorized changes and an opaque continuation cursor. |
| `POST /v1/namespaces/{ns}/sync-snapshots` | Establish a coherent initial snapshot and associated log watermark. |

### 7.1 Initiation example

```json
{
  "target_file_id": "file-123",
  "expected_head_revision": "rev-7",
  "declared_size_bytes": 73400320,
  "content_type_hint": "application/octet-stream",
  "preferred_part_size_bytes": 8388608,
  "operation_key": "device-42-local-op-891"
}
```

The server returns a session ID, reserved logical bytes, expiration, negotiated part policy, and a recovery/status endpoint. It treats content type and client hashes as claims to validate. Session possession alone does not authorize publication after access has been revoked.

### 7.2 Completion example

```json
{
  "operation_key": "device-42-local-op-891-complete",
  "expected_head_revision": "rev-7",
  "manifest": {
    "total_length": 73400320,
    "parts": [
      {"ordinal": 0, "blob_id": "blob-a", "length": 8388608, "sha256": "..."},
      {"ordinal": 1, "blob_id": "blob-b", "length": 8388608, "sha256": "..."}
    ],
    "manifest_digest": "..."
  }
}
```

The displayed parts array is deliberately abbreviated; a valid request must describe every part or reference a previously uploaded complete manifest. The server verifies exact coverage of `[0, total_length)`, order, lengths, part ownership, hashes, and the absence of unexpected overlap or gaps. A zero-byte file has an explicitly supported empty manifest.

### 7.3 Error semantics

Use unauthenticated versus unauthorized responses consistently with the information-disclosure policy; inaccessible objects may deliberately appear absent. A stale HTTP precondition can return `412`; a domain-specific revision or name conflict can return `409` with authorized conflict metadata. Rate limiting returns a retryable response with backoff guidance. Quota errors are explicit application errors, not generic server failures.

An expired sync cursor returns a clear `CURSOR_EXPIRED` condition, with instructions to bootstrap again while preserving unsynced local work. An expired upload session cannot be silently reused; a new session may reuse server-verified content only through an authorized protocol.

Every mutation accepts an operation key scoped to principal, namespace, and operation kind. Keys are bound to request hashes. Retrying an already committed completion recovers its existing result even though the supplied old expected head no longer matches: check the idempotency outcome before trying a new mutation. Reauthorize disclosure of that result.

<a id="08-content-layout-and-chunking"></a>
## 8. Content layout and chunking

### 8.1 Distinguish four different units

1. A **file revision** is the logical version users access.
2. A **logical chunk** is a unit listed in its manifest.
3. A **transfer part** is a unit retried over the network.
4. A **storage fragment** is an internal replication or erasure-coding unit.

These units can have different sizes. An object store's multipart-upload part is not automatically a deduplication chunk, and an erasure stripe is not automatically a client-visible part.

Our proposed API permits independent part uploads with bounded parallelism. That is a design choice; do not infer parallel out-of-order behavior from the public Drive resumable byte-range protocol.

### 8.2 Start with fixed-size chunks

For large files, choose an illustrative 8 MiB logical chunk and allow the last chunk to be shorter. A small file may use one object. Larger chunks reduce per-request, manifest, and hashing overhead but increase retransmission after a failed part. Smaller chunks improve retry granularity and potential reuse but increase object count and bookkeeping.

Never put the complete file in application memory. Stream input through bounded buffers while hashing and writing. Enforce maximum part length at the receiving endpoint, including when the client uses streaming transfer encoding or lies about content length.

```mermaid
flowchart LR
    R[Revision rev-8] --> M[Immutable manifest]
    M --> A[Chunk 0: offset 0]
    M --> B[Chunk 1: offset 8 MiB]
    M --> C[Final shorter chunk]
    A --> OA[(Immutable object A)]
    B --> OB[(Immutable object B)]
    C --> OC[(Immutable object C)]
```

The manifest includes order, lengths, content hashes, and exact storage generations. A digest of a manifest is not automatically the same as SHA-256 of the concatenated file bytes. Define which checksum the API exposes; a full-file digest can be verified through streaming if needed.

### 8.3 Prevent overwrites after validation

A reusable upload URL that can overwrite the same object after verification would break immutability. Use create-only writes, versioned object generations pinned in the manifest, or a sealed internal copy to an immutable final key. The verifier and downloader must refer to the same stored generation.

An object key is generated by the service and bound to the session, ordinal, and allowed length. A client cannot substitute an arbitrary user's object or a hash it merely knows. Upload endpoints must not grant bucket listing, deletion, or general object access.

### 8.4 A concrete protection model

Maintain a catalog protection root for each upload's content. Each accepted part attaches to that root before it can be considered publishable. An open session protects its root. A committed retained revision protects a sealed manifest root. Root attachment and transition to deletion eligibility are serialized in the metadata authority.

For the baseline, chunks are unique to an upload. This makes ownership straightforward. A whole-manifest copy can add another durable root reference atomically. An upload's expiration job checks its state in a transaction; it must not expire protection after the session has become committed.

For deduplicated chunks shared across independent manifests, use explicit durable pins or references in the blob catalog. Attaching a reference must atomically verify that the blob is live and has not entered a deleting generation. Physical deletion is conditional on the exact storage generation. [Garbage collection](#16-deletion-retention-and-garbage-collection) develops the race handling.

### 8.5 Fixed versus content-defined chunking

With fixed chunk boundaries, inserting one byte near the beginning shifts later content and can destroy reuse across many chunks. Content-defined chunking uses a rolling fingerprint to select boundaries based on content, often with minimum and maximum chunk sizes. Unchanged later content can regain the same boundaries.

This improves reuse for some workloads but adds CPU, variable-size planning, and more complex manifests. Compressed or encrypted files may exhibit little reusable structure. Treat content-defined chunking and binary delta transfer as measured optimizations, not requirements for a working Drive service.

### 8.6 Deduplication and security

Start without cross-user deduplication. Later, namespace-scoped reuse may reduce upload bandwidth and storage. Never expose “that hash already exists globally” to arbitrary users: existence and timing can reveal another user's private content. Knowledge of a digest is not proof of ownership or access.

Hash collisions are extraordinarily unlikely with an appropriate cryptographic digest, but the system still validates length, verified content identity, scope, and object state. A checksum detects mismatch; it does not prove that the uploader was authorized or that the file is harmless.

<a id="09-upload-protocol"></a>
## 9. Upload protocol

This is the most important write path to explain. The publication boundary must be explicit.

### 9.1 State machine

```mermaid
stateDiagram-v2
    [*] --> OPEN: authorize and reserve quota
    OPEN --> UPLOADING: accept first part
    UPLOADING --> UPLOADING: accept or retry parts
    OPEN --> VALIDATING: complete an empty file
    UPLOADING --> VALIDATING: seal requested manifest
    VALIDATING --> COMMITTED: verify then publish atomically
    VALIDATING --> CONFLICT: expected head is stale
    VALIDATING --> REJECTED: invalid content or policy
    OPEN --> ABORTED: client abort
    UPLOADING --> ABORTED: client abort
    OPEN --> EXPIRED: session lifetime exceeded
    UPLOADING --> EXPIRED: session lifetime exceeded
    VALIDATING --> EXPIRED: recovery determines lease expired
    CONFLICT --> COMMITTED: explicit authorized conflict-copy publication
    CONFLICT --> ABORTED: user discards staged work
    CONFLICT --> EXPIRED: conflict retention expires
    COMMITTED --> [*]
    ABORTED --> [*]
    EXPIRED --> [*]
    REJECTED --> [*]
```

Transitions use conditional updates and a session fencing generation. A validation worker whose lease expired cannot publish later unless it obtains current authority and rechecks state. A client changing its mind during validation requests cancellation; the transaction decides whether cancellation or publication won. A committed revision is deleted through the normal file lifecycle, not by pretending the upload was never committed.

### 9.2 Successful flow

```mermaid
sequenceDiagram
    participant C as Client
    participant A as Upload coordinator
    participant D as Metadata authority
    participant B as Object storage
    participant R as Outbox relay
    participant W as Scanner and other workers
    C->>A: Initiate with operation key and expected head
    A->>D: Authorize, reserve quota, create session
    D-->>A: Session committed
    A-->>C: Session ID and scoped part capabilities
    loop Bounded parallel part transfers
        C->>B: PUT exact part identity and bytes
        B-->>C: Stored generation and receipt
    end
    C->>A: Complete with immutable manifest
    A->>D: Claim validation and protect sealed manifest
    A->>B: Verify parts, checksums, generations, durability
    B-->>A: Validated durable objects
    A->>D: Atomic publication transaction
    Note over D: Recheck auth, head, lifecycle, quota and session fence
    Note over D: Insert revision, change head, retain root, record result and event
    D-->>A: Committed revision and namespace sequence
    A-->>C: Committed, content pending safety checks
    R->>D: Read committed outbox
    R->>W: Deliver revision event with retry
    W->>A: Record version-specific scan result
    A->>D: Transition content state and emit change
```

### 9.3 Step-by-step reasoning

**Initiate.** Verify the identity, namespace, target policy, size limits, and current write permission. Reserve quota in a short transaction. For a new file, allocate a stable file ID in the session; do not create a visible empty file unless the product intentionally supports placeholders. Reserve or recheck the destination name according to the chosen naming policy; the baseline rechecks uniqueness at publication.

**Upload parts.** Issue capabilities in bounded batches. Parts are idempotent for the exact identity and content generation. Store verified progress durably. If a receipt is lost, the client queries session status and the coordinator reconciles storage receipts; the client does not guess whether a part exists.

**Freeze the manifest.** Transition into validation with a fencing generation. No later part mutation can alter the sealed version. If parts are still in flight, either wait for them within the session contract or return a specific incomplete-manifest result.

**Validate.** Check all parts exist at the pinned generations, their lengths and hashes match, the manifest is complete, and the configured fault-domain durability requirement is met. Do this outside a long-held metadata transaction. Session/root protection prevents cleanup during validation.

**Publish.** Execute the short transaction below. Recheck authorization now: permission at upload initiation may have been revoked. Recheck file existence and lifecycle: the file may have been trashed or purged during transfer. Recheck the expected head: another device may have committed first.

**Respond and process.** The response identifies a committed revision and its content-safety state. Scanning and indexing consume durable events. A lost response is recovered from the idempotency result, not by creating another revision.

### 9.4 Publication transaction pseudocode

```text
begin serializable transaction with required real-time authority:
    result = lookup(principal, namespace, completion_key)
    if result exists:
        require stored_request_hash == current_request_hash
        authorize disclosure of result
        return stored result

    lock namespace sequence/quota row and session in canonical order
    require session.state == VALIDATING and session.fence == worker_fence
    require sealed manifest validation refers to exact immutable generations
    require session protection root is live
    require current principal may publish to current target
    require target and ancestors permit publication
    require actual logical bytes fit the reservation or an atomic extension

    if replacing an existing file:
        require file.head_revision_id == expected_head
    else:
        require destination parent exists and active sibling name is available

    retain sealed manifest root for new revision
    create revision with content_state = PENDING_SCAN
    create or update file head; increment metadata_generation
    convert this session's reserved quota into retained logical usage
    set session.state = COMMITTED and store committed_revision_id
    append next namespace change and outbox event
    store idempotency request hash and stable outcome
commit
```

The validation result is safe to reuse only because content generations are immutable and protected. If the storage policy changes or a root loses protection, revalidation is required. A transaction serialization failure causes a bounded retry with all relevant conditions re-evaluated.

### 9.5 Crash and retry points

| Failure point | Durable state | Recovery |
|---|---|---|
| Before initiation commits | No reservation/session, or unknown to caller. | Retry initiation with same key. |
| After initiation, before response | Session and reservation exist. | Return the same session; do not reserve twice. |
| After storing a part, before its receipt arrives | Exact part generation may exist. | Query/reconcile status; resend only if needed. |
| During validation | Protected parts and validation state exist. | New fenced worker resumes or expires the session safely. |
| After validation, before publication | Content exists; no visible revision. | Retry publication after rechecking current metadata. |
| After publication, before response | Revision, quota, result, and event committed. | Return recorded result; no duplicate revision. |
| After event delivery, before relay checkpoint | Event may be delivered again. | Consumer deduplicates or applies a version check. |

### 9.6 Why not publish first?

Publishing the head before storing content lets users observe a revision they cannot download. Rolling it back later is difficult because notifications, history, and clients may already reference it. Storing protected immutable content first creates the less dangerous failure mode: unused bytes that can be reclaimed after proving they are unreachable.

### 9.7 Revocation during upload

An already issued upload capability may remain usable until its short expiration, so revoked users may still send staging bytes. Bound that waste through session limits and reservations. They cannot publish after completed revocation because publication rechecks current authority. Revocation may also cancel open sessions proactively, but cancellation must serialize with publication.

The system must distinguish “upload endpoint accepted bytes” from “the user is allowed to create a visible revision.”

<a id="10-download-protocol"></a>
## 10. Download protocol

### 10.1 Authorize a revision, then stream immutable bytes

```mermaid
sequenceDiagram
    participant C as Client
    participant A as Metadata API
    participant D as Metadata and policy authority
    participant G as Content gateway
    participant K as Immutable edge cache
    participant B as Object storage
    C->>A: Request download of file and optional revision
    A->>D: Read current policy, lifecycle and selected revision
    D-->>A: Authorized immutable revision and content state
    A-->>C: Short-lived capability bound to file and revision
    C->>G: GET capability with optional byte range
    G->>D: Verify current access and active revision eligibility
    D-->>G: Allow or deny under current policy
    alt Authorized and content is allowed
        G->>K: Fetch immutable revision ranges
        alt Cache miss
            K->>B: Read exact object generations
            B-->>K: Verified content ranges
        end
        K-->>G: Bytes
        G-->>C: Stream response with revision validator
    else Revoked, trashed, pending or blocked
        G-->>C: Deny without serving content
    end
```

The API check is useful for selecting the revision and constructing a capability. The gateway check closes the gap if access changes before the client uses that capability. The gateway may call an authorization service rather than the database directly, but the service must meet the freshness contract.

Use immutable revision identity as a strong response validator. A resume request refers to the same revision and byte range. If the file's current head changes, the existing transfer remains pinned to the original revision; it must never assemble half of revision 8 and half of revision 9.

### 10.2 Range reads

Map the requested logical byte interval to manifest entries. Read the first and last chunks partially when the storage backend supports it; intermediate chunks may be read whole. Return correct length and range metadata. Validate requested ranges, cap pathological multi-range requests, and handle unsatisfiable ranges explicitly.

Support encrypted content with independently verifiable segments or another authenticated random-access format. A naive encryption scheme may require reading an entire large object to verify a small range. Decide the cryptographic format before promising cheap random access.

### 10.3 Cache keys and isolation

Cache immutable bytes by content or revision identity and relevant representation. Authorization is evaluated before the response is exposed to the caller. A cache hit is not evidence of access. Avoid user-specific tokens in content cache keys when that needlessly destroys sharing efficiency, but also avoid caching an authorization-dependent response as universally public.

Preview and transcoded representations need their own versioned identities, including transformation version. A regenerated preview must not overwrite a cached representation while keeping an identity that promises immutability.

### 10.4 Direct signed object URLs as an alternative

Direct object-store URLs reduce gateway work. The cost is that a still-valid bearer URL can remain usable after application-level revocation unless the serving layer consults current policy. Choose this alternative only with an explicit bounded revocation window. S3 documents presigned URLs as time-limited access based on the signer's permission and credential validity; an unrelated application grant is not automatically part of that check. [Presigned URL reference](https://docs.aws.amazon.com/AmazonS3/latest/userguide/using-presigned-url.html).

The baseline uses the authorized gateway because revocation semantics are an important product requirement. The gateway can still serve cached content at the edge; centralized authorization and centralized byte transport are different choices.

### 10.5 In-flight downloads

The baseline guarantees current permission for new gateway requests, including new range requests. A stream authorized before revocation may finish. If the requirement is tighter, periodically revalidate or receive revocation signals, fence the stream, and terminate it within a documented bound. There is always a race involving bytes already sent or buffered.

No server protocol can erase plaintext that an authorized device already downloaded and copied. Managed-device policies can limit behavior, but cannot change that fundamental boundary.

<a id="11-concurrent-edits-and-version-history"></a>
## 11. Concurrent edits and version history

### 11.1 Two devices edit the same base

```mermaid
sequenceDiagram
    participant A as Device A
    participant B as Device B
    participant S as Server
    A->>S: Read head rev-7
    S-->>A: rev-7
    B->>S: Read head rev-7
    S-->>B: rev-7
    A->>S: Publish content A with expected head rev-7
    S-->>A: Committed rev-8
    B->>S: Publish content B with expected head rev-7
    S-->>B: Conflict: current head is rev-8
    B->>S: Explicitly preserve staged content as conflict copy
    S-->>B: New file with content B; original remains rev-8
```

The comparison and head update occur in one transaction. Two application servers cannot both succeed against `rev-7`. If the second upload is already complete, retain its protected staged content for a bounded conflict-resolution interval, with quota still reserved.

The client can offer a conflict copy, manual merge, or an explicit “replace current version” action. Replacing requires a new precondition against the current head; the server should not silently reinterpret the stale attempt as an override.

### 11.2 Conflict classes

| Concurrent operations | Baseline resolution |
|---|---|
| Two content edits | One conditional head update wins; preserve the other as conflict work. |
| Rename and content edit | Can both succeed if the edit targets stable file identity and current access remains valid. |
| Move and content edit | Content publication rechecks permissions and lifecycle at the current location. |
| Delete and content edit | Transaction order decides; a later edit cannot publish into a trashed/deleted target. |
| Two renames | Metadata generation precondition; one fails or retries after reading current state. |
| Two creations with the same sibling name | Uniqueness constraint; the loser chooses a visible alternate name. |
| Permission revoke and content publication | Current authorization and transaction order decide whether publication is allowed. |
| Restore old content and fresh edit | Both are head mutations; require expected-head checks. |

### 11.3 Why not last-write-wins?

Client clocks can be wrong, edits can be concurrent, and “later timestamp” does not mean “the user's preferred content.” Last-write-wins is a valid product choice for some simple settings, but arbitrary binary-file editing can lose valuable work. Preserving both versions is usually a safer baseline when semantic merging is unavailable.

### 11.4 Revision history

Revisions are immutable and have stable IDs, authorship, creation metadata, and manifests. History listing is paginated. A revision being old does not bypass current access checks or malware policy.

Restoring content produces a new revision with a reference to the selected retained manifest and a link to its source revision for audit. The file head and generation advance. If the selected revision has been physically purged, restoration is unavailable unless a separate backup recovery workflow applies.

Retention can be time-based, count-based, user-pinned, or policy-controlled. Define it precisely. “Keep the last 100 revisions” behaves differently from “keep everything for 30 days” under a client that saves every second.

<a id="12-synchronization-and-change-feeds"></a>
## 12. Synchronization and change feeds

Synchronization means making local state converge with authorized server state without discarding unsynced local work. A notification channel alone cannot do this.

### 12.1 Authoritative namespace feed

Every visible metadata transaction appends a `ChangeEvent` with a namespace sequence. The baseline serves the authoritative change feed from this committed table or a proven gap-free replica of it. The asynchronous broker is used for workers and hints; broker delivery order alone is not the source of truth for client cursors.

An event contains stable object identity, event type, metadata generation, and enough information to apply or fetch resulting state. Changes can include create, rename, move, new head, trash, restore, content-safety transition, grant change, and subtree invalidation.

A server may coalesce redundant events if the feed promises current-state convergence rather than a complete audit trail. Keep audit history separate if every historical operation must be preserved.

### 12.2 The initial-snapshot race

The unsafe procedure is “list all files, then ask for the current change token.” A file can change after its listing page was read but before the token is obtained; neither the listing nor future changes then contains the needed state.

The baseline establishes a database snapshot and a matching committed log watermark `H` from the same consistent view. It enumerates the namespace **as of that snapshot**, then replays changes after `H`. The snapshot is paginated and retained only for a bounded bootstrap lifetime.

```mermaid
sequenceDiagram
    participant C as New device
    participant S as Sync API
    participant D as Metadata authority
    C->>S: Begin bootstrap for namespace
    S->>D: Establish consistent snapshot and matching watermark H
    D-->>S: Snapshot handle, H, membership epoch
    S-->>C: Opaque snapshot token and replay cursor H
    loop Snapshot pages
        C->>S: Next snapshot page
        S->>D: Enumerate as of snapshot and check current visibility
        D-->>S: Authorized snapshot rows
        S-->>C: Page and next token
        C->>C: Persist metadata and local materialization jobs
    end
    C->>S: Read changes after H
    S-->>C: Changes through a safe committed watermark
    C->>C: Apply changes and persist cursor atomically
    C->>S: Subscribe to change hints
    C->>S: Poll again to close subscription timing gap
```

The snapshot must remain available until enumeration finishes. If its MVCC history or token expires, restart bootstrap safely. A snapshot does not freeze authorization: each page checks current visibility, and an access/membership epoch change triggers an appropriate rescan or restart so older snapshots cannot disclose newly forbidden data.

An alternative is to capture a cursor **before** enumeration and replay from it, but it still requires an enumeration strategy that cannot permanently omit unchanged visible objects under concurrent moves. A coherent snapshot makes the reasoning clearer.

### 12.3 Incremental loop

```text
repeat while namespace remains authorized:
    response = fetch_changes(saved_opaque_cursor)
    begin local database transaction:
        for each event in response:
            ignore an older/equal generation already applied
            update local desired metadata state
            enqueue durable file download, rename, or removal work
        persist response.next_cursor
    commit local transaction
    process durable filesystem work with crash recovery
    if more pages exist: continue immediately within fairness limits
    otherwise wait for hint or randomized periodic reconciliation
```

Persisting the cursor before recording the work can lose updates on a crash. Persisting it afterward without deduplication can repeat effects. The local database transaction stores desired state, pending work, and the cursor together. Actual file I/O happens through a recoverable job protocol, discussed in [client internals](#13-client-internals-and-offline-operation).

### 12.4 Cursor contents and retention

Use opaque, authenticated cursors carrying namespace, sequence or partition positions, scope, membership epoch, format version, and expiration. A cursor is a progress token, not a permanent grant. Check current access on every request.

Assume a 30-day feed retention window for this design. This is a proposed internal contract, **not a statement that public Drive change tokens expire after 30 days**. A device older than retained history receives `CURSOR_EXPIRED` and reboots from a fresh snapshot while preserving local pending edits.

Deleted-object identity and stale-write protection may need to outlive feed retention. A client with an old revision cannot bypass deletion checks just because its event history expired. Never reuse a purged file ID for an unrelated new file.

### 12.5 Filtering shared visibility

A user may only see a subtree or one shared file in a namespace. Evaluate visibility before returning event metadata. It is acceptable to advance an opaque cursor past events outside the user's scope, provided changes in visibility have their own durable handling.

When access is **granted** to an existing folder, the recipient needs a subtree snapshot of existing descendants; replaying only future file edits would miss unchanged children. Emit a scope-added event and bootstrap that scope from a coherent boundary.

When access is **revoked**, stop returning protected details and invalidate the client's previously subscribed scope. Maintain a user/account membership stream or an equivalent durable scope-discovery mechanism so withdrawal is discoverable even when the user can no longer read the namespace feed. This can expose only the user's previously known subscription handle. Devices also periodically revalidate their subscribed scopes.

Permission changes affecting descendants can emit a subtree invalidation event instead of millions of per-file ACL events. The client re-evaluates that scope and removes unavailable entries. Shared-scope cursor positions and membership epochs prevent stale subscriptions from being reused as authority.

### 12.6 Push is an optimization

Push messages say “namespace or scope X may have new changes.” They can be duplicated, delayed, reordered, or missed by disconnected devices. Clients pull from their durable cursor and reconcile periodically. Google documents that Drive change notifications do not carry the full changes and that notification channels require lifecycle management. [Change retrieval](https://developers.google.com/workspace/drive/api/guides/manage-changes), [notification channels](https://developers.google.com/workspace/drive/api/guides/push).

Avoid a thundering herd by coalescing hints, adding reconnect jitter, and limiting per-device catch-up concurrency. Backpressure a huge bootstrap independently from a small incremental fetch.

<a id="13-client-internals-and-offline-operation"></a>
## 13. Client internals and offline operation

### 13.1 Local components

```mermaid
flowchart TD
    F[Local filesystem] --> W[Filesystem watcher]
    W --> R[Reconciliation engine]
    SC[Periodic scan] --> R
    R --> D[(Local metadata and operation journal)]
    D --> U[Bounded upload scheduler]
    U --> API[Server APIs and object endpoints]
    API --> S[Change feed consumer]
    S --> D
    D --> M[Recoverable file materialization worker]
    M --> F
    R --> UI[Sync status and conflict UI]
```

The local store records server file ID, local path, base revision, observed metadata generation, local fingerprint, pending operation IDs, cursors, and materialization status. It is the device's recovery journal.

### 13.2 Watchers are hints too

Filesystem watchers can coalesce events, overflow buffers, miss changes during shutdown, or represent an editor's save as temporary-file creation plus rename. Periodic reconciliation scans repair missed observations. Avoid uploading a temporary half-written file as a complete user edit.

Use a stable read strategy: open the file, record metadata, stream/hash it, and check whether it changed during reading. If it did, retry or use an OS snapshot where available. A file being open is not proof it is stable. Debouncing reduces redundant work but does not prove correctness.

### 13.3 Do not overwrite local pending work

On a remote revision event, compare local state with the last synchronized base. If the local file has no uncommitted edits, download the new revision. If it has edits, preserve both states and run the conflict protocol. A remote update is not permission to discard local bytes.

Suppress feedback loops using expected materialization records and content identities, not only a fragile “ignore the next watcher event” flag. The filesystem may emit multiple events or an unrelated user edit may arrive between them.

### 13.4 Crash-safe file installation

Download into a temporary file on the same filesystem, validate length and checksum, flush according to the required local durability contract, and atomically rename into place when the platform permits. Parent-directory durability may require its own synchronization on some filesystems.

The filesystem and local database do not share a transaction. Journal intent before installation, perform the operation, then mark it complete. If the process crashes after rename but before marking completion, recovery checks the installed identity/content and finishes the journal operation idempotently. It must not overwrite new user edits that occurred after the crash.

### 13.5 Offline edits

Each queued edit remembers the server base revision and a stable operation key. On reconnect, refresh permission and lifecycle state, fetch remote changes, and compare bases. Uploading local content first can be acceptable for staging, but publication still requires conflict checks.

If the remote file was deleted, offer recovery as a new file after authorization; do not silently undelete the old identity. If access was revoked, preserve unsent local work according to local privacy policy and show an actionable status. Do not send unauthorized content into the old namespace.

### 13.6 Cross-platform details

| Issue | Required handling |
|---|---|
| Case sensitivity | Detect local collisions such as `Readme` versus `README`; use visible safe mapping. |
| Unicode normalization | Preserve display names and compare under a defined namespace policy. |
| Reserved names and path length | Map or report names the local OS cannot represent. |
| Symlinks | Define whether they are unsupported, represented as links, or followed under explicit bounded rules. |
| Hard links | Decide whether identity is preserved or synchronized as independent files. |
| Sparse files | Avoid unintentionally materializing enormous zero-filled ranges without a policy. |
| Permissions and extended attributes | Define a portable subset; do not imply full filesystem backup semantics. |
| Disk full | Keep pending work and cursor/job consistency; avoid replacing a good local file with a partial one. |
| Selective sync | Track omitted content as intentional, not as a local deletion. |
| On-demand placeholders | Fetch content upon access while preserving identity and offline status. |
| Battery and metered links | Pause or throttle large transfers without losing durable progress. |

For a senior interview, mention at least watcher loss, atomic installation, local journals, filename differences, and conflict preservation. These are central to real sync behavior.

<a id="14-sharing-and-authorization"></a>
## 14. Sharing and authorization

### 14.1 Effective permission

Define roles such as viewer, editor, and owner/admin. A separate share-management capability can avoid accidentally granting every editor the right to expand access. Effective access combines direct grants, permitted ancestor grants, namespace membership, and group membership under the chosen policy.

The baseline uses allow grants with inherited access and lifecycle restrictions; it does not silently assume a full deny-rule language. If explicit denies, limited-access folders, or enterprise restrictions are introduced, specify precedence and inheritance boundaries.

A shortcut grants access to the shortcut object only; resolving its target requires target authorization. Moving a file can change inherited permissions even though its content and file ID stay the same.

Google's public permission model distinguishes roles and inherited/direct permissions. The simplified roles and namespace rules here are our design choices, not a full reproduction of that model. [Public sharing reference](https://developers.google.com/workspace/drive/api/guides/manage-sharing).

### 14.2 Permission checks and cached data

A cached allow decision needs a freshness strategy. The baseline advances a namespace `authz_epoch` on relevant grant or membership changes. Cached evaluations are tagged with that epoch, but a request must learn the **current** epoch from an authority meeting the freshness requirement. Comparing against another stale cache does not solve revocation.

This coarse epoch invalidates many entries but makes the correctness argument simple. At scale, use finer resource/relationship versions and dependency tracking. Group changes must invalidate decisions depending on the group, including nested membership where supported. Bound nesting and detect cycles.

### 14.3 Revocation sequence

```mermaid
sequenceDiagram
    participant O as Owner
    participant A as Policy API
    participant D as Metadata authority
    participant C as Former collaborator
    participant G as Download gateway
    O->>A: Revoke grant with operation key
    A->>D: Transactionally remove grant and advance authz epoch
    Note over D: Also append scope withdrawal and audit events
    D-->>A: Revocation committed
    A-->>O: Success
    C->>G: Use previously issued revision capability
    G->>D: Check current effective permission
    D-->>G: Deny if no other grant remains
    G-->>C: Access denied
```

Removing one grant does not necessarily remove all effective access: the user may still belong to an authorized group or have another direct grant. The UI and audit should distinguish revoking one grant from verifying no remaining access paths.

### 14.4 Permission/content ordering

Consider: remove Bob, then upload a confidential revision. If a serving replica sees the new revision but uses the old ACL, it can leak the new content. The baseline avoids this by checking current policy in the same authoritative metadata domain. A separate distributed authorization system needs a consistency token or causal dependency that prevents evaluation against an authorization snapshot older than the content's required policy state.

The Zanzibar paper is a primary example of treating authorization and object changes as a consistency problem. The token scheme here is illustrative, not a reproduction of Zanzibar's full protocol. [Zanzibar paper and presentation](https://www.usenix.org/conference/atc19/presentation/pang).

### 14.5 Public links

A public sharing link is a deliberately granted capability, not an authentication shortcut. Use a high-entropy secret token, store an appropriate verifier rather than unnecessarily exposing raw tokens internally, scope the allowed operation, support rotation/revocation, and rate-limit abuse. Avoid revealing whether unrelated private file IDs exist.

If the gateway checks the current link grant on each new request, revocation follows the baseline contract. A downloadable copy already obtained remains outside server control. Passwords or link expiration are additional product features with their own storage and recovery requirements.

<a id="15-folders-names-moves-and-copies"></a>
## 15. Folders, names, moves, and copies

### 15.1 Parent IDs rather than path identity

Represent a folder as a file-like metadata object with `kind = FOLDER`. Children refer to its stable ID. A same-namespace folder rename changes one row; descendant paths can be reconstructed by following parents or using a derived path index. A derived full-path index must update asynchronously or be versioned, but it does not establish identity or authorization.

Shortcuts can provide graph-like navigation without turning the physical containment hierarchy into a graph. Detect shortcut resolution loops and authorize each target appropriately.

### 15.2 Atomic move within a namespace

```mermaid
sequenceDiagram
    participant C as Client
    participant M as Metadata service
    participant D as Metadata authority
    C->>M: Move folder A under B with expected generation
    M->>D: Begin transaction and lock hierarchy generation
    M->>D: Check source and destination authorization
    M->>D: Check current generation, lifecycle and destination name
    M->>D: Walk B ancestors and reject if A is encountered
    M->>D: Update parent, hierarchy generation and authz epoch
    M->>D: Append move and subtree policy-change events
    D-->>M: Commit
    M-->>C: New metadata generation
```

Checking for a cycle outside the transaction is unsafe: concurrently moving A under B and B under A can each look valid against old state. The baseline serializes hierarchy changes through the namespace hierarchy row and validates ancestors within that transaction. This is simple but limits structural-write throughput in huge namespaces.

Check permission to remove from the old parent and insert into the new parent, plus file-specific restrictions. Moving into a differently shared folder can expand or reduce access. Product policy may require an explicit warning or forbid certain ownership/security-boundary transitions.

### 15.3 Folder deletion without updating a million children

Mark the subtree root trashed in one transaction, emit a subtree event, and make lifecycle checks consider ancestor state. Descendants become logically hidden even while their own rows remain unchanged. A background worker can enumerate descendants for indexes, quota accounting, or later purge.

All access paths must observe the ancestor restriction, including direct file-ID reads and old shared links. Hiding a folder only in the folder-listing UI leaves a serious correctness gap. Children cannot be moved out concurrently to evade deletion unless the transaction policy explicitly permits that ordering.

### 15.4 Copy

A same-namespace copy can reference an immutable manifest without copying every byte. Create new file/revision IDs, add a protected manifest reference, charge logical quota, and commit metadata atomically. The new file has an independent lifecycle and defined permission inheritance; deleting the source does not delete the copy's live content.

A deep folder copy is a resumable job with a documented source snapshot. Otherwise a folder changing during copy may produce an incoherent mixture. Expose progress and partial-job cleanup behavior. Do not hold one database transaction for the entire tree.

### 15.5 Cross-namespace move

Moving across namespaces can cross quota, region, encryption, ownership, and transaction boundaries. The baseline treats it as a copy-then-delete workflow with a durable operation record:

1. Authorize source read/export and destination creation.
2. Reserve destination quota and capture the source revision/tree snapshot.
3. Reuse or copy content only if policy, residency, and encryption permit it.
4. Publish destination metadata and verify durable completion.
5. Conditionally trash the source if its expected generation still matches.

There may be a period with two copies. If the source changed, leave both and report the conflict. If the requirement is a truly atomic cross-namespace move, introduce a stronger distributed transaction or explicit indirection protocol and discuss the added availability and recovery costs.

<a id="16-deletion-retention-and-garbage-collection"></a>
## 16. Deletion, retention, and garbage collection

### 16.1 User-visible deletion is not physical reclamation

```mermaid
stateDiagram-v2
    [*] --> ACTIVE
    ACTIVE --> TRASHED: authorized trash transaction
    TRASHED --> ACTIVE: restore with name and parent checks
    TRASHED --> PURGE_PENDING: retention allows permanent purge
    PURGE_PENDING --> LOGICALLY_PURGED: remove retained revision roots
    LOGICALLY_PURGED --> PHYSICALLY_RECLAIMED: safe background deletion
    PHYSICALLY_RECLAIMED --> [*]
```

Trash preserves content and counts toward quota in this design. Purge removes the user's retained references according to policy. Physical reclamation may occur later, and other files may still reference the same bytes. A legal or enterprise hold, if part of the product requirements, can prevent purge even when an ordinary user requests it; the API must explain the actual state.

Restore needs a valid destination parent and a nonconflicting name. If the original parent is gone, offer a recovery folder or an explicit destination. Do not pretend a successful restore recreates a nonexistent hierarchy automatically.

### 16.2 Tombstones and old devices

A tombstone records deletion identity, generation, and synchronization relevance. It allows devices to distinguish “the file was deleted” from “I have not listed it yet.” A deleted item omitted from a listing is insufficient for reliable incremental sync.

After feed retention expires, a full snapshot reconciles the live set. Stale writes still require a valid current file/base and cannot recreate purged identities. Keep compact deletion knowledge or an allocation policy that distinguishes never-issued, purged, and live IDs as needed for the API and replay horizon.

### 16.3 Why a grace period alone is insufficient

Imagine a collector observes zero references, waits an hour, and deletes. A new revision may have attached the blob during that hour. An arbitrary delay does not prove the absence of concurrent users.

The catalog must serialize the transition to deletion with attaching new references. A concrete protocol is:

```text
LIVE:
    new pins or manifest references may attach under catalog transaction

DELETE_CANDIDATE:
    no retained root or valid operation pin exists
    a grace interval permits reconciliation and delayed-work checks

DELETING(generation G):
    transaction rechecks all protection and advances deletion generation
    no new reference may attach to this object generation

DELETED:
    physical deletion confirmed for exact storage generation
```

A would-be new reference that races with `DELETING` must fail, create a fresh object generation, or safely cancel deletion through a protocol that fences any already dispatched deletion. The simplest choice is not to reuse a deleting generation.

### 16.4 Collector sequence

```mermaid
sequenceDiagram
    participant J as Collector
    participant D as Metadata and blob catalog
    participant B as Object storage
    participant P as Concurrent publisher
    J->>D: Find old unreachable candidates
    P->>D: Try to attach live generation reference
    alt Publisher attaches first
        D-->>P: Reference committed
        J->>D: Conditional transition to DELETING
        D-->>J: Reject because object is protected
    else Collector fences first
        J->>D: Commit DELETING generation G
        D-->>P: Reject reuse of deleting generation
        J->>B: Delete exact immutable storage generation
        B-->>J: Deleted or already absent
        J->>D: Mark deletion complete if generation still G
    end
```

This diagram assumes the catalog reference and deletion-state operations are in the same authoritative transaction domain. If the catalog is independently sharded, the design needs a durable reservation/lease protocol spanning those domains; a casual eventually updated refcount is not enough.

### 16.5 Protect uploads, manifests, and readers

Open uploads protect their content roots until expiration or abort. Publication converts protection to retained revision reachability atomically. Conflict uploads retain protection for their bounded resolution window. Preview generation and export jobs either retain a temporary pin or tolerate a safe cancellation when the source becomes unavailable.

Active downloads need a policy as well. Acquire a bounded read lease/pin if physical deletion must not interrupt a transfer, or define that an already opened storage stream survives unlink while new ranges may fail. Do not let unbounded client activity hold storage forever; leases and maximum transfer/session durations bound reclamation delay.

### 16.6 Reconciliation and conservative deletion

Use exact transactionally maintained references for normal operations and periodic reachability checks for repair. Compare retained revision roots, manifests, pins, and storage inventory. A mark-and-sweep implementation must account for concurrent new references, for example with a snapshot plus write barrier or generation protocol; snapshot age alone is not sufficient.

If reference accounting is uncertain, retaining extra bytes is safer than deleting live content. Alert and repair the discrepancy. Quota accounting and physical storage accounting are separate: the former reflects the product's logical charging policy, while the latter detects leaks and capacity risk.

### 16.7 Backups and deletion policy

Backups may retain purged bytes until backup retention expires. Document the recovery and deletion contract rather than promising immediate erasure of every copy. Restoration applies a durable deletion ledger or equivalent policy state so old backups cannot resurrect permanently removed items into active service.

Encryption-key destruction can make some retained ciphertext unusable, but shared keys or shared deduplicated chunks complicate per-file erasure. Key granularity must match the promised deletion granularity.

<a id="17-quota-and-accounting"></a>
## 17. Quota and accounting

### 17.1 Reserve before expensive work

```text
available = quota_limit - used_logical_bytes - reserved_bytes

initiate session of declared size S:
    transactionally require available >= S
    reserved_bytes += S

commit actual size A, where A <= reservation or reservation is atomically extended:
    reserved_bytes -= session_reservation
    used_logical_bytes += A

abort or expire uncommitted session:
    reserved_bytes -= session_reservation exactly once
```

Two uploads must not independently read “10 GB available” and both reserve 8 GB. The quota check and reservation update share one transaction. A completion retry cannot charge again because quota conversion and the stored operation outcome commit together.

### 17.2 Revisions, copies, and deletion

Replacing a 1 GB file with another 1 GB revision increases retained usage by 1 GB if the old revision remains. Copying a file can also increase logical usage even if content is physically shared. Trashing does not release usage in the baseline. Purging retained revisions releases their logical usage exactly once, independent of when physical bytes are reclaimed.

If the product instead bills only the current head, change the accounting contract explicitly. That simpler displayed number can hide substantial physical version-history cost and requires separate retention limits.

### 17.3 Reservation abuse and expiry

Cap concurrent sessions, reserved bytes, part count, transfer lifetime, and initiation rate per principal and namespace. Expiration jobs use conditional state transitions so they cannot release quota already converted by a concurrent commit. Aborted sessions do not continue to authorize fresh part capabilities.

The server measures actual bytes and rejects attempts to exceed the reservation without a successful extension. Never trust the client-declared length as the final accounting source.

### 17.4 Scaling a hot quota row

A namespace quota counter is a write contention point. A later design can allocate bounded quota credits to partitions, with the sum of allocated credits no greater than the namespace's available quota. This provides a hard upper bound while reducing per-upload coordination, at the cost of stranded credits and rebalancing complexity. Approximate counters alone cannot enforce a strict hard limit.

Reconcile usage from retained revision records and operation history. Keep physical usage, logical billed usage, and reservations as distinct metrics.

<a id="18-search-previews-and-notifications"></a>
## 18. Search, previews, and notifications

### 18.1 Indexing pipeline

```mermaid
flowchart LR
    C[Committed revision or metadata event] --> V[Version-aware consumer]
    V --> A[Check lifecycle and processing policy]
    A --> X[Sandboxed text extraction]
    X --> I[(Search index)]
    A --> P[Sandboxed preview generation]
    P --> B[(Versioned preview objects)]
    Q[Search query] --> I
    I --> F[Current authorization and lifecycle filtering]
    F --> R[Authorized results and snippets]
```

Index filename, relevant metadata, and supported extracted text. Use `(namespace, file_id)` as document identity and record the indexed revision/generation. An older worker completion must not replace a newer index record. Tombstone events remove documents, but query-time authorization and lifecycle checks remain necessary during indexing lag.

### 18.2 Search under permission changes

Permission filtering after candidate retrieval prevents returning unauthorized candidates, but requires careful pagination. Overfetch candidates, authorize in bounded batches, and continue from an opaque search position until the response page is filled or limits are reached. Do not reveal unauthorized snippets, raw totals, facets, or debug scores before filtering.

If authorization is unavailable, fail closed for private search results. A stale search index may omit a newly accessible document, which is a freshness problem; it must not disclose a document whose access was removed, which is a privacy problem.

### 18.3 Content scanning

New revisions start `PENDING_SCAN`; a version-specific result transitions them to `ALLOWED` or `BLOCKED`, with an explicit policy for unsupported or inconclusive formats. An owner may be allowed to see metadata while bytes remain quarantined. Scanner downtime queues work and increases time-to-usable; it does not silently treat unknown content as clean under the baseline policy.

Scanners consume hostile input. Run them in isolated environments with CPU, memory, time, output-size, recursion, and network limits. Bound decompression and archive nesting. A scan is one defense layer, not proof that a file is harmless forever; policy updates can require rescanning.

### 18.4 Previews

Generate previews from an exact revision using a transformation version. Cache their immutable outputs. Recheck authorization when delivering them; previews are content, and thumbnails can leak sensitive information. Unsupported formats return a clear fallback rather than blocking the entire file service.

### 18.5 Notifications

Coalesce frequent edits into hints. Notify only currently authorized subscriptions; avoid putting confidential names or snippets in lock-screen pushes unless product policy allows them. Handle token rotation, channel expiration, duplicate registration, and dead devices.

A massive shared namespace favors shared log subscriptions over copying full events to every member. Notification delivery metrics measure latency improvement; feed reconciliation establishes correctness even when a hint is lost.

<a id="19-partitioning-and-scaling"></a>
## 19. Partitioning and scaling

### 19.1 Start with namespace ownership

Route namespace metadata to an owning partition through a versioned directory. A personal drive and a team drive can each be a namespace. Related metadata, quota, grants, and change sequencing stay together initially. Content objects distribute independently because their IDs do not need to follow folder locality.

```mermaid
flowchart TB
    C[API request with namespace ID] --> R[Versioned namespace directory]
    R --> A[Metadata partition A]
    R --> B[Metadata partition B]
    R --> C2[Metadata partition C]
    A --> DA[(Namespace set A)]
    B --> DB[(Namespace set B)]
    C2 --> DC[(Namespace set C)]
    A --> O[Shared distributed object storage]
    B --> O
    C2 --> O
```

This is preferable to blindly hashing file IDs when most operations involve folder listings, shared policy, and per-namespace quota. It is not a claim that one database server can hold an arbitrarily large enterprise namespace.

### 19.2 The first scaling limits

| Bottleneck | Signal | Possible next step |
|---|---|---|
| Namespace sequence/quota row | Lock wait and mutation latency concentrated in one namespace. | Partitioned logs, transactional commit ordering, or quota credits. |
| Huge folder listing | Expensive ranges, deep pagination, slow authorization. | Subpartitioned child index with deterministic merge and snapshot tokens. |
| Viral download | Origin egress and repeated identical content reads. | Immutable edge caching, request coalescing, origin shields. |
| Many tiny files | Object request cost, row count, metadata IOPS. | Internal packing with an index and safe lifecycle handling. |
| Large sharing fanout | Notification queue grows with member count. | Shared namespace logs and coalesced hints. |
| Hot authorization graph | Repeated nested-group expansion and policy reads. | Versioned evaluation caches and batch checks. |
| Reconnect storm | Auth and snapshot APIs saturate together. | Jitter, admission budgets, checkpointed catch-up, fair scheduling. |

### 19.3 Scaling a giant namespace

Partition metadata by subtree or file-key range while preserving a logical namespace. This changes several protocols:

- Cross-partition moves require distributed transactions or a documented workflow.
- Quota needs a central reservation authority or bounded partition credits.
- Change feeds need multiple partition positions or a correctly ordered global commit index.
- Consistent bootstrap needs a distributed snapshot or a coordinated snapshot barrier.
- Authorization involving ancestors must see compatible hierarchy and policy versions.

A scalar sequence assigned before distributed commits is unsafe unless the feed only advances through a known complete committed prefix. A vector cursor can instead track a position per partition, but topology changes require translating positions and retaining migration lineage. Do not replace one namespace counter with “timestamps” and assume all gaps disappear.

### 19.4 Directory and hierarchy choices

A materialized path makes subtree lookup convenient but moves expensive. Parent pointers make moves cheap but ancestor evaluation more expensive. Closure tables precompute ancestry but can require many updates on moves. Select the representation based on depth, move frequency, subtree size, and transaction requirements.

For the baseline, parent pointers plus indexed children and bounded-depth ancestor reads are sufficient. Cache ancestry under hierarchy versions. Do not use a stale ancestor cache for a security-sensitive decision without validating its generation.

### 19.5 Partition migration

Copy a consistent namespace snapshot to the destination, stream subsequent changes, verify catch-up, fence the source at a new routing epoch, and switch ownership. A stale route returns a redirect or retryable response with the new epoch. Idempotency records, upload sessions, quota reservations, and blob protections migrate with the authority.

Migrating only file rows would leave old sessions able to publish against stale quota or policy. Define which side owns in-flight operations at every stage and how clients recover after a routing change.

### 19.6 Fairness

Maintain separate budgets for metadata reads, commits, large transfers, bootstrap enumeration, scanning, and optional previews. A namespace uploading millions of tiny files should not starve a user trying to recover an already uploaded file. Apply admission control using estimated resource cost where request count alone is misleading.

<a id="20-multi-region-operation-and-disaster-recovery"></a>
## 20. Multi-region operation and disaster recovery

### 20.1 Baseline deployment

Each namespace has a home metadata region with replicas across independent availability zones. Writes use an appropriate majority-backed transactional authority. Content is acknowledged only after its configured zone-survival requirement is met. Remote copies are asynchronous unless the namespace selects a stronger durability tier.

```mermaid
flowchart LR
    U[Global users] --> E[Nearby API and content edge]
    E --> H[Home-region metadata leader]
    H --> Z1[(Zone A replica)]
    H --> Z2[(Zone B replica)]
    H --> Z3[(Zone C replica)]
    E --> B[(Home-region durable content)]
    Z1 -. asynchronous protected history .-> R[(Remote metadata recovery state)]
    B -. asynchronous content copy .-> RB[(Remote content)]
    R --> F[Controlled regional recovery]
    RB --> F
```

The diagram is logical: the leader belongs to a replication group rather than adding an unexplained fourth voter. The exact placement and storage acknowledgement policy must be verified for the chosen backend.

Nearby edges improve connection setup and cached downloads. They do not remove the round-trip to the authoritative metadata region for a strongly ordered mutation or fresh authorization check. A traveling user can therefore have higher metadata latency.

### 20.2 Metadata and bytes must recover together

Track a remote recoverable watermark at which both metadata and all referenced content satisfy the disaster-recovery policy. A metadata checkpoint alone is insufficient if it references blobs not yet copied. Track object replication acknowledgements and the relationship to retained manifests.

If metadata is ahead of content after a disaster, mark affected revisions unavailable and recover them; never claim they are healthy or fabricate an empty file. If a region was lost before asynchronous copy completed, the baseline's stated RPO admits possible loss. That limitation must be visible in the contract.

### 20.3 Safe failover

1. Detect the incident and distinguish suspicion from confirmed ownership transfer.
2. Establish a new ownership epoch through a safe control-plane mechanism.
3. Fence the old region from committing writes or publishing stale outcomes.
4. Determine the recoverable metadata/content boundary.
5. Verify authorization, revocation, deletion, key access, and idempotency state.
6. Reopen permitted operations gradually, with bounded replay and cache warmup.

A witness can help establish ownership but does not contain missing file bytes merely because it voted. A quorum arrangement that survives a region outage must also have sufficient data and metadata placement to serve the workload safely.

### 20.4 Authorization after an RPO event

An older recovery snapshot may restore a grant that was revoked just before the outage. This is a privacy issue, not just an old filename. The baseline does **not** automatically resume private serving from an unverified stale policy snapshot. Affected scopes remain denied or unavailable until policy history is known to be safe.

If fast regional failover is required, durably replicate the necessary authorization/revocation and deletion history across regions before acknowledging those policy changes, or use a globally consistent policy authority. This adds a synchronous dependency for policy operations even if ordinary content replication remains asynchronous.

Likewise, lost idempotency outcomes can make replay ambiguous. Preserve the required operation history within the recovery guarantee, or quarantine uncertain operations instead of blindly replaying them. The baseline safety promises are evaluated within the declared node/zone fault model; regional recovery with accepted data loss requires explicit treatment of these lost-history cases.

### 20.5 Zero regional RPO extension

Before acknowledging publication, ensure both its content and its metadata decision are durable in a configuration surviving complete loss of the home region. That may require synchronous remote content replication and a consensus/transaction topology spanning regions. A remote copy of content alone does not preserve the file head or permission state.

The tradeoffs are inter-region latency, cost, and lower write availability when the required remote participants are unreachable. A product can expose tiers with different durability/latency promises, but must not call an asynchronously replicated tier zero-RPO.

### 20.6 Backups and restore exercises

Use independent retained metadata backups, content recovery mechanisms, key backups or recoverable key access, and tested replay of deletion and policy state. Protect backups from the same credentials and automation errors that could damage production.

Restore a namespace into an isolated environment, verify manifests and checksums, apply subsequent logs and deletion records, rebuild derived indexes, and validate access using test principals. Measure throughput, not just whether the first file restores. Large recovery may need prioritization: metadata and most-used recent files before a full cold corpus.

<a id="21-security-privacy-and-abuse"></a>
## 21. Security, privacy, and abuse

### 21.1 Threat model

| Threat | Design response |
|---|---|
| Guessing another user's file ID | Authorize every resource and operation; scope all lookups. |
| Forging part completion | Verify backend receipts, exact generations, length, and checksum. |
| Swapping a manifest entry to another user's blob | Bind blobs to authorized session/namespace roots; validate references. |
| Reusing a stolen capability | Narrow scope, bounded lifetime, optional identity binding, current gateway policy. |
| Uploading huge undeclared content | Enforce receiver-side byte limits and reserved quota. |
| Reserving quota indefinitely | Session caps, expiry, per-principal budgets, idempotent cleanup. |
| Malicious archives or parsers | Sandboxing, bounded extraction, no unnecessary network access. |
| Preview-based data leak | Same current resource authorization as original content. |
| Global hash-existence probing | Avoid public cross-tenant deduplication oracles. |
| Credential leakage through logs | Redact tokens and sensitive content; tightly scope operational access. |
| Shared-link spam or download abuse | Creation limits, anomaly detection, egress budgets, abuse workflows. |
| Ransomware-like sync changes | Retained revisions, bulk-change detection, user recovery tools. |

### 21.2 Encryption

Use authenticated transport. Protect stored content and metadata using an explicit key hierarchy, with least-privilege access to key services. Keep decryption capability available under the chosen disaster-recovery scenario; otherwise replicated ciphertext cannot satisfy recovery objectives.

Encrypt objects with authenticated schemes and version the encryption metadata. Key rotation, revocation, and re-encryption must not mutate an object behind an immutable revision identity without a safe mapping/version transition. Audit key use and separate service identities by responsibility.

### 21.3 Browser safety

Serve arbitrary user content from a controlled content origin rather than a privileged application origin. Set appropriate content disposition and content-type handling. Treat filenames as untrusted input when forming headers or local paths. Prevent path traversal during archive extraction and client materialization.

Upload capabilities must be protected from cross-origin misuse according to the authentication model. Cross-origin resource sharing is not a substitute for authorization. A server-side import-from-URL feature adds SSRF risks and requires egress controls; it is outside the baseline unless requested.

### 21.4 Privacy and enterprise extensions

Clarify residency, audit retention, organization ownership, external sharing restrictions, data-loss-prevention workflows, and administrative recovery. Tenant policy can be stricter than an individual's grant. Shared drives may need organization-owned files that survive an employee's departure.

Do not claim a universal legal deletion deadline. Treat jurisdiction-specific and contractual requirements as explicit inputs, then map them to retention, backup, key, and audit mechanisms.

<a id="22-reliability-and-failure-matrix"></a>
## 22. Reliability and failure matrix

| Failure or race | User-visible behavior | Required mechanism |
|---|---|---|
| API process crashes | Request may be retried. | Stateless routing plus durable operation records. |
| Metadata leader fails | Brief retryable unavailability. | Safe election and fenced old owner; no conflicting heads. |
| One storage zone fails | Committed files remain accessible under baseline promise. | Verified placement and sufficient surviving content. |
| Part acknowledgement is lost | Upload resumes without duplicate logical parts. | Exact part identity and durable status query. |
| Completion response is lost | Client recovers the same revision. | Outcome stored with publication. |
| File changes during upload | Stale edit becomes a conflict. | Expected-head transaction and protected staged content. |
| Target folder is trashed mid-upload | Publication rejects or follows a new explicit target action. | Current ancestor lifecycle check. |
| Permission revoked mid-upload | Staging may finish; publication denies. | Current commit-time authorization. |
| Notification connection drops | Device catches up later. | Durable feed, cursor, periodic polling. |
| Event broker unavailable | Core metadata can continue while capacity allows. | Durable outbox; backlog limits and admission before disk exhaustion. |
| Outbox event delivered twice | No duplicate logical consumer effect. | Event ID or generation-aware application. |
| Scanner down | New content remains pending; safe existing files still work. | Quarantine state and isolated worker capacity. |
| Search down | Direct file operations continue; search reports unavailable. | Derived-state isolation. |
| Cache cluster lost | More origin work; controlled degradation. | Coalescing, origin protection, and tested fallback capacity. |
| Authorization authority unavailable | Sensitive new reads and writes deny or return unavailable. | Fail-closed policy for private resources. |
| Local disk full | Sync pauses with recoverable pending work. | Journal and safe temporary-file handling. |
| Device offline beyond retention | Bootstrap and reconcile local pending edits. | Expired-cursor protocol, no blind overwrite. |
| Old GC worker resumes | It cannot delete a newly protected generation. | Catalog fencing and generation-conditional deletion. |
| Metadata corrupts logically | Scope may be quarantined and restored. | Independent backups, invariant checks, audited repair. |
| Entire region fails | Controlled recovery within declared RPO/RTO. | Ownership fencing and compatible metadata/content/policy recovery. |

### 22.1 Overload policy

Protect already accepted work. Prioritize lightweight metadata, permission changes, session status, and valid finalization over speculative indexing or previews. Throttle initiation when reservations, outbox storage, or scanner backlogs threaten capacity. An unbounded staging area is not a sustainable solution to worker failure.

Use separate pools for long transfers and small API calls. Bound request bodies, manifest size, open sessions, worker concurrency, and per-namespace resource use. Return actionable retry instructions with jittered backoff.

### 22.2 Corruption and repair

Verify checksums during ingress and periodically scrub stored content. On mismatch, isolate the bad replica/fragment, retrieve a valid copy, and repair with generation checks. A hash stored beside corrupted data is useful only if its integrity is independently protected or compared against trusted manifest metadata.

Repair priority depends on remaining redundancy and user demand. Track how long objects remain below the durability target. Repair itself consumes bandwidth and can interfere with live traffic; reserve capacity rather than assuming it is free.

### 22.3 Backlog recovery

If scanning receives 1,000 tasks/s but runs at 800 tasks/s during an incident, backlog grows by 200/s. Restoring only 1,000/s capacity stops growth but never drains it. Recovery needs spare throughput, prioritization, and an estimate of drain time. Communicate delayed usability separately from data-loss risk.

<a id="23-observability-and-verification"></a>
## 23. Observability and verification

### 23.1 Metrics tied to guarantees

| Area | Measure |
|---|---|
| Publication | Initiation success, completion success, commit latency, ambiguous-outcome recovery, duplicate suppression. |
| Transfer | Throughput, retry bytes, aborted bytes, part latency, failure by size/network class. |
| Synchronization | Commit-to-discovery lag, cursor age, bootstrap duration, expired cursors, conflict rate. |
| Authorization | Decision latency, stale-version rechecks, revocation propagation, unexpected allow/deny changes. |
| Content safety | Pending age, scan failures, blocked results, parser resource violations. |
| Storage | Durability deficit, checksum mismatch, repair backlog, orphan bytes, reclaim delay. |
| Accounting | Logical usage versus reconciliation, reserved bytes, expired reservations, charge corrections. |
| Work pipelines | Oldest event age, per-stage lag, dead letters, repeated processing failures. |
| Recovery | Remote safe watermark lag, backup age, restore throughput, verified recovery duration. |

Measure end-to-end scenarios with synthetic accounts: upload a known file, observe it from a second device, download and compare its digest, change permissions, confirm access is denied, then restore or clean up through normal paths. Synthetic probes complement real user SLIs; they do not replace them.

### 23.2 Trace one operation

Carry an operation ID across initiation, part requests, validation, publication, outbox events, scan jobs, and sync observation. Use separate attempt IDs for retries. Record stable identifiers and stage timings while avoiding file contents, bearer URLs, and unnecessarily sensitive names.

For a “sync is stuck” support case, be able to determine whether bytes are transferring, validation is pending, publication conflicted, scanning is blocked, a device cursor is old, or local materialization failed. One generic “upload error” metric cannot answer that.

### 23.3 Invariant tests

1. Two simultaneous completion calls produce one revision and one logical quota charge.
2. Two writers from the same base cannot both become its successful next head.
3. Every committed revision's manifest points to existing, validated, protected generations.
4. Publication and expiration racing cannot both consume/release the same reservation.
5. A revocation completed before new authorization prevents access absent another grant.
6. Concurrent folder moves cannot create a cycle.
7. Client cursor advancement cannot skip durable pending materialization work.
8. Duplicate or reordered indexing events cannot regress the indexed generation.
9. A collector cannot delete an object generation after a valid reference attaches first.
10. Restoring backup state cannot reactivate permanently deleted data or revoked access without policy reconciliation.

These are properties, not merely examples of ordinary success. Exercise many interleavings using model-based or property-based testing and targeted fault injection.

### 23.4 Workload tests

Include many tiny files, maximum-size files, deep folder trees, huge flat folders, many revisions of one file, massive shared folders, popular public links, interrupted mobile uploads, old-device reconnects, and simultaneous client upgrades. Test cache loss, notification loss, scanner backlog, and large restores while normal traffic continues.

A preview worker parsing one adversarial archive can exhaust memory despite a healthy average workload. A single large namespace can saturate a lock while the fleet appears idle. Inspect per-scope and tail behavior.

### 23.5 Model the client too

Generate operation sequences involving local edit, remote edit, rename, delete, permission loss, process crash, disk full, and reconnect. The reference model should distinguish server head, local base, pending local content, and applied metadata. Verify that every user edit is either published, deliberately discarded, or preserved as recoverable conflict work.

<a id="24-cost-and-optimization"></a>
## 24. Cost and optimization

### 24.1 Cost model

```text
storage cost = retained physical GB × unit storage price
transfer cost = user egress + origin-to-edge + cross-region replication
request cost = part writes + range reads + metadata/catalog requests
compute cost = hashing + encryption + scanning + previews + indexing
operating cost = backups + repair + observability + engineering complexity
```

Prices are deliberately omitted; they vary by provider, region, tier, and contract. Compare options with measured workload and current pricing when making a real purchase decision.

### 24.2 Optimize in an evidence-based order

Reduce abandoned staging bytes and needless retransmission. Cache repeated immutable downloads. Tune chunk size for the file-size and network distribution. Move cold retained content to suitable storage policies. Only then consider more complicated reuse mechanisms where their expected savings justify reference tracking and privacy costs.

Logical storage saved is not the only metric. A delta-transfer scheme may save upload bandwidth but increase reconstruction CPU, random reads, and dependency chains. Cap delta-chain length or periodically materialize full revisions so old-version recovery remains predictable.

### 24.3 Small-file packing

Packing small objects into larger immutable containers can reduce request and per-object overhead. The index maps each logical chunk to container, offset, and length. Individual deletion then creates dead space rather than immediately deleting a whole object. Compaction rewrites live entries into a new container and atomically updates mappings before reclaiming the old one.

Packing introduces a shared failure and reclamation unit. Keep generation-aware mappings, protect readers during compaction, and account for temporary duplicate space. Avoid adding it to the baseline without evidence that tiny-file overhead dominates.

### 24.4 Replication versus erasure coding

Three copies imply approximately 3× payload overhead. An ideal 10+4 erasure layout uses 1.4×, before placement, metadata, slack, and small-object effects. The code must support the promised recovery property and fragments must be placed across the intended fault domains.

Erasure coding can make cold storage cheaper but complicates repair, small reads, and degraded performance. A hybrid may replicate new/hot objects and later encode cold content. The transition needs a durable state machine that never drops the last sufficient recovery set before the new layout is verified.

<a id="25-extensions-and-changed-requirements"></a>
## 25. Extensions and changed requirements

### 25.1 Live collaborative editing

Binary-file sync detects whole-revision conflicts. A collaborative editor represents edits as operations on a structured document. It may use a central ordering service with transformation rules or a conflict-free replicated data type with a precisely defined merge algorithm.

The design must address operation identity, causal dependencies, offline edits, convergence, undo, cursor movement, document structure, compaction, and access revocation. Saying “use a CRDT” does not explain those decisions. Convergence does not automatically preserve every intuitive user intention, and arbitrary binary files do not become mergeable simply because their storage is versioned.

Keep the document service behind the file identity: the file entry points to a native document model, while exported PDF or office-file representations are derived artifacts. Define snapshot/export consistency separately from live editing.

### 25.2 End-to-end encryption

If clients hold keys unavailable to the server, encryption occurs before upload. Server-side plaintext search, malware scanning, preview generation, content-defined reuse, and recovery must change. Clients may build encrypted or local indexes and generate previews, but this creates key distribution, capability, leakage, and multi-device synchronization questions.

Sharing requires securely distributing access to decryption keys. Revoking server access cannot erase a key or plaintext already copied by a former collaborator; future revisions may require new keys. Account recovery and adding a device need an explicit trust and key-recovery design.

### 25.3 Offline-first with long disconnections

Long offline periods increase retained conflict history, pending local storage, and full-resync frequency. Reconcile object identity and base revisions rather than comparing only timestamps. A device must preserve local edits while discovering that remote folders, permissions, or quotas changed.

If an administrator demands immediate revocation on permanently offline devices, explain that server-side enforcement can prevent future service access but cannot guarantee deletion of already available offline plaintext.

### 25.4 Real filesystem or backup semantics

Supporting sparse files, hard links, POSIX permissions, extended attributes, application-consistent snapshots, and open databases moves the product toward backup or network-filesystem semantics. Ordinary file sync does not necessarily produce a transactionally consistent backup of a running database.

Clarify whether applications require locking, atomic multi-file updates, low-latency random writes, or coherent memory mapping. Those requirements can invalidate the immutable-upload-and-publish interface as the main access model.

### 25.5 Enterprise policy

Add organization ownership, external sharing controls, policy-scoped retention, administrator audit, delegated recovery, and data residency. Scope admin powers explicitly and audit them. An organization policy change can affect a huge subtree; use versioned policy evaluation and background convergence rather than millions of blocking mutations.

### 25.6 Other useful follow-ups

Consider offline mobile caches, shared-drive membership churn, bulk import/export, ransomware recovery, mass owner deletion, account transfer, region migration, and accessibility of conflict resolution. These can be independent interview deep dives. Explain which existing invariant carries over and which new state machine is required.

<a id="26-design-decisions-and-alternatives"></a>
## 26. Design decisions and alternatives

| Decision | Baseline | Alternative and reason to choose it |
|---|---|---|
| Metadata authority | Serializable namespace transactions with fresh sensitive reads. | Distributed SQL across namespace partitions when transactions must span larger scopes. |
| Content storage | Immutable objects and manifests. | Whole-object revisions for a simpler initial product with modest file sizes. |
| Upload | Independent bounded parts plus atomic final publication. | Sequential resumable byte ranges for simpler transfer state. |
| Edit conflict | Expected-head failure and preserved conflict work. | Application-specific merge for structured documents. |
| Client sync | Snapshot plus durable ordered changes. | Periodic full listing only for small datasets with loose latency needs. |
| Notifications | Best-effort hints. | No push initially; periodic polling with higher request cost/delay. |
| Authorization | Current policy in the metadata transaction domain. | Separate relationship authority with compatible consistency tokens. |
| Downloads | Gateway checks current access before cached byte delivery. | Direct signed URLs when bounded revocation is acceptable. |
| Chunking | Fixed-size chunks for large files. | Content-defined chunks after reuse benefits are measured. |
| Deduplication | No cross-user deduplication. | Scoped reuse with safe catalog references and privacy constraints. |
| Folder hierarchy | Parent pointers and serialized structural changes. | Distributed hierarchy/index designs for very large namespaces. |
| Deletion | Logical trash/purge, then fenced background reclamation. | More immediate physical deletion only if sharing and retention permit it. |
| Regional durability | Zone-safe commit plus asynchronous remote copy. | Synchronous cross-region durability for zero regional RPO. |
| Content safety | Commit as pending; gate downloads on checks. | Scan-before-publication if invisible pending uploads better match the product. |

The design is intentionally not optimal for every workload. Its value is that the contracts agree with one another. When replacing a baseline mechanism, revisit every guarantee that depended on it.

<a id="27-the-interview-presentation"></a>
## 27. The interview presentation

### 27.1 A concise opening

> “I will focus on storing arbitrary files, sharing them, and synchronizing multiple devices, including offline edits. I will keep live document collaboration as an extension. The main correctness goals are complete durable publication, no silent overwrite of concurrent work, and current authorization for content access. I will separate small transactional metadata from large immutable bytes.”

This establishes scope, priorities, and the central architectural boundary without spending several minutes naming technologies.

### 27.2 A 45-minute walkthrough

| Time | What to explain | Artifact |
|---|---|---|
| 0–5 min | Core journeys, offline scope, sharing, revocation, durability. | Requirements and invariants. |
| 5–8 min | Metadata QPS versus byte throughput and retained storage. | A few correct calculations. |
| 8–13 min | File identity, revision, manifest, session, namespace. | Small entity model and main APIs. |
| 13–19 min | Metadata authority, object storage, event feed, gateway. | Architecture and one read path. |
| 19–28 min | Resumable parts, validation, atomic publication, lost response. | Upload sequence and transaction boundary. |
| 28–35 min | Expected-head conflicts and snapshot-plus-feed synchronization. | Conflict and bootstrap sequences. |
| 35–41 min | Revocation, safe deletion, hotspots, region-loss contract. | One failure scenario and tradeoff table. |
| 41–45 min | Summarize guarantees, limitations, and next scaling step. | Explicit design conclusion. |

If the interviewer steers toward one topic, follow it while preserving a coherent baseline. A storage specialist may ask about coding and repair; a collaboration team may focus on offline merge; an infrastructure interviewer may emphasize failover and migrations.

### 27.3 A complete short upload explanation

> “I create an idempotent upload session and reserve quota. The client sends independently retryable parts directly to storage using scoped capabilities. I validate an immutable manifest against server-verified object generations. Then a short metadata transaction rechecks permissions, lifecycle, expected head, and quota, and atomically creates the revision, updates the head, retains the content root, stores the operation result, and appends the change event. If the response is lost, the same operation key returns the committed result. Unpublished content remains protected until the session expires safely.”

Be ready to expand any sentence. The content root is what prevents cleanup from racing publication. The expected head prevents silent overwrite. The result record handles uncertainty. The transactional event makes sync recoverable.

### 27.4 A complete short sync explanation

> “A new device reads a consistent metadata snapshot tied to a change watermark, then replays later changes. Existing devices pull from durable opaque cursors. They store the cursor together with local desired state and pending filesystem work. Push messages only reduce polling latency. Expired history causes a fresh bootstrap that preserves local unsynced edits. Permission grants require scope discovery and existing-content enumeration, while revocations withdraw scopes and block fresh content access.”

### 27.5 A strong ending

Summarize the enforced invariants and accepted limitations: authoritative metadata is coordinated; content is immutable; publication is conditional and idempotent; devices recover through history; current access gates content; deletion waits for proven unreachability. Then state the likely next bottleneck: namespace sequencing, quota contention, giant shared scopes, or bandwidth, depending on the workload.

Do not claim the design provides global active-active writes, instant offline erasure, and zero regional data loss if those mechanisms were not designed. A precise limitation is more credible than an unsupported promise.

<a id="28-question-bank-with-answer-checkpoints"></a>
## 28. Question bank with answer checkpoints

Use these as mock-interviewer prompts. Answer with a mechanism, its transaction or consistency boundary, and one failure case.

### Product and modeling

1. **What is the difference between Drive and object storage?** Drive adds identity, folders, permissions, revisions, quotas, synchronization, client behavior, search, and recovery over durable bytes.
2. **Why separate metadata from content?** They have different size, mutability, query, and bandwidth needs; explain publication across the boundary.
3. **Why give files stable IDs?** Rename and move preserve identity and references; paths are mutable presentation.
4. **Can folders have duplicate filenames?** It is a product decision. This baseline enforces normalized sibling uniqueness; explain collision behavior and do not claim it is actual Drive behavior.
5. **What does successful upload mean?** Distinguish transferred bytes, committed revision, and policy-approved usable content.
6. **Is metadata strongly consistent everywhere?** Sensitive operations use authoritative freshness and transactions; derived search, previews, and device copies can lag.
7. **What changes if folders can have multiple parents?** Containment becomes a graph; cycles, inherited permissions, listing, deletion, and move semantics all change.
8. **How do shortcuts work?** They reference a stable target but do not grant target access; detect loops and handle missing targets.

### Upload and download

9. **How do you upload a 100 GB file on an unreliable network?** Durable session, bounded parts, status queries, checksums, resumed transfer, quota reservation, and conditional publication; session lifetime must support the transfer.
10. **What happens if a part succeeded but its acknowledgement was lost?** Query verified progress or repeat the exact idempotent part operation; do not append a duplicate part.
11. **What if the final response is lost?** Recover the stored outcome by completion key; publication and result must have committed together.
12. **How do you know a client uploaded all bytes?** Verify exact immutable object generations, manifest coverage, lengths, checksums, and durability through trusted storage evidence.
13. **Can a client overwrite an uploaded part after validation?** Not in this design: create-only writes, pinned generations, or immutable sealing prevent it.
14. **Why not hold a transaction throughout upload?** Network transfer is long and failure-prone; hold short transactions around reservations and publication, with durable staged protection in between.
15. **What if the declared file size is wrong?** Measure bytes, reject over-limit parts, and atomically extend reservation or reject publication.
16. **How do you handle an empty file?** Explicit valid empty manifest and normal publication semantics, without inventing a missing content error.
17. **Why use chunks?** Retry granularity, bounded memory, range access, and optional reuse; account for object and manifest overhead.
18. **Why not use very small chunks?** More requests, metadata, hashing setup, scheduling, and storage operations; savings must outweigh overhead.
19. **Does multipart upload automatically provide deduplication?** No. Transfer parts, logical content chunks, and storage fragments are distinct abstractions.
20. **How do range downloads avoid mixing revisions?** Pin an immutable revision and validator for the whole transfer and all resumes.
21. **Can you use a CDN for private files?** Yes, with current authorization before byte exposure and immutable representation-aware cache keys.
22. **What happens if scanning fails?** Maintain explicit pending, blocked, or unsupported-policy state; do not equate scan failure with clean content.

### Concurrency and sync

23. **Two devices edit the same revision; who wins?** The first conditional publication wins; the second gets a conflict and preserves staged/local content.
24. **Why not use the latest modification time?** Clock skew and simultaneous intent make it an unreliable authority for preserving work.
25. **Can rename and content update proceed concurrently?** Usually yes through stable identity and separate content/metadata versions, with lifecycle and authorization rechecks.
26. **What if a file is deleted while an upload is running?** Publication checks current lifecycle and rejects stale resurrection; recovery as a new file is explicit.
27. **How does a new device avoid missing changes during bootstrap?** Snapshot and log watermark from a coherent state, then replay after the watermark.
28. **Why is ordinary sequence allocation insufficient for feed cursors?** Allocation order can differ from commit visibility; advancing past an uncommitted lower sequence loses it.
29. **When should the client persist its cursor?** In the same local transaction as desired-state updates and durable pending materialization jobs.
30. **What if a push notification is missed?** Durable pull from the cursor and periodic reconciliation recover it.
31. **What if a device is offline for a year?** Expired-history bootstrap while preserving local pending edits; stale IDs and bases do not override deletion or permissions.
32. **Why not periodically list everything?** It can work at small scale, but costs grow and concurrent enumeration needs consistency; change feeds support efficient incremental recovery.
33. **What if filesystem events are lost?** Periodic scans and a local journal reconcile actual state; watchers are hints.
34. **What if the local file changes while hashing?** Use a stable snapshot/read check, detect the mutation, and retry or capture a consistent version.
35. **What if the client crashes after replacing a file but before updating its database?** Recover the journaled intent and verify installed identity/content before marking completion.
36. **How do selective sync and deletion differ?** An intentionally unmaterialized file remains in local metadata; its absent bytes are not a deletion request.

### Permissions and lifecycle

37. **Does revoking one grant remove all access?** Not necessarily; evaluate direct, inherited, group, and public-link paths.
38. **Can a revoked user finish uploading?** Existing scoped endpoints may accept staging bytes temporarily; current publication authorization prevents a visible revision.
39. **Can a revoked user use an old download link?** The baseline gateway rechecks access; direct object capabilities can remain valid until their own enforcement/expiry boundary.
40. **What about already downloaded content?** Server-side revocation cannot erase independently copied plaintext.
41. **How does granting access to a folder reveal existing files?** Durable scope discovery plus a coherent subtree bootstrap; future-only events are insufficient.
42. **How does a user learn a namespace was revoked if they cannot read its feed?** A separate authorized membership/scope stream or durable equivalent, plus periodic scope validation.
43. **Why must content and permission versions be compatible?** New content served under old permissive ACLs can leak data after revocation.
44. **How do you stop search from leaking private data?** Current checks on candidates, snippets, counts, and facets; index lag never grants authority.
45. **How do you delete a million-file folder quickly?** Atomic root lifecycle transition with ancestor-aware reads and asynchronous descendant cleanup.
46. **Can two simultaneous folder moves create a cycle?** They can if checked against stale independent snapshots; serialize structural checks or use equivalent transactional protection.
47. **How do you restore into a missing parent or colliding name?** Use an explicit recovery location/name policy and current authorization; surface conflicts.
48. **Why does old revision restore create a new revision?** It preserves monotonic history, change ordering, audit, and concurrent-update checks.

### Storage, operations, and scaling

49. **When can a blob be deleted?** Only after proving no retained root or valid pin references it and fencing reference attachment against deletion.
50. **Why is a grace period not enough for GC?** A new reference can arrive during the delay; catalog state must serialize the race.
51. **How do copies affect storage and quota?** Physical content can be shared, but each retained logical revision is charged according to product policy and pins content independently.
52. **How do simultaneous uploads respect quota?** Atomic reservations; completion converts its own reservation exactly once.
53. **What if the cleanup worker races completion?** A conditional state transition decides whether the session expires or commits; quota and protection follow that decision atomically.
54. **Why can cross-user deduplication leak information?** Existence or timing of known hashes can reveal another user's content; scope reuse and avoid public oracles.
55. **How do you handle one giant enterprise namespace?** Split metadata/log/quota responsibilities explicitly; revisit transaction scope, snapshots, and authorization versions.
56. **What is the problem with per-user change fanout?** A widely shared file multiplies writes by recipient count; shared namespace logs can reduce this at increased read/subscription complexity.
57. **Can remote metadata recovery get ahead of file bytes?** Yes; track a safe recovery boundary and refuse to serve incomplete revisions.
58. **What is required for zero region-loss RPO?** Acknowledged metadata decisions and referenced bytes must both survive complete region loss; explain coordination and latency.
59. **What if restored ACLs are older than a completed revocation?** Fail closed until policy is safe, or preserve policy history synchronously across the failure domain.
60. **What if idempotency records are lost in disaster recovery?** Outcome replay becomes ambiguous; preserve records within the guarantee or quarantine uncertain operations.
61. **How do you recover from a bad sync-client release that deletes everything?** Stop/contain the rollout, detect bulk changes, retain versions/trash, and use audited namespace recovery with current policy.
62. **Which metrics matter most?** Publication success, sync delay, usable-content delay, access correctness, corruption, quota drift, and recoverable-state lag.
63. **What would you simplify for an MVP?** Whole immutable object revisions, one transactional metadata service, polling, limited sharing, and no deduplication; preserve the central invariants.
64. **What would you investigate before spending more on scale?** Measure bandwidth, object count, namespace lock contention, tail latency, auth cost, fanout, and storage lifecycle leaks.

<a id="29-exercises-and-worked-failure-traces"></a>
## 29. Exercises and worked failure traces

### Exercise 1: Lost completion response

**Trace:** session S reserves 70 MiB. All parts validate. The publication transaction creates revision R, converts reservation to retained usage, and stores completion key K. The API process crashes before replying. The client retries K twice concurrently.

**Required result:** both retries recover R, quota is charged once, and no second head update occurs. The uniqueness and transaction behavior of K prevent duplicate effects. An event may be delivered more than once, but each consumer handles duplication.

**Follow-up:** the user's access is revoked before the retry. The mutation remains committed, but the response must not disclose now-forbidden file metadata. Return an appropriately restricted operation status or denial according to the API contract; do not perform the upload again.

### Exercise 2: Sequence allocation trap

**Trace:** transaction A allocates event 10 and pauses. Transaction B allocates 11, commits, and a client reads through 11. A then commits 10.

**Bug:** the client will not ask for 10 again if its cursor means “strictly after 11.”

**Baseline repair:** hold the namespace sequencing lock through commit so B cannot expose 11 ahead of A's committed event. A different implementation can expose only a gap-free committed prefix or use partitioned positions with correct snapshot semantics. A larger numeric token is not proof of completeness.

### Exercise 3: Snapshot gap

**Trace:** a device lists folder A. A new file is created in A. The device lists folder B. It then requests a new current token and starts polling after it.

**Bug:** the new file was absent from A's old page and precedes the new token.

**Repair:** establish a snapshot with watermark H, enumerate that snapshot, then replay changes after H. Test creates, moves, deletes, and permission changes during every page boundary.

### Exercise 4: Quota race

**Trace:** quota is 100 GB, used is 90 GB, reserved is zero. Two clients each request an 8 GB reservation.

**Required result:** one succeeds and one fails under this policy. If both read available bytes independently and later update counters, the invariant can be violated. Use a transaction or atomic conditional update. If the first session expires while committing, exactly one state transition owns the reservation conversion or release.

### Exercise 5: Garbage-collection race

**Trace:** collector observes blob B unreferenced. A copy operation wants to attach B. An old collector message is delayed for 20 minutes.

**Required result:** if the copy attaches first, deletion's condition fails. If deletion fences first, copy cannot use that generation. The delayed message deletes only the exact generation authorized for deletion, never a newly allocated object that happens to reuse a name. Prefer unique keys and generation preconditions.

### Exercise 6: Concurrent folder cycle

**Trace:** A and B are siblings. Client 1 moves A inside B while client 2 moves B inside A. Each checks the old tree before writing.

**Bug:** both can independently conclude the move is safe, then create a cycle.

**Repair:** serialize hierarchy validation and parent changes in the namespace transaction domain. After one commits, the other's ancestor walk detects the cycle. A distributed hierarchy needs an equivalent proof, not just independent row CAS operations.

### Exercise 7: Privacy after region loss

**Trace:** Bob's access is revoked at 12:00:01. Remote policy replication is at 12:00:00. The home region fails at 12:00:02.

**Required result:** the remote region cannot safely use its old allow decision as current authority. Deny the uncertain scope until the policy state is recovered, or use a separately durable cross-region policy history. Restoring service availability by exposing revoked private data violates the security contract.

### Exercise 8: Offline edit and deletion

**Trace:** a laptop edits revision 5 offline. Another device trashes and permanently purges the file. Months later the laptop reconnects with an expired cursor and pending content.

**Required result:** bootstrap current authorized state, preserve the local edit, reject publishing into the purged identity, and offer an explicit new-file recovery where permitted. The local mtime is not authority to resurrect the file.

### Exercise 9: Size distribution

**Task:** compare two workloads with the same 10 MB mean: every file is 10 MB, versus mostly tiny files with a small fraction of very large files. Estimate part requests, metadata records, memory, transfer timeouts, and retry bytes for each.

**Checkpoint:** total daily bytes can match while object counts, tail latency, per-upload concurrency, and retry behavior differ greatly. Use a size distribution to size limits and workers. Do not divide average file size by chunk size and assume that fully describes the system.

### Exercise 10: Present the design in three minutes

Explain scope, metadata/content separation, immutable publication, conflict detection, snapshot-plus-feed sync, current authorization, and safe deletion. Then name one deliberate limitation and the mechanism needed to remove it. Record yourself; remove unexplained technology names and replace them with the guarantee each component provides.

<a id="30-final-review-and-primary-references"></a>
## 30. Final review and primary references

### 30.1 What you should be able to reconstruct

- [ ] File, revision, manifest, upload session, and namespace are distinct concepts.
- [ ] Every API has completion semantics, authorization, retry behavior, and relevant preconditions.
- [ ] Content is immutable and verified before its reference becomes committed.
- [ ] Publication atomically handles head, retained root, quota, operation result, and change event.
- [ ] Stale writers preserve their work without silently replacing newer content.
- [ ] Download resumes remain pinned to one revision.
- [ ] A snapshot and change cursor leave no synchronization gap.
- [ ] A client persists desired state, pending filesystem work, and cursor coherently.
- [ ] Permission grants enumerate existing scope; revocations withdraw scope and block new access.
- [ ] Folder moves preserve acyclicity and account for inherited permission changes.
- [ ] Trash, purge, tombstones, backups, and physical reclamation have different meanings.
- [ ] GC serializes against new references and uses exact-generation deletion.
- [ ] Quota is reserved, converted, released, and reconciled without double counting.
- [ ] Search, previews, and notifications are derived, versioned, and access-controlled.
- [ ] Namespace hotspots have identified scaling paths and consequences.
- [ ] Regional recovery includes metadata, content, policy, keys, and idempotency history.
- [ ] Monitoring tests user outcomes and correctness, not merely process health.
- [ ] Changed requirements such as live editing or end-to-end encryption have explicit consequences.

### 30.2 Verified primary references

Public documentation and papers were checked on **2026-09-29**. Their role is to ground specific protocol facts and provide deeper reading. The proposed architecture, numerical workload, and pedagogical examples in this document remain our design exercise.

| Source | Use it to study |
|---|---|
| [Drive: upload file data](https://developers.google.com/workspace/drive/api/guides/manage-uploads) | The actual public upload modes and resumable protocol; distinguish them from our proposed part API. |
| [Drive: retrieve changes](https://developers.google.com/workspace/drive/api/guides/manage-changes) | Public change retrieval and continuation-token usage. |
| [Drive: notifications](https://developers.google.com/workspace/drive/api/guides/push) | Notification channel setup, lifecycle, and message semantics. |
| [Drive: permissions and sharing](https://developers.google.com/workspace/drive/api/guides/manage-sharing) | Public roles and direct/inherited permissions. |
| [Zanzibar paper](https://www.usenix.org/system/files/atc19-pang.pdf) | The relationship between authorization, causality, and scalable policy evaluation. |
| [Spanner](https://research.google/pubs/spanner-googles-globally-distributed-database/) | Distributed transaction and replication reasoning. |
| [The Google File System](https://research.google/pubs/the-google-file-system/) | Workload-driven distributed file-storage choices; historical context, not an assertion about today's Drive internals. |
| [Raft](https://raft.github.io/raft.pdf) | Replicated agreement and leadership under failures. |
| [HTTP semantics](https://www.rfc-editor.org/rfc/rfc9110.html) | Conditional operations, validators, and byte-range responses. |
| [Cloud Storage consistency](https://docs.cloud.google.com/storage/docs/consistency) | Why object and cache/permission contracts must be examined separately. |
| [S3 presigned URLs](https://docs.aws.amazon.com/AmazonS3/latest/userguide/using-presigned-url.html) | Capability scope, credential lifetime, and expiration semantics. |
| [Google SRE: implementing SLOs](https://sre.google/workbook/implementing-slos/) | Connecting user outcomes to measurable reliability goals. |

Return to the [main preparation guide](README.md) for the general question bank, additional architecture families, practice schedule, and interview checklist.
