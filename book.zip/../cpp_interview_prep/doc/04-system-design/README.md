# System design interview preparation: a complete working guide

[Documentation home](../README.md) · [Detailed case study: design Google Drive](01-design-google-drive.md)

This is a study guide for designing large services in interviews, especially at senior level. Sections marked **Extension** are useful when the discussion reaches staff-level scope. These labels describe depth, not an official company interview rubric. Different teams and interviewers emphasize different skills.

The objective is to explain a defensible design: what it promises, how data moves, why each component exists, what happens under concurrency and failure, and how the system evolves. Memorizing an architecture drawing is insufficient. You should be able to remove a box, fail a box, double the workload, or change a requirement and explain the consequences.

Examples, capacities, latency targets, and proposed APIs are interview assumptions unless explicitly attributed. This guide does not claim access to Google's internal interview questions or production architecture. Primary references were checked on **2026-09-29**; product contracts can evolve.

## Contents and reading routes

1. [What a strong answer demonstrates](#01-what-a-strong-answer-demonstrates)
2. [A repeatable interview process](#02-a-repeatable-interview-process)
3. [Requirements and invariants](#03-requirements-and-invariants)
4. [Capacity and latency calculations](#04-capacity-and-latency-calculations)
5. [Networking and request paths](#05-networking-and-request-paths)
6. [APIs and data modeling](#06-apis-and-data-modeling)
7. [Storage engines and database choice](#07-storage-engines-and-database-choice)
8. [Consistency and replication](#08-consistency-and-replication)
9. [Transactions and concurrency control](#09-transactions-and-concurrency-control)
10. [Partitioning and hotspots](#10-partitioning-and-hotspots)
11. [Caching and content delivery](#11-caching-and-content-delivery)
12. [Queues, logs, and background work](#12-queues-logs-and-background-work)
13. [Timeouts, retries, and overload](#13-timeouts-retries-and-overload)
14. [Availability and disaster recovery](#14-availability-and-disaster-recovery)
15. [Security and privacy](#15-security-and-privacy)
16. [Observability and testing](#16-observability-and-testing)
17. [Cost, migrations, and evolution](#17-cost-migrations-and-evolution)
18. [Reusable architecture families](#18-reusable-architecture-families)
19. [How to draw and explain diagrams](#19-how-to-draw-and-explain-diagrams)
20. [Common mistakes and blind spots](#20-common-mistakes-and-blind-spots)
21. [Question bank with answer checkpoints](#21-question-bank-with-answer-checkpoints)
22. [Practice plan and mock interviews](#22-practice-plan-and-mock-interviews)
23. [Final interview checklist](#23-final-interview-checklist)
24. [Glossary](#24-glossary)
25. [Primary-source reading map](#25-primary-source-reading-map)

**If you have one evening:** read sections 2–4, 8–9, 13, and 23; then the Drive case study's [interview presentation](01-design-google-drive.md#27-the-interview-presentation).

**If you have a week:** read this guide once, work through the Drive write and sync paths on paper, and do three timed designs. Revisit every answer you cannot defend under a timeout or concurrent request.

**If you have a month:** use the [practice plan](#22-practice-plan-and-mock-interviews). Read papers to answer specific questions that arise from your designs; do not make reading papers a substitute for practicing.

Diagrams use Mermaid. Read in a Markdown viewer with Mermaid support to see rendered diagrams; the accompanying prose explains every flow without requiring a renderer. Links throughout this guide are intended as a navigable curriculum, not a requirement to read everything before attempting an interview.

<a id="01-what-a-strong-answer-demonstrates"></a>
## 1. What a strong answer demonstrates

An effective answer connects five layers:

| Layer | What you must make explicit | Example from file storage |
|---|---|---|
| Product | Who does what, and what must users observe? | An offline edit must not silently overwrite someone else's newer edit. |
| Contract | What does a successful operation guarantee? | A successful commit makes a complete, durable revision visible. |
| Mechanism | What enforces the contract? | Immutable content plus an atomic conditional metadata update. |
| Failure | What happens when an acknowledgement disappears? | Retry using an idempotency key and recover the committed result. |
| Operation | How do we know the promise continues to hold? | Reconciliation, corruption checks, conflict metrics, and restore exercises. |

At an introductory level, demonstrate a coherent request path, suitable storage, and an understanding of scale. At senior depth, explain state transitions, transaction boundaries, failure behavior, and measurable tradeoffs. For an extension, discuss region ownership, migrations, operational boundaries, cost, policy, and how a design changes as organizations and workloads grow.

Depth is not the number of named technologies. “Use Kafka, Redis, Kubernetes, and Cassandra” explains almost nothing without key selection, data ownership, ordering, retention, and failure semantics.

A useful statement has this form:

> “Because clients can retry after an unknown outcome, I store an operation key and its result in the same transaction as the mutation. That prevents a duplicate charge or revision. I must retain that record for at least the supported retry window.”

This sentence states the condition, mechanism, guarantee, and limitation.

<a id="02-a-repeatable-interview-process"></a>
## 2. A repeatable interview process

### 2.1 A suggested 45-minute allocation

Adapt to the interviewer rather than treating the table as a script.

| Minutes | Work | Concrete output |
|---|---|---|
| 0–5 | Clarify users, essential operations, scope, and guarantees. | Three to five functional requirements; explicit exclusions. |
| 5–8 | Estimate only quantities that influence the design. | Peak requests, bandwidth, storage, growth, and one skew assumption. |
| 8–13 | Define the important entities and API contracts. | IDs, partition boundary, write preconditions, and pagination. |
| 13–20 | Draw a complete baseline and walk one write and one read. | An understandable architecture with a source of truth. |
| 20–35 | Explore the hardest two or three problems. | For Drive: publication, synchronization, permissions. |
| 35–41 | Fail components and stress hot paths. | Retry semantics, overload response, regional failure, observability. |
| 41–45 | Summarize tradeoffs and remaining extensions. | What the design guarantees, where it compromises, next scaling step. |

For 60 minutes, add a concurrency example, a migration, and an operational incident. For 30 minutes, shorten breadth but still complete the write and read paths. A detailed explanation of one subsystem cannot compensate for never explaining how the core product works.

### 2.2 The first questions

Ask the questions with the greatest architectural impact first:

1. What is the main user journey and who are the users?
2. Which two or three operations matter most?
3. What must never happen: lost money, overwritten work, leaked private data, duplicate fulfillment?
4. What scale and geographic distribution should we assume?
5. Does success mean accepted for processing or fully committed?
6. Which operations must remain available during a network partition?
7. Is this a new product, or must we preserve an existing API and migrate data?

If the interviewer says “you decide,” choose reasonable assumptions and write them down. Do not spend ten minutes extracting perfect numbers. A good response is: “I will assume a global consumer service, focus on uploads, downloads, sharing, and sync, and keep live document editing as an extension.”

### 2.3 A reusable scratchpad

```text
Users and core operations:
In scope / extensions:
Workload: peak operations, bytes, skew, growth:
Correctness invariants:
Latency, availability, durability, RPO, RTO:
Entities and IDs:
Read path:
Write path and commit point:
Partition / replication / ownership:
Retry and concurrency behavior:
Failure recovery and security:
Costs and next bottleneck:
```

Keep a small “parking lot” for topics the interviewer does not prioritize. Acknowledge them and return later if useful. This is especially valuable for features such as billing, full-text search, analytics, or collaborative editing that can consume an entire interview on their own.

### 2.4 Explain decisions while making them

Present a simple working design first. Then identify its first bottleneck and evolve it. For example: one transactional metadata database and object storage → metadata partitions by workspace → special treatment for very large workspaces. This shows which complexity is necessary and which is optional.

When challenged, identify which assumption changed. If the interviewer introduces strict global write availability, you cannot quietly retain single-leader consistency and promise everything. Explain the conflict and choose which behavior changes.

<a id="03-requirements-and-invariants"></a>
## 3. Requirements and invariants

### 3.1 Functional requirements describe behavior

“Store files” is vague. “A user uploads a file, resumes after losing connectivity, sees its name on a second device, and shares read access with a colleague” exposes upload sessions, durable progress, change propagation, and authorization.

Separate actor, action, and outcome. Distinguish an owner from a collaborator, an anonymous reader from an authenticated reader, and a human action from a background process.

Explicit exclusions protect the discussion. Excluding live Google Docs editing from the initial Drive design is sensible; excluding conflict handling while supporting offline binary-file edits is not, because conflict handling is already implied by the product.

### 3.2 Quality requirements need a boundary and measurement

| Requirement | Incomplete statement | Useful formulation |
|---|---|---|
| Latency | Fast reads. | Metadata reads complete within an assumed 200 ms at p95 for supported regions. |
| Availability | Five nines. | A specified fraction of valid metadata requests succeeds within a deadline over a rolling window. |
| Durability | Never lose data. | Define acknowledged-data survival across machine, zone, and region failures. |
| Freshness | Real time. | Online devices usually discover committed metadata within a stated delay. |
| Consistency | Strong consistency. | Conditional updates to one file head reject stale writers. |
| Recovery | Fast failover. | State recovery time and the amount of acknowledged data allowed to be lost. |
| Security | Secure storage. | Every read is authorized; revoked access stops within an explicit contract. |

An **SLI**, or service-level indicator, is a measured outcome. An **SLO**, or service-level objective, is a target for that outcome. An **SLA**, or service-level agreement, is a contractual commitment with defined consequences. For example, measure successful upload finalizations separately from upload initiation; otherwise the service can look healthy while no file ever becomes usable. Google's SRE workbook describes SLOs and error budgets as tools for prioritizing reliability work. [Primary reference: implementing SLOs](https://sre.google/workbook/implementing-slos/).

### 3.3 State invariants before drawing infrastructure

An invariant is a condition that must hold in every valid state, including after recovery:

- A purchase cannot deduct inventory below the accepted reservation policy.
- One idempotent payment request cannot produce two charges.
- A visible file revision cannot reference incomplete content.
- A stale file writer cannot silently replace a newer revision.
- A user without access cannot obtain a download capability.
- A deleted object cannot reappear solely because an old device reconnects.

For each invariant, identify its enforcement point. “The application checks it” is inadequate if two application instances can check concurrently. You need an atomic constraint, transaction, conditional write, serialized owner, or a deliberately weaker product contract.

Distinguish **safety** from **liveness**. Safety says something bad never happens: two active leaders cannot both commit incompatible file heads. Liveness says progress eventually happens: a healthy majority eventually elects a leader. A system can preserve safety by refusing writes while temporarily failing liveness.

### 3.4 Define what is authoritative

Separate truth from derived data. In a file service, committed metadata and retained file bytes are authoritative; search indexes, previews, notification delivery, and some caches can be rebuilt. Back up authoritative data and preserve enough history to rebuild derived state. A queue becomes authoritative if it contains the only copy of an accepted operation.

<a id="04-capacity-and-latency-calculations"></a>
## 4. Capacity and latency calculations

### 4.1 Start from units

Use decimal units for rough capacity estimates unless stated otherwise: 1 KB = 1,000 bytes, 1 MB = 1,000,000 bytes, 1 GB = 1,000,000,000 bytes. Binary units are different: 1 MiB = 1,048,576 bytes. One byte is eight bits; network links are commonly described in bits per second.

```text
average requests/second = daily operations / 86,400
peak requests/second    = average requests/second × chosen peak factor
ingress bytes/second    = uploads/second × mean uploaded bytes
egress bytes/second     = downloads/second × mean bytes actually delivered
logical retained bytes = arrival bytes/second × retention seconds
physical storage       = retained bytes × redundancy overhead + metadata + slack
```

The mean file size matters for total capacity; percentiles and maximum size matter for individual latency, memory, and timeouts. A 1 MB median does not imply a 1 MB mean when a small fraction of files are enormous.

### 4.2 Worked example

Assume 10 million daily active users, 20 metadata reads and two writes per user per day, and a peak factor of five.

```text
metadata reads/day        = 10,000,000 × 20 = 200,000,000
average metadata reads/s  = 200,000,000 / 86,400 ≈ 2,315
peak metadata reads/s     ≈ 11,574
metadata writes/day       = 20,000,000
average metadata writes/s ≈ 231
peak metadata writes/s    ≈ 1,157
```

Now assume 20 million uploads/day at an average 10 MB: 200 TB/day, or approximately 2.31 GB/s average ingress and 11.57 GB/s at the same fivefold peak. Multiplying by eight gives approximately 18.5 Gbit/s average and 92.6 Gbit/s peak. Protocol overhead and cross-region replication are extra.

If all new bytes are retained for 30 days with no deletion or deduplication, that is 6 PB logical storage. Three copies would require 18 PB before indexes, manifests, repair headroom, old versions beyond the window, or incomplete uploads. The assumption matters more than the final digit.

This example demonstrates why “only a few thousand requests per second” can still be a substantial system: content bandwidth and retained bytes dominate metadata request counts. The [Drive capacity model](01-design-google-drive.md#04-capacity-model) extends these same assumptions.

### 4.3 Concurrency, utilization, and queues

Little's Law relates average concurrency, throughput, and time in a stable system:

```text
L = λ × W
L = average number of requests in the system
λ = completed requests per second
W = average time in the system in seconds
```

At 10,000 requests/s with 100 ms average time, there are about 1,000 requests in flight. This is a sizing relationship, not a guarantee that an overloaded queue is stable. If arrivals exceed service capacity, backlog grows and the stable-system assumption fails.

A queue with 1 million pending tasks and workers capable of 2,000 tasks/s takes 500 seconds to drain only if no new tasks arrive. If 1,500 tasks/s continue arriving, spare capacity is 500 tasks/s, so draining takes 2,000 seconds. Recovery capacity must exceed live traffic.

High CPU utilization is not automatically efficient operation. Near saturation, small bursts can produce large queueing delays. Keep capacity for burstiness, node failure, background compaction, and deployment overlap.

### 4.4 Latency budgets and tails

Draw the critical path. Sequential dependencies add latency; parallel dependencies generally contribute their maximum plus orchestration overhead. Do not add p99 values and call the result the exact end-to-end p99: percentile distributions do not combine that way.

If a request waits for all 100 independent subrequests, and each subrequest has a 99% chance of meeting its threshold, the probability all 100 meet it is `0.99^100 ≈ 36.6%`. Independence is a simplifying assumption; shared failures often make behavior worse in different ways. Large fanout makes tail control central to the design.

Separate time to first byte from full transfer time. A 1 GB download over a usable 100 Mbit/s path takes at least roughly 80 seconds for payload alone, even if authorization takes 10 ms. No metadata optimization removes that bandwidth floor.

### 4.5 Useful estimation traps

- Peak factor is workload-specific; a live event may have far more skew than an office application.
- Read/write ratio depends on what is counted: API calls, database operations, or bytes.
- A CDN hit saves origin bandwidth, but user egress still exists and may still cost money.
- Compression does little for already compressed videos and archives.
- Replication across zones is not the same expense or latency as replication across continents.
- Ten balanced partitions do not solve one file receiving half the traffic.
- Average object size does not predict the overhead from billions of tiny files.
- Total users, active users, online devices, open connections, and requests/s are different quantities.

<a id="05-networking-and-request-paths"></a>
## 5. Networking and request paths

### 5.1 Explain a request from the user's device

```mermaid
flowchart LR
    C[Client] --> D[DNS and edge routing]
    D --> E[TLS endpoint and load balancer]
    E --> A[Application API]
    A --> P[Authentication and authorization]
    A --> M[(Metadata store)]
    A --> Q[Background work log]
    C --> G[Authorized content gateway]
    G --> B[(Object storage)]
```

DNS maps names to endpoints and may help steer geography, but caching means DNS changes are not instantaneous failover. A load balancer distributes connections or requests among healthy targets. TLS authenticates endpoints and encrypts traffic in transit. The application must still authenticate the user and authorize the requested resource.

Layer 4 balancing works with transport connections. Layer 7 balancing understands application requests and can route by path or headers. Long-lived connections, connection pooling, retries, and uneven request cost all affect load distribution. Round-robin over connections does not guarantee equal work.

Health checks have distinct purposes: process liveness, readiness to accept traffic, and deeper dependency health. Restarting every service because a shared database is briefly unavailable can turn one dependency outage into a larger incident.

### 5.2 Transport choices

| Mechanism | Good fit | Questions to address |
|---|---|---|
| HTTP request/response | CRUD, paginated reads, resumable transfer control. | Deadlines, status codes, idempotency, caching. |
| Streaming RPC | Typed internal APIs or continuous results. | Cancellation, flow control, version compatibility. |
| WebSocket | Bidirectional updates and presence. | Reconnection, authentication refresh, connection ownership. |
| Server-sent events | Server-to-browser notifications. | Resume position, proxy buffering, reconnect behavior. |
| Long polling | Simple change notification fallback. | Open-request cost, empty responses, reconnect storms. |
| Periodic polling | Robust baseline with loose freshness needs. | Delay versus request cost; randomized polling schedules. |

Reliable transport delivery is not exactly-once application execution. A TCP connection can break after the server commits but before the client sees the response. That ambiguity still requires application-level recovery.

### 5.3 Bandwidth-delay product and large transfers

Bandwidth-delay product is the amount of data that must be in flight to fill a link: bandwidth × round-trip time. At 100 MB/s and 100 ms RTT, roughly 10 MB must be in flight. Sending one small chunk and waiting for a response before sending the next can underutilize the link.

Bounded parallelism or streaming helps, but unlimited concurrent chunks overload storage and device memory. Select concurrency using bandwidth, latency, storage limits, and fairness. Mobile clients also need battery and metered-network policies.

### 5.4 Service boundaries

Separate components when ownership, independent scaling, security, or failure isolation justify it. A diagram can show logical modules that initially run in one service. Every network boundary adds latency, deployment compatibility, timeouts, and partial failure. You do not need a separately deployed service for every noun.

<a id="06-apis-and-data-modeling"></a>
## 6. APIs and data modeling

### 6.1 Design contracts, not just endpoint names

For each important API, specify authentication, authorization, request fields, returned identifiers, preconditions, idempotency, error behavior, pagination, and completion semantics.

```http
PATCH /v1/files/file-123
Authorization: Bearer <access-token>
If-Match: "metadata-generation-17"
Idempotency-Key: operation-789
Content-Type: application/json

{"name": "proposal-final.pdf"}
```

The precondition protects against stale metadata. The operation key lets a retry recover its original outcome. They solve different problems: an idempotency key does not by itself stop two different users from overwriting each other.

HTTP defines conditional requests and range requests. A failed `If-Match` precondition normally maps to `412 Precondition Failed`; a broader application conflict can use `409 Conflict`. Use `202 Accepted` when work has only been accepted, and expose a way to query its eventual result. [Primary reference: HTTP semantics](https://www.rfc-editor.org/rfc/rfc9110.html).

### 6.2 Stable identity versus mutable names

Give objects stable IDs. Names and paths change. If a file's identity is its full path, moving a folder may require rewriting every descendant key and all references. An ID plus parent relationship makes a same-namespace move a metadata operation.

ID choices have tradeoffs. Random IDs reduce coordinated allocation and may resist casual enumeration, but do not replace authorization. Time-ordered IDs improve some index access patterns but may expose creation order and concentrate writes in range partitions. A clock-based generator must define behavior on clock rollback and worker-ID reuse.

### 6.3 Model access patterns before selecting indexes

Write the queries: list a folder, fetch by ID, fetch a revision, list recent changes, evaluate a grant. Then design keys and indexes. An index consumes storage and adds write amplification; it is not free acceleration.

Use a join table for many-to-many relationships when appropriate. Denormalization speeds reads but creates multiple copies that must be updated or reconciled. Label each denormalized copy with its source of truth and freshness promise.

### 6.4 Pagination under concurrent changes

Offset pagination (`OFFSET 100000`) can be expensive and can skip or repeat results when earlier rows change. Keyset pagination uses a stable ordering such as `(created_at, file_id)` and resumes after the last key.

Keyset pagination alone does not create a snapshot. If the requirement is “enumerate every object exactly as it existed when listing began,” include a snapshot timestamp or snapshot ID in an opaque page token and retain the necessary database history. Bind the token to the caller, query, scope, and expiration. Reauthorize visibility even when the token itself is valid.

### 6.5 Schema evolution

Expect old clients, partially deployed servers, and old queued events. Add fields compatibly, define defaults, tolerate unknown fields where safe, and version semantics that cannot be changed compatibly. Removing a database column before all old binaries stop reading it is a deployment bug, not a database problem.

<a id="07-storage-engines-and-database-choice"></a>
## 7. Storage engines and database choice

### 7.1 Match the workload to the storage contract

| Store | Natural strengths | Questions and costs |
|---|---|---|
| Relational database | Transactions, constraints, joins, evolving queries. | Index cost, contention, partitioning, transaction scope. |
| Distributed SQL | Relational model with distributed replication and transactions. | Cross-partition latency, placement, cost, transaction limits. |
| Key-value store | Predictable access by key, simple partitioning. | Range queries, secondary indexes, conditional writes, consistency. |
| Document store | Aggregate-shaped data and flexible fields. | Unbounded documents, nested updates, cross-document invariants. |
| Wide-column store | Large ordered key ranges and high ingestion. | Key design, hot ranges, limited joins, compaction. |
| Object storage | Large immutable byte objects and range reads. | Request overhead, lifecycle, namespace semantics, authorization. |
| Search index | Inverted indexes, relevance, tokenization, full-text queries. | Index lag, deletions, access filtering, rebuilds. |
| Time-series store | Time-window queries, retention, aggregation. | Label cardinality, late events, compression, downsampling. |

“SQL does not scale” and “NoSQL is eventually consistent” are not sound selection rules. Products expose different transaction, replication, and query contracts. Name the required guarantee before choosing an implementation.

### 7.2 B-trees, LSM trees, and the write path

A B-tree family index maintains ordered pages and supports point and range lookups. Updating it changes pages; caching, page splits, and write-ahead logging affect performance. An LSM design commonly buffers writes in memory, records them durably, flushes sorted files, and compacts those files over time. It trades write batching for read amplification, compaction work, and temporary extra disk space.

Three kinds of amplification matter:

- **Write amplification:** physical bytes written per logical byte changed.
- **Read amplification:** extra reads needed to answer one logical read.
- **Space amplification:** physical storage beyond the live logical dataset.

Tombstones mark deleted keys in some engines until compaction can safely discard them. A deletion acknowledged by the API may therefore precede physical byte reclamation. This affects retention promises, recovery, and capacity.

A Bloom filter can answer “definitely absent” or “possibly present,” with false positives. It does not replace an authoritative lookup for a possible match. Correctly maintained standard Bloom filters do not have false negatives for inserted items, but stale or incorrectly rebuilt filters can break that application assumption.

### 7.3 Durability is about the acknowledgement boundary

Writing to a process buffer is not durable. Writing to an operating-system cache is not the same as persistence under power failure. A durable database write may require a flushed log and replication acknowledgements according to its configuration. Ask precisely when success is returned and what failures the acknowledgement survives.

Replication protects against some hardware failures; backups protect against other events such as accidental deletion and corrupt writes propagated to every replica. Neither automatically replaces the other.

### 7.4 Why bytes and metadata often separate

Transactional metadata is small, mutable, and frequently queried. File content is large, often immutable per version, and dominates bandwidth. Keeping them separate lets the metadata tier enforce permissions and version transitions while the data tier streams bytes efficiently. It also creates a publication problem: the database and object store do not usually share one transaction. The [Drive upload protocol](01-design-google-drive.md#09-upload-protocol) explains how to make that boundary safe.

Object storage is not universally eventually consistent. For example, Cloud Storage documents strong consistency for several object and listing operations while describing separate behavior for access changes and caches. Read the specific contract instead of applying an old blanket assumption. [Primary reference: Cloud Storage consistency](https://docs.cloud.google.com/storage/docs/consistency).

<a id="08-consistency-and-replication"></a>
## 8. Consistency and replication

### 8.1 Name the observable guarantee

| Guarantee | Meaning | Example |
|---|---|---|
| Linearizability | Operations appear atomic in an order consistent with real-time precedence. | Once a file-head update finishes, a later authoritative read sees it or a newer head. |
| Sequential consistency | There is one operation order preserving each client's program order, without requiring real-time order. | An order is coherent but can disagree with wall-clock completion order across clients. |
| Causal consistency | Observers respect cause-before-effect dependencies. | A reply cannot appear before the message it depends on. |
| Read-your-writes | A client sees its own completed writes. | After rename, the author's next view shows the new name. |
| Monotonic reads | One client's successive reads do not move backward in version. | A device that saw revision 8 does not later show revision 7. |
| Eventual consistency | After updates stop and communication succeeds, replicas converge. | A derived search index eventually reflects current metadata. |
| Serializability | Concurrent transactions have results equivalent to some serial execution. | Two multirow updates preserve database invariants. |
| Strict serializability | Serializable transactions also respect real-time precedence. | A transaction starting after another completes cannot serialize before it. |

Linearizability concerns operations on shared state; serializability concerns transaction executions. They are related but not interchangeable. A database can offer serializable transactions while some replica reads are stale. Explain the read mode as well as the write mode.

Eventual consistency alone does not specify a maximum delay. If the product needs “within five seconds,” define a bounded-staleness objective, monitor it, and specify what happens when it cannot be met.

### 8.2 CAP without the slogan

During a network partition, a system cannot guarantee both linearizable behavior and a successful response to every request at every nonfailed node under the CAP model. This is about behavior during partitions, not choosing any two items from a menu during healthy operation. [Primary reference: Gilbert and Lynch's CAP paper](https://www.cs.princeton.edu/courses/archive/spr22/cos418/papers/cap.pdf).

For a file head, we might refuse writes in a partition without the authoritative quorum to avoid conflicting acknowledged heads. A disconnected client can still save locally and queue an edit, but that is not the same as the server committing the edit. Distinguish local availability from globally committed availability.

Even without a partition, stronger coordination can cost latency. Geography, consistency, and response time remain a tradeoff on healthy paths.

### 8.3 Replication models

**Single leader:** one leader orders writes; followers replicate. This simplifies conflict prevention, but leader availability, follower lag, failover fencing, and hot-leader capacity matter.

**Multiple leaders:** multiple sites accept writes. This can reduce local write latency, but concurrent edits require conflict detection and a merge policy. “Last writer wins” may discard user work and often depends on imperfect clocks.

**Leaderless replication:** clients or coordinators communicate with multiple replicas. Repair, version reconciliation, and quorum behavior must be explicit. The original Dynamo paper is a useful example of choosing availability and application-assisted reconciliation; it should not be treated as a complete description of today's DynamoDB product. [Primary reference: Dynamo](https://www.allthingsdistributed.com/files/amazon-dynamo-sosp2007.pdf).

### 8.4 Quorums and consensus

With `N` replicas, reading `R` and writing `W` replicas such that `R + W > N` creates overlap for quorums drawn from the same fixed replica set. Overlap alone does not prove linearizability. Concurrent writes, partial writes, version ordering, stale coordinator state, and sloppy quorums affect the result.

Consensus protocols solve agreement on an ordered history under their fault assumptions. Raft organizes this around leader election, replicated logs, and safety rules. A three-voter group can normally make progress with two communicating voters; it cannot tolerate two unavailable voters and still commit. Membership changes need a safe protocol as well. [Primary reference: Raft](https://raft.github.io/raft.pdf).

For an interview, explain what the database or coordinator provides rather than reinventing consensus. A leader being elected does not by itself guarantee that an old leader can no longer cause external side effects. Storage writes may need a monotonically increasing fencing token checked by the storage service.

### 8.5 Time is not an ordering oracle

Wall clocks drift and can jump. A timestamp supplied by a client is useful as descriptive metadata but is generally unsafe as the sole conflict-resolution authority. Use version numbers, log positions, or an appropriate logical clock to describe order.

Lamport timestamps can encode a causal ordering constraint, but a smaller timestamp does not prove causality. Vector clocks can represent concurrent histories, at the cost of metadata growth and membership complexity. Hybrid logical clocks combine physical-time proximity with logical ordering; they do not magically eliminate cross-node coordination requirements.

Spanner is a concrete system combining distributed replication, transactions, and time uncertainty handling. Study it to understand the mechanism and costs, not to assume that adding synchronized clocks makes any database externally consistent. [Primary reference: Spanner](https://research.google/pubs/spanner-googles-globally-distributed-database/).

<a id="09-transactions-and-concurrency-control"></a>
## 9. Transactions and concurrency control

### 9.1 ACID, stated carefully

- **Atomicity:** a transaction's database changes commit together or do not commit.
- **Consistency:** application and database constraints hold across valid transactions; this is not the same use of “consistency” as replica freshness.
- **Isolation:** concurrent transactions have the guarantees of the selected isolation level.
- **Durability:** acknowledged commits survive the failure modes promised by the storage configuration.

A database transaction does not automatically include an email, object-store write, external payment, or broker publication. Mark the transaction boundary on the diagram.

### 9.2 Lost updates, write skew, and phantoms

**Lost update:** two clients read revision 7; each writes a replacement; the second overwrites the first. Protect the update with a condition on revision 7, so only one succeeds.

**Write skew:** two transactions each read an invariant across multiple rows and update different rows. For example, each sees another on-call doctor and removes itself, leaving nobody on call. Snapshot isolation may permit this even when each individual row update is safe.

**Phantom:** a transaction repeats a predicate query and sees rows newly inserted by another transaction. Predicate-level invariants can require serializable execution or explicit coordination.

Isolation names differ in important implementation details across products. PostgreSQL's documentation explains its actual levels and the need to retry serialization failures. [Primary reference: transaction isolation](https://www.postgresql.org/docs/current/transaction-iso.html).

### 9.3 Optimistic and pessimistic control

Optimistic concurrency assumes conflicts are uncommon: read a version, compute, and conditionally commit if that version is still current. Retry or surface a conflict when the condition fails. It works well for edits that can tolerate a user-visible conflict.

Pessimistic control acquires locks before modifying contested data. It can avoid wasted work under contention but introduces blocking, deadlocks, and lock-lifetime problems. Never hold an ordinary database transaction open while a client uploads a multi-gigabyte file.

An advisory distributed lock is not a substitute for transactional checks. A process can pause, its lease can expire, and a new holder can start while the old process resumes. A fencing token makes the resource reject the stale holder's writes. The resource must actually enforce the token.

### 9.4 Idempotency under an unknown result

```mermaid
sequenceDiagram
    participant C as Client
    participant A as API
    participant D as Transactional database
    C->>A: Mutate with operation key K
    A->>D: Atomically store mutation and result for K
    D-->>A: Committed
    A--xC: Response lost
    C->>A: Retry same K and same request
    A->>D: Read committed result for K
    D-->>A: Original result
    A-->>C: Same logical outcome
```

Scope the key by authenticated principal and operation type. Bind it to a canonical request hash so reuse with different content is rejected. Coordinate concurrent requests for the same key with a uniqueness constraint and transaction. Define in-progress behavior, result retention, and what happens after key expiration.

Idempotency provides one logical effect for repeated attempts within the contract. It does not mean the network delivers once. If a result includes a short-lived download URL, recover the stable result and issue a new authorized URL rather than returning an expired capability forever.

### 9.5 Database plus event: the outbox

```mermaid
flowchart LR
    A[Application mutation] --> T[One database transaction]
    T --> R[(Business rows)]
    T --> O[(Outbox rows)]
    O --> W[Relay with retry]
    W --> L[Durable event log]
    L --> C[Idempotent consumers]
```

The outbox closes the gap between “database commit succeeded” and “event publication happened.” A relay reads committed outbox rows and publishes them. It can crash after publishing but before recording progress, so duplicate events remain possible. Consumers need event IDs, version checks, or atomic inbox records.

Change data capture is another way to derive events from committed changes. In either case, define ordering, retention, schema compatibility, backpressure, and replay behavior.

### 9.6 Two-phase commit and sagas

Two-phase commit coordinates atomic decisions across participants: prepare, then commit or abort. It introduces coordination and potentially blocked prepared transactions when a coordinator is unavailable, depending on the implementation and recovery protocol. Consensus within each participant does not eliminate this cross-participant problem.

A saga decomposes a workflow into locally committed steps with compensating actions. Compensation is a business action, not time travel: a refund does not erase the fact that a charge was visible. Use sagas for workflows that can represent intermediate states and compensation; use a transactional boundary when the invariant truly requires atomicity.

<a id="10-partitioning-and-hotspots"></a>
## 10. Partitioning and hotspots

Partitioning distributes different data across nodes. Replication keeps additional copies of the same data. You normally need both, for different reasons.

### 10.1 Select a partition key from transactions and queries

| Key strategy | Benefit | Cost |
|---|---|---|
| Hash of object ID | Balanced independent objects. | Folder listings and tenant-wide operations scatter. |
| Tenant or workspace ID | Local transactions and access control. | One enormous tenant can dominate a partition. |
| Time range | Efficient time-window scans and retention. | Current-time writes concentrate unless subdivided. |
| Geographic ownership | Data residency and local writes. | Traveling users and cross-region sharing add latency. |
| Composite key | Can balance locality and spread. | Query fanout and routing become more complicated. |

Choose what must be colocated: all rows needed for one invariant are a strong candidate. Then identify the largest possible unit. “Partition by user” fails if one enterprise account owns billions of objects or one creator has millions of followers.

### 10.2 Consistent hashing is a routing tool

Consistent hashing or a partition map can reduce the amount of data remapped when nodes change. Virtual partitions help balance heterogeneous nodes. Neither eliminates skew from one hot key, guarantees zero data movement, or solves transactional updates across keys.

### 10.3 Split a partition safely

A migration needs a source of truth during the transition:

1. Copy a consistent snapshot to the destination.
2. Stream subsequent changes from a known checkpoint.
3. Verify catch-up and data integrity.
4. Fence the old writer and atomically change ownership at a routing generation.
5. Redirect stale clients and retry with idempotency.
6. Retain recovery information until verification and rollback conditions are satisfied.

Naive dual writes create ambiguity when one destination succeeds and the other fails. A routing epoch, durable log, or explicit migration state machine is essential.

### 10.4 Hot objects need a different answer

For hot reads, immutable caching, replication, request coalescing, and precomputation can help. For hot writes, determine whether operations can be partitioned or combined. A single counter may be sharded if approximate or delayed totals are acceptable; one strictly ordered file head cannot accept arbitrary concurrent updates without some ordering point.

Large fanout is another hotspot. A shared file with a million viewers should not necessarily produce a million database writes for every edit. Consider shared logs, subscriptions, or fanout-on-read with an explicit freshness and read-cost tradeoff.

<a id="11-caching-and-content-delivery"></a>
## 11. Caching and content delivery

### 11.1 State the cache's correctness role

The easiest cache contains immutable data keyed by revision or content identity. A miss affects performance, not correctness. Mutable metadata and permissions are harder because stale data can change what users observe or are allowed to access.

| Pattern | Operation | Main risk |
|---|---|---|
| Cache-aside | Read cache; on miss read source and populate. | Stale fill races, stampedes, inconsistent invalidation. |
| Write-through | Update authoritative storage and cache through a coordinated path. | Partial failure still needs a defined order and recovery. |
| Write-behind | Buffer writes in cache and persist later. | Cache loss can lose acknowledged data unless it is itself durable. |
| Versioned immutable cache | Store values under immutable generation keys. | Discovering the current generation still needs a freshness contract. |

### 11.2 The stale-fill race

```mermaid
sequenceDiagram
    participant R as Reader
    participant D as Database
    participant W as Writer
    participant C as Cache
    R->>D: Read old value V1
    D-->>R: V1
    W->>D: Commit V2
    W->>C: Invalidate key
    R->>C: Populate key with V1
    Note over C: Cache now contains stale V1
```

“Write database, then delete cache” is not a universal proof of freshness. Possible mitigations include version-aware cache writes, generation keys, a short bounded TTL, change-log-driven invalidation, or authoritative reads for sensitive operations. Choose according to the required guarantee.

### 11.3 Stampedes, penetration, and eviction

Use request coalescing so concurrent misses for the same key share one fetch. Randomize expiration to avoid synchronized refreshes. Negative caching can protect against repeated missing keys, but keep authorization and object-creation behavior in mind. Bound memory and value sizes; a single huge value can evict useful data.

TTL is a staleness policy and capacity tool, not an immediate revocation mechanism. Cache loss must have a load-tested fallback; otherwise a cache becomes a hidden availability dependency.

### 11.4 CDN and private content

A content delivery network places cached bytes closer to users and absorbs repeated downloads. A private file still needs authorization before bytes are released, even if those bytes are already at the edge. Distinguish the cache key for immutable bytes from the credentials used to access them.

Signed URLs are bearer capabilities. Whoever possesses a valid URL can exercise its scoped permission according to the serving system's rules. Scope them narrowly, use a bounded lifetime, and keep them out of logs and referrers. Their validity is not automatically canceled by changing an unrelated application ACL. [Primary reference: S3 presigned URLs](https://docs.aws.amazon.com/AmazonS3/latest/userguide/using-presigned-url.html).

<a id="12-queues-logs-and-background-work"></a>
## 12. Queues, logs, and background work

### 12.1 Queue versus log

A work queue distributes tasks to workers. A durable log retains ordered events for consumers to read at their own positions. Products can support aspects of both, but clarify whether work disappears after acknowledgement, how long replay is available, and whether multiple consumers independently see the same event.

Ordering is usually scoped to a partition or key, not the whole system. If file events are keyed by file ID, you can maintain per-file order but may need extra coordination for operations involving two folders or an entire workspace.

### 12.2 Delivery and effects

| Delivery goal | Failure tradeoff |
|---|---|
| At most once | No redelivery, but a failure can lose processing. |
| At least once | Redelivery recovers failures, but duplicates are expected. |
| Exactly once within a defined boundary | Requires coordinated state and offset/output handling within that boundary. |

Kafka documents idempotent production and transactional processing, including the importance of cooperation when writing to external systems. A broker guarantee does not automatically deduplicate a separately committed database update or external API call. [Primary reference: Kafka design](https://kafka.apache.org/41/design/design/).

Make effects idempotent with a stable event ID and an inbox record in the same transaction as the effect, or apply a versioned state update. If processing older revision 8 after revision 9, do not overwrite the newer search entry with the older one.

### 12.3 Poison messages and backlogs

Use bounded retries with a dead-letter path for persistently failing tasks. Preserve enough context for diagnosis without logging private content or credentials. A dead-letter queue needs ownership, alerting, and a repair/replay procedure; otherwise it is a place where work disappears quietly.

Track age of the oldest unprocessed item as well as queue length. Ten long video transcodes can represent more work than ten thousand tiny metadata events. Bound concurrency by the constrained resource: CPU, memory, external quotas, or bandwidth.

### 12.4 Stream processing extension

Event time is when something happened; processing time is when a worker observes it. Out-of-order events require a lateness policy. A watermark estimates progress in event time; it is not proof that no older event can ever arrive.

For a five-minute aggregate, define whether late events amend prior results, are dropped, or create corrections. Deduplicate using event identity rather than timestamp. Approximate algorithms can reduce storage: sketches for cardinality or heavy hitters are useful when error bounds are part of the contract.

### 12.5 Notifications are often hints

A device receiving a push can pull authoritative changes from its saved cursor. It should also reconcile periodically because it can disconnect, miss a notification, or lose local state. The durable change feed establishes correctness; push reduces perceived delay. The Drive case study develops this distinction in its [sync protocol](01-design-google-drive.md#12-synchronization-and-change-feeds).

<a id="13-timeouts-retries-and-overload"></a>
## 13. Timeouts, retries, and overload

### 13.1 A timeout means uncertainty

If a request times out, the operation may not have started, may still be running, or may have committed. Do not equate timeout with rollback. Propagate deadlines so downstream services stop spending resources on abandoned work when safe, while preserving committed outcomes.

Distinguish connection, request, and overall operation timeouts. Uploading a large file needs a different contract from a small metadata lookup; an inactivity timeout may be useful in addition to an overall session lifetime.

### 13.2 Controlled retries

Retry transient failures only when the operation is safe to repeat or has an idempotency mechanism. Use exponential backoff with jitter, a maximum delay, an attempt or elapsed-time limit, and a retry budget. Honor server guidance such as `Retry-After` where appropriate.

If five layers each make up to three attempts, the deepest dependency can see up to `3^5 = 243` attempts for one original request in the worst case. Choose one responsible retry layer where practical and propagate useful error context.

Do not retry a stale precondition unchanged forever. A revision conflict requires reading current state and merging, branching, or asking the user to resolve it.

### 13.3 Backpressure and load shedding

Backpressure slows producers when consumers cannot keep up. Load shedding rejects work before it consumes scarce resources. Bounded queues prevent unbounded memory growth but require an admission policy when full.

Prefer protecting committed work and essential operations. For Drive, prioritize metadata and accepted-upload finalization over speculative previews. Use per-tenant limits to prevent one organization from consuming the whole worker pool. Google's SRE material discusses overload controls and the danger of cascading failure. [Primary reference: handling overload](https://sre.google/sre-book/handling-overload/).

### 13.4 Rate limiting and circuit breakers

A token bucket replenishes tokens at rate `r` up to burst capacity `b`; requests consume tokens. It supports bursts while constraining sustained usage. A fixed window can permit a double burst at the boundary. Sliding windows are smoother but may cost more state and computation.

Distributed rate limiting trades exactness against coordination. For a hard spending limit, approximate per-node counters may be unsafe; for abuse throttling they can be adequate with bounded overshoot. State whether a limiter outage fails open or closed for each operation.

A circuit breaker stops repeatedly calling a failing dependency for a period and probes for recovery. It can reduce wasted work, but misconfigured breakers can prolong outages. Bulkheads isolate pools so one dependency or tenant cannot exhaust all resources. Hedged requests can improve read tails but consume extra capacity and should be bounded and cancellable.

<a id="14-availability-and-disaster-recovery"></a>
## 14. Availability and disaster recovery

### 14.1 Fault domains and service dependencies

Replicas on three machines in one rack do not protect against a rack failure. Replicas in three zones do not automatically protect against a regional control-plane failure. Identify shared dependencies: DNS, authentication, key management, deployment tooling, and configuration can affect every replica.

For independent serial dependencies, multiplying their availabilities can provide a rough upper-level estimate. Five dependencies each at 99.9% give approximately `0.999^5 ≈ 99.501%`. Independence is often false, and cached or optional dependencies change the calculation. Use the exercise to find unnecessary synchronous dependencies, not to produce a precise SLA by arithmetic alone.

### 14.2 RPO and RTO

**Recovery point objective (RPO)** describes how much acknowledged data loss is acceptable, often expressed as a time window. **Recovery time objective (RTO)** describes how long restoration of the relevant service can take.

An asynchronously replicated region can have nonzero RPO. If the requirement is zero loss of acknowledged writes under complete region loss, success must wait for an appropriate durable copy outside that region or another mechanism providing the same fault survival. That decision affects latency and write availability.

Do not give one recovery number for everything. Metadata, file content, search, and previews can have different recovery paths. A file head recovered without its bytes is not a recovered file.

### 14.3 Failover needs fencing

```mermaid
flowchart TD
    F[Suspected leader or region failure] --> Q{Can safe ownership be established?}
    Q -->|No| R[Pause affected writes and preserve safety]
    Q -->|Yes| E[Issue new ownership epoch]
    E --> S[Fence stale writers at storage]
    S --> C[Confirm recoverable metadata and content]
    C --> T[Route traffic and monitor recovery]
```

A timeout is evidence of suspicion, not proof that the old leader is dead. Failover must prevent both sides from acting as current owner. Clients should tolerate redirects, transient errors, and retryable operation status queries.

### 14.4 Backups and restore

Back up data, schema, configuration, and the ability to decrypt data. Test point-in-time recovery, access-policy restoration, and index rebuilds. Keep recovery tools usable when the primary identity or control plane is impaired.

Measure actual restore throughput. Restoring 1 PB at 10 GB/s takes approximately 100,000 seconds, or 27.8 hours, before verification and service warmup. “We have backups” does not establish a one-hour RTO.

Deleted-data policy must cover replicas, backups, derived indexes, exports, and retained logs. Keep deletion markers or an equivalent ledger long enough that restoring an old snapshot does not resurrect data already purged by policy.

<a id="15-security-and-privacy"></a>
## 15. Security and privacy

### 15.1 Identify trust boundaries

The client is untrusted. It can lie about object ownership, file size, checksum, MIME type, and completion status. An internal network is not automatically a trusted identity. Validate inputs and authenticate service-to-service calls according to the deployment model.

Authentication establishes who is calling. Authorization determines whether that identity may perform an action on a resource. Encryption protects data under particular threat assumptions; it does not establish either of those decisions by itself.

### 15.2 Authorization as a consistency problem

If access is revoked and a new sensitive revision is then published, serving that revision based on an older permissive authorization snapshot leaks data. Content freshness and permission freshness must be compatible. This is one reason permission checks deserve the same concurrency reasoning as database writes.

Google's Zanzibar paper describes a relationship-based authorization system and causal consistency between authorization and content changes. It is useful background for reasoning about nested groups and resource hierarchies. [Primary reference: Zanzibar](https://www.usenix.org/conference/atc19/presentation/pang).

Always include tenant scope in data access. Unpredictable object IDs are not access control. Filtered search results, snippets, filenames, counts, and timing can expose information even when the actual download is blocked.

### 15.3 Encryption and key management

Use transport encryption and a defined at-rest encryption model. Envelope encryption uses data-encryption keys protected by higher-level keys, enabling rotation without necessarily re-encrypting all payload bytes. Explain key availability, access auditing, rotation, backup, and compromise response.

End-to-end encryption means the server lacks plaintext access under the chosen key model. It changes search, previews, malware scanning, deduplication, sharing, recovery, and device onboarding. Do not promise those capabilities unchanged without explaining a client-side mechanism and its tradeoffs.

### 15.4 Abuse and privacy

Consider credential abuse, enumeration, excessive storage reservation, expensive downloads, decompression bombs, malicious file parsers, and spam sharing. Sandbox preview generation with CPU, memory, time, and network limits. Use controlled content-serving origins and safe response headers to reduce browser execution risks.

Logs should contain correlation IDs and necessary operational metadata, not raw private documents, bearer tokens, or signed URLs. Set retention by purpose. Compliance and residency are product constraints to clarify; avoid inventing universal legal retention rules.

<a id="16-observability-and-testing"></a>
## 16. Observability and testing

### 16.1 Measure the user journey

Track request rate, errors, latency, and saturation, then add domain metrics. For Drive: successful publication, time to usable revision, sync lag, conflict frequency, permission-denial anomalies, corrupt-object detection, orphaned bytes, and restore completion.

Use histograms for latency distributions, not just averages. Segment by operation, region, and controlled workload classes. Unbounded labels such as individual file IDs can create excessive metric cardinality; keep detailed IDs in appropriately controlled logs or traces.

Distributed tracing follows a logical operation across service calls. Preserve the operation ID across retries while assigning attempt IDs where useful. A trace should reveal whether time was spent waiting in a queue, authorizing, replicating, or streaming.

### 16.2 Alert on outcomes and exhaustion

Page on user impact, rapid error-budget consumption, and imminent irreversible failures. Use dashboards or lower-urgency alerts for slower trends. A healthy process metric does not prove users can upload files. A short spike in an optional preview queue need not wake everyone unless it threatens a promise.

### 16.3 Verification methods

| Method | What it reveals |
|---|---|
| Unit tests | Local validation and state-transition rules. |
| Transaction/concurrency tests | Lost updates, duplicate commits, quota races, conflicting moves. |
| Property-based tests | Invariants across generated operation sequences. |
| Model-based tests | Differences between an implementation and a simpler state machine. |
| Fault injection | Behavior after lost acknowledgements, crashes, delayed events, or partial storage failure. |
| Load tests | Saturation point, p99 behavior, skew, and fallback capacity. |
| Restore drills | Whether backups, keys, and runbooks actually restore service. |
| Compatibility tests | Old clients, old event schemas, mixed deployments. |

Use realistic skew and file-size distributions. A load test of uniformly tiny requests says little about a system with huge uploads and viral downloads. Avoid coordinated omission: a load generator that waits for each slow request before sending the next can hide the queueing users would experience under a fixed arrival rate.

### 16.4 Reconciliation is part of the design

Even carefully designed systems need checks for corrupted state, old bugs, and interrupted workflows. Reconcile logical quota with retained revisions, manifests with existing blobs, expected events with consumer progress, and permission materializations with their authoritative source. Repairs must be idempotent, bounded, auditable, and safe under concurrent normal traffic.

<a id="17-cost-migrations-and-evolution"></a>
## 17. Cost, migrations, and evolution

### 17.1 Model the dominant costs

```text
monthly cost ≈ retained storage × storage rate
             + origin and user egress × transfer rates
             + operations × request rates
             + compute time × compute rates
             + replication and inter-zone traffic
             + observability, backups, and operational overhead
```

Use symbolic rates or clearly labeled hypothetical prices unless current provider pricing is supplied. Compare architectures using cost per useful operation, per stored logical GB, or per active user. A 50% storage reduction can be a poor trade if it adds expensive reads to every download.

### 17.2 Compression, deduplication, and erasure coding

Compression reduces redundancy within data, with CPU and random-access costs. Deduplication shares identical data across references, introducing identity, privacy, reference-tracking, and garbage-collection complexity. Neither savings rate should be assumed without measuring the workload.

An erasure code with `k` data fragments and `m` parity fragments has idealized storage overhead `(k + m) / k`. A 10+4 layout gives 1.4× overhead and can recover from any four missing fragments for an appropriate MDS code, provided fragment placement respects failure domains. Repair bandwidth, encoding CPU, small-object overhead, and correlated failures still matter.

Replication is often simpler for hot or small data. Erasure coding can be attractive for cold large data. A hybrid changes lifecycle and repair logic; explain when objects move between policies and how transitions remain safe.

### 17.3 Expand, migrate, contract

A safe schema migration often adds the new representation first, deploys compatible code, backfills with checkpoints, verifies results, switches reads, and only later removes the old representation. Use idempotent backfills and throttle them against production load.

Compare old and new behavior using shadow reads where appropriate. Shadow writes must not accidentally trigger real side effects. Rollback plans must account for data written in a new format that old binaries cannot understand.

### 17.4 Evolution driven by measured bottlenecks

Start with a clear owner and a coherent transaction boundary. Add a cache when repeated reads are expensive; add partitions when measured capacity or isolation needs justify them; split a service when independent scaling or ownership requires it. Explain the next two likely bottlenecks and the signals that would trigger a redesign.

<a id="18-reusable-architecture-families"></a>
## 18. Reusable architecture families

Do not memorize one drawing per company. Practice the distinct hard problem behind each family.

| Family and practice prompt | Central decisions | Questions that expose depth |
|---|---|---|
| Object storage and sync: Drive or Dropbox | Metadata/content split, versions, resumability, change feeds. | What happens after a lost commit response or a month offline? |
| Messaging: team chat | Conversation ordering, delivery states, offline replay, membership. | Does “delivered” mean server, device, or human? |
| Feed: social timeline | Fanout-on-write versus read, ranking, celebrity skew. | How do edits and privacy changes remove cached entries? |
| Video: streaming platform | Upload processing, transcoding, segment delivery, CDN. | How do you start playback while processing continues? |
| Search: document search | Inverted index, ingestion, ranking, updates, authorization. | Can a revoked document appear in a snippet? |
| Payments or inventory | Idempotency, ledger, reservations, reconciliation. | Which invariant spans services and who resolves uncertainty? |
| Scheduler: distributed cron | Durable schedules, leases, fencing, retries. | Can two workers execute the same job after failover? |
| Rate limiter | Key scope, burst policy, exactness, failure behavior. | How much overshoot is acceptable across regions? |
| Metrics and logs | Ingestion, partitions, retention, aggregation, cardinality. | How do late data and overload change results? |
| URL shortener | ID allocation, redirect cache, abuse, expiration. | What happens when one URL becomes globally viral? |
| Geospatial service | Spatial indexing, location freshness, matching. | How precise and recent must locations be? |
| Reservation system | Holds, expiration, uniqueness, payments. | Can two users both see successful purchase of the last seat? |
| Collaboration editor | Operation representation, causal order, convergence. | How do undo and offline edits interact? |
| Web crawler | Frontier scheduling, politeness, deduplication, traps. | How do you bound one site's impact and avoid infinite URLs? |

### 18.1 Fanout-on-write versus fanout-on-read

Fanout-on-write materializes a result for each recipient when something changes. Reads are fast, but writes and deletions can be expensive for huge audiences. Fanout-on-read merges source streams when requested. Writes are cheap, but reads can become expensive and tail-sensitive. A hybrid can materialize ordinary accounts while handling very large audiences through shared streams.

The same pattern appears in Drive: copying each file-change event into every collaborator's feed versus having devices follow shared namespace logs. The choice depends on audience size, online activity, read frequency, and revocation behavior.

### 18.2 Online and batch paths

Some designs combine low-latency online work with batch reconciliation or indexing. Define how results converge, whether batch work can overwrite newer online state, and which version establishes precedence. “A nightly job fixes it” is acceptable only if that delay satisfies the product and the repair cannot corrupt newer data.

<a id="19-how-to-draw-and-explain-diagrams"></a>
## 19. How to draw and explain diagrams

Use different diagrams to answer different questions:

- **Architecture diagram:** responsibilities, dependencies, stores, and trust boundaries.
- **Sequence diagram:** time order, requests, responses, transaction commits, retries, and asynchronous work.
- **State machine:** allowed transitions and recovery after interrupted operations.
- **Entity model:** identity, relationships, constraints, and transaction locality.

For every arrow, be ready to state what travels over it, whether it is synchronous, who retries, and what happens if it fails. For every store, identify its authoritative data, partition key, replication policy, and retention. For every background consumer, identify ordering and deduplication.

Draw one successful path first, then add one realistic failure. An upload sequence that ends at “write to storage” omits publication. A sequence that ends at “notify device” omits replay after missed notifications.

Keep a baseline architecture readable. A sprawling diagram with 25 services and no explained write path is harder to assess than six well-defined components. Add detail in a second diagram around the critical subsystem. The [Drive case study](01-design-google-drive.md) includes architecture, entity, state, and sequence diagrams for this reason.

<a id="20-common-mistakes-and-blind-spots"></a>
## 20. Common mistakes and blind spots

| Mistake | Why it fails | Better reasoning |
|---|---|---|
| Start with technologies. | Requirements and invariants remain unspecified. | Explain what must happen before choosing mechanisms. |
| Promise “exactly once” everywhere. | External effects cross transaction boundaries. | Define one logical effect and its deduplication boundary. |
| Treat timeout as failure. | The server may already have committed. | Recover by operation identity and status. |
| Use a timestamp to resolve every conflict. | Clock skew and concurrent intent can destroy work. | Use versions and a product-specific merge policy. |
| Say “CAP: choose two.” | Hides operation-specific behavior during partitions. | Describe which requests reject and why. |
| Use cache invalidation as immediate revocation. | Stale caches and bearer URLs can remain usable. | Define and enforce the serving authorization contract. |
| Route all file bytes through metadata servers. | Couples bandwidth growth to transaction capacity. | Separate content transfer from publication control. |
| Ignore small-file overhead. | Per-object rows and requests can dominate. | Estimate object count as well as total bytes. |
| Replicate without backups. | Logical corruption spreads to replicas. | Test restoration from independent history. |
| Delete before considering old clients. | Stale clients can resurrect removed state. | Use tombstones, versions, and expired-cursor recovery. |
| Claim a queue solves overload. | Unbounded backlog is deferred failure. | Define admission, prioritization, and drain capacity. |
| Ignore control-plane dependencies. | A globally shared key or identity service can stop everything. | Include them in the availability model. |
| End with “monitor everything.” | No measurable user promise is defined. | Name SLIs and incident signals. |
| Optimize for uniform load. | Viral items and huge tenants dominate tails. | Stress skew, large objects, and reconnect storms. |
| Leave migration until after launch. | Ownership and schema changes can corrupt data. | Explain versioned routing and compatible rollout. |

### 20.1 Questions people often forget to ask

What exactly counts toward quota? Can two files have the same name? Are folders trees or graphs? Does deleting a folder immediately hide all descendants? Can a viewer see old revisions? What does “revoked” mean for an existing download? Are search results allowed to lag? What happens if the phone's clock is wrong? What happens if a device was offline longer than event retention? How do you recover a user whose sync client accidentally deleted everything? How do you tell an empty directory from a directory the user can no longer access?

These are not decorative edge cases. Each can change data modeling, consistency, or recovery. The [Drive question bank](01-design-google-drive.md#28-question-bank-with-answer-checkpoints) answers them in context.

### 20.2 Product tradeoffs you must not silently decide

Clarify destructive conflict resolution, end-to-end encryption, historical access, public sharing, retention, and region residency when they become relevant. You can propose defaults, but identify them as product decisions. Infrastructure cannot choose what users mean by “delete” or “keep both versions” without a contract.

<a id="21-question-bank-with-answer-checkpoints"></a>
## 21. Question bank with answer checkpoints

Answer aloud before reading the checkpoint. A checkpoint is the minimum a complete answer should cover; practice expanding each into a scenario and a failure case.

### Requirements and sizing

1. **What do you clarify first?** Core users and operations, correctness, scale, geography, completion semantics, and scope.
2. **How do you choose latency targets?** Start from user experience and geography, separate metadata from transfer time, and define percentile and measurement point.
3. **Why is average QPS insufficient?** Peaks, hot keys, expensive requests, payload size, concurrent connections, and failure headroom.
4. **How do you estimate storage?** Arrival bytes, retention, versions, redundancy, metadata, temporary uploads, and slack; state deletion assumptions.
5. **What changes when growth is tenfold?** Identify the actual bottleneck using CPU, bandwidth, IOPS, coordination, and skew rather than multiplying every service blindly.
6. **What does 99.9% availability mean?** Define the denominator and window. A time-based 30-day budget is about 43.2 minutes, but request-based availability is a different measure.
7. **How do you estimate worker count?** Arrival rate × service time gives average busy workers under simplifying assumptions; add utilization targets, variance, failures, and recovery backlog.
8. **Which estimates can you skip?** Those that do not alter a decision; focus on order-of-magnitude constraints.

### Data and consistency

9. **Why choose a relational database?** Transactions, constraints, and query requirements; discuss contention and partitioning without assuming scale is impossible.
10. **How do you prevent lost updates?** Conditional version checks or serialized transactions; show two simultaneous writers.
11. **How does serializability differ from linearizability?** Transaction-equivalent ordering versus real-time atomic operations; mention strict serializability.
12. **When is eventual consistency acceptable?** Derived or mergeable state with an explicit freshness and conflict contract, not every field indiscriminately.
13. **Does `R + W > N` guarantee strong consistency?** No; overlap is only one condition, and versioning, concurrency, and quorum implementation matter.
14. **How does a read replica affect read-your-writes?** Lag can violate it; use leader reads, a session version watermark, or waiting for replica catch-up.
15. **How do you avoid split brain?** Safe leader election, ownership epochs, and fencing enforced at the resource.
16. **Why not use a distributed lock everywhere?** Leases expire, holders pause, lock services fail, and multirow invariants may still need transactions.
17. **What makes an ID suitable?** Uniqueness scope, allocation availability, order/locality, privacy, and clock or worker-ID failure behavior.
18. **What does stable pagination require?** A deterministic tie-breaker; a snapshot contract if enumeration consistency matters; token scope and expiration.

### Messaging and failure

19. **The response was lost after commit; what next?** Retry or query with the same operation key and retrieve the durable outcome.
20. **How do you atomically update a database and notify consumers?** Outbox or committed-change capture, then at-least-once delivery and idempotent consumption.
21. **A consumer processed an event but did not acknowledge it; what happens?** Redelivery; commit deduplication with the effect or use monotonic version application.
22. **Can a broker guarantee exactly-once email delivery?** Not by itself; external provider cooperation and a defined semantic boundary are needed.
23. **How do retries cause outages?** Attempt multiplication and synchronized retry bursts amplify load on a struggling dependency.
24. **How do you choose retryable errors?** Distinguish transient infrastructure failure from authorization, malformed input, and semantic conflict; account for unknown outcomes.
25. **Why bound queues?** To bound resource use and latency; then specify rejection, prioritization, and backpressure.
26. **How do you recover a poisoned event?** Bounded retries, quarantined context, diagnosis, corrected replay, and preserved idempotency.
27. **How do you retain order while scaling consumers?** Partition by the required ordering key; accept that one hot key may remain serialized.
28. **What if event retention expires?** Rebuild from a snapshot or source of truth, with a coherent checkpoint and old-event handling.

### Performance and operations

29. **How do you choose a partition key?** Transaction locality, query locality, expected distribution, and the largest possible tenant or key.
30. **How do you solve a hot key?** Cache or replicate immutable reads; combine or redesign writes only if the semantic contract permits it.
31. **What if the cache fails?** Bound fallback traffic, coalesce misses, preserve authorization, and shed optional work.
32. **How do you invalidate safely?** Explain stale-fill races and use versioning, authoritative checks, or an explicitly bounded stale policy.
33. **How do you meet a zero regional RPO?** Acknowledge only after data survives the chosen regional failure; include both metadata and payload.
34. **Why are replicas insufficient as backups?** Corruption and accidental deletion replicate; independent retained history enables recovery.
35. **How do you prove a restore plan works?** Restore representative data with keys and policies, verify integrity, and measure time at realistic throughput.
36. **What makes an alert actionable?** User impact, urgency, an owner, diagnostic context, and a plausible response.
37. **How do you deploy without downtime?** Compatible schema and API evolution, capacity overlap, canarying, and rollback-aware data formats.
38. **What is your first cost optimization?** Measure the dominant cost and preserve the required guarantees; do not assume storage or CPU is always largest.

### Security and judgment

39. **Can a random file ID replace authorization?** No. IDs can leak and do not express permitted actions.
40. **Can a signed URL be instantly revoked?** Only if the serving path supports a revocation check or invalidation mechanism; expiration alone is bounded eventual revocation.
41. **How do you prevent search leaks?** Authorize candidates and all exposed metadata against current policy; stale indexing must not imply stale access.
42. **What does end-to-end encryption change?** Server-side plaintext processing, sharing keys, device recovery, indexing, previews, and abuse handling.
43. **How do you isolate tenants?** Scoped keys, authorization, resource quotas, fair scheduling, and operational blast-radius controls.
44. **How do you handle clocks moving backward?** Avoid clock-only ordering for correctness; use versions or appropriate logical mechanisms.
45. **What if the interviewer changes a requirement?** Identify the assumption that changed, update the contract, and show the corresponding architecture change.
46. **What if you do not know a product's guarantee?** State the capability you require and the uncertainty; do not invent guarantees from a brand name.
47. **How do you end an answer?** Summarize the main user paths, enforced invariants, accepted tradeoffs, and the next bottleneck.
48. **How do you choose between two valid designs?** Compare against the same workload, failure model, consistency requirements, operational cost, and team constraints.

<a id="22-practice-plan-and-mock-interviews"></a>
## 22. Practice plan and mock interviews

### 22.1 Four-week plan

| Week | Study | Deliberate practice | Deliverable |
|---|---|---|---|
| 1 | Sections 2–10; requirements, estimates, storage, consistency. | Design a URL shortener, rate limiter, and inventory reservation service. | One-page designs with invariants and estimates. |
| 2 | Sections 11–17; cache, queues, reliability, security. | Add lost responses, duplicate events, hot keys, and region loss to week 1 designs. | Failure tables and sequence diagrams. |
| 3 | Full [Google Drive case study](01-design-google-drive.md). | Reproduce upload, conflict, sync bootstrap, revoke, and purge protocols without looking. | A coherent 45-minute Drive presentation. |
| 4 | Architecture families and weak areas. | Four timed mocks: messaging, feed, scheduler, and a second Drive attempt. | Scores, recorded gaps, and corrected explanations. |

Each study session should include recall. Close the guide, draw the system, and explain a failure. Recognizing a diagram when reading is much easier than generating a correct protocol under pressure.

### 22.2 A useful self-review rubric

Score each dimension from 0 to 3: missing, superficial, coherent, or defended under challenge. This is a practice tool, not a company hiring rubric.

| Dimension | Evidence for a strong self-score |
|---|---|
| Requirements | Prioritized scope, measurable goals, explicit invariants. |
| Estimation | Correct units and estimates that change design choices. |
| Baseline | Complete read/write paths with an authoritative store. |
| Correctness | Clear transaction boundaries, concurrency, and retry behavior. |
| Scale | Partition key, skew, bandwidth, and realistic bottlenecks. |
| Failure | Partial failure, repair, recovery, and degraded behavior. |
| Security | Resource authorization, privacy, revocation, and abuse. |
| Communication | Clear decisions, readable diagrams, adaptation to questions. |

After each mock, identify the two weakest dimensions. Rework those mechanisms rather than merely reading another design.

### 22.3 Failure drills

Run these against any design:

1. Crash the server immediately before and immediately after its commit point.
2. Lose every response from one successful operation and retry it concurrently.
3. Deliver events twice and in reverse order.
4. Pause a lease holder until its lease expires, then resume it.
5. Revoke a user's access while a read or upload is in progress.
6. Lose the largest region during a traffic peak.
7. Restore a month-old backup and reconnect a year-old device.
8. Give one tenant half the traffic and one object a million readers.
9. Fill the queue, disk, connection pool, and user's local disk separately.
10. Deploy old and new versions together, then roll back.

The answer should name a state transition and recovery mechanism, not only “retry,” “replicate,” or “monitor.”

### 22.4 Connecting this guide to the C++ material

System design and implementation interact. Bounded queues, memory limits, cancellation, and backpressure depend on correct local code. Review [Linux networking and I/O](../01-general-topics/17-linux-for-cpp.md), [file I/O and durability](../01-general-topics/20-file-io-read-stdio-iostream-mmap.md), [concurrency](../01-general-topics/04-concurrency-and-memory-model.md), and [memory ordering](../01-general-topics/24-memory-order-and-barriers-complete-guide.md) when implementing components. A mutex only coordinates threads in its process; it does not serialize requests across replicas.

<a id="23-final-interview-checklist"></a>
## 23. Final interview checklist

Before finishing, check whether you can answer each item in one or two sentences:

- [ ] Who uses the system, and which operations are in scope?
- [ ] What does successful completion mean?
- [ ] Which invariant must never be violated?
- [ ] What are peak operations, bandwidth, retained bytes, and skew?
- [ ] Where is authoritative data stored?
- [ ] What are the entity IDs, partition keys, indexes, and ownership rules?
- [ ] Can I walk a complete write and read?
- [ ] Where is the commit point, and what does its acknowledgement survive?
- [ ] What happens after an unknown result or a duplicate request?
- [ ] What happens when two users act concurrently?
- [ ] Which reads can be stale, and by how much?
- [ ] How do background consumers recover and deduplicate?
- [ ] How do clients recover after lost notifications or expired history?
- [ ] How do authorization, revocation, and deletion interact with caches?
- [ ] What is the first hot key, large tenant, or bandwidth bottleneck?
- [ ] How does the system reject or defer excess work?
- [ ] What happens during machine, zone, and region failure?
- [ ] What are RPO, RTO, backup, restore, and reconciliation procedures?
- [ ] Which user-facing metrics and alerts show correctness and health?
- [ ] How do schemas, ownership, and clients evolve safely?
- [ ] What is expensive, and what tradeoff would reduce that cost?
- [ ] Which important extensions did I identify but leave outside the baseline?

<a id="24-glossary"></a>
## 24. Glossary

| Term | Meaning in this guide |
|---|---|
| ACL | Access-control list: grants associated with a resource. |
| CAS | Compare-and-swap; here, a conditional state update based on an expected version. |
| CDC | Change data capture from committed database history. |
| CDN | Content delivery network serving cached content near users. |
| Checkpoint / cursor | Durable position from which a consumer resumes. |
| Control plane | Metadata, policy, routing, and coordination operations. |
| Data plane | The path carrying the main payload, such as file bytes. |
| Deduplication | Recognizing repeated operations or identical content; specify which. |
| Epoch / generation | Monotonic version identifying an ownership or state change. |
| Fanout | One operation causing work for many downstream recipients. |
| Fencing | Rejecting actions from an obsolete owner or lease holder. |
| Hotspot | A disproportionate concentration of load on one key or resource. |
| Idempotent | Repeating an operation has the same intended logical effect. |
| Immutable | Never modified after creation; new state gets a new identity. |
| Lease | Time-limited authority whose expiration requires safe handling. |
| Manifest | Ordered metadata describing the pieces of a larger object. |
| MVCC | Multiversion concurrency control: retaining versions for transaction visibility. |
| Outbox | Events stored atomically with the business mutation for later publication. |
| Quorum | A set of participants sufficient for a specified protocol decision. |
| RPO / RTO | Acceptable recovery data loss / acceptable service restoration time. |
| SLI / SLO / SLA | Measured indicator / target / contractual agreement. |
| Snapshot | A coherent view of state at a defined logical point. |
| Tombstone | A durable deletion marker retained for synchronization or safe reclamation. |
| Watermark | A progress boundary; its exact guarantees depend on the protocol. |
| Write amplification | Physical write work exceeding logical data changed. |

<a id="25-primary-source-reading-map"></a>
## 25. Primary-source reading map

Read with a question in mind. The original papers describe systems and assumptions at their publication time; they are not universal instructions or current product inventories.

| Read | Question to answer afterward |
|---|---|
| [Google SRE: implementing SLOs](https://sre.google/workbook/implementing-slos/) | Which user outcomes would you measure and how would they influence priorities? |
| [Google SRE: handling overload](https://sre.google/sre-book/handling-overload/) | How will the system remain useful when offered more work than it can process? |
| [Raft paper](https://raft.github.io/raft.pdf) | What state must replicas agree on, and what happens without a majority? |
| [Gilbert and Lynch: CAP](https://www.cs.princeton.edu/courses/archive/spr22/cos418/papers/cap.pdf) | Which guarantee must change during a partition? |
| [Dynamo paper](https://www.allthingsdistributed.com/files/amazon-dynamo-sosp2007.pdf) | What reconciliation burden follows from accepting concurrent versions? |
| [Spanner](https://research.google/pubs/spanner-googles-globally-distributed-database/) | What does global transactional consistency cost and require? |
| [Zanzibar](https://www.usenix.org/conference/atc19/presentation/pang) | Why must authorization and content respect causal dependencies? |
| [The Google File System](https://research.google/pubs/the-google-file-system/) | How do workload assumptions influence file storage architecture? |
| [Bigtable](https://research.google/pubs/bigtable-a-distributed-storage-system-for-structured-data/) | How does row-key design determine locality and hotspots? |
| [PostgreSQL isolation](https://www.postgresql.org/docs/current/transaction-iso.html) | Which anomalies can occur at the actual chosen isolation level? |
| [Kafka design](https://kafka.apache.org/41/design/design/) | What is ordered, what is replayable, and where do transactional guarantees end? |
| [HTTP semantics](https://www.rfc-editor.org/rfc/rfc9110.html) | How do preconditions and range requests support safe clients? |
| [Cloud Storage consistency](https://docs.cloud.google.com/storage/docs/consistency) | Which object operations are strong, and which related behaviors need separate treatment? |
| [S3 presigned URLs](https://docs.aws.amazon.com/AmazonS3/latest/userguide/using-presigned-url.html) | What authority does a URL grant, and how does it expire? |
| [Drive uploads](https://developers.google.com/workspace/drive/api/guides/manage-uploads) | What public resumable-upload behavior must an API client handle? |
| [Drive change retrieval](https://developers.google.com/workspace/drive/api/guides/manage-changes) | How do pagination and durable polling differ from a notification? |

Next: work through [Design Google Drive](01-design-google-drive.md), then reproduce its core protocols without consulting the text.
