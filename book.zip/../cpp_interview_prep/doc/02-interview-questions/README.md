# Раздел 2. Конкретные вопросы с интервью

## Формат

Файл 01 — референсный: это реальный слитый с интервью код, разбор идёт сразу, без спойлера.

Файлы 02–13 устроены одинаково и рассчитаны на самостоятельное решение:

```
## Вопрос          — постановка + код с намеренно заложенными багами
<details>Разбор</details>   — свёрнуто, открываешь ПОСЛЕ того, как ответил сам
## На что смотрит интервьюер
## Чеклист для устного ответа
```

Блоки с багами помечены комментарием `// Пример намеренно сломан.` В секции «Вопрос»
намеренно нет подсказок — сначала ищешь сам.

## Основной блок (02–11)

Порядок — по приоритету подготовки.

### Слой A — язык и STL

| # | Файл | О чём |
|---|---|---|
| 01 | [Слитый код: `vector` + `set<string>`](01-leaked-interview-code-vector-remove-and-set-capitalize.md) | Реальные вопросы с интервью: erase-remove idiom, что на самом деле делает `remove_if`, `std::erase_if` (C++20), capitalize в `std::set<std::string>` через `extract`/node handle (C++17). Плюс разбор ошибок «списанного» ответа и раздел «как отвечать, чтобы не выглядеть как человек, читающий чужой ответ». |
| 02 | [Инвалидация итераторов](02-iterator-invalidation-erase-in-loop.md) | Удаление элементов во время обхода `vector`, `map` и `unordered_map`. Почему `vector::erase` инвалидирует всё до конца, а `map::erase` — только удалённый узел; идиома `it = c.erase(it)`; range-based for кэширует `end()`; сводная таблица инвалидации. |
| 03 | [`shared_ptr`: цикл и `weak_ptr`](03-shared-ptr-cycles-and-weak-ptr.md) | Утечка по циклической ссылке, направление владения, `weak_ptr::lock()`, устройство control block (strong/weak count, deleter), что атомарно и что нет, `make_shared` против `shared_ptr(new T)`. |
| 04 | [Move semantics](04-move-semantics-noexcept-self-move.md) | Рукописные move-операции: забытый `noexcept` и `move_if_noexcept` при реаллокации `vector`, self-move, незанулённые поля, moved-from state, rule of five, `return std::move(x)` ломает NRVO. |
| 05 | [Exception safety](05-exception-safety-and-raii.md) | `operator=` через delete+new как антипаттерн, copy-and-swap, гарантии nothrow/strong/basic/none, утечка при броске в конструкторе, бросок из деструктора и почему деструкторы неявно `noexcept`. |
| 06 | [UB и type punning](06-ub-and-type-punning.md) | Strict aliasing и что с таким кодом делает `-O2`, `union`-хак, `std::memcpy` и `std::bit_cast` (C++20), исключение `char`/`unsigned char`/`std::byte`, signed overflow, выравнивание, endianness. |

### Слой B — конкурентность

| # | Файл | О чём |
|---|---|---|
| 07 | [Double-checked locking / singleton](07-double-checked-locking-singleton.md) | Data race на сыром флаге, отсутствие happens-before, публикация недостроенного объекта из-за переупорядочивания; починка через `atomic` + acquire/release, `std::call_once`, magic statics (C++11), static init order fiasco. |
| 08 | [Thread pool на `mutex` + `condition_variable`](08-thread-pool-condition-variable.md) | `wait` без предиката и spurious wakeup, lost wakeup, работа под локом, graceful shutdown (флаг + `notify_all` + `join`), исключение из задачи убивает процесс, `packaged_task`/`promise`. |
| 09 | [Lock-free SPSC ring buffer](09-lock-free-spsc-ring-buffer.md) | `relaxed` вместо acquire/release и что именно гарантирует пара, неверное вычисление full/empty, false sharing и `alignas(hardware_destructive_interference_size)`, кэширование чужого индекса, wait-free vs lock-free. |
| 10 | [Spinlock на `std::atomic_flag`](10-spinlock-atomic-flag-memory-order.md) | Наивный `test_and_set` в цикле, почему нужен TTAS, acquire/release вместо `seq_cst`, backoff (`_mm_pause`, `yield`), когда spinlock хуже мьютекса: oversubscription, вытеснение внутри критической секции, приоритетная инверсия. |

### Слой C — quant / performance

| # | Файл | О чём |
|---|---|---|
| 11 | [Cache-friendliness: order book](11-cache-friendliness-order-book.md) | AoS vs SoA с оценкой в мегабайтах трафика, `std::map<price, level>` против отсортированного вектора и почему pointer chasing не префетчится, alignment и padding, false sharing на счётчиках, модель стоимости памяти в наносекундах. |

## Дополнительно (12–13)

Менее вероятно, но полезно; в основной список не входит.

| # | Файл | О чём |
|---|---|---|
| 12 | [Шаблоны: SFINAE → `if constexpr` → concepts](12-templates-sfinae-if-constexpr-concepts.md) | Неоднозначные `enable_if`-перегрузки, forwarding-конструктор, перехватывающий копирование, reference collapsing, `if constexpr`, subsumption у концептов. |
| 13 | [Floating point в quant-коде](13-floating-point-in-quant-code.md) | Сравнение с epsilon и ULP, накопление ошибки и Kahan, catastrophic cancellation в дисперсии и алгоритм Уэлфорда, `-ffast-math`, denormals и всплески латентности, детерминизм backtest'а. |

## Сквозные темы

Если времени мало, готовь в первую очередь это — оно всплывает почти в каждом вопросе:

- **Инвалидация итераторов** по контейнерам (01, 02, 11).
- **Release/acquire и happens-before** (07, 08, 09, 10).
- **Data race = UB**, а не «редкий баг» (07, 08, 09, 10).
- **`noexcept`** и его влияние на поведение STL (04, 05).
- **RAII и exception safety** (04, 05, 08).
- **Владение**: `unique_ptr` по умолчанию, `shared_ptr` только при разделяемом владении (03, 11).
- **Модель стоимости памяти**: кэш-линия, false sharing, аллокации в hot path (09, 10, 11).
- **UB, которое проявляется только на `-O2`** (06, 07).

## Как тренироваться

По каждому файлу: читаешь секцию «Вопрос», **не разворачивая спойлер**, засекаешь 10–15
минут (это близко к реальному темпу интервью), выписываешь найденные проблемы, потом
открываешь «Разбор» и сверяешься. Отдельно прогоняй вслух «Чеклист для устного ответа» —
на интервью важна не только правильность, но и то, насколько структурно ты формулируешь.

## Пул коротких вопросов

| # | Тема |
|---|---|
| [14](14-question-pool.md) | Десять компактных фрагментов «найди баг»: висячий `string_view`, range-for по временному (C++20 против C++23), захваты лямбды и `this`, отсутствие виртуального деструктора, `vector<bool>` и прокси, static init order fiasco, знаковое/беззнаковое, `std::function` в hot path, deadlock и `scoped_lock`, `const`-метод и потокобезопасность |
