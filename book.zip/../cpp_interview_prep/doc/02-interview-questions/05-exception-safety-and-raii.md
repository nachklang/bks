# 05. Exception safety: гарантии, `operator=` через delete+new, copy-and-swap

## Вопрос

Вот менеджер соединений.

Какие гарантии безопасности исключений даёт каждый метод этого класса? Что произойдёт,
если исключение вылетит в каждой из отмеченных точек (1)–(5)?

```cpp
// Пример намеренно сломан.
#include <mutex>
#include <string>
#include <vector>

class Connection
{
public:
    explicit Connection(const std::string& host);
    ~Connection();
    void send(const std::string& msg);
};

class Session
{
public:
    Session(const std::string& host, std::size_t buf_size)
        : conn_(new Connection(host))
        , buf_(new char[buf_size])           // (5)
        , size_(buf_size)
        , host_(host)
    {
        conn_->send("HELLO");
    }

    ~Session()
    {
        conn_->send("BYE");     // (1)
        delete conn_;
        delete[] buf_;
    }

    Session& operator=(const Session& other)
    {
        delete conn_;
        delete[] buf_;
        conn_ = new Connection(other.host_);   // (2)
        buf_  = new char[other.size_];
        size_ = other.size_;
        log_  = other.log_;
        return *this;
    }

    void reconnect(const std::string& host)
    {
        delete conn_;                        // (3)
        conn_ = new Connection(host);
    }

    void add_all(const std::vector<std::string>& msgs)
    {
        std::lock_guard<std::mutex> lk(m_);
        for (const auto& m : msgs)
        {
            log_.push_back(m);               // (4)
            conn_->send(m);
        }
    }

private:
    Connection* conn_;
    char* buf_;
    std::size_t size_;
    std::string host_;
    std::mutex m_;
    std::vector<std::string> log_;
};
```

<details>
<summary>Разбор</summary>

### Три (четыре) гарантии — терминология, которую надо назвать первой

| Гарантия | Смысл |
|---|---|
| **nothrow / no-fail** | Операция не бросает вообще. Обязательна для деструкторов, `swap`, move-операций, освобождения ресурсов. |
| **strong** | «Commit or rollback»: либо операция выполнена целиком, либо состояние ровно такое, каким было до вызова. Ничего не утекло. |
| **basic** | Инварианты сохранены, ничего не утекло, но состояние может быть изменённым (валидным, но неопределённым). |
| **none** | Никаких обещаний. Обычно означает UB/утечку — по сути баг. |

### Баг 1 (место (5)): утечка в конструкторе

```cpp
: conn_(new Connection(host))
, buf_(new char[buf_size])      // если бросит bad_alloc — conn_ утечёт
```

Правило: **если конструктор бросает, деструктор объекта НЕ вызывается**. Уже
сконструированные *члены* разрушаются, но `conn_` — сырой указатель, у него нет
деструктора. `Connection` утекает. То же самое, если бросит `conn_->send("HELLO")`
в теле конструктора.

Лечение — RAII на каждый ресурс: `std::unique_ptr<Connection> conn_;` и
`std::vector<char> buf_;`. Тогда любое исключение на любом шаге корректно разматывается.

Альтернатива (если нельзя менять типы) — function-try-block, но это громоздко и почти
всегда признак того, что вы не используете RAII.

### Баг 2 (место (1)): бросок из деструктора → `std::terminate`

`conn_->send("BYE")` может бросить. С C++11 деструкторы **неявно `noexcept`**, поэтому
исключение, вылетевшее из деструктора, приводит к `std::terminate()` — процесс умирает.

**Почему деструкторы сделали неявно `noexcept`.** Причина — stack unwinding. Когда
исключение раскручивает стек, оно вызывает деструкторы локальных объектов. Если один
из них бросит **второе** исключение, в полёте окажутся два исключения одновременно, а
языковой механизм умеет обрабатывать ровно одно — в этой ситуации всегда вызывался
`std::terminate` (ещё до C++11). C++11 просто сделал это правило явным и распространил
на все случаи: деструктор по умолчанию `noexcept(true)`, если только все его подобъекты
не имеют потенциально бросающих деструкторов (можно явно написать `noexcept(false)`,
но это почти всегда ошибка проектирования).

Плюс: здесь ещё и `delete conn_`/`delete[] buf_` не выполнятся — утечка.

Правило: **деструктор не должен бросать. Никогда.** Всё, что может упасть, оборачивается:

```cpp
~Session() noexcept
{
    try { conn_->send("BYE"); }
    catch (...) { /* залогировать; наружу не выпускать */ }
}
```

Если операция «закрытия» логически может провалиться и это важно знать вызывающему —
нужен явный метод `close()`, который бросает, а деструктор делает best-effort
(так устроен `std::fstream`, так рекомендуют делать с транзакциями).

### Баг 3 (место (2)): `operator=` через delete+new — ни strong, ни basic guarantee

Каноническая антипаттерн-реализация:

```cpp
delete conn_;
delete[] buf_;
conn_ = new Connection(other.host_);   // если бросит — объект РАЗРУШЕН
buf_  = new char[other.size_];
size_ = other.size_;
```

Что здесь ломается:

1. **Нет strong guarantee.** Ресурсы уже освобождены, а новые ещё не получены. Если
   `new Connection` бросит `bad_alloc` или конструктор соединения кинет `network_error`,
   объект остаётся с **висячими** `conn_` и `buf_` и старым `size_`. Последующий
   деструктор сделает double-free — то есть нет даже **basic** guarantee: инварианты
   разрушены.
2. **Self-assignment.** `s = s;` уничтожит собственные данные, а потом попытается
   скопировать `other.host_` из уже уничтоженного объекта.
3. **Порядок присваиваний.** `log_ = other.log_` в конце может бросить (аллокация в
   `vector`), оставив объект наполовину обновлённым.

Правильное решение — **copy-and-swap**:

```cpp
Session& operator=(Session other) noexcept   // параметр по значению: копия уже сделана
{
    swap(other);
    return *this;
}

void swap(Session& other) noexcept
{
    std::swap(conn_, other.conn_);
    std::swap(buf_,  other.buf_);
    std::swap(size_, other.size_);
    host_.swap(other.host_);
    log_.swap(other.log_);
}
```

Почему это работает:
- Вся бросающая работа (копирование) происходит **до** входа в тело, при создании
  параметра. Если она упала — `*this` вообще не тронут → **strong guarantee**.
- Тело состоит только из `noexcept`-операций (`swap` указателей и контейнеров).
- Self-assignment безопасен автоматически: копия себя, потом обмен.
- Один `operator=` покрывает и copy, и move (для move параметр создаётся move-конструктором).

Цена: всегда создаётся временная копия, старая память не переиспользуется. Если это
критично, пишут две перегрузки: copy-assign через `Session tmp(other); swap(tmp);`
и move-assign через `swap(other)`.

Обрати внимание: `std::mutex` не movable и не swappable, поэтому в реальном классе с
мьютексом либо мьютекс не участвует в swap (он защищает объект, а не является его
состоянием — тогда нужен аккуратный захват обоих мьютексов через `std::scoped_lock`),
либо класс делается non-copyable. Это отдельная ловушка, которую стоит проговорить.

### Баг 4 (место (3)): `reconnect` не даёт даже basic guarantee

```cpp
delete conn_;                 // conn_ теперь висячий
conn_ = new Connection(host); // если бросит — объект в невалидном состоянии
```

Если конструктор `Connection` бросит, `conn_` останется висячим указателем. Деструктор
`Session` сделает `conn_->send("BYE")` — use-after-free, потом double delete.

Правильно — «сначала создать, потом заменить»:

```cpp
void reconnect(const std::string& host)          // strong guarantee
{
    auto fresh = std::make_unique<Connection>(host);
    conn_ = std::move(fresh);                    // move-assign unique_ptr — noexcept
}
```

Это общий рецепт strong guarantee: **всю бросающую работу сделать в сторонке, а
коммит выполнить только nothrow-операциями** (`swap`, move указателей, `std::exchange`).

### Баг 5 (место (4)): `add_all` даёт только basic guarantee, а выглядит как атомарная

Если `conn_->send(m)` бросит на третьем сообщении, первые два уже отправлены, а `log_`
уже содержит три записи. Состояние валидно, ничего не утекло (`lock_guard` корректно
отпустит мьютекс при раскрутке стека) — это **basic**, но не strong.

Если нужна strong: подготовить всё в локальной копии и закоммитить одним nothrow-шагом.

```cpp
void add_all(const std::vector<std::string>& msgs)   // strong для log_
{
    std::vector<std::string> tmp;
    tmp.reserve(log_.size() + msgs.size());
    tmp = log_;
    tmp.insert(tmp.end(), msgs.begin(), msgs.end());

    std::lock_guard<std::mutex> lk(m_);
    for (const auto& m : msgs)
        conn_->send(m);          // побочные эффекты наружу откатить нельзя в принципе
    log_.swap(tmp);              // noexcept commit
}
```

Важный честный ответ на интервью: **strong guarantee невозможна, если есть внешние
побочные эффекты** (отправка в сеть, запись в файл). Тогда либо basic + идемпотентность
на приёмнике, либо явный протокол отката. Это ценится выше, чем формальное «оберну в
try/catch».

### Что ещё правильно заметить

- `std::lock_guard` — сам по себе пример RAII: exception-safe разблокировка «бесплатно».
  Ручные `m_.lock()/m_.unlock()` в этом коде были бы багом номер один.
- `buf_`/`size_` не используются, но участвуют в утечках — мёртвый код тоже стоит назвать.
- Класс нарушает rule of 3/5: сырые указатели + сгенерированные компилятором copy-операции
  → двойное освобождение при копировании `Session`. Надо либо удалить копирование,
  либо перейти на RAII-члены (тогда rule of zero).
- `noexcept` на `~Session()` явно писать не обязательно (оно по умолчанию), но полезно.

### Правильная версия (rule of zero)

```cpp
#include <memory>
#include <mutex>
#include <string>
#include <vector>

class Session
{
public:
    Session(const std::string& host, std::size_t buf_size)
        : conn_(std::make_unique<Connection>(host))
        , buf_(buf_size)
    {
        conn_->send("HELLO");     // бросок здесь корректно разрушит conn_ и buf_
    }

    ~Session()
    {
        try { if (conn_) conn_->send("BYE"); }
        catch (...) {}
    }

    Session(const Session&) = delete;
    Session& operator=(const Session&) = delete;
    Session(Session&&) noexcept = default;
    Session& operator=(Session&&) noexcept = default;

    void reconnect(const std::string& host)
    {
        conn_ = std::make_unique<Connection>(host);
    }

private:
    std::unique_ptr<Connection> conn_;
    std::vector<char> buf_;
    std::mutex m_;
    std::vector<std::string> log_;
};
```

(`std::mutex` не movable, поэтому дефолтные move-операции здесь на самом деле удалятся —
это отдельный хороший момент, чтобы его заметить: мьютекс делает класс non-movable, и если
move нужен, мьютекс кладут в `unique_ptr` или переосмысливают дизайн.)

### Смежные вопросы, которые обычно идут следом

**«Сколько стоит исключение?»** На современных ABI (Itanium EH, table-driven) — **zero-cost
на happy path**: нет ни проверок, ни пролога; вся информация в таблицах в отдельной секции.
Но `throw` дорогой: аллокация объекта исключения, поиск по таблицам раскрутки,
захват глобального мьютекса в `_Unwind_*` на некоторых реализациях — единицы-десятки
микросекунд. Отсюда правило low-latency: исключения только для действительно
исключительных ситуаций, не для control flow в hot path; часто их и вовсе отключают
(`-fno-exceptions`) и используют коды ошибок / `std::expected`.

**«Что делает `noexcept` на функции, которая бросит?»** `std::terminate` немедленно,
без гарантии раскрутки стека. `noexcept` — не подавление, а обещание.

**«Зачем `noexcept` вообще?»** Оптимизатор не генерирует landing pads; `vector` использует
move вместо copy при реаллокации (`move_if_noexcept`); `noexcept(expr)` позволяет писать
условно-noexcept обобщённый код.

**«Исключение в потоке?»** Если вылетит из функции потока `std::thread` — `std::terminate`.
Ловить надо внутри и передавать через `std::promise::set_exception` /
`std::current_exception` + `std::rethrow_exception`.

</details>

## На что смотрит интервьюер

- Опознаешь ли `operator=` через delete+new как классический антипаттерн и предложишь ли
  **copy-and-swap** — это главный ожидаемый ответ.
- Называешь ли ты гарантии **по именам** и умеешь ли классифицировать каждый метод.
- Понимаешь ли, что **деструктор объекта не вызывается, если конструктор бросил**.
- Знаешь ли, что деструкторы `noexcept` по умолчанию с C++11, и объяснишь ли **почему**
  (два исключения одновременно во время раскрутки стека).
- Видишь ли паттерн «сначала создай, потом коммить nothrow-операцией».
- Скажешь ли, что strong guarantee нельзя дать при внешних побочных эффектах.
- Приходишь ли в итоге к RAII/rule of zero, а не к расстановке `try/catch`.

## Чеклист для устного ответа

- nothrow / strong / basic / none — знать определения и уметь применять к конкретной функции.
- Конструктор бросил → деструктор не вызовется → каждый ресурс под собственным RAII.
- Деструктор не бросает (иначе `terminate`); «закрытие с ошибкой» — отдельный `close()`.
- Strong guarantee = вся бросающая работа во временном объекте + nothrow commit (`swap`/move).
- `operator=` через delete+new: ресурсы уже освобождены, новые ещё не получены →
  висячие указатели, нет даже basic guarantee; плюс ломается self-assignment.
- copy-and-swap (параметр по значению + nothrow `swap`) решает self-assignment,
  strong guarantee и дублирование copy/move одним приёмом.
- `lock_guard`/`scoped_lock`/`unique_ptr` вместо ручных lock/unlock/delete.
- `noexcept` — обещание, нарушение = `terminate`; влияет на оптимизации и на `vector`.
- Исключения zero-cost на happy path, но дорогой `throw` — в hot path не для control flow.
