# 09. Lock-free SPSC ring buffer: memory ordering, false sharing, full/empty

## Вопрос

Вот очередь между потоком-приёмником market data и потоком-стратегией.
Один писатель, один читатель.

Найди все проблемы: и корректность, и производительность.

```cpp
// Пример намеренно сломан.
#include <atomic>
#include <cstddef>
#include <vector>

template <typename T>
class SpscQueue
{
public:
    explicit SpscQueue(std::size_t cap) : buf_(cap), cap_(cap) {}

    bool push(const T& v)
    {
        const std::size_t head = head_.load(std::memory_order_relaxed);
        const std::size_t tail = tail_.load(std::memory_order_relaxed);

        if (head - tail == cap_)
            return false;

        buf_[head % cap_] = v;
        head_.store(head + 1, std::memory_order_relaxed);
        return true;
    }

    bool pop(T& out)
    {
        const std::size_t head = head_.load(std::memory_order_relaxed);
        const std::size_t tail = tail_.load(std::memory_order_relaxed);

        if (head - tail <= 0)
            return false;

        out = buf_[tail % cap_];
        tail_.store(tail + 1, std::memory_order_relaxed);
        return true;
    }

    std::size_t size() const
    {
        return head_ - tail_;
    }

private:
    std::vector<T> buf_;
    std::size_t cap_;
    std::atomic<std::size_t> head_{0};
    std::atomic<std::size_t> tail_{0};
};
```

<details>
<summary>Разбор</summary>

### Баг 1: `memory_order_relaxed` везде — данные могут прийти позже индекса

Самый главный дефект. Индексы атомарны, гонки в формальном смысле на них нет, но
**`relaxed` не устанавливает никакого порядка** относительно других обращений к памяти.
Продюсер делает:

```cpp
buf_[head % cap_] = v;                                  // обычная запись
head_.store(head + 1, std::memory_order_relaxed);       // публикация
```

Ни компилятор, ни процессор не обязаны сохранять этот порядок. Консюмер может увидеть
новое значение `head_`, войти в `pop` и прочитать из `buf_` **старое содержимое ячейки**
— то есть чтение неинициализированных или уже перезаписанных данных. Между записью
элемента и его чтением нет **happens-before**, значит доступ к `buf_` — это **data race
и UB**, а не просто «неправильное значение».

**Что именно даёт release/acquire (объяснение «на пальцах»):**

- `store(x, release)` — «всё, что я записал **до** этого store, гарантированно видно
  тому, кто прочитает это значение через `acquire`». Никакая предшествующая запись не
  может быть переупорядочена вниз через release-store.
- `load(acquire)` — «всё, что было записано до соответствующего release-store, я увижу».
  Никакое последующее чтение не может быть переупорядочено вверх через acquire-load.
- Вместе они образуют **synchronizes-with**: release-store в потоке A и acquire-load в
  потоке B, прочитавший **именно это значение**, создают happens-before между всем, что
  было до store в A, и всем, что после load в B.

Важно: пара работает только «через переменную» — синхронизирует не сама по себе, а
когда load действительно прочитал значение, записанное этим store.

Отсюда правильная расстановка:
- Продюсер: запись данных → `head_.store(next, release)`.
- Консюмер: `head_.load(acquire)` → чтение данных → `tail_.store(next, release)`
  (release нужен, чтобы продюсер не перезаписал слот раньше, чем консюмер дочитал).
- Продюсер: `tail_.load(acquire)`.

Свой собственный индекс каждый поток может читать `relaxed` — он его единственный писатель.

### Баг 2: неверное вычисление full/empty

```cpp
if (head - tail == cap_) return false;   // push
if (head - tail <= 0)   return false;    // pop
```

Две ошибки:

1. **`head - tail <= 0` для `std::size_t` — всегда `false`**, когда разность не ноль,
   и `true` только при `head == tail`. Здесь это случайно совпало с «пусто», но
   `<= 0` на беззнаковом типе — сигнал, что автор не думал о типах; компилятор выдаст
   `-Wtype-limits`. Правильно: `head == tail`.
2. **Индексы читаются не в том порядке и не согласованно.** В `push` продюсеру нужен
   свежий `tail_`, а он читает и `head_` (свой, можно `relaxed`), и `tail_` (чужой,
   нужен `acquire`) как равноправные. Если между двумя загрузками консюмер что-то
   сделает, значения будут из разных моментов времени — для SPSC это безопасно
   (проверка лишь консервативна: `tail` может «отстать», и мы решим, что очередь
   полна, хотя место уже есть), но об этом надо сказать вслух, а не полагаться на удачу.
3. **Условие полноты `head - tail == cap_`** корректно для монотонных (не завёрнутых)
   индексов и даёт все `cap_` слотов. Но в этом коде вместе с `%` оно работает только
   потому, что `cap_` совпадает с размером буфера — стоит проверить в конструкторе, что
   `buf_.size() == cap_`, иначе получаем тихую порчу памяти.

Для сравнения: схема с завёрнутыми индексами («полно ⟺ `next(head) == tail`») теряет
один слот. Монотонные индексы + маска — чище.

### Баг 3: `size()` — гонка и бессмысленный результат

`head_ - tail_` читает два атомика **не атомарно**: между загрузками состояние меняется,
и результат может быть больше `cap_` или «из будущего». Плюс неявная конверсия
`std::atomic<size_t>` → `size_t` через `operator T()` использует `seq_cst`. В lock-free
очереди `size()` — это в лучшем случае подсказка; если она нужна, её надо документировать
как приблизительную и брать `tail` первым (тогда результат — верхняя оценка).

### Баг 4: разделяемый счётчик размера (частая альтернативная реализация)

Стоит проговорить и вариант, который часто пишут вместо этого: `std::atomic<size_t> size_`
с `++size_` в `push` и `--size_` в `pop`. Он корректен по гонкам, но **архитектурно
неверен**: это read-modify-write на одной кэш-линии из обоих потоков, то есть постоянный
`cache line ping-pong`. Правильный SPSC вообще **не нуждается в общем счётчике**:
продюсер пишет только `head_`, консюмер — только `tail_`.

### Сводка: где какой memory order нужен

| Место | Порядок | Почему |
|---|---|---|
| `head_.load` в `push` | `relaxed` | продюсер — единственный писатель `head_` |
| `tail_.load` в `push` | `acquire` | синхронизация с release-store консюмера (слот свободен) |
| `head_.store` в `push` | `release` | публикация записанных данных |
| `tail_.load` в `pop` | `relaxed` | консюмер — единственный писатель `tail_` |
| `head_.load` в `pop` | `acquire` | синхронизация с release-store продюсера (данные готовы) |
| `tail_.store` в `pop` | `release` | слот дочитан, можно перезаписывать |

Почему баг не проявляется на x86: TSO не переупорядочивает store-store и load-load,
поэтому железо «прощает» отсутствие барьеров. Но **компилятор** переупорядочивает на
любой архитектуре, а на ARM/POWER воспроизводится и аппаратное переупорядочивание.
Классическая ловушка «на моей машине работает».

### Баг 6: `% cap_` — деление в hot path

Целочисленное деление/остаток — 20–40 циклов на x86 и не конвейеризуется. Стандартное
решение: **capacity — степень двойки**, тогда `idx & (cap_ - 1)`, один такт. Проверять
в конструкторе:

```cpp
assert((cap & (cap - 1)) == 0 && cap >= 2);
```

Альтернатива без степени двойки — хранить индексы «не завёрнутыми» и делать
`if (++idx == cap_) idx = 0;` — предсказуемая ветка, тоже дёшево.

### Баг 7: false sharing

`head_`, `tail_`, `size_`, `cap_` лежат подряд и почти наверняка попадают в одну
64-байтную кэш-линию. Продюсер пишет `head_`, консюмер пишет `tail_` — линия
инвалидируется на каждой операции у обоих. Это **false sharing**: логически независимые
переменные конкурируют за одну линию. Замеры обычно показывают разницу в 2–10 раз.

Лечение — выравнивание на отдельные кэш-линии:

```cpp
static constexpr std::size_t kCacheLine = 64;   // или std::hardware_destructive_interference_size
alignas(kCacheLine) std::atomic<std::size_t> head_{0};
alignas(kCacheLine) std::atomic<std::size_t> tail_{0};
```

Правильное имя константы — **`std::hardware_destructive_interference_size`** из `<new>`
(C++17): «минимальное расстояние между объектами, при котором они гарантированно не
делят кэш-линию». Парная константа `std::hardware_constructive_interference_size` —
наоборот, максимальный размер, при котором объекты **стоит** класть рядом, чтобы они
попали в одну линию.

Практическая оговорка: GCC предупреждает об ABI-нестабильности этих констант
(`-Winterference-size`), а libc++ долго их не определял, поэтому в проде обычно пишут:

```cpp
#ifdef __cpp_lib_hardware_interference_size
    static constexpr std::size_t kCacheLine = std::hardware_destructive_interference_size;
#else
    static constexpr std::size_t kCacheLine = 64;
#endif
```

64 — верно для x86-64 и большинства ARM; на Apple M-серии и некоторых POWER — 128,
и там `alignas(64)` не спасёт от false sharing.

### Баг 8: одна лишняя загрузка чужого индекса на каждую операцию

Даже с корректными atomics продюсер на каждом `push` читает `tail_` — а это загрузка
кэш-линии, которую пишет другое ядро. Профессиональный приём — **кэшировать чужой индекс
локально** и перечитывать только когда локальная копия говорит «полно/пусто». Это
превращает большинство операций в чисто локальные и даёт основной выигрыш в реальных
бенчмарках (так устроены Folly `ProducerConsumerQueue`, Boost `spsc_queue`, очередь Rigtorp).

### Баг 9: capacity и монотонные индексы

При схеме «пусто ⟺ head == tail» и «полно ⟺ next(head) == tail» реально доступно
`cap - 1` элементов. Это надо либо задокументировать, либо использовать «не завёрнутые»
монотонные индексы (`head_ - tail_ == cap_` ⟺ полно), где доступны все `cap` слотов.
Второй вариант чище; переполнение `size_t` при монотонном росте на практике не наступает
(2^64 сообщений), но об этом стоит упомянуть — это признак аккуратности.

### Баг 10: конструирование/разрушение элементов

`std::vector<T> buf_(cap)` требует default-constructible `T` и создаёт `cap` объектов
заранее. `push` делает copy-assign в уже существующий объект — для `T` со сложным
состоянием (например, `std::string`) это может аллоцировать. В настоящей очереди для
low-latency используют сырое выровненное хранилище + placement new + явный вызов
деструктора в `pop`, чтобы избежать требований к `T` и лишней работы. Для интервью
достаточно **назвать** этот компромисс; полноценно писать placement-new-версию нужно,
только если попросят.

Также: `push(const T&)` — стоит добавить `push(T&&)` и `emplace`.

### Баг 11: нет `noexcept`

Возврат `bool` — нормально, но методы должны быть `noexcept` при `noexcept`-операциях `T`,
иначе исключение в lock-free-структуре оставит её в неопределённом состоянии.

### Корректная версия

```cpp
#include <atomic>
#include <cassert>
#include <cstddef>
#include <vector>

template <typename T>
class SpscQueue
{
public:
    explicit SpscQueue(std::size_t capacity)
        : buf_(capacity)
        , mask_(capacity - 1)
    {
        assert(capacity >= 2 && (capacity & (capacity - 1)) == 0);
    }

    SpscQueue(const SpscQueue&) = delete;
    SpscQueue& operator=(const SpscQueue&) = delete;

    bool push(const T& v)
    {
        const std::size_t head = head_.load(std::memory_order_relaxed);
        const std::size_t next = head + 1;

        if (next - cached_tail_ > buf_.size())
        {
            cached_tail_ = tail_.load(std::memory_order_acquire);
            if (next - cached_tail_ > buf_.size())
                return false;                              // полна
        }

        buf_[head & mask_] = v;
        head_.store(next, std::memory_order_release);      // публикация
        return true;
    }

    bool pop(T& out)
    {
        const std::size_t tail = tail_.load(std::memory_order_relaxed);

        if (tail == cached_head_)
        {
            cached_head_ = head_.load(std::memory_order_acquire);
            if (tail == cached_head_)
                return false;                              // пуста
        }

        out = std::move(buf_[tail & mask_]);
        tail_.store(tail + 1, std::memory_order_release);  // освобождение слота
        return true;
    }

private:
    static constexpr std::size_t kCacheLine = 64;

    std::vector<T> buf_;
    std::size_t mask_;

    alignas(kCacheLine) std::atomic<std::size_t> head_{0};
    alignas(kCacheLine) std::size_t cached_tail_ = 0;      // только продюсер

    alignas(kCacheLine) std::atomic<std::size_t> tail_{0};
    alignas(kCacheLine) std::size_t cached_head_ = 0;      // только консюмер
};
```

Разбор ключевых мест, который надо проговорить:

- `head_` пишет **только** продюсер, `tail_` — **только** консюмер. Значит свои индексы
  читаются `relaxed`, чужие — `acquire`, публикация — `release`.
- `next - cached_tail_ > buf_.size()` — арифметика на монотонных (не завёрнутых) индексах;
  беззнаковая разность корректна даже при переполнении.
- `cached_*` — обычные не-атомарные поля, приватные для одного потока.
- `release`-store в `pop` нужен, чтобы продюсер не перезаписал слот раньше, чем консюмер
  дочитал из него значение.

### Смежные вопросы

- **«А если много писателей?»** SPSC ломается. Для MPMC нужен CAS-цикл на индексе
  (`compare_exchange_weak`) и per-slot sequence-номера (очередь Вьюкова), либо
  `head_.fetch_add` с секвенсами. Сложность возрастает на порядок; на интервью
  правильный ответ — «взял бы проверенную реализацию (Folly MPMCQueue, moodycamel),
  а не писал свою».
- **«Почему `compare_exchange_weak`, а не `strong`?»** Weak может дать spurious failure
  (на LL/SC-архитектурах — ARM/POWER), но дешевле; в цикле это бесплатно. `strong`
  используют, когда CAS не в цикле.
- **«Что такое ABA?»** Указатель вернулся к тому же значению, а объект уже другой.
  Актуально для lock-free стека/списка на указателях; в ring buffer на монотонных
  индексах ABA не возникает (индексы не переиспользуются). Решения: tagged pointers,
  hazard pointers, epoch-based reclamation.
- **«lock-free vs wait-free?»** Lock-free: хотя бы один поток прогрессирует. Wait-free:
  каждый поток завершит операцию за ограниченное число шагов. Эта SPSC-очередь
  **wait-free** (нет циклов повторных попыток) — это сильный аргумент.
- **«Зачем `memory_order_seq_cst` по умолчанию?»** Это самый строгий и самый понятный
  порядок (единый глобальный порядок для всех seq_cst-операций); на x86 store становится
  `xchg`/`mfence` — дороже release. Начинать с seq_cst и ослаблять по мере доказательства
  корректности — нормальная стратегия, о которой стоит сказать.
- **«Как это тестировать?»** TSan (`-fsanitize=thread`) ловит гонки; но lock-free-код
  с relaxed TSan понимает не полностью. Полезны stress-тесты с проверкой монотонности
  последовательности, `relacy`/CDSChecker, прогон на ARM (там слабая модель памяти
  вскроет отсутствующие барьеры).

</details>

## На что смотрит интервьюер

- Понимаешь ли ты **release/acquire как пару** и что именно она гарантирует
  (happens-before, видимость записей до store).
- Знаешь ли, что data race = UB, а не «редкая ошибка».
- Заметил ли **false sharing** и предложил ли `alignas`.
- Понимаешь ли, что общий счётчик размера — архитектурная ошибка в SPSC.
- Знаешь ли трюк с кэшированием чужого индекса (признак того, что реально писал такое).
- Скажешь ли про степень двойки и маску вместо `%`.
- Различаешь ли lock-free / wait-free и умеешь ли аргументировать, почему тут wait-free.

## Чеклист для устного ответа

- SPSC: продюсер владеет `head`, консюмер — `tail`; общих RMW и общего `size` нет.
- Пусто ⟺ `head == tail`; полно ⟺ `head - tail == capacity` (монотонные индексы).
- `relaxed` для своего индекса, `acquire` для чужого, `release` для публикации.
- Данные пишем → потом `release` store; читаем `acquire` load → потом данные. Порядок важен.
- `alignas(std::hardware_destructive_interference_size)` (C++17, с фолбэком на 64)
  на head и tail; иначе false sharing съедает всю выгоду.
- Capacity — степень двойки, индексы монотонные, `& mask`.
- Кэшировать чужой индекс, перечитывать только при «полно/пусто».
- x86 TSO прощает многое; баг проявится на ARM. Всегда рассуждать по модели C++, не по железу.
- Wait-free (без CAS-циклов), MPMC — принципиально другая задача.
