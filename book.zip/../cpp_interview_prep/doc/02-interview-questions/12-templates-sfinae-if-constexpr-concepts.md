# 12. Дополнительно: шаблоны (SFINAE → `if constexpr` → concepts)

## Вопрос

Объясни, что делает этот код.

Две из пронумерованных строк в `main` не компилируются. Какие, почему, и как бы ты
переписал всё это на современном C++?

```cpp
// Пример намеренно сломан.
#include <iostream>
#include <string>
#include <type_traits>
#include <vector>

template <typename T>
typename std::enable_if<std::is_integral<T>::value, void>::type
serialize(const T& v) { std::cout << "int:" << v << "\n"; }

template <typename T>
typename std::enable_if<std::is_arithmetic<T>::value, void>::type
serialize(const T& v) { std::cout << "num:" << v << "\n"; }

template <typename T>
void serialize(const std::vector<T>& v)
{
    for (const auto& e : v)
        serialize(e);
}

template <typename T>
class Holder
{
public:
    template <typename U>
    Holder(U&& u) : value_(std::forward<U>(u)) {}

    Holder(const Holder& other) : value_(other.value_) {}

    const T& get() const { return value_; }

private:
    T value_;
};

int main()
{
    serialize(42);                        // (1)
    serialize(3.14);                      // (2)
    serialize(std::vector<int>{1, 2, 3}); // (3)

    Holder<std::string> h1("abc");
    Holder<std::string> h2 = h1;          // (4)
    const Holder<std::string> h3("xyz");
    Holder<std::string> h4 = h3;          // (5)
}
```

<details>
<summary>Разбор</summary>

### Проблема 1: перегрузки `enable_if` не взаимоисключающие → (1) неоднозначна

`serialize(42)`: `T = int`. `is_integral<int>` — true, `is_arithmetic<int>` — **тоже true**
(arithmetic = integral ∪ floating point). Обе перегрузки жизнеспособны, обе одинаково
специализированы → **ambiguous call**, ошибка компиляции.

Ключевая идея, которую проверяют: **SFINAE не даёт приоритетов**. Условия перегрузок надо
делать **взаимоисключающими вручную**:

```cpp
template <typename T>
std::enable_if_t<std::is_integral_v<T>> serialize(const T& v);

template <typename T>
std::enable_if_t<std::is_floating_point_v<T>> serialize(const T& v);
```

Либо использовать механизм приоритетов: tag dispatch, наследование тегов
(`priority_tag<N>`), или, что лучше всего, — просто `if constexpr` внутри одной функции.

`serialize(3.14)` (строка 2) при этом скомпилируется: `is_integral<double>` — false,
подходит только вторая перегрузка. То есть баг проявляется избирательно, что делает
задачу хорошей.

### Проблема 2: устаревший синтаксис

`typename std::enable_if<C, void>::type` — C++11. С C++14 есть `std::enable_if_t<C>`
(и `_v` для трейтов с C++17):

```cpp
template <typename T>
std::enable_if_t<std::is_integral_v<T>> serialize(const T& v);
```

Полезно назвать три типовых места для SFINAE-условия и их различия:
- в возвращаемом типе (как здесь) — не работает для конструкторов;
- в дефолтном шаблонном параметре: `template <typename T, typename = enable_if_t<...>>` —
  **не участвует в сигнатуре**, поэтому две такие перегрузки с разными условиями считаются
  переобъявлением одной функции (классическая ловушка);
- в дефолтном значении non-type параметра: `template <typename T, enable_if_t<C, int> = 0>` —
  самый надёжный вариант, работает и для конструкторов.

### Проблема 3: `serialize(std::vector<T>)` и two-phase lookup

Внутри шаблона вызов `serialize(e)` — **зависимое имя**. Оно разрешается в два этапа:
на этапе определения ищутся видимые в этой точке объявления, на этапе инстанцирования
добавляется только ADL. Для `std::vector<std::vector<int>>` вложенный вызов найдётся
(перегрузка объявлена выше), но если бы перегрузка для `vector` была объявлена **после**
использования, и типы находились не в том же namespace, — вызов не нашёлся бы.
Это причина, по которой обобщённые «сериализаторы» пишут с явной точкой кастомизации
(tag_invoke, CPO) или объявляют forward-декларации заранее.

### Проблема 4 (главная): forwarding-конструктор перехватывает копирование → (5) не компилируется

```cpp
template <typename U>
Holder(U&& u) : value_(std::forward<U>(u)) {}

Holder(const Holder& other);
```

`Holder<std::string> h4 = h3;` где `h3` — **`const Holder<std::string>`**: кандидат
`Holder(const Holder&)` требует точного совпадения, кандидат-шаблон при `U = const Holder&`
даёт `Holder(const Holder&)` — тоже точное совпадение, и **шаблон проигрывает
не-шаблону**. Значит (5) компилируется нормально.

А вот (4), `Holder<std::string> h2 = h1;`, где `h1` — **не-const** `Holder`:
- копирующий конструктор требует добавления `const` (квалификационная конверсия);
- шаблон при `U = Holder&` даёт **`Holder(Holder&)`** — точное совпадение без конверсий.

Шаблон **выигрывает**. Вызывается forwarding-конструктор, который пытается сделать
`value_(std::forward<Holder&>(h1))`, то есть инициализировать `std::string` из
`Holder<std::string>&` → **ошибка компиляции** (нет такой конверсии).

Это самый известный подвох perfect forwarding (Meyers, Effective Modern C++, item 26):
**forwarding-конструктор — «жадный» и перехватывает копирование не-const объектов.**

Лечение (три варианта, по возрастанию современности):

```cpp
// C++11/14: SFINAE-ограничение
template <typename U,
          std::enable_if_t<!std::is_base_of_v<Holder, std::decay_t<U>>, int> = 0>
Holder(U&& u) : value_(std::forward<U>(u)) {}
```

```cpp
// C++17: то же самое, но требование выражено к целевому типу
template <typename U,
          std::enable_if_t<std::is_constructible_v<T, U&&>
                        && !std::is_same_v<std::decay_t<U>, Holder>, int> = 0>
Holder(U&& u) : value_(std::forward<U>(u)) {}
```

```cpp
// C++20: concepts — читаемо и без ритуалов
template <typename U>
    requires (!std::same_as<std::remove_cvref_t<U>, Holder>)
          && std::constructible_from<T, U>
Holder(U&& u) : value_(std::forward<U>(u)) {}
```

Плюс: раз есть пользовательский copy-конструктор, надо определить и остальные из rule of 5
(здесь он вообще не нужен — компилятор сгенерирует правильный, если его удалить: **rule of zero**).

### Проблема 5: `U&&` — не всегда rvalue-ссылка

Полезно проговорить явно: `U&&` в шаблоне с выводимым `U` — это **forwarding reference**
(универсальная ссылка), а не rvalue-ссылка. Работает reference collapsing:
`& + && = &`, `&& + && = &&`. Поэтому при передаче lvalue `U` выводится как `Holder&`.

А вот `std::vector<T>&&` в методе класса — это **настоящая** rvalue-ссылка, потому что
`T` не выводится из этого параметра. Разница между `std::move` (безусловный каст) и
`std::forward` (условный, сохраняющий категорию) — обязательный вопрос-спутник.

### Как это выглядит на современном C++

**`if constexpr` (C++17) вместо набора перегрузок:**

```cpp
#include <iostream>
#include <string>
#include <type_traits>
#include <vector>

template <typename T>
void serialize(const T& v)
{
    if constexpr (std::is_integral_v<T>)
        std::cout << "int:" << v << "\n";
    else if constexpr (std::is_floating_point_v<T>)
        std::cout << "num:" << v << "\n";
    else if constexpr (requires { v.begin(); v.end(); })   // C++20 requires-expression
        for (const auto& e : v) serialize(e);
    else
        static_assert(sizeof(T) == 0, "unsupported type");
}
```

Отличие от рантайм-`if`: **невыбранная ветка не инстанцируется** (но всё ещё должна быть
синтаксически корректной и не зависеть от невыполнимых зависимых конструкций). Отсюда
трюк `static_assert(sizeof(T) == 0, ...)` — зависимое от `T` ложное условие, чтобы
`static_assert` не сработал при разборе шаблона.

**Concepts (C++20) — когда нужны разные перегрузки:**

```cpp
#include <concepts>
#include <ranges>

template <std::integral T>
void serialize(const T& v) { /* ... */ }

template <std::floating_point T>
void serialize(const T& v) { /* ... */ }

template <std::ranges::input_range R>
void serialize(const R& r) { for (const auto& e : r) serialize(e); }
```

Здесь неоднозначности **нет**, и это ключевое преимущество: концепты **упорядочены по
специализации (subsumption)**. `std::integral` строго вкладывается в определённые через
него более общие концепты, и компилятор выбирает наиболее специализированный. Плюс
сообщения об ошибках короткие и осмысленные, вместо «портянки» от `enable_if`.

### Смежные вопросы

- **«Что такое SFINAE и где именно оно работает?»** Substitution Failure Is Not An Error:
  ошибка подстановки шаблонных аргументов **в непосредственном контексте** сигнатуры
  убирает кандидата из overload set, а не прерывает компиляцию. Ошибка **в теле** функции —
  уже hard error.
- **«`if constexpr` vs SFINAE vs специализация?»** `if constexpr` — когда одна функция с
  разным поведением. Concepts/SFINAE — когда нужны разные перегрузки или надо
  ограничить интерфейс. Частичная специализация — для классов (у функций её нет,
  только перегрузка).
- **«Влияние шаблонов на компиляцию и бинарь?»** Каждая инстанциация — отдельный код;
  code bloat, время компиляции, раздутые символы. Смягчение: `extern template`,
  вынос независимой от типа части в не-шаблонную функцию, type erasure.
- **«CRTP?»** Статический полиморфизм без виртуальных вызовов — актуально в low-latency:
  `template <class Derived> struct Base { void run() { static_cast<Derived*>(this)->impl(); } };`
- **«Почему `std::vector<bool>` — проблема?»** Специализация с упаковкой битов: `operator[]`
  возвращает прокси, а не `bool&`; `auto x = v[0];` даёт прокси, а не значение; не
  удовлетворяет требованиям Container. Классический вопрос-спутник.

</details>

## На что смотрит интервьюер

- Найдёшь ли **неоднозначность перегрузок** и объяснишь, что SFINAE не даёт приоритетов.
- Знаешь ли ловушку **forwarding-конструктора** — это отличает читавших Meyers'а.
- Различаешь ли forwarding reference и rvalue reference, `std::move` и `std::forward`.
- Знаешь ли современные инструменты (`if constexpr`, concepts) и **когда что** применять.
- Понимаешь ли, что concepts решают проблему неоднозначности через subsumption,
  а не «просто красивее».
- Скажешь ли про два этапа поиска имён и про цену шаблонов в компиляции.

## Чеклист для устного ответа

- SFINAE не упорядочивает перегрузки — условия должны быть взаимоисключающими.
- `enable_if` в дефолтном типовом параметре не участвует в сигнатуре → «переопределение».
  Надёжный вид: `template <class T, std::enable_if_t<C, int> = 0>`.
- `U&&` при выводимом `U` — forwarding reference; reference collapsing; `forward` ≠ `move`.
- Forwarding-конструктор перехватывает копирование не-const объекта → ограничивать через
  `!is_same_v<remove_cvref_t<U>, Class>`.
- `if constexpr`: невыбранная ветка не инстанцируется; `static_assert(sizeof(T)==0)` для else.
- Concepts упорядочены по subsumption → нет ambiguity, читаемые ошибки.
- SFINAE работает только в непосредственном контексте сигнатуры.
- Rule of zero: не писать copy-конструктор, если он не нужен.
