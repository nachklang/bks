# 04. Move semantics: рукописные move-конструктор и move-assignment

## Вопрос

Вот класс-буфер, написанный джуном.

Найди все проблемы этого класса.

```cpp
// Пример намеренно сломан.
#include <algorithm>
#include <cstddef>
#include <vector>

class Buffer
{
public:
    explicit Buffer(std::size_t n)
        : data_(new double[n])
        , size_(n)
    {}

    ~Buffer() { delete[] data_; }

    Buffer(const Buffer& other)
        : data_(new double[other.size_])
        , size_(other.size_)
    {
        std::copy(other.data_, other.data_ + size_, data_);
    }

    Buffer(Buffer&& other)
        : data_(other.data_)
        , size_(other.size_)
    {
        other.data_ = nullptr;
    }

    Buffer& operator=(const Buffer& other)
    {
        delete[] data_;
        data_ = new double[other.size_];
        size_ = other.size_;
        std::copy(other.data_, other.data_ + size_, data_);
        return *this;
    }

    Buffer& operator=(Buffer&& other)
    {
        delete[] data_;
        data_ = other.data_;
        size_ = other.size_;
        other.data_ = nullptr;
        return *this;
    }

    std::size_t size() const { return size_; }

private:
    double* data_;
    std::size_t size_;
};

Buffer make_buffer(std::size_t n)
{
    Buffer buf(n);
    return std::move(buf);
}

void fill(std::vector<Buffer>& v)
{
    for (int i = 0; i < 1000; ++i)
        v.push_back(Buffer(1024));
}
```

<details>
<summary>Разбор</summary>

### Баг 1: move-конструктор не обнуляет `size_`

`other.data_ = nullptr;` есть, а `other.size_ = 0;` — нет. Moved-from объект остаётся в
состоянии «нулевой указатель, но `size() == n`». Формально стандарт требует от moved-from
объекта лишь *valid but unspecified state*, но здесь состояние **невалидно по инвариантам
самого класса**: любой код, который сделает `for (i = 0; i < b.size(); ++i) b[i]`,
разыменует `nullptr`. Инвариант «`data_ != nullptr` ⟺ `size_ > 0`» должен сохраняться.

То же самое в move-assignment.

### Баг 2: self-move в `operator=(Buffer&&)` — use-after-free

```cpp
b = std::move(b);   // delete[] data_; data_ = other.data_;  // висячий указатель
```

`delete[] data_` освобождает память, а `other.data_` — это тот же самый указатель.
Получаем double-free при следующем `delete[]` и use-after-free при любом обращении.

Self-move не такая экзотика, как кажется: он возникает внутри алгоритмов
(`std::sort`, `std::remove_if`, `std::shuffle` на некоторых реализациях) при
`*it = std::move(*it)`. Стандарт требует от типов, используемых в стандартных алгоритмах,
чтобы self-move-assignment оставлял объект в valid-but-unspecified состоянии
(то есть не падал), — данный код это требование нарушает.

Три способа решить:
1. Проверка `if (this == &other) return *this;`
2. Идиома «swap»: обменять содержимое и позволить `other` уничтожить старое.
3. Copy-and-swap (см. ниже) — self-assignment безопасен «бесплатно».

### Баг 3: copy-assignment не exception-safe и не self-safe

```cpp
delete[] data_;                  // 1
data_ = new double[other.size_]; // 2 — а если бросит bad_alloc?
```

Если `new` бросит, объект остаётся с висячим `data_` и старым `size_` — деструктор сделает
double-free. Это нарушение даже **basic guarantee**. Плюс `b = b;` уничтожит данные до
копирования.

Правильно — **copy-and-swap**: сначала выделяем новое, потом коммитим.

### Баг 4: отсутствие `noexcept` — главный «перформансный» вопрос

Это то, ради чего задача обычно и даётся.

`std::vector` при реаллокации должен перенести элементы в новый буфер. Он использует
`std::move_if_noexcept`: если move-конструктор типа **не** помечен `noexcept` и тип
copy-constructible, вектор будет **копировать**, а не перемещать. Причина — strong
exception guarantee: если move бросит на середине переноса, восстановить исходный вектор
уже нельзя (элементы-источники разрушены), а при копировании старый буфер цел и его
можно оставить.

Следствие: `Buffer` с не-`noexcept` move-конструктором в `vector<Buffer>` при росте
будет копировать все элементы вместе с массивами `double` — O(n·m) вместо O(n)
перестановок указателей. Это отличный «тихий» источник просадки производительности,
и на интервью в quant-конторе именно это и хотят услышать.

Проверить можно так:

```cpp
static_assert(std::is_nothrow_move_constructible_v<Buffer>);
static_assert(std::is_nothrow_move_assignable_v<Buffer>);
```

Move-операции, которые только перекладывают указатели, **обязаны** быть `noexcept`.

### Баг 5: `delete[] data_` в move-assignment вместо обмена

Даже исправив self-move, схема «удалить своё, забрать чужое» освобождает память **прямо
сейчас**, в потенциально горячем месте. Схема со `swap` откладывает `delete[]` на момент
уничтожения `other`. Для vector-реаллокации разницы почти нет, для `std::sort` — есть.
Кроме того, `swap`-версия тривиально `noexcept`.

### Баг 6: `return std::move(buf)` — пессимизация, ломающая NRVO

```cpp
Buffer make_buffer(std::size_t n)
{
    Buffer buf(n);
    return std::move(buf);   // ХУЖЕ, чем return buf;
}
```

`return buf;` даёт компилятору право на **NRVO** (named return value optimization):
`buf` конструируется **прямо в памяти вызывающего**, и не выполняется вообще никакой
конструктор — ни move, ни copy. Это ноль операций.

`return std::move(buf)` превращает выражение в **xvalue**, а NRVO требует, чтобы
возвращалось имя локального объекта. Оптимизация запрещается, и компилятор обязан
вызвать move-конструктор. Итог: вместо нуля операций — одна.

Хуже того, если бы возвращаемым типом был базовый класс или тип, у которого нет
move-конструктора, `std::move` привёл бы к **копированию**.

Важные уточнения:
- Для `return buf;` (локальный объект того же типа) `buf` рассматривается как rvalue
  **автоматически** даже если NRVO не сработает — это гарантировано стандартом
  (implicit move on return). То есть `std::move` не нужен никогда.
- Guaranteed copy elision (C++17) относится к **prvalue** (`return Buffer(n);`) — там
  копия/move не просто оптимизируется, а формально не существует. NRVO для именованных
  объектов остаётся необязательной оптимизацией, но реализована во всех компиляторах.
- Исключение, где `std::move` при возврате **нужен**: возвращается член объекта
  (`return std::move(this->buf_);`) или параметр по значению в тип, отличный от
  типа возврата.
- GCC/Clang предупреждают: `-Wpessimizing-move`, `-Wredundant-move`.

### Баг 7: `push_back(Buffer(1024))` в цикле без `reserve`

`fill` делает 1000 `push_back` без `v.reserve(1000)`. Вектор растёт геометрически
(×2 в libstdc++, ×1.5 в MSVC), то есть ~10 реаллокаций, и каждая переносит все уже
лежащие элементы. С не-`noexcept` move (баг 4) это **копирование** мегабайтов данных.
`reserve` убирает реаллокации совсем.

Плюс: `push_back(Buffer(1024))` создаёт временный объект и перемещает его;
`v.emplace_back(1024)` конструирует на месте, без временного.

### Баг 8: rule of 5 / rule of 0

Класс вручную реализует все пять функций ради одного `double*`. Правильный ответ на
интервью: **этот класс не должен существовать**.

```cpp
class Buffer
{
public:
    explicit Buffer(std::size_t n) : data_(n) {}
    std::size_t size() const noexcept { return data_.size(); }
private:
    std::vector<double> data_;
};
```

`std::vector`/`std::unique_ptr<double[]>` дают все пять операций корректно и бесплатно
(rule of zero). Ручное владение оправдано только если есть особая политика аллокации
(arena, huge pages, alignment под SIMD) — и тогда об этом надо сказать явно.

### Мелочи, за которые дают плюс

- `explicit` у конструктора от `size_t` — есть, хорошо.
- `size()` не `noexcept` — мелочь, но на low-latency позиции замечают.
- `new double[n]` не инициализирует значения (для `double` это value-init только при
  `new double[n]()`); неинициализированное чтение — UB. Стоит проговорить.
- Нет `operator[]`, `data()`, `begin/end` — но это вне вопроса.
- Нет `alignas`/aligned allocation — для SIMD-кода это существенно.

### Исправленная версия

```cpp
#include <algorithm>
#include <cstddef>
#include <utility>

class Buffer
{
public:
    Buffer() noexcept = default;

    explicit Buffer(std::size_t n)
        : data_(n ? new double[n]() : nullptr)
        , size_(n)
    {}

    ~Buffer() { delete[] data_; }

    Buffer(const Buffer& other)
        : data_(other.size_ ? new double[other.size_] : nullptr)
        , size_(other.size_)
    {
        std::copy(other.data_, other.data_ + size_, data_);
    }

    Buffer(Buffer&& other) noexcept
        : data_(std::exchange(other.data_, nullptr))
        , size_(std::exchange(other.size_, 0))
    {}

    Buffer& operator=(Buffer other) noexcept   // copy-and-swap: покрывает и copy, и move
    {
        swap(other);
        return *this;
    }

    void swap(Buffer& other) noexcept
    {
        std::swap(data_, other.data_);
        std::swap(size_, other.size_);
    }

    friend void swap(Buffer& a, Buffer& b) noexcept { a.swap(b); }

    std::size_t size() const noexcept { return size_; }

private:
    double* data_ = nullptr;
    std::size_t size_ = 0;
};
```

**Важная оговорка про copy-and-swap с параметром по значению.** Он элегантен и решает
self-assignment и exception safety разом, но у него есть цена: move-assignment
получается «move-construct + swap + destroy» вместо одного swap, и, что важнее,
он **всегда освобождает** старый буфер, теряя возможность переиспользовать уже выделенную
память при `a = b` одинакового размера. В hot path часто пишут две отдельные перегрузки:

```cpp
Buffer& operator=(const Buffer& other)
{
    if (this != &other)
    {
        Buffer tmp(other);
        swap(tmp);
    }
    return *this;
}

Buffer& operator=(Buffer&& other) noexcept
{
    swap(other);
    return *this;
}
```

Версия move-assignment через `swap` self-move-safe автоматически (`swap(*this, *this)`
ничего не ломает).

</details>

## На что смотрит интервьюер

- Заметил ли ты **`noexcept` и связь с реаллокацией `vector`** — это ключевой пункт.
- Заметил ли **self-move** и понимаешь ли, откуда он берётся в реальном коде.
- Понимаешь ли **exception safety** copy-assignment (delete до new).
- Знаешь ли про **moved-from state**: что гарантирует стандарт, а что — инварианты класса.
- Заметил ли `return std::move(buf)` — это маркер понимания copy elision.
- Скажешь ли про **rule of zero** — то есть думаешь ли о дизайне, а не только о багах.
- Бонус: правило генерации специальных функций (объявил деструктор → move-операции
  **не генерируются**, копирование генерируется, но deprecated).

## Чеклист для устного ответа

- Move-операции всегда `noexcept`, иначе `vector` копирует (`move_if_noexcept`).
- Move должен оставлять источник в валидном состоянии: обнулять **все** поля, не только указатель.
- Self-move: `a = std::move(a)` не должен падать; проверка или swap-идиома.
- Copy-assign: сначала выделить новое, потом освободить старое (strong guarantee) → copy-and-swap.
- Rule of 5, а лучше rule of 0: `vector`/`unique_ptr` вместо сырого указателя.
- Объявленный деструктор подавляет генерацию move-операций.
- `std::exchange` — идиоматичный способ написать move-конструктор в одну строку.
- `std::move` ничего не перемещает — это `static_cast` к rvalue-ссылке.
- `return std::move(local)` запрещает NRVO и делает код медленнее; `return local;`
  и так использует move (implicit move on return).
