# 08. Thread pool на `mutex` + `condition_variable`

## Вопрос

Вот пул потоков для параллельного расчёта.

Найди все проблемы этой реализации.

```cpp
// Пример намеренно сломан.
#include <condition_variable>
#include <functional>
#include <mutex>
#include <queue>
#include <thread>
#include <vector>

class ThreadPool
{
public:
    explicit ThreadPool(std::size_t n)
    {
        for (std::size_t i = 0; i < n; ++i)
            workers_.emplace_back([this] { run(); });
    }

    ~ThreadPool()
    {
        stop_ = true;
        cv_.notify_all();
        for (auto& t : workers_)
            t.join();
    }

    void submit(std::function<void()> task)
    {
        std::unique_lock<std::mutex> lk(m_);
        tasks_.push(std::move(task));
        cv_.notify_one();
    }

private:
    void run()
    {
        while (!stop_)
        {
            std::unique_lock<std::mutex> lk(m_);
            if (tasks_.empty())
                cv_.wait(lk);

            auto task = std::move(tasks_.front());
            tasks_.pop();
            task();
        }
    }

    std::vector<std::thread> workers_;
    std::queue<std::function<void()>> tasks_;
    std::mutex m_;
    std::condition_variable cv_;
    bool stop_ = false;
};
```

<details>
<summary>Разбор</summary>

### Баг 1: `stop_` — обычный `bool`, читаемый вне мьютекса

`while (!stop_)` в `run()` читает `stop_` без лока, деструктор пишет его без лока —
**data race, UB**. Компилятор вправе вынести чтение из цикла (`while (true)`), и поток
никогда не остановится.

Лечение: либо `std::atomic<bool>`, либо (правильнее для этой схемы) — обычный `bool`,
но **всегда** под тем же мьютексом, что и очередь. Второй вариант предпочтителен: флаг
и очередь образуют одно логическое состояние, и проверять их надо атомарно вместе.

### Баг 2: `cv_.wait(lk)` без предиката — spurious и lost wakeups

Два независимых дефекта:

**Spurious wakeup.** `condition_variable::wait` может вернуться **без** уведомления —
это разрешено стандартом (следствие реализации через futex и сигналы). После пробуждения
`tasks_` может быть пуста, и код упадёт на `tasks_.front()` (UB на пустой очереди).

**Lost wakeup / notify до wait.** Между `if (tasks_.empty())` и `cv_.wait(lk)`... здесь
как раз лока не теряем, но проблема в `if` вместо `while`: одно уведомление могло разбудить
поток, а задачу успел забрать другой (это реально при `notify_all` в деструкторе).

Каноническая форма — **всегда предикат в цикле**:

```cpp
cv_.wait(lk, [this] { return stop_ || !tasks_.empty(); });
```

Это ровно эквивалентно `while (!pred()) cv_.wait(lk);` и решает обе проблемы разом.
Формулировка, которую надо произнести: **«condition_variable — не хранилище состояния,
а только механизм пробуждения; состояние всегда проверяется под мьютексом в цикле»**.

### Баг 3: deadlock при завершении

`~ThreadPool` ставит `stop_ = true` и делает `notify_all()`. Но потоки, уже спящие в
`cv_.wait(lk)` **без предиката**, проснутся, увидят пустую очередь и... в исправленном
варианте без флага в предикате — снова уснут. `join()` заблокируется навсегда.

Даже в текущем виде есть гонка: `stop_ = true` может произойти после того, как воркер
проверил `!stop_`, но до того, как он ушёл в `wait` — уведомление потеряется, поток уснёт
навсегда. Это классический **lost wakeup**, и именно поэтому изменение состояния и
`notify` должны быть согласованы с мьютексом:

```cpp
{
    std::lock_guard<std::mutex> lk(m_);
    stop_ = true;
}
cv_.notify_all();
```

Установка флага **под мьютексом** гарантирует, что ожидающий поток либо ещё не начал
проверку предиката (и увидит флаг), либо уже спит (и получит notify).

### Баг 4: задача выполняется **под мьютексом**

```cpp
auto task = std::move(tasks_.front());
tasks_.pop();
task();          // lk всё ещё захвачен!
```

`std::unique_lock lk` живёт до конца итерации цикла, поэтому вся полезная работа
сериализуется — пул из 8 потоков работает как один. Плюс: если задача внутри вызовет
`submit()`, получим **самоблокировку** (`std::mutex` не рекурсивен → UB/deadlock).

Лечение: `lk.unlock()` перед вызовом задачи, либо ограничить область видимости лока
вложенным блоком.

### Баг 5: исключение из задачи убивает процесс

`task()` бросает → исключение вылетает из лямбды потока → `std::terminate`. Плюс поток
исчезает, и пул тихо деградирует.

Лечение: `try { task(); } catch (...) { /* log */ }`. Если результат задачи кому-то нужен
— возвращать `std::future` и передавать исключение через `promise::set_exception`
(`std::packaged_task` делает это автоматически).

### Баг 6: исключение в конструкторе → `terminate` в деструкторе

Если `workers_.emplace_back` бросит на середине (например, `std::system_error` при
`pthread_create`), деструктор `ThreadPool` **не вызовется**, а уже созданные `std::thread`
разрушатся неприсоединёнными → деструктор `std::thread` при `joinable()` вызывает
`std::terminate`. Нужен либо try/catch в конструкторе, либо `std::jthread` (C++20,
join в деструкторе), либо RAII-обёртка над вектором потоков.

То же в деструкторе: если `join()` бросит, остальные потоки не будут присоединены.

### Баг 7: нет `submit` с результатом, `std::function` требует копируемости

- `std::function` требует, чтобы вызываемый объект был **копируемым**, поэтому в него
  нельзя положить лямбду, захватившую `std::promise` или `unique_ptr`. Обходные пути:
  `std::move_only_function` (C++23), `std::packaged_task` в `shared_ptr`, свой type-erased
  move-only wrapper.
- `std::function` может аллоцировать (SBO обычно 16 байт) — в low-latency пуле это заметно.

### Баг 8: нет запрета копирования пула

Копирование `ThreadPool` не имеет смысла и не скомпилируется из-за `std::mutex`, но явное
`= delete` документирует намерение.

### Исправленная версия

```cpp
#include <condition_variable>
#include <functional>
#include <future>
#include <mutex>
#include <queue>
#include <stdexcept>
#include <thread>
#include <utility>
#include <vector>

class ThreadPool
{
public:
    explicit ThreadPool(std::size_t n)
    {
        workers_.reserve(n);
        try
        {
            for (std::size_t i = 0; i < n; ++i)
                workers_.emplace_back([this] { run(); });
        }
        catch (...)
        {
            shutdown();
            throw;
        }
    }

    ~ThreadPool() { shutdown(); }

    ThreadPool(const ThreadPool&) = delete;
    ThreadPool& operator=(const ThreadPool&) = delete;

    template <typename F>
    auto submit(F&& f) -> std::future<std::invoke_result_t<F>>
    {
        using R = std::invoke_result_t<F>;
        auto task = std::make_shared<std::packaged_task<R()>>(std::forward<F>(f));
        auto fut = task->get_future();
        {
            std::lock_guard<std::mutex> lk(m_);
            if (stop_)
                throw std::runtime_error("submit on stopped pool");
            tasks_.emplace([task] { (*task)(); });
        }
        cv_.notify_one();
        return fut;
    }

private:
    void run()
    {
        for (;;)
        {
            std::function<void()> task;
            {
                std::unique_lock<std::mutex> lk(m_);
                cv_.wait(lk, [this] { return stop_ || !tasks_.empty(); });

                if (stop_ && tasks_.empty())
                    return;                       // graceful: доработать очередь и выйти

                task = std::move(tasks_.front());
                tasks_.pop();
            }
            try { task(); } catch (...) {}        // packaged_task сам ловит, это страховка
        }
    }

    void shutdown() noexcept
    {
        {
            std::lock_guard<std::mutex> lk(m_);
            stop_ = true;
        }
        cv_.notify_all();
        for (auto& t : workers_)
            if (t.joinable())
                t.join();
        workers_.clear();
    }

    std::vector<std::thread> workers_;
    std::queue<std::function<void()>> tasks_;
    std::mutex m_;
    std::condition_variable cv_;
    bool stop_ = false;
};
```

Обрати внимание на политику завершения: `if (stop_ && tasks_.empty()) return;` — это
**drain-then-exit** (доработать всё, что уже поставлено). Альтернатива — «бросить всё
немедленно» (`if (stop_) return;`). Об этом выборе на интервью надо спросить явно —
это разные требования.

### Смежные вопросы

**«`notify` под локом или после?»** Оба варианта корректны. Вне лока — чуть лучше:
разбуженный поток не наткнётся сразу на занятый мьютекс (hurry-up-and-wait). Но
**изменение состояния** обязано быть под локом. Для `notify_all` в shutdown разницы
практически нет.

**«`notify_one` или `notify_all`?»** Для симметричных воркеров с одинаковым предикатом
достаточно `notify_one` при добавлении задачи, `notify_all` — при shutdown. Если предикаты
у ожидающих разные, `notify_one` может разбудить «не того» — тогда только `notify_all`.

**«Почему не `std::async`?»** Нет контроля над количеством потоков; политика по умолчанию
`async|deferred` определяется реализацией; деструктор `future` от `std::async` **блокирует**
до завершения — сюрприз, ломающий ожидания.

**«Как сделать пул без мьютекса?»** Work-stealing deque на потоке (Chase-Lev), MPMC-очередь
с CAS, per-thread очереди + балансировка. Для low-latency чаще делают **один поток на ядро
с запиненными affinity и spin-ожиданием** без пула вовсе.

**«Как продиагностировать deadlock?»** `gdb` → `thread apply all bt`; TSan умеет
детектировать нарушение порядка захвата локов; `perf`/`eu-stack`; в проде — watchdog-поток
и таймауты (`wait_for` вместо `wait`).

</details>

## На что смотрит интервьюер

- Знаешь ли ты **предикатную форму `wait`** и умеешь ли объяснить spurious/lost wakeup.
- Заметил ли, что задача исполняется под локом (главная «производительностная» ошибка).
- Понимаешь ли, что состояние надо менять **под тем же мьютексом**, что проверяет предикат.
- Продумал ли **graceful shutdown**: флаг + notify_all + join, drain vs abort.
- Знаешь ли про `terminate` при разрушении joinable-потока и при исключении из задачи.
- Знаешь ли ограничение `std::function` (копируемость) и как отдать результат через future.
- Спросишь ли про требования (сколько потоков, какие задачи, нужен ли результат) до кода.

## Чеклист для устного ответа

- `cv_.wait(lk, pred)` всегда; голый `wait` — почти всегда баг.
- Состояние (`stop_`, очередь) меняется под мьютексом, `notify` — можно после разблокировки.
- Работу выполнять **вне** критической секции; лок только на извлечение задачи.
- Shutdown: `stop_` под локом → `notify_all` → `join` всех joinable-потоков.
- Исключение из задачи ловить в воркере; результат/исключение отдавать через `future`.
- Разрушение joinable `std::thread` = `terminate`; C++20 `jthread` + `stop_token` решает.
- `std::function` требует copyable; для move-only — `packaged_task` в `shared_ptr` или
  `std::move_only_function` (C++23).
- `std::async` не заменяет пул: нет контроля потоков, блокирующий деструктор future.
