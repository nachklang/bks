# 10. Spinlock на `std::atomic_flag`: memory order, TTAS, backoff

## Вопрос

Кто-то написал свой spinlock, потому что `std::mutex` «слишком медленный».

Корректна ли эта реализация? Где она проиграет обычному мьютексу?

```cpp
// Пример намеренно сломан.
#include <atomic>

class SpinLock
{
public:
    void lock()
    {
        while (flag_.test_and_set(std::memory_order_relaxed))
        {
        }
    }

    void unlock()
    {
        flag_.clear(std::memory_order_relaxed);
    }

private:
    std::atomic_flag flag_ = ATOMIC_FLAG_INIT;
};

// использование
SpinLock g_lock;
int g_counter = 0;

void worker()
{
    for (int i = 0; i < 1'000'000; ++i)
    {
        g_lock.lock();
        ++g_counter;
        g_lock.unlock();
    }
}
```

<details>
<summary>Разбор</summary>

### Баг 1: `memory_order_relaxed` — блокировка ничего не защищает

`relaxed` гарантирует только атомарность самой операции над флагом и **никакого** порядка
относительно других обращений к памяти. Значит:

- Компилятор и процессор вправе переместить `++g_counter` **выше** `lock()` или **ниже**
  `unlock()` — критическая секция «протекает» в обе стороны.
- Нет `synchronizes-with` между `unlock()` в одном потоке и `lock()` в другом, значит нет
  happens-before, значит доступ к `g_counter` — **data race и UB**.

Правильно:
- `lock()`: `test_and_set(std::memory_order_acquire)` — ничто из критической секции не
  уедет вверх, и мы увидим все записи предыдущего владельца.
- `unlock()`: `clear(std::memory_order_release)` — все записи критической секции станут
  видны следующему, кто захватит лок через acquire.

Это каноническая **release/acquire пара**: она и есть определение «мьютекса» в модели
памяти C++.

**Почему не `seq_cst`.** `seq_cst` (значение по умолчанию у всех операций `std::atomic`)
корректен, но избыточен: он дополнительно требует единого глобального порядка **всех**
seq_cst-операций в программе. Для лока этого не нужно — нужна только видимость записей
критической секции. Цена на x86: seq_cst-**store** компилируется в `xchg` или
`mov`+`mfence` (~20–100 тактов при contention), тогда как release-store — обычный `mov`
(x86 TSO даёт release/acquire бесплатно). На ARM разница между `stlr` и `dmb ish` тоже
заметна. То есть `unlock()` с `seq_cst` — это лишний барьер на каждом выходе из
критической секции.

Практическое правило: **`acquire` на захвате, `release` на освобождении, `relaxed`
на спин-чтении.** Спин-loop читает `relaxed`, потому что синхронизацию всё равно
обеспечит успешный RMW с `acquire`.

### Баг 2: чистый TAS-цикл жжёт кэш-когерентность

`test_and_set` — это read-modify-write: на x86 `lock bts`/`xchg`. Каждая итерация цикла
запрашивает кэш-линию в состояние **Exclusive/Modified**, даже если лок занят. При N
ожидающих потоках линия непрерывно перебрасывается между ядрами, что тормозит и самого
владельца лока, когда он захочет сделать `unlock`.

Стандартное решение — **TTAS (test-and-test-and-set)**: сначала крутиться на обычной
*загрузке* (`relaxed` load держит линию в Shared, не инвалидируя её у других), и лишь
когда флаг стал свободен — пробовать RMW.

С C++20 у `atomic_flag` появился `test()` (и `wait()`/`notify_one()`).

### Баг 3: нет `pause` / backoff

В spin-цикле нужна инструкция-подсказка процессору:
- x86: `_mm_pause()` (`PAUSE`) — снижает энергопотребление, устраняет штраф за
  memory order violation при выходе из цикла, отдаёт ресурсы parallel-гипертреду
  на том же физическом ядре.
- ARM: `__yield()` / `YIELD`, или `WFE`.
- C++20: `std::atomic_flag::wait()` — futex-подобное ожидание без сжигания CPU.

Без `pause` спин на HT-паре «съедает» соседний логический процессор.

### Баг 4: нет отступления к ядру → livelock/starvation при oversubscription

Если потоков больше, чем ядер, ожидающий поток крутится весь свой квант времени, не давая
владельцу лока (которого шедулер вытеснил) доработать критическую секцию. Это классический
**priority inversion** / lock convoy на spinlock'е; итоговая пропускная способность может
упасть на порядок по сравнению с `std::mutex`. `std::mutex` на Linux — это futex: короткий
адаптивный спин, а потом сон в ядре, и он **не страдает** от этой проблемы.

Правильный spinlock после N итераций делает `std::this_thread::yield()`, а после M —
уходит в ожидание ядра.

Кроме того, `atomic_flag`-spinlock **не fair**: порядок захвата не гарантирован, поток может
голодать сколь угодно долго. Fairness даёт ticket lock или MCS lock.

### Баг 5: нет RAII-обёртки

`lock()`/`unlock()` вручную = утечка лока при исключении или раннем `return`. Класс должен
удовлетворять именованному требованию *Lockable* (`lock`, `try_lock`, `unlock`), чтобы
работать с `std::lock_guard`/`std::scoped_lock`/`std::unique_lock`. Здесь нет `try_lock`.

### Баг 6: копируемость и выравнивание

- Spinlock не должен копироваться/перемещаться — надо `= delete`.
- Если несколько spinlock'ов лежат подряд в структуре, они попадут в одну кэш-линию —
  false sharing между независимыми локами. `alignas(64)`.

### Исправленная версия

```cpp
#include <atomic>
#include <thread>
#if defined(__x86_64__) || defined(_M_X64)
  #include <immintrin.h>
#endif

class SpinLock
{
public:
    SpinLock() = default;
    SpinLock(const SpinLock&) = delete;
    SpinLock& operator=(const SpinLock&) = delete;

    void lock() noexcept
    {
        for (int spins = 0; ; ++spins)
        {
            if (!flag_.exchange(true, std::memory_order_acquire))
                return;

            // TTAS: крутимся на чтении, не инвалидируя линию у других ядер
            while (flag_.load(std::memory_order_relaxed))
            {
                cpu_relax();
                if (spins++ > 1000)
                    std::this_thread::yield();
            }
        }
    }

    bool try_lock() noexcept
    {
        return !flag_.load(std::memory_order_relaxed)
            && !flag_.exchange(true, std::memory_order_acquire);
    }

    void unlock() noexcept
    {
        flag_.store(false, std::memory_order_release);
    }

private:
    static void cpu_relax() noexcept
    {
#if defined(__x86_64__) || defined(_M_X64)
        _mm_pause();
#elif defined(__aarch64__)
        asm volatile("yield" ::: "memory");
#endif
    }

    alignas(64) std::atomic<bool> flag_{false};
};
```

Здесь `std::atomic<bool>` вместо `atomic_flag` — только ради `load()` (в C++17 у
`atomic_flag` нет `test()`); формально lock-free-ность `atomic<bool>` не гарантирована
стандартом, но на всех реальных платформах она есть (`is_always_lock_free`).

Использование:

```cpp
std::lock_guard<SpinLock> lk(g_lock);
++g_counter;
```

### Когда spinlock уместен, а когда нет

**Уместен:**
- Критическая секция — десятки наносекунд (обновление пары полей, публикация указателя).
- Потоков не больше, чем выделенных ядер, потоки запинены (`sched_setaffinity`), ядра
  изолированы (`isolcpus`).
- Нельзя уходить в ядро: обработчик, hot path биржевого шлюза.

**Не уместен:**
- Критическая секция делает I/O, аллокацию, вызов чужого кода, берёт другой лок.
- Oversubscription, общие ядра, контейнеры с cgroups-квотами.
- Просто «мьютекс медленный» без замеров. Незанятый `std::mutex` на Linux —
  это `lock cmpxchg` без системного вызова, ~20 нс; вся разница со спинлоком видна
  только под contention, где спинлок часто **проигрывает**.

**Лучшая альтернатива обоим:** убрать разделяемое состояние. Для счётчика из примера
достаточно `std::atomic<int> g_counter; g_counter.fetch_add(1, std::memory_order_relaxed);`
— никакого лока вообще, и это в разы быстрее. Правильный ответ на интервью почти всегда
начинается с «а зачем тут вообще лок?».

</details>

## На что смотрит интервьюер

- Назовёшь ли ты **acquire/release** и объяснишь, что именно ломает `relaxed` (не «медленнее»,
  а UB и переупорядочивание критической секции).
- Знаешь ли **TTAS** и почему просто TAS плох на уровне протокола кэш-когерентности (MESI).
- Знаешь ли про `PAUSE`/`YIELD` и что такое hyper-threading в этом контексте.
- Понимаешь ли, почему spinlock проигрывает мьютексу при oversubscription.
- Скажешь ли про fairness/starvation и что бывают ticket/MCS локи.
- Предложишь ли вообще обойтись без лока (atomic fetch_add).
- Помнишь ли, что тип должен быть *Lockable*, чтобы работать с `lock_guard`.

## Чеклист для устного ответа

- `lock` → acquire, `unlock` → release. `relaxed` = data race = UB; `seq_cst` = лишний
  барьер (на x86 `xchg`/`mfence` вместо обычного `mov`).
- TAS в цикле = ping-pong кэш-линии; TTAS = спин на load, RMW только при свободном флаге.
- `_mm_pause()` в спин-цикле обязателен; после N итераций — `yield`, потом сон.
- Spinlock не fair, возможна голодовка; ticket lock / MCS lock решают.
- Oversubscription убивает spinlock: владелец вытеснен, ожидающие жгут кванты.
- `std::mutex` = адаптивный спин + futex; без contention он почти бесплатен.
- `alignas(64)`, non-copyable, `try_lock` для совместимости с `lock_guard`.
- Лучший лок — отсутствующий: atomic-операция или per-thread состояние.
