# 03. `shared_ptr`: циклическая ссылка, `weak_ptr`, устройство control block

## Вопрос

Вот код подписки на market data feed. Он «работает», но при выходе из `main` не печатается
ни одна строка из деструкторов.

Почему и как это чинить?

```cpp
// Пример намеренно сломан.
#include <iostream>
#include <memory>
#include <string>
#include <vector>

class Subscriber;

class Feed
{
public:
    explicit Feed(std::string name) : name_(std::move(name)) {}
    ~Feed() { std::cout << "~Feed " << name_ << "\n"; }

    void subscribe(std::shared_ptr<Subscriber> s) { subs_.push_back(std::move(s)); }
    void publish(double px);

private:
    std::string name_;
    std::vector<std::shared_ptr<Subscriber>> subs_;
};

class Subscriber
{
public:
    explicit Subscriber(std::shared_ptr<Feed> feed) : feed_(std::move(feed)) {}
    ~Subscriber() { std::cout << "~Subscriber\n"; }

    void on_tick(double px) { last_ = px; }

private:
    std::shared_ptr<Feed> feed_;
    double last_ = 0.0;
};

void Feed::publish(double px)
{
    for (auto& s : subs_)
        s->on_tick(px);
}

int main()
{
    auto feed = std::make_shared<Feed>("ES");
    auto sub  = std::make_shared<Subscriber>(feed);
    feed->subscribe(sub);
    feed->publish(4200.0);
}   // ничего не печатается: оба объекта утекли
```

<details>
<summary>Разбор</summary>

### Почему течёт

`shared_ptr` — это неинтрузивный подсчёт ссылок. Он освобождает объект, когда strong count
падает до нуля. Здесь:

- `feed` держит `sub` (через `subs_`), `sub` держит `feed` (через `feed_`).
- В конце `main` локальные `shared_ptr` разрушаются, счётчики уменьшаются с 2 до 1.
- Ни один не достигает нуля → деструкторы не вызываются → утечка **и объектов, и control
  block'ов**.

Это фундаментальное ограничение reference counting: **он не собирает циклы**.
Trace-based GC (Java, Go) их собирает, RC — нет.

### Как чинить

Правило: **владелец держит `shared_ptr`, обратная ссылка — `weak_ptr` (или сырой указатель /
ссылка, если время жизни гарантировано)**. Здесь владение однонаправленное: feed владеет
подписчиками, подписчик лишь «знает» о feed.

```cpp
class Subscriber
{
public:
    explicit Subscriber(std::weak_ptr<Feed> feed) : feed_(std::move(feed)) {}

    void on_tick(double px)
    {
        last_ = px;
        if (auto f = feed_.lock())   // временный shared_ptr на время использования
            (void)f;                 // объект жив, работаем с ним
    }

private:
    std::weak_ptr<Feed> feed_;
    double last_ = 0.0;
};
```

`weak_ptr` не увеличивает strong count; он увеличивает **weak count**, который держит живым
только control block, но не сам объект. `lock()` атомарно проверяет strong count и, если он
не ноль, инкрементирует его — это единственный корректный способ «оживить» слабую ссылку.
Проверка `expired()` с последующим `lock()` — гонка (TOCTOU), так писать нельзя.

Если бы feed жил заведомо дольше подписчиков (типично: feed — синглтон/член engine),
корректно и дешевле хранить `Feed&` или `Feed*`. `shared_ptr` — не «умный указатель по
умолчанию», а инструмент **разделяемого владения с неопределённым временем жизни**.

### Что ещё спросят по этому коду

**1. `make_shared` vs `shared_ptr<T>(new T)`.**
`make_shared` делает **одну** аллокацию: control block и объект лежат рядом (лучше
локальность, меньше вызовов аллокатора). Минусы:
- память объекта не освобождается, пока жив хотя бы один `weak_ptr` (control block и
  объект в одном блоке) — для больших объектов + долгоживущих weak это реальная проблема;
- нельзя передать custom deleter (для этого только конструктор из указателя);
- не работает с `new T[]` до C++20 (`make_shared<T[]>` появился в C++20).

Отдельный аргумент за `make_shared`: exception safety в вызове
`f(shared_ptr<A>(new A), g())` — до C++17 порядок вычисления не определён и возможна утечка.

**2. Как устроен control block.**
Это отдельный объект в куче, на который ссылаются все `shared_ptr` и `weak_ptr` одного
объекта. В нём лежат:
- **strong count** — сколько `shared_ptr` владеют объектом; при нуле вызывается deleter
  (то есть **разрушается объект**);
- **weak count** — сколько `weak_ptr` (плюс единица, пока strong > 0); при нуле
  **освобождается сам control block**;
- **deleter** (type-erased) и **allocator**.

Отсюда два важных следствия: объект и control block имеют **разные** времена жизни
(объект умирает при strong = 0, блок — при weak = 0), а при `make_shared` они лежат в
одном куске памяти, поэтому память объекта не возвращается системе, пока жив хотя бы
один `weak_ptr`.

**3. Что атомарно, а что нет.**
Атомарны **только операции над счётчиками** в control block. Не атомарно всё остальное:
- сам объект `shared_ptr` (пара указателей) — одновременные чтение и запись **одного и
  того же** `shared_ptr` из разных потоков это data race; разные копии, указывающие на
  один объект, использовать параллельно можно;
- указываемый объект — `shared_ptr` не даёт никакой синхронизации доступа к `*p`;
- сброс/переприсваивание (`p = q`, `p.reset()`) — не атомарная операция.

Для атомарного `shared_ptr` есть `std::atomic<std::shared_ptr<T>>` (C++20) и устаревшие
свободные функции `std::atomic_load/store(&sp)` (C++11, deprecated в C++20).

**4. Стоимость `shared_ptr`.**
- `sizeof(shared_ptr) == 2 * sizeof(void*)` (указатель на объект + на control block).
- Копирование = **атомарный** инкремент (`lock xadd`), разрушение = атомарный декремент
  с acquire-release. Это десятки циклов при contention между ядрами, плюс перебрасывание
  кэш-линии control block'а между ядрами (`false sharing` де-факто на счётчике).
- Вывод для hot path: **передавай `const shared_ptr<T>&` или сырой `T*`/`T&`**, если функция
  не берёт владение. Копия `shared_ptr` в аргументе — самая частая скрытая просадка.
- Сам указатель не потокобезопасен: атомарен только счётчик. Одновременные запись и чтение
  *одного и того же* `shared_ptr` объекта — data race (для этого есть
  `std::atomic<std::shared_ptr<T>>` в C++20).

**5. `enable_shared_from_this`.**
Если объекту нужно раздать `shared_ptr` на себя:

```cpp
class Feed : public std::enable_shared_from_this<Feed>
{
    void arm() { some_registry.add(shared_from_this()); }
};
```

Ловушки: `shared_from_this()` в конструкторе — UB (`weak_this` ещё не проинициализирован,
бросит `std::bad_weak_ptr`); объект обязан быть создан через `shared_ptr`, иначе тоже
`bad_weak_ptr`; наследование должно быть public.

**6. Двойное владение — классическая ошибка:**

```cpp
// Пример намеренно сломан.
Feed* raw = new Feed("ES");
std::shared_ptr<Feed> a(raw);
std::shared_ptr<Feed> b(raw);   // два независимых control block'а → double free
```

Из сырого указателя `shared_ptr` не «узнаёт» о существующих владельцах.

**7. Aliasing constructor** — `shared_ptr<Member>(owner_sp, &owner_sp->member)`: считает
ссылки на владельца, а указывает на подобъект. Спрашивают редко, но упоминание производит
впечатление.

**8. `unique_ptr` вместо `shared_ptr`.** Если владелец один — `unique_ptr`, он бесплатный
(с stateless deleter `sizeof == sizeof(void*)`, никаких атомиков). На интервью полезно
сказать: «`shared_ptr` здесь избыточен, владение однонаправленное».

### Как обнаружить такую утечку

- ASan/LSan (`-fsanitize=address`) покажет утечку блоков в конце процесса.
- Valgrind `--leak-check=full` — «still reachable» vs «definitely lost»: цикл
  `shared_ptr` обычно попадает в **definitely lost** (на них не осталось внешних указателей).
- В логах: деструктор не печатается. Ассерт-счётчик живых объектов в тестах.
- `use_count()` в отладке (не для логики — он race-prone и лишь «подсказка»).

</details>

## На что смотрит интервьюер

- Мгновенно ли ты называешь **цикл ссылок** и `weak_ptr` как решение.
- Понимаешь ли **направление владения** — что `weak_ptr` ставят не «куда попало»,
  а на обратную (не-владеющую) ссылку.
- Знаешь ли, что `lock()` — атомарен, а `expired() + lock()` — гонка.
- Скажешь ли про **цену атомарного счётчика** — на quant-позиции это ожидаемая реакция.
- Знаешь ли разницу `make_shared` / `new` в обе стороны (плюсы **и** минусы).
- Предложишь ли вообще убрать `shared_ptr` (`unique_ptr` + сырая обратная ссылка).

## Чеклист для устного ответа

- RC не собирает циклы; `weak_ptr` разрывает цикл, не участвуя в владении.
- `weak_ptr::lock()` → `shared_ptr` или пустой; только так, без `expired()`-проверок.
- Владелец → `shared_ptr`; наблюдатель → `weak_ptr`/сырой указатель.
- `make_shared`: 1 аллокация, но объект живёт, пока жив weak; нет custom deleter.
- Копия `shared_ptr` = 2 атомарные операции; в hot path передавать по `const&`.
- Control block: strong count (жизнь объекта), weak count (жизнь блока), deleter, allocator.
- Атомарны только счётчики; сам `shared_ptr` и указываемый объект — нет.
  C++20 — `std::atomic<std::shared_ptr<T>>`.
- `enable_shared_from_this`: не в конструкторе, только для объектов под `shared_ptr`.
- Один сырой указатель нельзя отдать двум `shared_ptr` — два control block'а, double free.
