# 06. UB и type punning: strict aliasing, `union`-хак, `memcpy` и `std::bit_cast`

## Вопрос

Вот парсер бинарного протокола котировок и пара утилит рядом с ним. Код проходит тесты
в debug-сборке и даёт мусор (а иногда падает) в release с `-O2`.

Что здесь не так и почему это проявляется только с оптимизациями?

```cpp
// Пример намеренно сломан.
#include <cstdint>
#include <cstring>

#pragma pack(push, 1)
struct QuoteMsg
{
    std::uint8_t  type;
    std::uint32_t symbol_id;
    std::int64_t  price;
    std::uint32_t qty;
};
#pragma pack(pop)

union FloatBits
{
    float f;
    std::uint32_t u;
};

double parse_price(const char* buffer)
{
    const QuoteMsg* msg = reinterpret_cast<const QuoteMsg*>(buffer);   // (1)
    if (msg->type != 'Q')
        return 0.0;
    return static_cast<double>(msg->price) / 1e8;
}

std::uint32_t float_to_bits(float f)
{
    FloatBits fb;
    fb.f = f;
    return fb.u;                                                       // (2)
}

int fast_inverse_sqrt_bits(float x)
{
    int i = *reinterpret_cast<int*>(&x);                               // (3)
    return i;
}

std::uint32_t read_be32(const char* p)
{
    std::uint32_t v = *reinterpret_cast<const std::uint32_t*>(p);      // (4)
    return v;
}
```

<details>
<summary>Разбор</summary>

### Что такое strict aliasing

Правило C++ ([basic.lval]): к объекту разрешено обращаться только через glvalue одного из
типов: динамический тип объекта, его cv-квалифицированная версия, знаковый/беззнаковый
вариант, базовый класс, а также `char`, `unsigned char` и `std::byte`. Всё остальное — **UB**.

Зачем: компилятор предполагает, что `int*` и `float*` не могут указывать на одну память,
и на этом основании кэширует значения в регистрах, переупорядочивает загрузки/записи,
векторизует циклы. Отключается флагом `-fno-strict-aliasing` (GCC/Clang), но полагаться
на это — не решение, а признание поражения.

Ключевая фраза для интервью: **«в debug работает, в release ломается» — почти всегда
это strict aliasing либо неинициализированная переменная либо UB со знаковым переполнением.**

### Баг (3): `*reinterpret_cast<int*>(&x)` — прямое нарушение

Объект имеет динамический тип `float`, читаем как `int` → UB. На `-O2` GCC вправе
не перечитывать память вовсе. Классический «быстрый обратный квадратный корень» из Quake
формально UB в C++.

Правильно:

```cpp
#include <cstring>
std::uint32_t bits;
std::memcpy(&bits, &x, sizeof bits);   // всегда корректно, оптимизируется в один mov
```

или, с C++20:

```cpp
#include <bit>
auto bits = std::bit_cast<std::uint32_t>(x);   // constexpr, без UB, ноль накладных расходов
```

`std::bit_cast` требует, чтобы оба типа были trivially copyable и одного размера, — это
именно тот инструмент, который тут нужен.

Важно уметь сказать, что `memcpy` **не** приводит к реальному вызову функции: компилятор
распознаёт его как builtin и генерирует одну инструкцию загрузки. Это самый частый
контр-аргумент («а memcpy же медленно») — он неверен.

### Баг (2): чтение неактивного члена union

В C++ (в отличие от C99+) чтение члена union, который не был записан последним, — **UB**.
На практике GCC/Clang это поддерживают как документированное расширение, и код работает,
но формально `fb.u` после `fb.f = f` — неактивный член.

Правильно: `std::bit_cast` / `memcpy`. Union-трюк — легаси из C, его надо уметь опознать
и назвать, но не писать в новом коде.

### Баг (1) и (4): misaligned access + aliasing

```cpp
const QuoteMsg* msg = reinterpret_cast<const QuoteMsg*>(buffer);
```

Две проблемы:

1. **Aliasing.** В буфере нет объекта типа `QuoteMsg` — там объекты типа `char`. Формально
   до C++20 это UB (объект не начал существовать); C++20 добавил implicit object creation
   для некоторых операций (`malloc`, `memcpy`, `bit_cast`), но `reinterpret_cast` сам по
   себе объект не создаёт. Строго корректный способ — `std::memcpy` в локальную переменную,
   или `std::start_lifetime_as` (C++23).
2. **Выравнивание.** `buffer` — это `const char*`, он может быть выровнен по 1 байту.
   `QuoteMsg` с `#pragma pack(1)` требует выравнивания 1, поэтому сам доступ формально
   разрешён, **но** поля `price` (8 байт) и `symbol_id` (4 байта) окажутся по невыровненным
   адресам. На x86 невыровненный доступ работает (с небольшим штрафом, и с большим — при
   пересечении кэш-линии); на ARMv7 и старых SPARC — SIGBUS; SSE-инструкции с требованием
   выравнивания (`movaps`) упадут и на x86.

То же и в (4): `reinterpret_cast<const std::uint32_t*>(p)` при невыровненном `p`.

Правильно и переносимо:

```cpp
QuoteMsg parse(const char* buffer)
{
    QuoteMsg msg;
    std::memcpy(&msg, buffer, sizeof msg);   // корректно и по aliasing, и по выравниванию
    return msg;
}
```

### Баг: endianness

`read_be32` называется «big endian», но читает нативным порядком. Биржевые протоколы
(FIX/FAST, ITCH, OUCH, большинство сетевых) — обычно **big endian**, x86 — little endian.
Код молча даст перевёрнутые числа.

```cpp
#include <bit>
#include <cstring>

std::uint32_t read_be32(const char* p) noexcept
{
    std::uint32_t v;
    std::memcpy(&v, p, sizeof v);
    if constexpr (std::endian::native == std::endian::little)
        v = __builtin_bswap32(v);        // C++23: std::byteswap
    return v;
}
```

`std::endian` — C++20, `std::byteswap` — C++23; до этого `__builtin_bswap32` / `ntohl`.
`bswap` — одна инструкция, бесплатно.

### Баг: `#pragma pack` и его цена

`#pragma pack(1)` убирает padding — структура становится 17 байт вместо 24. Это нужно,
чтобы layout совпадал с wire-форматом. Но:
- Все поля становятся потенциально невыровненными → доступ к ним дороже, компилятор может
  разбить одну загрузку на несколько.
- **Нельзя брать указатель/ссылку на поле упакованной структуры** — тип указателя обещает
  выравнивание, которого нет (GCC даёт `-Waddress-of-packed-member`).
- `#pragma pack` — не стандарт, а расширение (хотя поддерживается везде);
  `[[gnu::packed]]` / `__attribute__((packed))` — аналог.

Промышленный подход: не мапить структуры на буфер вообще, а иметь **явный
декодер по полям** с `memcpy` + `byteswap`, генерируемый из описания протокола. Это
безопаснее и обычно не медленнее.

### Смежное UB, которое живёт в том же коде: signed integer overflow

Переполнение **знакового** целого — UB (беззнакового — определено, работает по модулю 2^n).
Это тот же класс проблем: компилятор оптимизирует, **предполагая, что UB не происходит**.

```cpp
// Пример намеренно сломан.
bool will_overflow(int x) { return x + 1 < x; }        // всегда false на -O2
for (int i = 0; i <= n; ++i) { /* ... */ }             // если n == INT_MAX — бесконечный цикл
int seq = msg_seq * 1000 + sub_id;                     // молчаливое UB при больших seq
```

`x + 1 < x` компилятор сворачивает в `false`, потому что «переполнения не бывает».
Проверять надо до операции (`x > INT_MAX - 1`) либо через builtins
(`__builtin_add_overflow`) / C++26 `std::add_sat`, либо считать в `int64_t`,
либо использовать беззнаковый тип там, где нужна арифметика по модулю.

Практический вывод для парсеров протоколов: все счётчики, sequence numbers и
идентификаторы — беззнаковые фиксированной ширины (`std::uint32_t`, `std::uint64_t`),
никаких `int`. Ловится UBSan (`-fsanitize=signed-integer-overflow`).

### Дополнительно: что ещё спросят

- **«Что гарантированно можно alias'ить?»** Исключение из правила strict aliasing —
  **`char`, `unsigned char` и `std::byte`**: через glvalue этих типов можно читать
  байтовое представление **любого** объекта, и именно поэтому `memcpy` (который
  формально работает через `unsigned char`) всегда легален. Обратное **не** работает:
  смотреть на массив `char` как на `int` нельзя — там нет объекта типа `int`.
  Заметь, что `signed char` в этот список **не входит** (хотя на практике поддерживается).
- **«`reinterpret_cast` vs `static_cast` vs `bit_cast`?»** `static_cast` — конверсия
  значений с известной семантикой (в т.ч. вверх/вниз по иерархии без проверки);
  `dynamic_cast` — с проверкой во время выполнения; `reinterpret_cast` — переинтерпретация
  бит указателя, почти всегда UB при разыменовании; `bit_cast` — копирование битового
  представления в новый объект, корректно.
- **«`std::launder`?»** Нужен, когда объект пересоздали placement new поверх другого и
  компилятор мог закэшировать предположения о старом (особенно с `const`-членами и vptr).
- **«Что такое trivially copyable?»** Тривиальные copy/move-конструкторы и присваивания,
  тривиальный деструктор. Только такие типы можно `memcpy`/`bit_cast`.
- **«Как поймать?»** UBSan (`-fsanitize=undefined,alignment`) ловит misaligned access;
  `-Wstrict-aliasing=2`, `-Wcast-align`, `-Waddress-of-packed-member`. Strict aliasing
  санитайзеры **не** ловят надёжно — это как раз то, что делает баг коварным.

</details>

## На что смотрит интервьюер

- Назовёшь ли ты strict aliasing **по имени** и объяснишь, зачем это правило существует
  (оптимизации), а не просто «так нельзя».
- Знаешь ли `std::bit_cast` / `memcpy` как правильный инструмент и то, что `memcpy`
  компилируется в одну инструкцию.
- Знаешь ли, что чтение неактивного члена union в C++ — UB (а в C — нет).
- Отделяешь ли **aliasing** от **alignment** — это две разные проблемы, часто путают.
- Заметишь ли endianness — маркер человека, писавшего парсеры протоколов.
- Понимаешь ли компромисс `#pragma pack` и почему нельзя брать ссылку на packed-поле.
- Скажешь ли «в debug работает, в release нет» → «ищем UB», а не «баг компилятора».

## Чеклист для устного ответа

- Strict aliasing: обращаться к объекту можно только через его тип. Исключение —
  `char`/`unsigned char`/`std::byte` (только в эту сторону). Нарушение = UB на `-O2`.
- Signed overflow — тоже UB: `x + 1 < x` сворачивается в `false`; считать в `int64_t`
  или в беззнаковых типах, ловить UBSan.
- `reinterpret_cast` + разыменование = почти всегда нарушение; `memcpy`/`std::bit_cast` = ок.
- `memcpy` фиксированного размера — builtin, компилируется в один `mov`.
- Union type punning — UB в C++ (расширение в GCC/Clang), легально в C.
- Alignment — отдельная проблема: SIGBUS на ARM, штраф и падение SSE на x86.
- `char*`-буфер не содержит объекта нужного типа: копируем в локальную переменную.
- Endianness: сетевые протоколы big endian, `byteswap`/`bswap` — бесплатно.
- `#pragma pack`: совпадение с wire-форматом ценой невыровненных полей; ссылки на поля брать нельзя.
- Ловим: UBSan alignment, `-Wcast-align`, `-Waddress-of-packed-member`; strict aliasing —
  почти не ловится, поэтому просто не писать так.
