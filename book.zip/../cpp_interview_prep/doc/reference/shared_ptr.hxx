// Справочная реализация std::shared_ptr. Этот файл — КОРРЕКТНЫЙ образец,
// в отличие от ../../shared_ptr_fix/my_shared_ptr.hxx, где ошибки заложены нарочно.
// Открывать после того, как починил тренажёр, — иначе смысла в тренажёре нет.
//
// Устройство повторяет libstdc++ (_Sp_counted_base и наследники) и libc++
// (__shared_weak_count). Имена свои, читаемые; вся суть — та же.
//
// Что здесь есть:
//   * иерархия блоков управления с двумя атомарными счётчиками;
//   * стирание типа удалителя и настоящего типа объекта;
//   * make_shared с одной аллокацией и объектом внутри блока;
//   * weak_ptr с честным CAS-циклом в lock();
//   * enable_shared_from_this, aliasing-конструктор, pointer_cast'ы.
//
// Чего здесь нет (сознательно, чтобы не утонуть): аллокаторы (allocate_shared),
// shared_ptr<T[]> из C++17, atomic<shared_ptr> из C++20, поддержка unique_ptr
// в конструкторе. В комментариях помечено, куда они встраиваются.
//
// Проверка: doc/reference/shared_ptr_test.cxx

#pragma once

#include <atomic>
#include <cstddef>
#include <functional>
#include <memory>
#include <new>
#include <type_traits>
#include <utility>

namespace ref {

template <class T> class SharedPtr;
template <class T> class WeakPtr;

// =====================================================================================
// Блок управления
// =====================================================================================
//
// Два счётчика, и это не «сильный и слабый» в лоб:
//
//   strong_ — сколько SharedPtr владеют объектом;
//   weak_   — сколько WeakPtr плюс ОДНА общая ссылка от всей группы strong.
//
// Приём с «группа strong держит одну weak» — из libstdc++. Он избавляет от гонки
// между «последний strong умер» и «последний weak умер»: пока жив хоть один
// SharedPtr, weak_ гарантированно >= 1, поэтому блок не могут снести из-под ног.
//
// Жизненный цикл:
//   strong_ -> 0   ==> dispose()  — уничтожаем ОБЪЕКТ, блок ещё жив (в нём счётчики,
//                                   на которые смотрят живые WeakPtr);
//   weak_   -> 0   ==> destroy()  — уничтожаем САМ БЛОК.
class ControlBlockBase
{
public:
    ControlBlockBase()                                   = default;
    ControlBlockBase(const ControlBlockBase&)            = delete;
    ControlBlockBase& operator=(const ControlBlockBase&) = delete;

    virtual ~ControlBlockBase() = default;

    // Копирование SharedPtr. relaxed достаточно: мы уже владеем объектом, значит
    // никакой новой видимости чужих записей нам этот инкремент не обязан давать,
    // а атомарность самого ++ relaxed гарантирует.
    void add_ref() noexcept
    {
        strong_.fetch_add(1, std::memory_order_relaxed);
    }

    // Это WeakPtr::lock(). Нельзя «проверить != 0, потом ++»: между проверкой и
    // инкрементом другой поток успеет уронить счётчик в ноль и удалить объект.
    // Нужен CAS-цикл, который отказывается поднимать счётчик с нуля.
    bool add_ref_lock() noexcept
    {
        long count = strong_.load(std::memory_order_relaxed);

        do
        {
            if (count == 0)
                return false;   // объект уже уничтожен, воскрешать нечего
        }
        while (!strong_.compare_exchange_weak(count, count + 1,
                                              std::memory_order_acquire,   // успех
                                              std::memory_order_relaxed)); // провал

        return true;
    }

    void weak_add_ref() noexcept
    {
        weak_.fetch_add(1, std::memory_order_relaxed);
    }

    // Декремент relaxed делать НЕЛЬЗЯ, и это главный вопрос на интервью.
    //
    // Поток, который отпускает ссылку, мог до этого писать в объект. Поток,
    // который увидит ноль и вызовет деструктор, обязан эти записи увидеть —
    // иначе деструктор гонится с чужими записями, а это UB. Нужна пара
    // release (на всех декрементах) / acquire (на том, который увидел ноль).
    //
    // acq_rel даёт обе половины одной операцией. Так делает libstdc++.
    //
    // Есть более дешёвый вариант — идиома из Boost:
    //
    //     if (strong_.fetch_sub(1, std::memory_order_release) == 1)
    //     {
    //         std::atomic_thread_fence(std::memory_order_acquire);
    //         dispose();
    //     }
    //
    // Здесь acquire платится только на последнем декременте, а не на каждом.
    // Расплата практическая: ThreadSanitizer не моделирует atomic_thread_fence
    // (GCC даже предупреждает -Wtsan) и выдаёт на этом коде ложную гонку
    // «free() против fetch_sub». Проверить такой релиз инструментом нельзя —
    // только глазами. Поэтому по умолчанию здесь acq_rel.
    void release() noexcept
    {
        if (strong_.fetch_sub(1, std::memory_order_acq_rel) == 1)
        {
            dispose();       // объект умер
            weak_release();  // группа strong отпустила свою общую weak-ссылку
        }
    }

    void weak_release() noexcept
    {
        if (weak_.fetch_sub(1, std::memory_order_acq_rel) == 1)
            destroy();       // блок умер
    }

    // use_count() — это ПОДСКАЗКА, а не факт: к моменту, когда вы посмотрите
    // на результат, другой поток уже мог сделать копию или отпустить свою.
    // Осмысленно только в однопоточном коде и в тестах.
    long use_count() const noexcept
    {
        return strong_.load(std::memory_order_relaxed);
    }

protected:
    // Уничтожить управляемый объект. Именно здесь стирается его настоящий тип:
    // блок помнит, чем был указатель в момент создания SharedPtr.
    virtual void dispose() noexcept = 0;

    // Уничтожить сам блок. В настоящих реализациях здесь работает аллокатор,
    // поэтому функция виртуальная, а не просто delete this в базе.
    virtual void destroy() noexcept
    {
        delete this;
    }

private:
    std::atomic<long> strong_{1};
    std::atomic<long> weak_{1};   // единица — это ссылка от группы strong, не от WeakPtr
};

// -------------------------------------------------------------------------------------
// Блок для SharedPtr<T>(new Y): помним настоящий Y и удаляем именно его.
//
// Отсюда растёт неочевидное свойство: shared_ptr<Base> p(new Derived) корректно
// зовёт ~Derived ДАЖЕ БЕЗ виртуального деструктора у Base — тип запомнил блок,
// а не указатель. С unique_ptr этот фокус не работает: там удалитель часть типа.
template <class Y>
class ControlBlockPtr final : public ControlBlockBase
{
public:
    explicit ControlBlockPtr(Y* raw) noexcept
        : raw_(raw)
    {
    }

private:
    void dispose() noexcept override { delete raw_; }

    Y* raw_;
};

// -------------------------------------------------------------------------------------
// Блок с пользовательским удалителем.
//
// [[no_unique_address]] — тот самый EBO, из-за которого удалитель без состояния
// (лямбда без захватов, пустой функтор) не стоит ни байта. В libstdc++ то же самое
// сделано наследованием от _Sp_ebo_helper.
template <class Y, class Deleter>
class ControlBlockDeleter final : public ControlBlockBase
{
public:
    ControlBlockDeleter(Y* raw, Deleter deleter) noexcept
        : raw_(raw)
        , deleter_(std::move(deleter))
    {
    }

private:
    // noexcept здесь — обещание, а не проверка: если удалитель бросит,
    // будет std::terminate. Стандарт требует, чтобы удалитель не бросал.
    void dispose() noexcept override { deleter_(raw_); }

    Y*                              raw_;
    [[no_unique_address]] Deleter   deleter_;
};

// -------------------------------------------------------------------------------------
// Блок для make_shared: объект лежит ВНУТРИ блока, аллокация одна.
//
// Плата за это — память не освобождается, пока жив хотя бы один WeakPtr:
// объект и счётчики в одном куске, отдать половину куска аллокатору нельзя.
// Для большого объекта и долгоживущего weak_ptr это реальная проблема, и это
// единственный честный аргумент против make_shared.
template <class T>
class ControlBlockInplace final : public ControlBlockBase
{
public:
    template <class... Args>
    explicit ControlBlockInplace(Args&&... args)
    {
        ::new (static_cast<void*>(storage_)) T(std::forward<Args>(args)...);
    }

    // std::launder обязателен: мы читаем объект через указатель, полученный
    // из массива байт, а не из new-выражения. Без него это формально UB.
    T* get() noexcept
    {
        return std::launder(reinterpret_cast<T*>(storage_));
    }

private:
    void dispose() noexcept override { get()->~T(); }

    alignas(T) std::byte storage_[sizeof(T)];
};

// =====================================================================================
// enable_shared_from_this
// =====================================================================================
//
// Хранит внутри объекта WeakPtr на самого себя. Заполняется НЕ конструктором
// объекта, а конструктором SharedPtr — потому что в момент работы конструктора
// T никакого SharedPtr ещё не существует. Отсюда правило: shared_from_this()
// нельзя звать из конструктора и из деструктора.
template <class T>
class EnableSharedFromThis
{
public:
    SharedPtr<T> shared_from_this()             { return SharedPtr<T>(weak_this_); }
    SharedPtr<const T> shared_from_this() const { return SharedPtr<const T>(weak_this_); }

    WeakPtr<T> weak_from_this() noexcept              { return weak_this_; }
    WeakPtr<const T> weak_from_this() const noexcept  { return weak_this_; }

protected:
    EnableSharedFromThis()                                       = default;
    EnableSharedFromThis(const EnableSharedFromThis&) noexcept    {}
    EnableSharedFromThis& operator=(const EnableSharedFromThis&) noexcept { return *this; }
    ~EnableSharedFromThis()                                      = default;

private:
    template <class U> friend class SharedPtr;

    mutable WeakPtr<T> weak_this_;
};

namespace detail {

template <class Y, class T>
concept CompatibleWith = std::is_convertible_v<Y*, T*>;

} // namespace detail

// =====================================================================================
// SharedPtr
// =====================================================================================
//
// Ровно два поля, отсюда sizeof == 2 * sizeof(void*) == 16 на x86-64.
// unique_ptr — 8, потому что его удалитель часть типа и схлопывается по EBO,
// а здесь удалитель стёрт в блок управления, и на него нужен указатель.
//
// ptr_ и объект, которым владеет блок, — РАЗНЫЕ вещи. Это и есть aliasing:
// можно владеть агрегатом, а указывать на его поле.
//
// Сам объект SharedPtr НЕ атомарен. Атомарны только счётчики. Две нити,
// пишущие в один и тот же SharedPtr, — это гонка данных; для этого случая
// есть std::atomic<std::shared_ptr> (C++20).
template <class T>
class SharedPtr
{
public:
    using element_type = T;

    constexpr SharedPtr() noexcept = default;
    constexpr SharedPtr(std::nullptr_t) noexcept {}

    // explicit — чтобы сырой указатель не превращался в владельца молча.
    // Два SharedPtr из одного сырого указателя дадут два блока и двойное удаление.
    template <class Y>
        requires detail::CompatibleWith<Y, T>
    explicit SharedPtr(Y* raw)
    {
        // Если new блока бросит, сырой указатель уже ничей — течёт.
        // Поэтому владение перехватываем до того, как что-то может бросить.
        try
        {
            ctrl_ = new ControlBlockPtr<Y>(raw);
        }
        catch (...)
        {
            delete raw;
            throw;
        }

        ptr_ = raw;
        enable_weak_this(raw);
    }

    template <class Y, class Deleter>
        requires detail::CompatibleWith<Y, T>
    SharedPtr(Y* raw, Deleter deleter)
    {
        try
        {
            ctrl_ = new ControlBlockDeleter<Y, Deleter>(raw, std::move(deleter));
        }
        catch (...)
        {
            deleter(raw);
            throw;
        }

        ptr_ = raw;
        enable_weak_this(raw);
    }

    SharedPtr(const SharedPtr& other) noexcept
        : ptr_(other.ptr_)
        , ctrl_(other.ctrl_)
    {
        if (ctrl_ != nullptr)
            ctrl_->add_ref();
    }

    template <class Y>
        requires detail::CompatibleWith<Y, T>
    SharedPtr(const SharedPtr<Y>& other) noexcept
        : ptr_(other.ptr_)
        , ctrl_(other.ctrl_)
    {
        if (ctrl_ != nullptr)
            ctrl_->add_ref();
    }

    SharedPtr(SharedPtr&& other) noexcept
        : ptr_(std::exchange(other.ptr_, nullptr))
        , ctrl_(std::exchange(other.ctrl_, nullptr))
    {
    }

    template <class Y>
        requires detail::CompatibleWith<Y, T>
    SharedPtr(SharedPtr<Y>&& other) noexcept
        : ptr_(std::exchange(other.ptr_, nullptr))
        , ctrl_(std::exchange(other.ctrl_, nullptr))
    {
    }

    // Aliasing-конструктор: владение берём у other, а указываем куда сказали.
    // Так живёт shared_ptr на поле структуры, на элемент массива, на базу.
    // Счётчик — общий с other, поэтому агрегат не умрёт, пока жив вид на поле.
    template <class Y>
    SharedPtr(const SharedPtr<Y>& owner, element_type* raw) noexcept
        : ptr_(raw)
        , ctrl_(owner.ctrl_)
    {
        if (ctrl_ != nullptr)
            ctrl_->add_ref();
    }

    // Из WeakPtr. Бросает, если объект уже умер: тихо вернуть пустой указатель
    // нельзя, иначе разыменование даст UB там, где программист ждал объект.
    // Мягкий вариант — WeakPtr::lock(), он возвращает пустой SharedPtr.
    template <class Y>
        requires detail::CompatibleWith<Y, T>
    explicit SharedPtr(const WeakPtr<Y>& weak)
    {
        if (weak.ctrl_ == nullptr || !weak.ctrl_->add_ref_lock())
            throw std::bad_weak_ptr();

        ptr_  = weak.ptr_;
        ctrl_ = weak.ctrl_;
    }

    ~SharedPtr()
    {
        if (ctrl_ != nullptr)
            ctrl_->release();
    }

    // Copy-and-swap: самоприсваивание безопасно без единого if,
    // и strong exception guarantee получается сама собой.
    SharedPtr& operator=(const SharedPtr& other) noexcept
    {
        SharedPtr(other).swap(*this);
        return *this;
    }

    // Самоперемещение тоже безопасно: временный забирает ресурс, *this пустеет,
    // swap возвращает ресурс на место. Ни двойного release, ни висячего ptr_.
    SharedPtr& operator=(SharedPtr&& other) noexcept
    {
        SharedPtr(std::move(other)).swap(*this);
        return *this;
    }

    template <class Y>
        requires detail::CompatibleWith<Y, T>
    SharedPtr& operator=(const SharedPtr<Y>& other) noexcept
    {
        SharedPtr(other).swap(*this);
        return *this;
    }

    template <class Y>
        requires detail::CompatibleWith<Y, T>
    SharedPtr& operator=(SharedPtr<Y>&& other) noexcept
    {
        SharedPtr(std::move(other)).swap(*this);
        return *this;
    }

    void swap(SharedPtr& other) noexcept
    {
        std::swap(ptr_,  other.ptr_);
        std::swap(ctrl_, other.ctrl_);
    }

    // reset() — это ровно присваивание нового владельца, поэтому и пишется
    // через него: старая ссылка отпускается, а не затирается.
    void reset() noexcept { SharedPtr().swap(*this); }

    template <class Y>
        requires detail::CompatibleWith<Y, T>
    void reset(Y* raw) { SharedPtr(raw).swap(*this); }

    template <class Y, class Deleter>
        requires detail::CompatibleWith<Y, T>
    void reset(Y* raw, Deleter deleter) { SharedPtr(raw, std::move(deleter)).swap(*this); }

    element_type* get() const noexcept { return ptr_; }

    // Без проверки на nullptr: разыменование пустого — UB, ровно как у сырого
    // указателя. Проверка стоила бы ветки в каждом обращении.
    element_type& operator*()  const noexcept { return *ptr_; }
    element_type* operator->() const noexcept { return ptr_; }

    explicit operator bool() const noexcept { return ptr_ != nullptr; }

    long use_count() const noexcept { return ctrl_ != nullptr ? ctrl_->use_count() : 0; }

    // Сравнение ПО ВЛАДЕЛЬЦУ, а не по указателю: два aliasing-указателя на разные
    // поля одного объекта равны как владельцы, но не равны как указатели.
    // Нужно, чтобы класть shared_ptr в set/map осмысленным образом.
    template <class Y>
    bool owner_before(const SharedPtr<Y>& other) const noexcept
    {
        return std::less<const void*>()(ctrl_, other.ctrl_);
    }

    template <class Y>
    bool owner_before(const WeakPtr<Y>& other) const noexcept
    {
        return std::less<const void*>()(ctrl_, other.ctrl_);
    }

    friend bool operator==(const SharedPtr& lhs, const SharedPtr& rhs) noexcept
    {
        return lhs.ptr_ == rhs.ptr_;
    }

    friend bool operator==(const SharedPtr& lhs, std::nullptr_t) noexcept
    {
        return lhs.ptr_ == nullptr;
    }

private:
    template <class U> friend class SharedPtr;
    template <class U> friend class WeakPtr;

    template <class U, class... Args>
    friend SharedPtr<U> make_shared(Args&&... args);

    // Конструктор для make_shared: блок уже создан и уже имеет strong == 1,
    // добавлять ссылку не нужно. А вот про enable_shared_from_this забыть здесь
    // легко — и тогда shared_from_this() после make_shared бросит bad_weak_ptr.
    SharedPtr(ControlBlockBase* ctrl, element_type* raw) noexcept
        : ptr_(raw)
        , ctrl_(ctrl)
    {
        enable_weak_this(raw);
    }

    // Хук enable_shared_from_this. Настоящие реализации умеют ещё и случай,
    // когда Y наследуется от EnableSharedFromThis<Base>; здесь для читаемости
    // ограничимся прямым Y.
    template <class Y>
    void enable_weak_this(Y* raw) noexcept
    {
        if constexpr (std::is_base_of_v<EnableSharedFromThis<Y>, Y>)
        {
            if (raw != nullptr && raw->weak_this_.expired())
                raw->weak_this_ = SharedPtr<Y>(*this, raw);
        }
    }

    element_type*     ptr_  = nullptr;
    ControlBlockBase* ctrl_ = nullptr;
};

// =====================================================================================
// WeakPtr
// =====================================================================================
//
// Ссылка без владения: держит блок живым, но не объект. Ровно этим разрывается
// цикл shared_ptr <-> shared_ptr: одно из направлений делаем weak, и как только
// внешний владелец уходит, strong падает до нуля и объекты умирают.
//
// Разыменовать WeakPtr нельзя by design: между «проверил, что жив» и
// «разыменовал» объект мог умереть. Единственный вход — lock().
template <class T>
class WeakPtr
{
public:
    using element_type = T;

    constexpr WeakPtr() noexcept = default;

    WeakPtr(const WeakPtr& other) noexcept
        : ptr_(other.ptr_)
        , ctrl_(other.ctrl_)
    {
        if (ctrl_ != nullptr)
            ctrl_->weak_add_ref();
    }

    template <class Y>
        requires detail::CompatibleWith<Y, T>
    WeakPtr(const SharedPtr<Y>& other) noexcept
        : ptr_(other.ptr_)
        , ctrl_(other.ctrl_)
    {
        if (ctrl_ != nullptr)
            ctrl_->weak_add_ref();
    }

    template <class Y>
        requires detail::CompatibleWith<Y, T>
    WeakPtr(const WeakPtr<Y>& other) noexcept
        : ptr_(other.ptr_)
        , ctrl_(other.ctrl_)
    {
        if (ctrl_ != nullptr)
            ctrl_->weak_add_ref();
    }

    WeakPtr(WeakPtr&& other) noexcept
        : ptr_(std::exchange(other.ptr_, nullptr))
        , ctrl_(std::exchange(other.ctrl_, nullptr))
    {
    }

    ~WeakPtr()
    {
        if (ctrl_ != nullptr)
            ctrl_->weak_release();
    }

    WeakPtr& operator=(const WeakPtr& other) noexcept
    {
        WeakPtr(other).swap(*this);
        return *this;
    }

    WeakPtr& operator=(WeakPtr&& other) noexcept
    {
        WeakPtr(std::move(other)).swap(*this);
        return *this;
    }

    template <class Y>
        requires detail::CompatibleWith<Y, T>
    WeakPtr& operator=(const SharedPtr<Y>& other) noexcept
    {
        WeakPtr(other).swap(*this);
        return *this;
    }

    void swap(WeakPtr& other) noexcept
    {
        std::swap(ptr_,  other.ptr_);
        std::swap(ctrl_, other.ctrl_);
    }

    void reset() noexcept { WeakPtr().swap(*this); }

    long use_count() const noexcept { return ctrl_ != nullptr ? ctrl_->use_count() : 0; }

    // expired() в многопоточном коде — только подсказка: между ответом и
    // следующей строкой объект может умереть. Единственный корректный способ
    // «проверить и получить» — lock(), он делает это одной атомарной операцией.
    bool expired() const noexcept { return use_count() == 0; }

    SharedPtr<T> lock() const noexcept
    {
        SharedPtr<T> result;

        if (ctrl_ != nullptr && ctrl_->add_ref_lock())
        {
            result.ptr_  = ptr_;
            result.ctrl_ = ctrl_;
        }

        return result;
    }

    template <class Y>
    bool owner_before(const WeakPtr<Y>& other) const noexcept
    {
        return std::less<const void*>()(ctrl_, other.ctrl_);
    }

private:
    template <class U> friend class SharedPtr;
    template <class U> friend class WeakPtr;

    element_type*     ptr_  = nullptr;
    ControlBlockBase* ctrl_ = nullptr;
};

// =====================================================================================
// make_shared и приведения
// =====================================================================================

// Одна аллокация вместо двух, и объект лежит рядом со счётчиками — на одной
// кэш-линии, что заметно на горячем пути.
//
// Минусы, которые надо назвать самому:
//   1. Память живёт, пока жив последний WeakPtr (см. ControlBlockInplace).
//   2. Нельзя передать свой удалитель — для этого есть allocate_shared/конструктор.
//   3. Не работает с приватным конструктором T без обходных приёмов.
template <class T, class... Args>
SharedPtr<T> make_shared(Args&&... args)
{
    auto* block = new ControlBlockInplace<T>(std::forward<Args>(args)...);
    return SharedPtr<T>(block, block->get());
}

// Приведения идут через aliasing-конструктор: владение прежнее, меняется только вид.
template <class T, class U>
SharedPtr<T> static_pointer_cast(const SharedPtr<U>& other) noexcept
{
    return SharedPtr<T>(other, static_cast<T*>(other.get()));
}

template <class T, class U>
SharedPtr<T> dynamic_pointer_cast(const SharedPtr<U>& other) noexcept
{
    auto* raw = dynamic_cast<T*>(other.get());
    return raw != nullptr ? SharedPtr<T>(other, raw) : SharedPtr<T>();
}

template <class T, class U>
SharedPtr<T> const_pointer_cast(const SharedPtr<U>& other) noexcept
{
    return SharedPtr<T>(other, const_cast<T*>(other.get()));
}

template <class T>
void swap(SharedPtr<T>& lhs, SharedPtr<T>& rhs) noexcept
{
    lhs.swap(rhs);
}

} // namespace ref
