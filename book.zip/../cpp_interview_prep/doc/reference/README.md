# Справочные реализации

Здесь лежат **корректные** образцы того, что в других разделах даётся как задача.
Открывать после того, как решил сам, — иначе тренажёр теряет смысл.

## [`my-mistakes.md`](my-mistakes.md)

Личный чеклист собственных ошибок из ревью за 2026-09-05…09-19: что повторялось
(`isupper` от `char`, непроверенный результат `insert(node)`, всё на `seq_cst`,
`notify_all` вместо `notify_one`), что стоило дорого один раз, и четыре пункта,
которые надо проговаривать самому после каждого куска кода. Читать перед интервью.

## [`lockfree-cheatsheet.md`](lockfree-cheatsheet.md)

Шпаргалка на три связанные темы, которые спрашивают одной цепочкой: правильный
double-checked locking (и почему magic static лучше), ABA с четырьмя вариантами
решения, reclamation problem с таблицей цен. Исключение из правила «сначала реши сам»:
это конспект для чтения перед интервью, а не задача. Все сниппеты скомпилированы.

## `shared_ptr.hxx`

Полная реализация `shared_ptr` / `weak_ptr` / `make_shared` по устройству
libstdc++ (`_Sp_counted_base` и наследники) и libc++ (`__shared_weak_count`).
Парная задача — [`../../shared_ptr_fix/`](../../shared_ptr_fix/), где те же места
сломаны нарочно.

```
g++ -std=c++20 -Wall -Wextra -O2 -o sp_ref shared_ptr_test.cxx -lgtest -lgtest_main -pthread && ./sp_ref
g++ -std=c++20 -g -fsanitize=address,undefined -o sp_asan shared_ptr_test.cxx -lgtest -lgtest_main -pthread && ./sp_asan
g++ -std=c++20 -g -O1 -fsanitize=thread -o sp_tsan shared_ptr_test.cxx -lgtest -lgtest_main -pthread && ./sp_tsan
```

Проверено: 19 тестов зелёные, под ASan/UBSan и TSan чисто.

### Что смотреть в первую очередь

| Место | Зачем |
|---|---|
| `ControlBlockBase` | два счётчика и приём «группа strong держит одну weak-ссылку» — почему без него гонка между смертью объекта и смертью блока |
| `release()` / `weak_release()` | почему инкремент relaxed, а декремент нет; acq_rel против release + acquire-фенс и почему TSan второй вариант проверить не может |
| `add_ref_lock()` | `weak_ptr::lock()` — CAS-цикл, который отказывается поднимать счётчик с нуля; почему «проверил и увеличил» здесь сломано |
| `ControlBlockPtr` | стирание настоящего типа: `shared_ptr<Base> p(new Derived)` зовёт `~Derived` **без виртуального деструктора** |
| `ControlBlockInplace` | одна аллокация в `make_shared` и почему память не отдаётся, пока жив последний `weak_ptr` |
| `operator=` через copy-and-swap | самоприсваивание и самоперемещение безопасны без единого `if` |
| aliasing-конструктор | владеем агрегатом, указываем на его поле; на нём же построены `static/dynamic_pointer_cast` |
| `enable_weak_this` | почему `shared_from_this()` нельзя звать из конструктора |

### Чего в файле нет

Аллокаторы (`allocate_shared`), `shared_ptr<T[]>` из C++17, `std::atomic<std::shared_ptr>`
из C++20, конструктор из `unique_ptr`. В комментариях помечено, куда они встраиваются.
