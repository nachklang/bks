// Проверка справочной реализации из shared_ptr.hxx.
//
// Сборка:
//   g++ -std=c++20 -Wall -Wextra -O2 -o sp_ref shared_ptr_test.cxx -lgtest -lgtest_main -pthread && ./sp_ref
//   g++ -std=c++20 -g -fsanitize=address,undefined -o sp_ref_asan shared_ptr_test.cxx -lgtest -lgtest_main -pthread && ./sp_ref_asan
//   g++ -std=c++20 -g -fsanitize=thread -o sp_ref_tsan shared_ptr_test.cxx -lgtest -lgtest_main -pthread && ./sp_ref_tsan

#include "shared_ptr.hxx"

#include <gtest/gtest.h>

#include <atomic>
#include <cstdlib>
#include <thread>
#include <vector>

namespace {

// Счётчик глобальных аллокаций — им проверяем, что make_shared делает одну.
std::atomic<int> g_allocations{0};

struct Probe
{
    static inline int alive = 0;

    int value = 0;

    explicit Probe(int v = 0) : value(v) { ++alive; }
    Probe(const Probe& other) : value(other.value) { ++alive; }
    ~Probe() { --alive; }
};

struct Base
{
    static inline int destroyed_as_base = 0;

    int tag = 1;

    ~Base() { ++destroyed_as_base; }   // НЕ виртуальный — это часть проверки
};

struct Derived : Base
{
    static inline int destroyed_as_derived = 0;

    int extra = 2;

    ~Derived() { ++destroyed_as_derived; }
};

struct Aggregate
{
    int  first  = 10;
    int  second = 20;
};

struct Node
{
    static inline int alive = 0;

    ref::SharedPtr<Node> next;   // вперёд — владеющей ссылкой
    ref::WeakPtr<Node>   prev;   // назад — слабой, иначе цикл и утечка

    Node()  { ++alive; }
    ~Node() { --alive; }
};

struct Session : ref::EnableSharedFromThis<Session>
{
    int id = 7;

    ref::SharedPtr<Session> self() { return shared_from_this(); }
};

class SharedPtrRef : public ::testing::Test
{
protected:
    void SetUp() override { Probe::alive = 0; }
    void TearDown() override { EXPECT_EQ(Probe::alive, 0) << "объект пережил все владельцев"; }
};

} // namespace

// Подменяем глобальные operator new/delete, чтобы посчитать аллокации и показать,
// что make_shared делает одну, а SharedPtr(new T) — две.
//
// Под ASan подмену выключаем: санитайзер сам перехватывает operator new, часть
// аллокаций (например, внутри libgtest) уходит в его версию, а освобождается
// нашей — и он честно ругается alloc-dealloc-mismatch. Тест на счёт аллокаций
// тогда просто пропускается: под ASan мы ловим утечки, а не считаем malloc'и.
#if defined(__SANITIZE_ADDRESS__) || defined(__SANITIZE_THREAD__)
#  define REF_COUNT_ALLOCATIONS 0
#elif defined(__has_feature)
#  if __has_feature(address_sanitizer) || __has_feature(thread_sanitizer)
#    define REF_COUNT_ALLOCATIONS 0
#  else
#    define REF_COUNT_ALLOCATIONS 1
#  endif
#else
#  define REF_COUNT_ALLOCATIONS 1
#endif

#if REF_COUNT_ALLOCATIONS

// GCC на такой подмене выдаёт ложный -Wmismatched-new-delete: он видит free()
// внутри operator delete и считает это несовпадением с встроенным new.
// Это ровно тот случай, для которого подмена и предусмотрена стандартом.
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wmismatched-new-delete"

void* operator new(std::size_t bytes)
{
    g_allocations.fetch_add(1, std::memory_order_relaxed);

    void* memory = std::malloc(bytes != 0 ? bytes : 1);
    if (memory == nullptr)
        throw std::bad_alloc();

    return memory;
}

void operator delete(void* memory) noexcept        { std::free(memory); }
void operator delete(void* memory, std::size_t) noexcept { std::free(memory); }

#pragma GCC diagnostic pop

#endif // REF_COUNT_ALLOCATIONS

TEST_F(SharedPtrRef, CountsOwners)
{
    ref::SharedPtr<Probe> a(new Probe(42));
    EXPECT_EQ(a.use_count(), 1);
    EXPECT_EQ(Probe::alive, 1);

    {
        ref::SharedPtr<Probe> b = a;
        EXPECT_EQ(a.use_count(), 2);
        EXPECT_EQ(b->value, 42);
    }

    EXPECT_EQ(a.use_count(), 1);
    EXPECT_EQ(Probe::alive, 1);
}

TEST_F(SharedPtrRef, EmptyPtrHasZeroOwners)
{
    ref::SharedPtr<Probe> empty;

    EXPECT_EQ(empty.use_count(), 0);
    EXPECT_FALSE(static_cast<bool>(empty));
    EXPECT_EQ(empty.get(), nullptr);
}

TEST_F(SharedPtrRef, MoveLeavesSourceEmpty)
{
    ref::SharedPtr<Probe> a(new Probe(1));
    ref::SharedPtr<Probe> b = std::move(a);

    EXPECT_EQ(a.get(), nullptr);
    EXPECT_EQ(a.use_count(), 0);
    EXPECT_EQ(b.use_count(), 1);
}

TEST_F(SharedPtrRef, CopyAssignmentReleasesOldResource)
{
    ref::SharedPtr<Probe> a(new Probe(1));
    ref::SharedPtr<Probe> b(new Probe(2));
    EXPECT_EQ(Probe::alive, 2);

    a = b;   // объект №1 обязан умереть ровно здесь

    EXPECT_EQ(Probe::alive, 1);
    EXPECT_EQ(a->value, 2);
    EXPECT_EQ(a.use_count(), 2);
}

TEST_F(SharedPtrRef, SelfAssignmentIsSafe)
{
    ref::SharedPtr<Probe> a(new Probe(5));
    const ref::SharedPtr<Probe>& alias = a;

    a = alias;

    EXPECT_EQ(a.use_count(), 1);
    EXPECT_EQ(a->value, 5);
    EXPECT_EQ(Probe::alive, 1);
}

TEST_F(SharedPtrRef, SelfMoveKeepsObjectAlive)
{
    ref::SharedPtr<Probe> a(new Probe(5));
    ref::SharedPtr<Probe>& alias = a;

    a = std::move(alias);

    EXPECT_EQ(Probe::alive, 1);
    EXPECT_EQ(a->value, 5);
}

TEST_F(SharedPtrRef, ResetReleasesOnlyOneReference)
{
    ref::SharedPtr<Probe> a(new Probe(1));
    ref::SharedPtr<Probe> b = a;

    a.reset();

    EXPECT_EQ(a.use_count(), 0);
    EXPECT_EQ(b.use_count(), 1);
    EXPECT_EQ(Probe::alive, 1) << "reset у одного владельца не должен убивать объект";

    b.reset();
    EXPECT_EQ(Probe::alive, 0);
}

TEST_F(SharedPtrRef, CustomDeleterRunsInsteadOfDelete)
{
    int deleted = 0;
    auto* raw = new Probe(3);

    {
        ref::SharedPtr<Probe> p(raw, [&deleted](Probe* ptr) { ++deleted; delete ptr; });
        EXPECT_EQ(p.use_count(), 1);
    }

    EXPECT_EQ(deleted, 1);
    EXPECT_EQ(Probe::alive, 0);
}

TEST_F(SharedPtrRef, DeleterDoesNotChangeSize)
{
    // Удалитель стёрт в блок управления, поэтому размер самого указателя не растёт.
    EXPECT_EQ(sizeof(ref::SharedPtr<Probe>), 2 * sizeof(void*));
}

TEST_F(SharedPtrRef, DeletesRealTypeWithoutVirtualDestructor)
{
    Base::destroyed_as_base = 0;
    Derived::destroyed_as_derived = 0;

    {
        ref::SharedPtr<Base> p(new Derived());
        EXPECT_EQ(p->tag, 1);
    }

    // Блок запомнил Derived в момент конструирования — деструктор вызвался верный,
    // хотя у Base деструктор невиртуальный. С unique_ptr тут было бы UB.
    EXPECT_EQ(Derived::destroyed_as_derived, 1);
    EXPECT_EQ(Base::destroyed_as_base, 1);
}

TEST_F(SharedPtrRef, MakeSharedDoesOneAllocation)
{
#if !REF_COUNT_ALLOCATIONS
    GTEST_SKIP() << "счёт аллокаций отключён под санитайзером";
#else
    const int before_new = g_allocations.load();
    {
        ref::SharedPtr<Probe> p(new Probe(1));
    }
    const int new_cost = g_allocations.load() - before_new;

    const int before_make = g_allocations.load();
    {
        ref::SharedPtr<Probe> p = ref::make_shared<Probe>(1);
    }
    const int make_cost = g_allocations.load() - before_make;

    EXPECT_EQ(new_cost, 2) << "объект + блок управления";
    EXPECT_EQ(make_cost, 1) << "объект лежит внутри блока";
#endif
}

TEST_F(SharedPtrRef, WeakPtrDoesNotKeepObjectAlive)
{
    ref::WeakPtr<Probe> weak;

    {
        ref::SharedPtr<Probe> strong = ref::make_shared<Probe>(9);
        weak = strong;

        EXPECT_FALSE(weak.expired());
        EXPECT_EQ(weak.use_count(), 1) << "weak не увеличивает счётчик владельцев";

        ref::SharedPtr<Probe> locked = weak.lock();
        ASSERT_TRUE(static_cast<bool>(locked));
        EXPECT_EQ(locked->value, 9);
        EXPECT_EQ(weak.use_count(), 2);
    }

    EXPECT_TRUE(weak.expired());
    EXPECT_FALSE(static_cast<bool>(weak.lock()));
    EXPECT_EQ(Probe::alive, 0);
}

TEST_F(SharedPtrRef, WeakPtrBreaksCycle)
{
    Node::alive = 0;

    {
        auto first  = ref::make_shared<Node>();
        auto second = ref::make_shared<Node>();

        first->next  = second;
        second->prev = first;

        EXPECT_EQ(Node::alive, 2);
        EXPECT_EQ(first.use_count(), 1) << "prev не должен добавлять владельца";
    }

    EXPECT_EQ(Node::alive, 0) << "цикл не разорвался — утечка";
}

TEST_F(SharedPtrRef, ConstructingFromExpiredWeakThrows)
{
    ref::WeakPtr<Probe> weak;

    {
        ref::SharedPtr<Probe> strong = ref::make_shared<Probe>(1);
        weak = strong;
    }

    EXPECT_THROW(ref::SharedPtr<Probe>{weak}, std::bad_weak_ptr);
}

TEST_F(SharedPtrRef, AliasingPointsAtMemberAndKeepsOwnerAlive)
{
    ref::SharedPtr<int> field;

    {
        auto owner = ref::make_shared<Aggregate>();
        field = ref::SharedPtr<int>(owner, &owner->second);

        EXPECT_EQ(owner.use_count(), 2) << "владение общее";
    }

    EXPECT_EQ(*field, 20) << "агрегат обязан жить, пока жив вид на его поле";
}

TEST_F(SharedPtrRef, EnableSharedFromThisReusesSameControlBlock)
{
    auto session = ref::make_shared<Session>();

    ref::SharedPtr<Session> again = session->self();

    EXPECT_EQ(session.use_count(), 2) << "второй блок управления — двойное удаление";
    EXPECT_EQ(again.get(), session.get());
    EXPECT_EQ(again->id, 7);
}

TEST_F(SharedPtrRef, PointerCastsShareOwnership)
{
    struct PolyBase        { virtual ~PolyBase() = default; };
    struct PolyDerived : PolyBase { int value = 5; };

    ref::SharedPtr<PolyBase> base = ref::make_shared<PolyDerived>();

    auto derived = ref::dynamic_pointer_cast<PolyDerived>(base);
    ASSERT_TRUE(static_cast<bool>(derived));
    EXPECT_EQ(derived->value, 5);
    EXPECT_EQ(base.use_count(), 2) << "приведение не создаёт нового владельца";
}

TEST_F(SharedPtrRef, RefCountSurvivesConcurrentCopies)
{
    constexpr int kThreads = 8;
    constexpr int kIters   = 20000;

    auto shared = ref::make_shared<Probe>(1);

    std::vector<std::thread> workers;
    for (int i = 0; i < kThreads; ++i)
        workers.emplace_back([&shared] {
            for (int k = 0; k < kIters; ++k)
            {
                ref::SharedPtr<Probe> copy = shared;   // чтение общего SharedPtr — можно
                EXPECT_EQ(copy->value, 1);
            }
        });

    for (auto& t : workers) t.join();

    EXPECT_EQ(shared.use_count(), 1) << "счётчик потерял обновления — он не атомарный";
    EXPECT_EQ(Probe::alive, 1);
}

TEST_F(SharedPtrRef, LastOwnerAmongThreadsDestroysExactlyOnce)
{
    constexpr int kThreads = 8;

    Probe::alive = 0;

    {
        auto shared = ref::make_shared<Probe>(1);

        std::vector<std::thread> workers;
        for (int i = 0; i < kThreads; ++i)
            workers.emplace_back([copy = shared]() mutable { copy.reset(); });

        shared.reset();
        for (auto& t : workers) t.join();
    }

    EXPECT_EQ(Probe::alive, 0);
}
