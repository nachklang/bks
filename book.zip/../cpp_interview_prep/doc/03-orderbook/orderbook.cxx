#include <unordered_map>
#include <map>
#include <vector>
#include <cstdint>
#include <list>

enum class Side
{
    BUY,
    SELL    
};

using ID = std::uint64_t;
using Price = std::uint64_t; 

struct Order
{
    ID id;
    Side side;
    Price price;
};

using Orders = std::list<Order>;
using OrdersIt = Orders::iterator;
using BookIt = std::map<Price, std::list<Order>>::iterator;

struct Pos {
    OrdersIt it;
    Orders& orders;
};

class OrderBook
{
public:
    bool add(const Order& order)
    {
        if(auto it = tracking.find(order.id); it != tracking.end())
        {
            return false;
        }

        switch(order.side)
        {
            case Side::BUY:
            {
                auto& pos = bids[order.price];
                pos.emplace_back(order);
                tracking.emplace(order.id, Pos{std::prev(pos.end()), pos});
            }
            break;
            case Side::SELL:
            {
                auto& pos = asks[order.price];
                pos.emplace_back(order);
                tracking.emplace(order.id, Pos{std::prev(pos.end()), pos});
            }
            break;
            default:
            break;
        }
    }

    bool cancel(Order& order)
    {
        auto it = tracking.find(order.id);

        if(it == tracking.end())
        {
            return false;
        }
        
        std::map<Price, std::list<Order>>* book{nullptr};

        auto [listIt, orders] = it->second;

        auto price = listIt->price;
        auto side = listIt->side;

        if(side == Side::BUY)
        {
            book = &bids;
        }
        else{
            book = &asks;
        }
    }

    std::uint64_t spread()
    {

    }

private:
   std::map<Price, std::list<Order>, std::greater<Price>> bids; // Buys
   std::map<Price, std::list<Order>, std::less<Price>> asks; // Sell
   std::unordered_map<ID, Pos> tracking;
};